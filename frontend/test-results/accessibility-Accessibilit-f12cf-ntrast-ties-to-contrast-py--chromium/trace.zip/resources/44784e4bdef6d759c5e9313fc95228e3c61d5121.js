import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/WorkspacePage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { cmsApi } from "/src/features/cms/cmsApi.js";
import { StructureTree } from "/src/features/cms/StructureTree.jsx";
import { ContentTab } from "/src/features/cms/ContentTab.jsx?t=1790183660675";
import { AssessmentsTab } from "/src/features/cms/AssessmentsTab.jsx";
import { SettingsTab } from "/src/features/cms/SettingsTab.jsx";
import { AiImportModal } from "/src/features/cms/AiImportModal.jsx?t=1790183660675";
import "/src/features/cms/cms.css";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/WorkspacePage.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const TABS = [
	"Structure",
	"Content",
	"Assessments",
	"Settings"
];
const structureActions = {
	createModule: (courseId, title) => cmsApi.createModule(courseId, title),
	renameModule: (id, title) => cmsApi.renameModule(id, title),
	deleteModule: (id) => cmsApi.deleteModule(id),
	reorderModules: (courseId, ids) => cmsApi.reorderModules(courseId, ids),
	createChapter: (moduleId, title) => cmsApi.createChapter(moduleId, title),
	renameChapter: (id, title) => cmsApi.renameChapter(id, title),
	deleteChapter: (id) => cmsApi.deleteChapter(id),
	reorderChapters: (moduleId, ids) => cmsApi.reorderChapters(moduleId, ids),
	createPage: (chapterId, title) => cmsApi.createPage(chapterId, title),
	renamePage: (id, title) => cmsApi.renamePage(id, title),
	deletePage: (id) => cmsApi.deletePage(id),
	reorderPages: (chapterId, ids) => cmsApi.reorderPages(chapterId, ids)
};
/**
* WorkspacePage (11-content-workspace-cms) — one route per course, tabbed
* (Structure / Content / Assessments / Settings), per 11's own resolved
* open question. Route: /cms/:slug (see App.jsx — not wired here, see the
* workspace report for the exact <Route> to add).
*/
export function WorkspacePage() {
	_s();
	const { slug } = useParams();
	const [course, setCourse] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [tab, setTab] = useState("Structure");
	const [selectedPage, setSelectedPage] = useState(null);
	const [assessmentTarget, setAssessmentTarget] = useState(null);
	const [aiModal, setAiModal] = useState(null);
	const load = useCallback(() => {
		setLoading(true);
		cmsApi.getCourse(slug).then((c) => {
			setCourse(c);
			setError(null);
		}).catch((err) => setError(err.message)).finally(() => setLoading(false));
	}, [slug]);
	useEffect(load, [load]);
	if (loading && !course) return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-workspace cms-loading",
		children: "Loading workspace…"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 34
	}, this);
	if (error) return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-workspace cms-error",
		children: error
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 21
	}, this);
	if (!course) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-workspace",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "cms-workspace-header",
				children: [/* @__PURE__ */ _jsxDEV("h1", { children: course.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "cms-hint",
					children: "Content workspace"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: "cms-tabs",
				children: TABS.map((t) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: `cms-tab${tab === t ? " cms-tab-active" : ""}`,
					onClick: () => setTab(t),
					children: t
				}, t, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					exit: { opacity: 0 },
					transition: { duration: .15 },
					className: "cms-tab-panel",
					children: [
						tab === "Structure" && /* @__PURE__ */ _jsxDEV(StructureTree, {
							course,
							actions: structureActions,
							onChange: load,
							onSelectPage: (page) => {
								setSelectedPage(page);
								setTab("Content");
							},
							selectedPageId: selectedPage?.id,
							onGenerateWithAi: setAiModal
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 13
						}, this),
						tab === "Content" && /* @__PURE__ */ _jsxDEV(ContentTab, {
							page: selectedPage,
							onGenerateWithAi: setAiModal
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 13
						}, this),
						tab === "Assessments" && /* @__PURE__ */ _jsxDEV("div", {
							className: "cms-assessments-wrap",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "cms-module-picker",
								children: /* @__PURE__ */ _jsxDEV("label", { children: ["Bank:", /* @__PURE__ */ _jsxDEV("select", {
									value: assessmentTarget ? JSON.stringify(assessmentTarget) : "",
									onChange: (e) => setAssessmentTarget(e.target.value ? JSON.parse(e.target.value) : null),
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "",
											children: "Choose…"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 119,
											columnNumber: 21
										}, this),
										(course.modules || []).map((m) => /* @__PURE__ */ _jsxDEV("option", {
											value: JSON.stringify({
												kind: "module",
												id: m.id
											}),
											children: m.title
										}, m.id, false, {
											fileName: _jsxFileName,
											lineNumber: 121,
											columnNumber: 23
										}, this)),
										/* @__PURE__ */ _jsxDEV("option", {
											value: JSON.stringify({ kind: "final-exam" }),
											children: "Final exam"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 125,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(AssessmentsTab, {
								target: assessmentTarget,
								courseId: course.id,
								onGenerateWithAi: setAiModal
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 13
						}, this),
						tab === "Settings" && /* @__PURE__ */ _jsxDEV(SettingsTab, { course }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 34
						}, this)
					]
				}, tab, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AiImportModal, {
				open: !!aiModal,
				onClose: () => setAiModal(null),
				courseId: course.id,
				scope: aiModal?.scope,
				targetIds: {
					moduleId: aiModal?.moduleId,
					chapterId: aiModal?.chapterId,
					pageId: aiModal?.pageId
				},
				onCommitted: load
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 137,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_s(WorkspacePage, "yksm/TjiVvn72pD1MbXgVtSp+M4=", false, function() {
	return [useParams];
});
_c = WorkspacePage;
var _c;
$RefreshReg$(_c, "WorkspacePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/WorkspacePage.jsx?t=1790183660675";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/WorkspacePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/WorkspacePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/WorkspacePage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFVBQVUsbUJBQW1CO0FBQ2pELFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsaUJBQWlCLGNBQWM7QUFDeEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMscUJBQXFCO0FBQzlCLE9BQU87Ozs7QUFFUCxNQUFNLE9BQU87Q0FBQztDQUFhO0NBQVc7Q0FBZTtBQUFVO0FBRS9ELE1BQU0sbUJBQW1CO0NBQ3ZCLGVBQWUsVUFBVSxVQUFVLE9BQU8sYUFBYSxVQUFVLEtBQUs7Q0FDdEUsZUFBZSxJQUFJLFVBQVUsT0FBTyxhQUFhLElBQUksS0FBSztDQUMxRCxlQUFlLE9BQU8sT0FBTyxhQUFhLEVBQUU7Q0FDNUMsaUJBQWlCLFVBQVUsUUFBUSxPQUFPLGVBQWUsVUFBVSxHQUFHO0NBQ3RFLGdCQUFnQixVQUFVLFVBQVUsT0FBTyxjQUFjLFVBQVUsS0FBSztDQUN4RSxnQkFBZ0IsSUFBSSxVQUFVLE9BQU8sY0FBYyxJQUFJLEtBQUs7Q0FDNUQsZ0JBQWdCLE9BQU8sT0FBTyxjQUFjLEVBQUU7Q0FDOUMsa0JBQWtCLFVBQVUsUUFBUSxPQUFPLGdCQUFnQixVQUFVLEdBQUc7Q0FDeEUsYUFBYSxXQUFXLFVBQVUsT0FBTyxXQUFXLFdBQVcsS0FBSztDQUNwRSxhQUFhLElBQUksVUFBVSxPQUFPLFdBQVcsSUFBSSxLQUFLO0NBQ3RELGFBQWEsT0FBTyxPQUFPLFdBQVcsRUFBRTtDQUN4QyxlQUFlLFdBQVcsUUFBUSxPQUFPLGFBQWEsV0FBVyxHQUFHO0FBQ3RFOzs7Ozs7O0FBUUEsT0FBTyxTQUFTLGdCQUFnQjs7Q0FDOUIsTUFBTSxFQUFFLFNBQVMsVUFBVTtDQUMzQixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsSUFBSTtDQUN6QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTtDQUN2QyxNQUFNLENBQUMsS0FBSyxVQUFVLFNBQVMsV0FBVztDQUMxQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxJQUFJO0NBQ3JELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsSUFBSTtDQUM3RCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUUzQyxNQUFNLE9BQU8sa0JBQWtCO0VBQzdCLFdBQVcsSUFBSTtFQUNmLE9BQ0csVUFBVSxJQUFJLENBQUMsQ0FDZixNQUFNLE1BQU07R0FDWCxVQUFVLENBQUM7R0FDWCxTQUFTLElBQUk7RUFDZixDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQVEsU0FBUyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQ3JDLGNBQWMsV0FBVyxLQUFLLENBQUM7Q0FDcEMsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULFVBQVUsTUFBTSxDQUFDLElBQUksQ0FBQztDQUV0QixJQUFJLFdBQVcsQ0FBQyxRQUFRLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBNEI7Q0FBdUI7Ozs7O0NBQ2pHLElBQUksT0FBTyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQTJCO0NBQVc7Ozs7O0NBQ3ZFLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxNQUFELFlBQUssT0FBTyxNQUFVOzs7O2NBQ3RCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVc7SUFBb0I7Ozs7WUFDdEM7Ozs7OztHQUVSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osS0FBSyxLQUFLLE1BQ1Qsd0JBQUMsVUFBRDtLQUVFLE1BQUs7S0FDTCxXQUFXLFVBQVUsUUFBUSxJQUFJLG9CQUFvQjtLQUNyRCxlQUFlLE9BQU8sQ0FBQztlQUV0QjtJQUNLLEdBTkQ7Ozs7V0FNQyxDQUNUO0dBQ0U7Ozs7O0dBRUwsd0JBQUMsaUJBQUQ7SUFBaUIsTUFBSztjQUNwQix3QkFBQyxPQUFPLEtBQVI7S0FFRSxTQUFTLEVBQUUsU0FBUyxFQUFFO0tBQ3RCLFNBQVMsRUFBRSxTQUFTLEVBQUU7S0FDdEIsTUFBTSxFQUFFLFNBQVMsRUFBRTtLQUNuQixZQUFZLEVBQUUsVUFBVSxJQUFLO0tBQzdCLFdBQVU7ZUFOWjtNQVFHLFFBQVEsZUFDUCx3QkFBQyxlQUFEO09BQ1U7T0FDUixTQUFTO09BQ1QsVUFBVTtPQUNWLGVBQWUsU0FBUztRQUN0QixnQkFBZ0IsSUFBSTtRQUNwQixPQUFPLFNBQVM7T0FDbEI7T0FDQSxnQkFBZ0IsY0FBYztPQUM5QixrQkFBa0I7TUFDbkI7Ozs7O01BR0YsUUFBUSxhQUNQLHdCQUFDLFlBQUQ7T0FBWSxNQUFNO09BQWMsa0JBQWtCO01BQWE7Ozs7O01BR2hFLFFBQVEsaUJBQ1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxTQUFELGFBQU8sU0FFTCx3QkFBQyxVQUFEO1NBQ0UsT0FBTyxtQkFBbUIsS0FBSyxVQUFVLGdCQUFnQixJQUFJO1NBQzdELFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLFFBQVEsS0FBSyxNQUFNLEVBQUUsT0FBTyxLQUFLLElBQUksSUFBSTttQkFGekY7VUFJRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBRztVQUFlOzs7OztXQUM5QixPQUFPLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUMzQix3QkFBQyxVQUFEO1dBQW1CLE9BQU8sS0FBSyxVQUFVO1lBQUUsTUFBTTtZQUFVLElBQUksRUFBRTtXQUFHLENBQUM7cUJBQ2xFLEVBQUU7VUFDRyxHQUZLLEVBQUU7Ozs7aUJBRVAsQ0FDVDtVQUNELHdCQUFDLFVBQUQ7V0FBUSxPQUFPLEtBQUssVUFBVSxFQUFFLE1BQU0sYUFBYSxDQUFDO3FCQUFHO1VBQWtCOzs7OztTQUNuRTs7Ozs7Z0JBQ0g7Ozs7O09BQ0o7Ozs7aUJBQ0wsd0JBQUMsZ0JBQUQ7UUFBZ0IsUUFBUTtRQUFrQixVQUFVLE9BQU87UUFBSSxrQkFBa0I7T0FBYTs7OztlQUMzRjs7Ozs7O01BR04sUUFBUSxjQUFjLHdCQUFDLGFBQUQsRUFBcUIsT0FBUzs7Ozs7S0FDM0M7T0FqREw7Ozs7V0FpREs7R0FDRzs7Ozs7R0FFakIsd0JBQUMsZUFBRDtJQUNFLE1BQU0sQ0FBQyxDQUFDO0lBQ1IsZUFBZSxXQUFXLElBQUk7SUFDOUIsVUFBVSxPQUFPO0lBQ2pCLE9BQU8sU0FBUztJQUNoQixXQUFXO0tBQUUsVUFBVSxTQUFTO0tBQVUsV0FBVyxTQUFTO0tBQVcsUUFBUSxTQUFTO0lBQU87SUFDakcsYUFBYTtHQUNkOzs7OztFQUNFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJXb3Jrc3BhY2VQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcbmltcG9ydCB7IEFuaW1hdGVQcmVzZW5jZSwgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0J1xuaW1wb3J0IHsgY21zQXBpIH0gZnJvbSAnLi4vZmVhdHVyZXMvY21zL2Ntc0FwaSdcbmltcG9ydCB7IFN0cnVjdHVyZVRyZWUgfSBmcm9tICcuLi9mZWF0dXJlcy9jbXMvU3RydWN0dXJlVHJlZSdcbmltcG9ydCB7IENvbnRlbnRUYWIgfSBmcm9tICcuLi9mZWF0dXJlcy9jbXMvQ29udGVudFRhYidcbmltcG9ydCB7IEFzc2Vzc21lbnRzVGFiIH0gZnJvbSAnLi4vZmVhdHVyZXMvY21zL0Fzc2Vzc21lbnRzVGFiJ1xuaW1wb3J0IHsgU2V0dGluZ3NUYWIgfSBmcm9tICcuLi9mZWF0dXJlcy9jbXMvU2V0dGluZ3NUYWInXG5pbXBvcnQgeyBBaUltcG9ydE1vZGFsIH0gZnJvbSAnLi4vZmVhdHVyZXMvY21zL0FpSW1wb3J0TW9kYWwnXG5pbXBvcnQgJy4uL2ZlYXR1cmVzL2Ntcy9jbXMuY3NzJ1xuXG5jb25zdCBUQUJTID0gWydTdHJ1Y3R1cmUnLCAnQ29udGVudCcsICdBc3Nlc3NtZW50cycsICdTZXR0aW5ncyddXG5cbmNvbnN0IHN0cnVjdHVyZUFjdGlvbnMgPSB7XG4gIGNyZWF0ZU1vZHVsZTogKGNvdXJzZUlkLCB0aXRsZSkgPT4gY21zQXBpLmNyZWF0ZU1vZHVsZShjb3Vyc2VJZCwgdGl0bGUpLFxuICByZW5hbWVNb2R1bGU6IChpZCwgdGl0bGUpID0+IGNtc0FwaS5yZW5hbWVNb2R1bGUoaWQsIHRpdGxlKSxcbiAgZGVsZXRlTW9kdWxlOiAoaWQpID0+IGNtc0FwaS5kZWxldGVNb2R1bGUoaWQpLFxuICByZW9yZGVyTW9kdWxlczogKGNvdXJzZUlkLCBpZHMpID0+IGNtc0FwaS5yZW9yZGVyTW9kdWxlcyhjb3Vyc2VJZCwgaWRzKSxcbiAgY3JlYXRlQ2hhcHRlcjogKG1vZHVsZUlkLCB0aXRsZSkgPT4gY21zQXBpLmNyZWF0ZUNoYXB0ZXIobW9kdWxlSWQsIHRpdGxlKSxcbiAgcmVuYW1lQ2hhcHRlcjogKGlkLCB0aXRsZSkgPT4gY21zQXBpLnJlbmFtZUNoYXB0ZXIoaWQsIHRpdGxlKSxcbiAgZGVsZXRlQ2hhcHRlcjogKGlkKSA9PiBjbXNBcGkuZGVsZXRlQ2hhcHRlcihpZCksXG4gIHJlb3JkZXJDaGFwdGVyczogKG1vZHVsZUlkLCBpZHMpID0+IGNtc0FwaS5yZW9yZGVyQ2hhcHRlcnMobW9kdWxlSWQsIGlkcyksXG4gIGNyZWF0ZVBhZ2U6IChjaGFwdGVySWQsIHRpdGxlKSA9PiBjbXNBcGkuY3JlYXRlUGFnZShjaGFwdGVySWQsIHRpdGxlKSxcbiAgcmVuYW1lUGFnZTogKGlkLCB0aXRsZSkgPT4gY21zQXBpLnJlbmFtZVBhZ2UoaWQsIHRpdGxlKSxcbiAgZGVsZXRlUGFnZTogKGlkKSA9PiBjbXNBcGkuZGVsZXRlUGFnZShpZCksXG4gIHJlb3JkZXJQYWdlczogKGNoYXB0ZXJJZCwgaWRzKSA9PiBjbXNBcGkucmVvcmRlclBhZ2VzKGNoYXB0ZXJJZCwgaWRzKSxcbn1cblxuLyoqXG4gKiBXb3Jrc3BhY2VQYWdlICgxMS1jb250ZW50LXdvcmtzcGFjZS1jbXMpIOKAlCBvbmUgcm91dGUgcGVyIGNvdXJzZSwgdGFiYmVkXG4gKiAoU3RydWN0dXJlIC8gQ29udGVudCAvIEFzc2Vzc21lbnRzIC8gU2V0dGluZ3MpLCBwZXIgMTEncyBvd24gcmVzb2x2ZWRcbiAqIG9wZW4gcXVlc3Rpb24uIFJvdXRlOiAvY21zLzpzbHVnIChzZWUgQXBwLmpzeCDigJQgbm90IHdpcmVkIGhlcmUsIHNlZSB0aGVcbiAqIHdvcmtzcGFjZSByZXBvcnQgZm9yIHRoZSBleGFjdCA8Um91dGU+IHRvIGFkZCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBXb3Jrc3BhY2VQYWdlKCkge1xuICBjb25zdCB7IHNsdWcgfSA9IHVzZVBhcmFtcygpXG4gIGNvbnN0IFtjb3Vyc2UsIHNldENvdXJzZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFt0YWIsIHNldFRhYl0gPSB1c2VTdGF0ZSgnU3RydWN0dXJlJylcbiAgY29uc3QgW3NlbGVjdGVkUGFnZSwgc2V0U2VsZWN0ZWRQYWdlXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFthc3Nlc3NtZW50VGFyZ2V0LCBzZXRBc3Nlc3NtZW50VGFyZ2V0XSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFthaU1vZGFsLCBzZXRBaU1vZGFsXSA9IHVzZVN0YXRlKG51bGwpIC8vIHsgc2NvcGUsIG1vZHVsZUlkPywgY2hhcHRlcklkPyB9XG5cbiAgY29uc3QgbG9hZCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgY21zQXBpXG4gICAgICAuZ2V0Q291cnNlKHNsdWcpXG4gICAgICAudGhlbigoYykgPT4ge1xuICAgICAgICBzZXRDb3Vyc2UoYylcbiAgICAgICAgc2V0RXJyb3IobnVsbClcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycikgPT4gc2V0RXJyb3IoZXJyLm1lc3NhZ2UpKVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH0sIFtzbHVnXSlcblxuICB1c2VFZmZlY3QobG9hZCwgW2xvYWRdKVxuXG4gIGlmIChsb2FkaW5nICYmICFjb3Vyc2UpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNtcy13b3Jrc3BhY2UgY21zLWxvYWRpbmdcIj5Mb2FkaW5nIHdvcmtzcGFjZeKApjwvZGl2PlxuICBpZiAoZXJyb3IpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNtcy13b3Jrc3BhY2UgY21zLWVycm9yXCI+e2Vycm9yfTwvZGl2PlxuICBpZiAoIWNvdXJzZSkgcmV0dXJuIG51bGxcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXdvcmtzcGFjZVwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJjbXMtd29ya3NwYWNlLWhlYWRlclwiPlxuICAgICAgICA8aDE+e2NvdXJzZS50aXRsZX08L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJjbXMtaGludFwiPkNvbnRlbnQgd29ya3NwYWNlPC9wPlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwiY21zLXRhYnNcIj5cbiAgICAgICAge1RBQlMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXt0fVxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BjbXMtdGFiJHt0YWIgPT09IHQgPyAnIGNtcy10YWItYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWIodCl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3R9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9uYXY+XG5cbiAgICAgIDxBbmltYXRlUHJlc2VuY2UgbW9kZT1cIndhaXRcIj5cbiAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICBrZXk9e3RhYn1cbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX1cbiAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjE1IH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwiY21zLXRhYi1wYW5lbFwiXG4gICAgICAgID5cbiAgICAgICAgICB7dGFiID09PSAnU3RydWN0dXJlJyAmJiAoXG4gICAgICAgICAgICA8U3RydWN0dXJlVHJlZVxuICAgICAgICAgICAgICBjb3Vyc2U9e2NvdXJzZX1cbiAgICAgICAgICAgICAgYWN0aW9ucz17c3RydWN0dXJlQWN0aW9uc31cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2xvYWR9XG4gICAgICAgICAgICAgIG9uU2VsZWN0UGFnZT17KHBhZ2UpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhZ2UocGFnZSlcbiAgICAgICAgICAgICAgICBzZXRUYWIoJ0NvbnRlbnQnKVxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBzZWxlY3RlZFBhZ2VJZD17c2VsZWN0ZWRQYWdlPy5pZH1cbiAgICAgICAgICAgICAgb25HZW5lcmF0ZVdpdGhBaT17c2V0QWlNb2RhbH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHt0YWIgPT09ICdDb250ZW50JyAmJiAoXG4gICAgICAgICAgICA8Q29udGVudFRhYiBwYWdlPXtzZWxlY3RlZFBhZ2V9IG9uR2VuZXJhdGVXaXRoQWk9e3NldEFpTW9kYWx9IC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHt0YWIgPT09ICdBc3Nlc3NtZW50cycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtYXNzZXNzbWVudHMtd3JhcFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy1tb2R1bGUtcGlja2VyXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgICAgICAgQmFuazpcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Fzc2Vzc21lbnRUYXJnZXQgPyBKU09OLnN0cmluZ2lmeShhc3Nlc3NtZW50VGFyZ2V0KSA6ICcnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFzc2Vzc21lbnRUYXJnZXQoZS50YXJnZXQudmFsdWUgPyBKU09OLnBhcnNlKGUudGFyZ2V0LnZhbHVlKSA6IG51bGwpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+Q2hvb3Nl4oCmPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIHsoY291cnNlLm1vZHVsZXMgfHwgW10pLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXttLmlkfSB2YWx1ZT17SlNPTi5zdHJpbmdpZnkoeyBraW5kOiAnbW9kdWxlJywgaWQ6IG0uaWQgfSl9PlxuICAgICAgICAgICAgICAgICAgICAgICAge20udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXtKU09OLnN0cmluZ2lmeSh7IGtpbmQ6ICdmaW5hbC1leGFtJyB9KX0+RmluYWwgZXhhbTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxBc3Nlc3NtZW50c1RhYiB0YXJnZXQ9e2Fzc2Vzc21lbnRUYXJnZXR9IGNvdXJzZUlkPXtjb3Vyc2UuaWR9IG9uR2VuZXJhdGVXaXRoQWk9e3NldEFpTW9kYWx9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3RhYiA9PT0gJ1NldHRpbmdzJyAmJiA8U2V0dGluZ3NUYWIgY291cnNlPXtjb3Vyc2V9IC8+fVxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cblxuICAgICAgPEFpSW1wb3J0TW9kYWxcbiAgICAgICAgb3Blbj17ISFhaU1vZGFsfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBaU1vZGFsKG51bGwpfVxuICAgICAgICBjb3Vyc2VJZD17Y291cnNlLmlkfVxuICAgICAgICBzY29wZT17YWlNb2RhbD8uc2NvcGV9XG4gICAgICAgIHRhcmdldElkcz17eyBtb2R1bGVJZDogYWlNb2RhbD8ubW9kdWxlSWQsIGNoYXB0ZXJJZDogYWlNb2RhbD8uY2hhcHRlcklkLCBwYWdlSWQ6IGFpTW9kYWw/LnBhZ2VJZCB9fVxuICAgICAgICBvbkNvbW1pdHRlZD17bG9hZH1cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==