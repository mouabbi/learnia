import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RouteLogger.jsx");const useEffect = __vite__cjsImport0_react["useEffect"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { createLogger } from "/src/utils/logger.js";
var _s = $RefreshSig$();
const log = createLogger("route");
/** Renders nothing; logs every page change ("navigated to /login"). Place inside <BrowserRouter>. */
export function RouteLogger() {
	_s();
	const { pathname } = useLocation();
	useEffect(() => {
		log.info(`navigated to ${pathname}`);
	}, [pathname]);
	return null;
}
_s(RouteLogger, "glIs83H2MXbU6fcNhYK7n0QqbD4=", false, function() {
	return [useLocation];
});
_c = RouteLogger;
var _c;
$RefreshReg$(_c, "RouteLogger");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/RouteLogger.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/RouteLogger.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/RouteLogger.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/RouteLogger.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxvQkFBb0I7O0FBRTdCLE1BQU0sTUFBTSxhQUFhLE9BQU87O0FBR2hDLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLEVBQUUsYUFBYSxZQUFZO0NBRWpDLGdCQUFnQjtFQUNkLElBQUksS0FBSyxnQkFBZ0IsVUFBVTtDQUNyQyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBRWIsT0FBTztBQUNUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJvdXRlTG9nZ2VyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBjcmVhdGVMb2dnZXIgfSBmcm9tICcuLi91dGlscy9sb2dnZXInXHJcblxyXG5jb25zdCBsb2cgPSBjcmVhdGVMb2dnZXIoJ3JvdXRlJylcclxuXHJcbi8qKiBSZW5kZXJzIG5vdGhpbmc7IGxvZ3MgZXZlcnkgcGFnZSBjaGFuZ2UgKFwibmF2aWdhdGVkIHRvIC9sb2dpblwiKS4gUGxhY2UgaW5zaWRlIDxCcm93c2VyUm91dGVyPi4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIFJvdXRlTG9nZ2VyKCkge1xyXG4gIGNvbnN0IHsgcGF0aG5hbWUgfSA9IHVzZUxvY2F0aW9uKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxvZy5pbmZvKGBuYXZpZ2F0ZWQgdG8gJHtwYXRobmFtZX1gKVxyXG4gIH0sIFtwYXRobmFtZV0pXHJcblxyXG4gIHJldHVybiBudWxsXHJcbn1cclxuIl19