import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MfaChallengePage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Navigate, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { ApiError } from "/src/api/client.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/MfaChallengePage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Reached only from LoginPage, right after a correct password on an
// account with MFA enabled — see LoginPage's navigate('/mfa-challenge', ...)
// and AuthContext.completeMfaLogin(). The ticket lives in route state, not
// the URL, so refreshing this page loses it (by design: start over at /login).
export function MfaChallengePage() {
	_s();
	const { completeMfaLogin } = useAuth();
	const location = useLocation();
	const navigate = useNavigate();
	const mfaTicket = location.state?.mfaTicket;
	const [code, setCode] = useState("");
	const [error, setError] = useState(null);
	const [isSubmitting, setIsSubmitting] = useState(false);
	if (!mfaTicket) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 12
		}, this);
	}
	async function handleSubmit(event) {
		event.preventDefault();
		setError(null);
		setIsSubmitting(true);
		try {
			await completeMfaLogin(mfaTicket, code);
			navigate("/");
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "page",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Two-factor verification" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "code",
						children: "Authenticator code"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "code",
						type: "text",
						inputMode: "numeric",
						autoComplete: "one-time-code",
						value: code,
						onChange: (e) => setCode(e.target.value),
						required: true,
						autoFocus: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hint",
						children: "Enter the 6-digit code from your authenticator app, or one of your recovery codes."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "error",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					children: isSubmitting ? "Verifying..." : "Verify"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(MfaChallengePage, "7XSk7xm8JL4wvEOwTReUhddmOdw=", false, function() {
	return [
		useAuth,
		useLocation,
		useNavigate
	];
});
_c = MfaChallengePage;
var _c;
$RefreshReg$(_c, "MfaChallengePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/MfaChallengePage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/MfaChallengePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/MfaChallengePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/MfaChallengePage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxVQUFVLGFBQWEsbUJBQW1CO0FBQ25ELFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7Ozs7Ozs7QUFNekIsT0FBTyxTQUFTLG1CQUFtQjs7Q0FDakMsTUFBTSxFQUFFLHFCQUFxQixRQUFRO0NBQ3JDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sWUFBWSxTQUFTLE9BQU87Q0FDbEMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxJQUFJLENBQUMsV0FBVztFQUNkLE9BQU8sd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUztFQUFTOzs7OztDQUN4QztDQUVBLGVBQWUsYUFBYSxPQUFPO0VBQ2pDLE1BQU0sZUFBZTtFQUNyQixTQUFTLElBQUk7RUFDYixnQkFBZ0IsSUFBSTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxpQkFBaUIsV0FBVyxJQUFJO0dBQ3RDLFNBQVMsR0FBRztFQUNkLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxXQUFXLElBQUksVUFBVSxzQkFBc0I7RUFDekUsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLDBCQUEyQjs7OztZQUMvQix3QkFBQyxRQUFEO0dBQU0sVUFBVTthQUFoQjtJQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBTztLQUF5Qjs7Ozs7S0FDL0Msd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsV0FBVTtNQUNWLGNBQWE7TUFDYixPQUFPO01BQ1AsV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7TUFDdkM7TUFDQTtLQUNEOzs7OztLQUNELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFPO0tBRWpCOzs7OztJQUNBOzs7OztJQUNKLFNBQ0Msd0JBQUMsS0FBRDtLQUFHLE1BQUs7S0FBUSxXQUFVO2VBQ3ZCO0lBQ0E7Ozs7O0lBRUwsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVO2VBQzdCLGVBQWUsaUJBQWlCO0lBQzNCOzs7OztHQUNKOzs7OztVQUNDOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNZmFDaGFsbGVuZ2VQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vYXBpL2NsaWVudCdcclxuXHJcbi8vIFJlYWNoZWQgb25seSBmcm9tIExvZ2luUGFnZSwgcmlnaHQgYWZ0ZXIgYSBjb3JyZWN0IHBhc3N3b3JkIG9uIGFuXHJcbi8vIGFjY291bnQgd2l0aCBNRkEgZW5hYmxlZCDigJQgc2VlIExvZ2luUGFnZSdzIG5hdmlnYXRlKCcvbWZhLWNoYWxsZW5nZScsIC4uLilcclxuLy8gYW5kIEF1dGhDb250ZXh0LmNvbXBsZXRlTWZhTG9naW4oKS4gVGhlIHRpY2tldCBsaXZlcyBpbiByb3V0ZSBzdGF0ZSwgbm90XHJcbi8vIHRoZSBVUkwsIHNvIHJlZnJlc2hpbmcgdGhpcyBwYWdlIGxvc2VzIGl0IChieSBkZXNpZ246IHN0YXJ0IG92ZXIgYXQgL2xvZ2luKS5cclxuZXhwb3J0IGZ1bmN0aW9uIE1mYUNoYWxsZW5nZVBhZ2UoKSB7XHJcbiAgY29uc3QgeyBjb21wbGV0ZU1mYUxvZ2luIH0gPSB1c2VBdXRoKClcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCBtZmFUaWNrZXQgPSBsb2NhdGlvbi5zdGF0ZT8ubWZhVGlja2V0XHJcbiAgY29uc3QgW2NvZGUsIHNldENvZGVdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgaWYgKCFtZmFUaWNrZXQpIHtcclxuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+XHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZXZlbnQpIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIHNldEVycm9yKG51bGwpXHJcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSlcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGNvbXBsZXRlTWZhTG9naW4obWZhVGlja2V0LCBjb2RlKVxyXG4gICAgICBuYXZpZ2F0ZSgnLycpXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICA8aDE+VHdvLWZhY3RvciB2ZXJpZmljYXRpb248L2gxPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb2RlXCI+QXV0aGVudGljYXRvciBjb2RlPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBpZD1cImNvZGVcIlxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJvbmUtdGltZS1jb2RlXCJcclxuICAgICAgICAgICAgdmFsdWU9e2NvZGV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29kZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnRcIj5cclxuICAgICAgICAgICAgRW50ZXIgdGhlIDYtZGlnaXQgY29kZSBmcm9tIHlvdXIgYXV0aGVudGljYXRvciBhcHAsIG9yIG9uZSBvZiB5b3VyIHJlY292ZXJ5IGNvZGVzLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJlcnJvclwiPlxyXG4gICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfT5cclxuICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAnVmVyaWZ5aW5nLi4uJyA6ICdWZXJpZnknfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==