import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/settings/AccentColorPicker.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Check } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { useAccentColor } from "/src/hooks/useAccentColor.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/settings/AccentColorPicker.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Curated rebrand options — each reads well as both the light-mode solid
// button color and the dark-mode accent (see useAccentColor/applyAccent,
// which derives --accent-hover/--accent-text from whichever of these, or
// a custom pick, is active).
const PRESET_COLORS = [
	{
		name: "Indigo",
		hex: "#4f46e5"
	},
	{
		name: "Violet",
		hex: "#7c3aed"
	},
	{
		name: "Blue",
		hex: "#2563eb"
	},
	{
		name: "Teal",
		hex: "#0d9488"
	},
	{
		name: "Emerald",
		hex: "#059669"
	},
	{
		name: "Amber",
		hex: "#d97706"
	},
	{
		name: "Rose",
		hex: "#e11d48"
	},
	{
		name: "Slate",
		hex: "#475569"
	}
];
// Lets the user rebrand the app: pick one of a few curated presets, or
// fall back to the native color-wheel for a fully custom pick. Both paths
// go through the same useAccentColor hook, which derives a hover shade
// and readable foreground text color for whatever's chosen, so every
// option — preset or custom — stays legible in both light and dark mode.
export function AccentColorPicker() {
	_s();
	const { accent, setAccentColor, resetAccent, isDefault } = useAccentColor();
	const normalizedAccent = accent.toLowerCase();
	const activePreset = PRESET_COLORS.find((preset) => preset.hex === normalizedAccent);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "accent-picker",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "accent-swatches",
			role: "group",
			"aria-label": "Preset accent colors",
			children: [PRESET_COLORS.map((preset) => {
				const isActive = preset.hex === normalizedAccent;
				return /* @__PURE__ */ _jsxDEV(motion.button, {
					type: "button",
					className: `accent-swatch${isActive ? " accent-swatch-active" : ""}`,
					style: { background: preset.hex },
					onClick: () => setAccentColor(preset.hex),
					"aria-label": preset.name,
					"aria-pressed": isActive,
					title: preset.name,
					whileTap: { scale: .9 },
					children: isActive && /* @__PURE__ */ _jsxDEV(Check, {
						size: 16,
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 28
					}, this)
				}, preset.hex, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this);
			}), /* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "accent-color",
				className: `accent-swatch accent-swatch-custom${!activePreset ? " accent-swatch-active" : ""}`,
				title: "Custom color",
				children: [/* @__PURE__ */ _jsxDEV("input", {
					id: "accent-color",
					type: "color",
					className: "accent-swatch-input",
					value: accent,
					onChange: (event) => setAccentColor(event.target.value),
					"aria-label": "Custom accent color"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this), !activePreset && /* @__PURE__ */ _jsxDEV(Check, {
					size: 16,
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 29
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "accent-picker-footer",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "accent-picker-value",
				children: activePreset ? activePreset.name : accent
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this), !isDefault && /* @__PURE__ */ _jsxDEV(motion.button, {
				type: "button",
				className: "accent-picker-reset",
				onClick: resetAccent,
				whileTap: { scale: .95 },
				children: "Reset to default"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s(AccentColorPicker, "tIVYUu/jYJLqwSheTW9AKcK9v/8=", false, function() {
	return [useAccentColor];
});
_c = AccentColorPicker;
var _c;
$RefreshReg$(_c, "AccentColorPicker");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/settings/AccentColorPicker.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/settings/AccentColorPicker.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/settings/AccentColorPicker.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/settings/AccentColorPicker.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsY0FBYztBQUN2QixTQUFTLHNCQUFzQjs7Ozs7Ozs7QUFNL0IsTUFBTSxnQkFBZ0I7Q0FDcEI7RUFBRSxNQUFNO0VBQVUsS0FBSztDQUFVO0NBQ2pDO0VBQUUsTUFBTTtFQUFVLEtBQUs7Q0FBVTtDQUNqQztFQUFFLE1BQU07RUFBUSxLQUFLO0NBQVU7Q0FDL0I7RUFBRSxNQUFNO0VBQVEsS0FBSztDQUFVO0NBQy9CO0VBQUUsTUFBTTtFQUFXLEtBQUs7Q0FBVTtDQUNsQztFQUFFLE1BQU07RUFBUyxLQUFLO0NBQVU7Q0FDaEM7RUFBRSxNQUFNO0VBQVEsS0FBSztDQUFVO0NBQy9CO0VBQUUsTUFBTTtFQUFTLEtBQUs7Q0FBVTtBQUNsQzs7Ozs7O0FBT0EsT0FBTyxTQUFTLG9CQUFvQjs7Q0FDbEMsTUFBTSxFQUFFLFFBQVEsZ0JBQWdCLGFBQWEsY0FBYyxlQUFlO0NBQzFFLE1BQU0sbUJBQW1CLE9BQU8sWUFBWTtDQUM1QyxNQUFNLGVBQWUsY0FBYyxNQUFNLFdBQVcsT0FBTyxRQUFRLGdCQUFnQjtDQUVuRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTtHQUFrQixNQUFLO0dBQVEsY0FBVzthQUF6RCxDQUNHLGNBQWMsS0FBSyxXQUFXO0lBQzdCLE1BQU0sV0FBVyxPQUFPLFFBQVE7SUFDaEMsT0FDRSx3QkFBQyxPQUFPLFFBQVI7S0FFRSxNQUFLO0tBQ0wsV0FBVyxnQkFBZ0IsV0FBVywwQkFBMEI7S0FDaEUsT0FBTyxFQUFFLFlBQVksT0FBTyxJQUFJO0tBQ2hDLGVBQWUsZUFBZSxPQUFPLEdBQUc7S0FDeEMsY0FBWSxPQUFPO0tBQ25CLGdCQUFjO0tBQ2QsT0FBTyxPQUFPO0tBQ2QsVUFBVSxFQUFFLE9BQU8sR0FBSTtlQUV0QixZQUFZLHdCQUFDLE9BQUQ7TUFBTyxNQUFNO01BQUksZUFBWTtLQUFROzs7OztJQUNyQyxHQVhSLE9BQU87Ozs7V0FXQztHQUVuQixDQUFDLEdBRUQsd0JBQUMsU0FBRDtJQUNFLFNBQVE7SUFDUixXQUFXLHFDQUFxQyxDQUFDLGVBQWUsMEJBQTBCO0lBQzFGLE9BQU07Y0FIUixDQUtFLHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLFdBQVU7S0FDVixPQUFPO0tBQ1AsV0FBVyxVQUFVLGVBQWUsTUFBTSxPQUFPLEtBQUs7S0FDdEQsY0FBVztJQUNaOzs7O2NBQ0EsQ0FBQyxnQkFBZ0Isd0JBQUMsT0FBRDtLQUFPLE1BQU07S0FBSSxlQUFZO0lBQVE7Ozs7WUFDbEQ7Ozs7O1dBQ0o7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQXVCLGVBQWUsYUFBYSxPQUFPO0dBQWE7Ozs7YUFFdEYsQ0FBQyxhQUNBLHdCQUFDLE9BQU8sUUFBUjtJQUNFLE1BQUs7SUFDTCxXQUFVO0lBQ1YsU0FBUztJQUNULFVBQVUsRUFBRSxPQUFPLElBQUs7Y0FDekI7R0FFYzs7OztXQUVkOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBY2NlbnRDb2xvclBpY2tlci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2hlY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ21vdGlvbi9yZWFjdCdcclxuaW1wb3J0IHsgdXNlQWNjZW50Q29sb3IgfSBmcm9tICcuLi8uLi9ob29rcy91c2VBY2NlbnRDb2xvcidcclxuXHJcbi8vIEN1cmF0ZWQgcmVicmFuZCBvcHRpb25zIOKAlCBlYWNoIHJlYWRzIHdlbGwgYXMgYm90aCB0aGUgbGlnaHQtbW9kZSBzb2xpZFxyXG4vLyBidXR0b24gY29sb3IgYW5kIHRoZSBkYXJrLW1vZGUgYWNjZW50IChzZWUgdXNlQWNjZW50Q29sb3IvYXBwbHlBY2NlbnQsXHJcbi8vIHdoaWNoIGRlcml2ZXMgLS1hY2NlbnQtaG92ZXIvLS1hY2NlbnQtdGV4dCBmcm9tIHdoaWNoZXZlciBvZiB0aGVzZSwgb3JcclxuLy8gYSBjdXN0b20gcGljaywgaXMgYWN0aXZlKS5cclxuY29uc3QgUFJFU0VUX0NPTE9SUyA9IFtcclxuICB7IG5hbWU6ICdJbmRpZ28nLCBoZXg6ICcjNGY0NmU1JyB9LFxyXG4gIHsgbmFtZTogJ1Zpb2xldCcsIGhleDogJyM3YzNhZWQnIH0sXHJcbiAgeyBuYW1lOiAnQmx1ZScsIGhleDogJyMyNTYzZWInIH0sXHJcbiAgeyBuYW1lOiAnVGVhbCcsIGhleDogJyMwZDk0ODgnIH0sXHJcbiAgeyBuYW1lOiAnRW1lcmFsZCcsIGhleDogJyMwNTk2NjknIH0sXHJcbiAgeyBuYW1lOiAnQW1iZXInLCBoZXg6ICcjZDk3NzA2JyB9LFxyXG4gIHsgbmFtZTogJ1Jvc2UnLCBoZXg6ICcjZTExZDQ4JyB9LFxyXG4gIHsgbmFtZTogJ1NsYXRlJywgaGV4OiAnIzQ3NTU2OScgfSxcclxuXVxyXG5cclxuLy8gTGV0cyB0aGUgdXNlciByZWJyYW5kIHRoZSBhcHA6IHBpY2sgb25lIG9mIGEgZmV3IGN1cmF0ZWQgcHJlc2V0cywgb3JcclxuLy8gZmFsbCBiYWNrIHRvIHRoZSBuYXRpdmUgY29sb3Itd2hlZWwgZm9yIGEgZnVsbHkgY3VzdG9tIHBpY2suIEJvdGggcGF0aHNcclxuLy8gZ28gdGhyb3VnaCB0aGUgc2FtZSB1c2VBY2NlbnRDb2xvciBob29rLCB3aGljaCBkZXJpdmVzIGEgaG92ZXIgc2hhZGVcclxuLy8gYW5kIHJlYWRhYmxlIGZvcmVncm91bmQgdGV4dCBjb2xvciBmb3Igd2hhdGV2ZXIncyBjaG9zZW4sIHNvIGV2ZXJ5XHJcbi8vIG9wdGlvbiDigJQgcHJlc2V0IG9yIGN1c3RvbSDigJQgc3RheXMgbGVnaWJsZSBpbiBib3RoIGxpZ2h0IGFuZCBkYXJrIG1vZGUuXHJcbmV4cG9ydCBmdW5jdGlvbiBBY2NlbnRDb2xvclBpY2tlcigpIHtcclxuICBjb25zdCB7IGFjY2VudCwgc2V0QWNjZW50Q29sb3IsIHJlc2V0QWNjZW50LCBpc0RlZmF1bHQgfSA9IHVzZUFjY2VudENvbG9yKClcclxuICBjb25zdCBub3JtYWxpemVkQWNjZW50ID0gYWNjZW50LnRvTG93ZXJDYXNlKClcclxuICBjb25zdCBhY3RpdmVQcmVzZXQgPSBQUkVTRVRfQ09MT1JTLmZpbmQoKHByZXNldCkgPT4gcHJlc2V0LmhleCA9PT0gbm9ybWFsaXplZEFjY2VudClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNjZW50LXBpY2tlclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY2VudC1zd2F0Y2hlc1wiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJQcmVzZXQgYWNjZW50IGNvbG9yc1wiPlxyXG4gICAgICAgIHtQUkVTRVRfQ09MT1JTLm1hcCgocHJlc2V0KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IHByZXNldC5oZXggPT09IG5vcm1hbGl6ZWRBY2NlbnRcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxtb3Rpb24uYnV0dG9uXHJcbiAgICAgICAgICAgICAga2V5PXtwcmVzZXQuaGV4fVxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFjY2VudC1zd2F0Y2gke2lzQWN0aXZlID8gJyBhY2NlbnQtc3dhdGNoLWFjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6IHByZXNldC5oZXggfX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY2NlbnRDb2xvcihwcmVzZXQuaGV4KX1cclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtwcmVzZXQubmFtZX1cclxuICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2lzQWN0aXZlfVxyXG4gICAgICAgICAgICAgIHRpdGxlPXtwcmVzZXQubmFtZX1cclxuICAgICAgICAgICAgICB3aGlsZVRhcD17eyBzY2FsZTogMC45IH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXNBY3RpdmUgJiYgPENoZWNrIHNpemU9ezE2fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPn1cclxuICAgICAgICAgICAgPC9tb3Rpb24uYnV0dG9uPlxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH0pfVxyXG5cclxuICAgICAgICA8bGFiZWxcclxuICAgICAgICAgIGh0bWxGb3I9XCJhY2NlbnQtY29sb3JcIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgYWNjZW50LXN3YXRjaCBhY2NlbnQtc3dhdGNoLWN1c3RvbSR7IWFjdGl2ZVByZXNldCA/ICcgYWNjZW50LXN3YXRjaC1hY3RpdmUnIDogJyd9YH1cclxuICAgICAgICAgIHRpdGxlPVwiQ3VzdG9tIGNvbG9yXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJhY2NlbnQtY29sb3JcIlxyXG4gICAgICAgICAgICB0eXBlPVwiY29sb3JcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhY2NlbnQtc3dhdGNoLWlucHV0XCJcclxuICAgICAgICAgICAgdmFsdWU9e2FjY2VudH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0QWNjZW50Q29sb3IoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkN1c3RvbSBhY2NlbnQgY29sb3JcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIHshYWN0aXZlUHJlc2V0ICYmIDxDaGVjayBzaXplPXsxNn0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY2VudC1waWNrZXItZm9vdGVyXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWNjZW50LXBpY2tlci12YWx1ZVwiPnthY3RpdmVQcmVzZXQgPyBhY3RpdmVQcmVzZXQubmFtZSA6IGFjY2VudH08L3NwYW4+XHJcblxyXG4gICAgICAgIHshaXNEZWZhdWx0ICYmIChcclxuICAgICAgICAgIDxtb3Rpb24uYnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhY2NlbnQtcGlja2VyLXJlc2V0XCJcclxuICAgICAgICAgICAgb25DbGljaz17cmVzZXRBY2NlbnR9XHJcbiAgICAgICAgICAgIHdoaWxlVGFwPXt7IHNjYWxlOiAwLjk1IH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFJlc2V0IHRvIGRlZmF1bHRcclxuICAgICAgICAgIDwvbW90aW9uLmJ1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXX0=