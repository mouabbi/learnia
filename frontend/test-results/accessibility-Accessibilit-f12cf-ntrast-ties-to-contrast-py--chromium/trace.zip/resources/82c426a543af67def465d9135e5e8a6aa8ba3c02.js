import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AppLayout.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Menu, Sun, Moon, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { Link, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { Sidebar } from "/src/components/layout/Sidebar.jsx";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { useTheme } from "/src/hooks/useTheme.js";
import { useLearnerXp } from "/src/features/courses/useLearnerXp.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppLayout.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Shell for every authenticated page (see App.jsx): a topbar with a menu
// button, the slide-in Sidebar it controls, and the routed page content.
// Only mounted inside <ProtectedRoute>, so `user` is always set here.
// At desktop widths (see .app-shell-desktop in index.css) the sidebar is
// also rendered pinned in a permanent left column; the off-canvas drawer
// keeps working underneath for mobile/tablet widths.
export function AppLayout() {
	_s();
	const { user, logout } = useAuth();
	const [isSidebarOpen, setSidebarOpen] = useState(false);
	const [isDesktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
	const { theme, toggleTheme } = useTheme();
	const learnerXp = useLearnerXp();
	const isDark = theme === "dark" || theme === "system" && typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;
	async function handleLogout() {
		setSidebarOpen(false);
		await logout();
	}
	// One trigger, two behaviors: below the desktop breakpoint it opens the
	// off-canvas drawer; at/above it, it collapses/expands the pinned column
	// instead (see .app-shell-collapsed in index.css).
	function toggleSidebar() {
		if (typeof window !== "undefined" && window.matchMedia?.("(min-width: 1024px)").matches) {
			setDesktopSidebarOpen((open) => !open);
		} else {
			setSidebarOpen(true);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `app-shell ${isDesktopSidebarOpen ? "" : "app-shell-collapsed"}`,
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "topbar",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "menu-button",
						"aria-label": isDesktopSidebarOpen ? "Close menu" : "Open menu",
						"aria-expanded": isSidebarOpen || isDesktopSidebarOpen,
						onClick: toggleSidebar,
						children: /* @__PURE__ */ _jsxDEV(Menu, {
							"aria-hidden": "true",
							size: 20
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "topbar-title",
						children: "Learnia"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { className: "topbar-spacer" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 9
					}, this),
					learnerXp && /* @__PURE__ */ _jsxDEV("span", {
						className: "topbar-xp",
						title: `${learnerXp.xp} XP total`,
						children: [
							/* @__PURE__ */ _jsxDEV(Sparkles, {
								size: 14,
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 13
							}, this),
							"Level ",
							learnerXp.level
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "menu-button theme-toggle",
						"aria-label": isDark ? "Switch to light mode" : "Switch to dark mode",
						onClick: toggleTheme,
						children: isDark ? /* @__PURE__ */ _jsxDEV(Sun, {
							"aria-hidden": "true",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 21
						}, this) : /* @__PURE__ */ _jsxDEV(Moon, {
							"aria-hidden": "true",
							size: 18
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 60
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "sidebar-pinned",
				children: /* @__PURE__ */ _jsxDEV(Sidebar, {
					email: user.email,
					isOpen: true,
					pinned: true,
					collapsed: !isDesktopSidebarOpen,
					onToggleCollapse: () => setDesktopSidebarOpen((open) => !open),
					onLogout: handleLogout
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Sidebar, {
				email: user.email,
				isOpen: isSidebarOpen,
				onClose: () => setSidebarOpen(false),
				onLogout: handleLogout
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "app-content",
				children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
}
_s(AppLayout, "zSKP1zCuUBJjjOG95sdQenvcHi0=", false, function() {
	return [
		useAuth,
		useTheme,
		useLearnerXp
	];
});
_c = AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/AppLayout.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppLayout.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppLayout.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFDMUMsU0FBUyxNQUFNLGNBQWM7QUFDN0IsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG9CQUFvQjs7Ozs7Ozs7OztBQVE3QixPQUFPLFNBQVMsWUFBWTs7Q0FDMUIsTUFBTSxFQUFFLE1BQU0sV0FBVyxRQUFRO0NBQ2pDLE1BQU0sQ0FBQyxlQUFlLGtCQUFrQixTQUFTLEtBQUs7Q0FDdEQsTUFBTSxDQUFDLHNCQUFzQix5QkFBeUIsU0FBUyxJQUFJO0NBQ25FLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixTQUFTO0NBQ3hDLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sU0FDSixVQUFVLFVBQ1QsVUFBVSxZQUNULE9BQU8sV0FBVyxlQUNsQixPQUFPLGFBQWEsOEJBQThCLENBQUMsQ0FBQztDQUV4RCxlQUFlLGVBQWU7RUFDNUIsZUFBZSxLQUFLO0VBQ3BCLE1BQU0sT0FBTztDQUNmOzs7O0NBS0EsU0FBUyxnQkFBZ0I7RUFDdkIsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQWEscUJBQXFCLENBQUMsQ0FBQyxTQUFTO0dBQ3ZGLHVCQUF1QixTQUFTLENBQUMsSUFBSTtFQUN2QyxPQUFPO0dBQ0wsZUFBZSxJQUFJO0VBQ3JCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLGFBQWEsdUJBQXVCLEtBQUs7WUFBekQ7R0FDRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtNQUNWLGNBQVksdUJBQXVCLGVBQWU7TUFDbEQsaUJBQWUsaUJBQWlCO01BQ2hDLFNBQVM7Z0JBRVQsd0JBQUMsTUFBRDtPQUFNLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7O0tBQzlCOzs7OztLQUNSLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQUksV0FBVTtnQkFBZTtLQUVoQzs7Ozs7S0FFTix3QkFBQyxPQUFELEVBQUssV0FBVSxnQkFBaUI7Ozs7O0tBRS9CLGFBQ0Msd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBWSxPQUFPLEdBQUcsVUFBVSxHQUFHO2dCQUFuRDtPQUNFLHdCQUFDLFVBQUQ7UUFBVSxNQUFNO1FBQUksZUFBWTtPQUFROzs7OztPQUFDO09BQ2xDLFVBQVU7TUFDYjs7Ozs7O0tBR1Isd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsY0FBWSxTQUFTLHlCQUF5QjtNQUM5QyxTQUFTO2dCQUVSLFNBQVMsd0JBQUMsS0FBRDtPQUFLLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7aUJBQUksd0JBQUMsTUFBRDtPQUFNLGVBQVk7T0FBTyxNQUFNO01BQUs7Ozs7O0tBQy9FOzs7OztJQUNGOzs7Ozs7R0FNUix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFNBQUQ7S0FDRSxPQUFPLEtBQUs7S0FDWjtLQUNBO0tBQ0EsV0FBVyxDQUFDO0tBQ1osd0JBQXdCLHVCQUF1QixTQUFTLENBQUMsSUFBSTtLQUM3RCxVQUFVO0lBQ1g7Ozs7O0dBQ0U7Ozs7O0dBRUwsd0JBQUMsU0FBRDtJQUNFLE9BQU8sS0FBSztJQUNaLFFBQVE7SUFDUixlQUFlLGVBQWUsS0FBSztJQUNuQyxVQUFVO0dBQ1g7Ozs7O0dBRUQsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxRQUFELENBQVM7Ozs7O0dBQ0w7Ozs7O0VBQ0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcExheW91dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgTWVudSwgU3VuLCBNb29uLCBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgTGluaywgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgU2lkZWJhciB9IGZyb20gJy4vU2lkZWJhcidcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2ZlYXR1cmVzL2F1dGgvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlVGhlbWUnXHJcbmltcG9ydCB7IHVzZUxlYXJuZXJYcCB9IGZyb20gJy4uLy4uL2ZlYXR1cmVzL2NvdXJzZXMvdXNlTGVhcm5lclhwJ1xyXG5cclxuLy8gU2hlbGwgZm9yIGV2ZXJ5IGF1dGhlbnRpY2F0ZWQgcGFnZSAoc2VlIEFwcC5qc3gpOiBhIHRvcGJhciB3aXRoIGEgbWVudVxyXG4vLyBidXR0b24sIHRoZSBzbGlkZS1pbiBTaWRlYmFyIGl0IGNvbnRyb2xzLCBhbmQgdGhlIHJvdXRlZCBwYWdlIGNvbnRlbnQuXHJcbi8vIE9ubHkgbW91bnRlZCBpbnNpZGUgPFByb3RlY3RlZFJvdXRlPiwgc28gYHVzZXJgIGlzIGFsd2F5cyBzZXQgaGVyZS5cclxuLy8gQXQgZGVza3RvcCB3aWR0aHMgKHNlZSAuYXBwLXNoZWxsLWRlc2t0b3AgaW4gaW5kZXguY3NzKSB0aGUgc2lkZWJhciBpc1xyXG4vLyBhbHNvIHJlbmRlcmVkIHBpbm5lZCBpbiBhIHBlcm1hbmVudCBsZWZ0IGNvbHVtbjsgdGhlIG9mZi1jYW52YXMgZHJhd2VyXHJcbi8vIGtlZXBzIHdvcmtpbmcgdW5kZXJuZWF0aCBmb3IgbW9iaWxlL3RhYmxldCB3aWR0aHMuXHJcbmV4cG9ydCBmdW5jdGlvbiBBcHBMYXlvdXQoKSB7XHJcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQgfSA9IHVzZUF1dGgoKVxyXG4gIGNvbnN0IFtpc1NpZGViYXJPcGVuLCBzZXRTaWRlYmFyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbaXNEZXNrdG9wU2lkZWJhck9wZW4sIHNldERlc2t0b3BTaWRlYmFyT3Blbl0gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gIGNvbnN0IHsgdGhlbWUsIHRvZ2dsZVRoZW1lIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgbGVhcm5lclhwID0gdXNlTGVhcm5lclhwKClcclxuICBjb25zdCBpc0RhcmsgPVxyXG4gICAgdGhlbWUgPT09ICdkYXJrJyB8fFxyXG4gICAgKHRoZW1lID09PSAnc3lzdGVtJyAmJlxyXG4gICAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICB3aW5kb3cubWF0Y2hNZWRpYT8uKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspJykubWF0Y2hlcylcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlTG9nb3V0KCkge1xyXG4gICAgc2V0U2lkZWJhck9wZW4oZmFsc2UpXHJcbiAgICBhd2FpdCBsb2dvdXQoKVxyXG4gIH1cclxuXHJcbiAgLy8gT25lIHRyaWdnZXIsIHR3byBiZWhhdmlvcnM6IGJlbG93IHRoZSBkZXNrdG9wIGJyZWFrcG9pbnQgaXQgb3BlbnMgdGhlXHJcbiAgLy8gb2ZmLWNhbnZhcyBkcmF3ZXI7IGF0L2Fib3ZlIGl0LCBpdCBjb2xsYXBzZXMvZXhwYW5kcyB0aGUgcGlubmVkIGNvbHVtblxyXG4gIC8vIGluc3RlYWQgKHNlZSAuYXBwLXNoZWxsLWNvbGxhcHNlZCBpbiBpbmRleC5jc3MpLlxyXG4gIGZ1bmN0aW9uIHRvZ2dsZVNpZGViYXIoKSB7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93Lm1hdGNoTWVkaWE/LignKG1pbi13aWR0aDogMTAyNHB4KScpLm1hdGNoZXMpIHtcclxuICAgICAgc2V0RGVza3RvcFNpZGViYXJPcGVuKChvcGVuKSA9PiAhb3BlbilcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFNpZGViYXJPcGVuKHRydWUpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2BhcHAtc2hlbGwgJHtpc0Rlc2t0b3BTaWRlYmFyT3BlbiA/ICcnIDogJ2FwcC1zaGVsbC1jb2xsYXBzZWQnfWB9PlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInRvcGJhclwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWVudS1idXR0b25cIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17aXNEZXNrdG9wU2lkZWJhck9wZW4gPyAnQ2xvc2UgbWVudScgOiAnT3BlbiBtZW51J31cclxuICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzU2lkZWJhck9wZW4gfHwgaXNEZXNrdG9wU2lkZWJhck9wZW59XHJcbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVTaWRlYmFyfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxNZW51IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT1cInRvcGJhci10aXRsZVwiPlxyXG4gICAgICAgICAgTGVhcm5pYVxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b3BiYXItc3BhY2VyXCIgLz5cclxuXHJcbiAgICAgICAge2xlYXJuZXJYcCAmJiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0b3BiYXIteHBcIiB0aXRsZT17YCR7bGVhcm5lclhwLnhwfSBYUCB0b3RhbGB9PlxyXG4gICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTR9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICAgIExldmVsIHtsZWFybmVyWHAubGV2ZWx9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtZW51LWJ1dHRvbiB0aGVtZS10b2dnbGVcIlxyXG4gICAgICAgICAgYXJpYS1sYWJlbD17aXNEYXJrID8gJ1N3aXRjaCB0byBsaWdodCBtb2RlJyA6ICdTd2l0Y2ggdG8gZGFyayBtb2RlJ31cclxuICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtpc0RhcmsgPyA8U3VuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPiA6IDxNb29uIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPn1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICB7LyogUGlubmVkIGRlc2t0b3Agc2lkZWJhciDigJQgYSBzZWNvbmQgcmVuZGVyIG9mIHRoZSBzYW1lIGNvbXBvbmVudCwgbm9cclxuICAgICAgICAgIG92ZXJsYXkvY2xvc2UgYWZmb3JkYW5jZSwgY29sbGFwc2libGUgdmlhIHRoZSB0b3BiYXIgbWVudSBidXR0b25cclxuICAgICAgICAgIChzZWUgdG9nZ2xlU2lkZWJhcikgb3IgaXRzIG93biBpbi1zaWRlYmFyIHRvZ2dsZS4gSGlkZGVuIHZpYSBDU1NcclxuICAgICAgICAgIGJlbG93IHRoZSBkZXNrdG9wIGJyZWFrcG9pbnQsIHdoZXJlIHRoZSBkcmF3ZXIgaW5zdGFuY2UgdGFrZXMgb3Zlci4gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1waW5uZWRcIj5cclxuICAgICAgICA8U2lkZWJhclxyXG4gICAgICAgICAgZW1haWw9e3VzZXIuZW1haWx9XHJcbiAgICAgICAgICBpc09wZW5cclxuICAgICAgICAgIHBpbm5lZFxyXG4gICAgICAgICAgY29sbGFwc2VkPXshaXNEZXNrdG9wU2lkZWJhck9wZW59XHJcbiAgICAgICAgICBvblRvZ2dsZUNvbGxhcHNlPXsoKSA9PiBzZXREZXNrdG9wU2lkZWJhck9wZW4oKG9wZW4pID0+ICFvcGVuKX1cclxuICAgICAgICAgIG9uTG9nb3V0PXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8U2lkZWJhclxyXG4gICAgICAgIGVtYWlsPXt1c2VyLmVtYWlsfVxyXG4gICAgICAgIGlzT3Blbj17aXNTaWRlYmFyT3Blbn1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaWRlYmFyT3BlbihmYWxzZSl9XHJcbiAgICAgICAgb25Mb2dvdXQ9e2hhbmRsZUxvZ291dH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImFwcC1jb250ZW50XCI+XHJcbiAgICAgICAgPE91dGxldCAvPlxyXG4gICAgICA8L21haW4+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19