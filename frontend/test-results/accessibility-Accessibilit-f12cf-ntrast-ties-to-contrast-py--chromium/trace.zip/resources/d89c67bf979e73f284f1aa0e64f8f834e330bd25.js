import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/ProtectedRoute.jsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { createLogger } from "/src/utils/logger.js";
import { AppShellSkeleton } from "/src/components/layout/AppShellSkeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ProtectedRoute.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const log = createLogger("route");
/**
* Wrap any route element that requires a logged-in user:
*   <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
*/
export function ProtectedRoute({ children }) {
	_s();
	const { isAuthenticated, isLoading } = useAuth();
	// Logged from an effect (not the render body) so it prints once per decision,
	// not on every re-render.
	useEffect(() => {
		if (!isLoading && !isAuthenticated) log.info("ProtectedRoute: not logged in -> /login");
	}, [isLoading, isAuthenticated]);
	// Wait for the initial GET /auth/me to resolve before deciding — see
	// AuthContext's isLoading comment for why this check exists.
	if (isLoading) return /* @__PURE__ */ _jsxDEV(AppShellSkeleton, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 25
	}, this);
	if (!isAuthenticated) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/login",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 32
	}, this);
	return children;
}
_s(ProtectedRoute, "Welk9fbFNINSfytYxhp3k8pzvRM=", false, function() {
	return [useAuth];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/ProtectedRoute.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ProtectedRoute.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsd0JBQXdCOzs7O0FBRWpDLE1BQU0sTUFBTSxhQUFhLE9BQU87Ozs7O0FBTWhDLE9BQU8sU0FBUyxlQUFlLEVBQUUsWUFBWTs7Q0FDM0MsTUFBTSxFQUFFLGlCQUFpQixjQUFjLFFBQVE7OztDQUkvQyxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixJQUFJLEtBQUsseUNBQXlDO0NBQ3hGLEdBQUcsQ0FBQyxXQUFXLGVBQWUsQ0FBQzs7O0NBSS9CLElBQUksV0FBVyxPQUFPLHdCQUFDLGtCQUFELENBQW1COzs7OztDQUV6QyxJQUFJLENBQUMsaUJBQWlCLE9BQU8sd0JBQUMsVUFBRDtFQUFVLElBQUc7RUFBUztDQUFTOzs7OztDQUU1RCxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuL0F1dGhDb250ZXh0J1xyXG5pbXBvcnQgeyBjcmVhdGVMb2dnZXIgfSBmcm9tICcuLi8uLi91dGlscy9sb2dnZXInXHJcbmltcG9ydCB7IEFwcFNoZWxsU2tlbGV0b24gfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL2xheW91dC9BcHBTaGVsbFNrZWxldG9uJ1xyXG5cclxuY29uc3QgbG9nID0gY3JlYXRlTG9nZ2VyKCdyb3V0ZScpXHJcblxyXG4vKipcclxuICogV3JhcCBhbnkgcm91dGUgZWxlbWVudCB0aGF0IHJlcXVpcmVzIGEgbG9nZ2VkLWluIHVzZXI6XHJcbiAqICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PFByb3RlY3RlZFJvdXRlPjxIb21lUGFnZSAvPjwvUHJvdGVjdGVkUm91dGU+fSAvPlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIFByb3RlY3RlZFJvdXRlKHsgY2hpbGRyZW4gfSkge1xyXG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCBpc0xvYWRpbmcgfSA9IHVzZUF1dGgoKVxyXG5cclxuICAvLyBMb2dnZWQgZnJvbSBhbiBlZmZlY3QgKG5vdCB0aGUgcmVuZGVyIGJvZHkpIHNvIGl0IHByaW50cyBvbmNlIHBlciBkZWNpc2lvbixcclxuICAvLyBub3Qgb24gZXZlcnkgcmUtcmVuZGVyLlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWlzTG9hZGluZyAmJiAhaXNBdXRoZW50aWNhdGVkKSBsb2cuaW5mbygnUHJvdGVjdGVkUm91dGU6IG5vdCBsb2dnZWQgaW4gLT4gL2xvZ2luJylcclxuICB9LCBbaXNMb2FkaW5nLCBpc0F1dGhlbnRpY2F0ZWRdKVxyXG5cclxuICAvLyBXYWl0IGZvciB0aGUgaW5pdGlhbCBHRVQgL2F1dGgvbWUgdG8gcmVzb2x2ZSBiZWZvcmUgZGVjaWRpbmcg4oCUIHNlZVxyXG4gIC8vIEF1dGhDb250ZXh0J3MgaXNMb2FkaW5nIGNvbW1lbnQgZm9yIHdoeSB0aGlzIGNoZWNrIGV4aXN0cy5cclxuICBpZiAoaXNMb2FkaW5nKSByZXR1cm4gPEFwcFNoZWxsU2tlbGV0b24gLz5cclxuXHJcbiAgaWYgKCFpc0F1dGhlbnRpY2F0ZWQpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+XHJcblxyXG4gIHJldHVybiBjaGlsZHJlblxyXG59XHJcbiJdfQ==