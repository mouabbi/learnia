import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CourseReaderPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link, useParams, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { ArrowLeft, ArrowRight, CheckSquare, GraduationCap, PartyPopper, X } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { coursesApi } from "/src/features/courses/coursesApi.js";
import { Quiz } from "/src/features/courses/Quiz.jsx";
import { Skeleton } from "/src/components/Skeleton.jsx";
import { ReaderShell } from "/src/components/reader/ReaderShell.jsx";
import { markPageComplete, setLastPage } from "/src/features/courses/progressStore.js";
import { learningProgress, isModuleLocked as computeModuleLocked, isModuleComplete, isQuizPassed, isCourseComplete } from "/src/features/courses/progress.js";
import { shade, contrastText } from "/src/utils/color.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/CourseReaderPage.jsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
// Flattens Module > Chapter > Page into an ordered list with back-refs, so
// "next"/"end of module" can be computed by array position instead of
// re-walking the tree on every click.
function flattenPages(course) {
	const list = [];
	course.modules.forEach((courseModule, moduleIndex) => {
		courseModule.chapters.forEach((chapter) => {
			chapter.pages.forEach((coursePage) => {
				list.push({
					moduleIndex,
					module: courseModule,
					chapter,
					page: coursePage
				});
			});
		});
	});
	return list;
}
// Docs-style reader for a single course — opened in its own browser tab
// (see CourseCard/ContinueLearningCard), outside the main AppLayout shell.
// Route: /courses/:slug/learn (see App.jsx). Owns all progress state for
// the session and persists every change via progressStore.js.
export function CourseReaderPage() {
	_s();
	const { slug } = useParams();
	const [searchParams, setSearchParams] = useSearchParams();
	const [course, setCourse] = useState(null);
	const [completedPageIds, setCompletedPageIds] = useState(() => new Set());
	const [moduleQuizzes, setModuleQuizzes] = useState({});
	const [expandedModuleIds, setExpandedModuleIds] = useState(() => new Set());
	const [view, setView] = useState(null);
	// Last non-quiz page shown — kept so the quiz can render as a modal on
	// top of it instead of replacing the whole content pane.
	const [backdropPageId, setBackdropPageId] = useState(null);
	const [loadError, setLoadError] = useState(null);
	useEffect(() => {
		let cancelled = false;
		setCourse(null);
		setLoadError(null);
		coursesApi.getCourse(slug).then(async (data) => {
			if (cancelled) return;
			setCourse(data);
			const progress = await coursesApi.getProgress(data.id);
			if (cancelled) return;
			const completed = new Set(progress.completedPageIds);
			setCompletedPageIds(completed);
			setModuleQuizzes(progress.moduleQuizzes);
			const flat = flattenPages(data);
			const pageExists = (id) => flat.some((f) => f.page.id === id);
			const moduleLockedAt = (moduleIndex) => computeModuleLocked(data, moduleIndex, [...completed], progress.moduleQuizzes);
			const quizParam = searchParams.get("quiz");
			const pageParam = searchParams.get("page");
			let initialView = null;
			if (quizParam && data.modules.some((m) => m.id === quizParam)) {
				initialView = {
					kind: "quiz",
					moduleId: quizParam
				};
			} else if (pageParam && pageExists(pageParam)) {
				const entry = flat.find((f) => f.page.id === pageParam);
				if (!moduleLockedAt(entry.moduleIndex)) initialView = {
					kind: "page",
					pageId: pageParam
				};
			}
			if (!initialView && pageExists(progress.lastPageId)) {
				const entry = flat.find((f) => f.page.id === progress.lastPageId);
				if (!moduleLockedAt(entry.moduleIndex)) initialView = {
					kind: "page",
					pageId: progress.lastPageId
				};
			}
			if (!initialView) {
				const first = flat[0];
				initialView = first ? {
					kind: "page",
					pageId: first.page.id
				} : { kind: "done" };
			}
			setView(initialView);
			if (initialView.kind === "page") setBackdropPageId(initialView.pageId);
			const activeModuleIndex = flat.find((f) => initialView.kind === "page" && f.page.id === initialView.pageId || initialView.kind === "quiz" && f.module.id === initialView.moduleId)?.moduleIndex ?? 0;
			setExpandedModuleIds(new Set([data.modules[activeModuleIndex]?.id].filter(Boolean)));
		}).catch((error) => {
			if (cancelled) return;
			// Course doesn't exist, or the backend errored — surface a plain
			// error state instead of leaving the reader stuck on its skeleton
			// forever and throwing an unhandled rejection into the console.
			console.error(`Failed to load course "${slug}"`, error);
			setLoadError(error);
		});
		return () => {
			cancelled = true;
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [slug]);
	const flat = useMemo(() => course ? flattenPages(course) : [], [course]);
	if (loadError) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "reader-shell reader-load-error",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: "Couldn't load this course. It may not exist, or the server is unavailable." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: "/courses",
				children: "Back to courses"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 7
		}, this);
	}
	if (course === null || view === null) return /* @__PURE__ */ _jsxDEV(ReaderSkeleton, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 120,
		columnNumber: 48
	}, this);
	const learning = learningProgress(course, [...completedPageIds]);
	const allModulesDone = isCourseComplete(course, [...completedPageIds], moduleQuizzes);
	function moduleLocked(moduleIndex) {
		return computeModuleLocked(course, moduleIndex, [...completedPageIds], moduleQuizzes);
	}
	function modulePagesComplete(courseModule) {
		return isModuleComplete({
			...courseModule,
			quiz: null
		}, [...completedPageIds], moduleQuizzes);
	}
	function moduleQuizPassed(moduleId) {
		return isQuizPassed(moduleQuizzes[moduleId]);
	}
	function goToPage(pageId) {
		setView({
			kind: "page",
			pageId
		});
		setBackdropPageId(pageId);
		setSearchParams({ page: pageId }, { replace: true });
		// Fire-and-forget: local state above already reflects the move, this
		// just persists it — a failed request shouldn't block navigation.
		setLastPage(course.id, pageId).catch(() => {});
		const entry = flat.find((f) => f.page.id === pageId);
		if (entry) setExpandedModuleIds((prev) => new Set(prev).add(entry.module.id));
	}
	function closeQuizModal() {
		if (backdropPageId) goToPage(backdropPageId);
	}
	function goToQuiz(moduleId) {
		setView({
			kind: "quiz",
			moduleId
		});
		setSearchParams({ quiz: moduleId }, { replace: true });
	}
	function toggleModule(moduleId) {
		setExpandedModuleIds((prev) => {
			const next = new Set(prev);
			if (next.has(moduleId)) next.delete(moduleId);
			else next.add(moduleId);
			return next;
		});
	}
	function markComplete(pageId) {
		markPageComplete(course.id, pageId).catch(() => {});
		setCompletedPageIds((prev) => new Set(prev).add(pageId));
	}
	// "Next" advances through pages in reading order; at the end of a module
	// it routes into that module's QCM (if any and not yet passed) instead
	// of a page, and at the very end of the course it shows a completion
	// panel pointing at the final exam.
	function goNext(currentPageId) {
		markComplete(currentPageId);
		const index = flat.findIndex((f) => f.page.id === currentPageId);
		const current = flat[index];
		const next = flat[index + 1];
		const leavingModule = !next || next.moduleIndex !== current.moduleIndex;
		if (leavingModule && current.module.quiz && !isQuizPassed(moduleQuizzes[current.module.id])) {
			goToQuiz(current.module.id);
			return;
		}
		if (next) {
			goToPage(next.page.id);
			return;
		}
		setView({ kind: "done" });
	}
	// "Previous" just steps back in reading order — no quiz-gate to worry
	// about since anything earlier was already unlocked to get here.
	function goPrev(currentPageId) {
		const index = flat.findIndex((f) => f.page.id === currentPageId);
		const prev = flat[index - 1];
		if (prev) goToPage(prev.page.id);
	}
	function handleQuizAttempt(moduleId, attempt) {
		setModuleQuizzes((prev) => ({
			...prev,
			[moduleId]: { ...attempt }
		}));
	}
	function continueAfterQuiz(moduleId) {
		const moduleIndex = course.modules.findIndex((m) => m.id === moduleId);
		const nextModule = course.modules[moduleIndex + 1];
		if (nextModule) {
			const firstPage = flat.find((f) => f.moduleIndex === moduleIndex + 1);
			setExpandedModuleIds((prev) => new Set(prev).add(nextModule.id));
			if (firstPage) goToPage(firstPage.page.id);
		} else {
			setView({ kind: "done" });
		}
	}
	const accentStyle = course.color ? {
		"--course-accent": course.color,
		"--course-accent-hover": shade(course.color, -12),
		"--course-accent-text": contrastText(course.color)
	} : undefined;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "reader-theme",
		style: accentStyle,
		children: [
			/* @__PURE__ */ _jsxDEV(ReaderShell, {
				course,
				learningPct: learning.pct,
				expandedModuleIds,
				onToggleModule: toggleModule,
				isModuleLocked: moduleLocked,
				isPageComplete: (id) => completedPageIds.has(id),
				isModulePagesComplete: modulePagesComplete,
				isModuleQuizPassed: moduleQuizPassed,
				activeKind: view.kind,
				activePageId: view.kind === "page" ? view.pageId : null,
				activeModuleId: view.kind === "quiz" ? view.moduleId : null,
				onSelectPage: goToPage,
				onSelectQuiz: goToQuiz,
				allModulesDone,
				children: [
					view.kind === "page" && /* @__PURE__ */ _jsxDEV(PageView, {
						course,
						entry: flat.find((f) => f.page.id === view.pageId),
						pageNumber: flat.findIndex((f) => f.page.id === view.pageId) + 1,
						totalPages: flat.length,
						completed: completedPageIds.has(view.pageId),
						hasPrev: flat.findIndex((f) => f.page.id === view.pageId) > 0,
						onMarkComplete: () => markComplete(view.pageId),
						onNext: () => goNext(view.pageId),
						onPrev: () => goPrev(view.pageId)
					}, view.pageId, false, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 11
					}, this),
					view.kind === "quiz" && backdropPageId && /* @__PURE__ */ _jsxDEV(PageView, {
						course,
						entry: flat.find((f) => f.page.id === backdropPageId),
						pageNumber: flat.findIndex((f) => f.page.id === backdropPageId) + 1,
						totalPages: flat.length,
						completed: completedPageIds.has(backdropPageId),
						interactive: false
					}, backdropPageId, false, {
						fileName: _jsxFileName,
						lineNumber: 259,
						columnNumber: 11
					}, this),
					view.kind === "done" && backdropPageId && /* @__PURE__ */ _jsxDEV(PageView, {
						course,
						entry: flat.find((f) => f.page.id === backdropPageId),
						pageNumber: flat.findIndex((f) => f.page.id === backdropPageId) + 1,
						totalPages: flat.length,
						completed: completedPageIds.has(backdropPageId),
						interactive: false
					}, backdropPageId, false, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 227,
				columnNumber: 7
			}, this),
			view.kind === "quiz" && /* @__PURE__ */ _jsxDEV(QuizModal, {
				course,
				courseModule: course.modules.find((m) => m.id === view.moduleId),
				previousAttempt: moduleQuizzes[view.moduleId],
				onAttempt: (attempt) => handleQuizAttempt(view.moduleId, attempt),
				passed: isQuizPassed(moduleQuizzes[view.moduleId]),
				onContinue: () => continueAfterQuiz(view.moduleId),
				onClose: closeQuizModal
			}, view.moduleId, false, {
				fileName: _jsxFileName,
				lineNumber: 284,
				columnNumber: 9
			}, this),
			view.kind === "done" && /* @__PURE__ */ _jsxDEV(CourseDoneModal, {
				course,
				allModulesDone,
				onClose: closeQuizModal
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 297,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 226,
		columnNumber: 5
	}, this);
}
_s(CourseReaderPage, "Wo38soZDo1N2bRnYd+fr/lH2wg0=", false, function() {
	return [useParams, useSearchParams];
});
_c = CourseReaderPage;
function PageView({ entry, pageNumber, totalPages, completed, hasPrev, onMarkComplete, onNext, onPrev, interactive = true }) {
	if (!entry) return null;
	const { page: coursePage, chapter, module: courseModule } = entry;
	const pagePct = totalPages ? Math.round(pageNumber / totalPages * 100) : 0;
	return /* @__PURE__ */ _jsxDEV(motion.article, {
		className: "reader-page content-card",
		initial: {
			opacity: 0,
			y: 6
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: { duration: .2 },
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "reader-page-toolbar",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "reader-page-toolbar-top",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "reader-page-toolbar-position",
						children: [
							"Page ",
							pageNumber,
							" of ",
							totalPages
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 11
					}, this), interactive && /* @__PURE__ */ _jsxDEV("div", {
						className: "reader-page-toolbar-actions",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "reader-toolbar-button",
								disabled: !hasPrev,
								onClick: onPrev,
								children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 17
								}, this), " Previous"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 15
							}, this),
							!completed && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "reader-toolbar-button",
								onClick: onMarkComplete,
								children: [/* @__PURE__ */ _jsxDEV(CheckSquare, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 346,
									columnNumber: 19
								}, this), " Mark as read"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 345,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "reader-toolbar-button reader-toolbar-button-primary",
								onClick: onNext,
								children: [
									completed ? "Continue" : "Mark read & continue",
									" ",
									/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 15 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 67
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 330,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "reader-page-toolbar-track",
					children: /* @__PURE__ */ _jsxDEV(motion.div, {
						className: "reader-page-toolbar-fill",
						initial: false,
						animate: { width: `${pagePct}%` },
						transition: {
							duration: .3,
							ease: "easeOut"
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "reader-page-eyebrow",
				children: [
					courseModule.title,
					" · ",
					chapter.title
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 365,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: coursePage.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 368,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "reader-page-body",
				children: coursePage.content.split("\n\n").map((paragraph, i) => /* @__PURE__ */ _jsxDEV("p", { children: paragraph }, i, false, {
					fileName: _jsxFileName,
					lineNumber: 371,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 369,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 323,
		columnNumber: 5
	}, this);
}
_c2 = PageView;
function QuizModal({ course, courseModule, previousAttempt, onAttempt, passed, onContinue, onClose }) {
	if (!courseModule?.quiz) return null;
	return /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "quiz-modal-backdrop",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		onClick: onClose,
		children: /* @__PURE__ */ _jsxDEV(motion.div, {
			className: "quiz-modal content-card module-quiz-panel",
			initial: {
				opacity: 0,
				y: 16,
				scale: .97
			},
			animate: {
				opacity: 1,
				y: 0,
				scale: 1
			},
			exit: {
				opacity: 0,
				y: 16,
				scale: .97
			},
			transition: {
				duration: .2,
				ease: "easeOut"
			},
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "quiz-modal-close",
					"aria-label": "Close quiz",
					onClick: onClose,
					children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 398,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 397,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "reader-page-eyebrow",
					children: courseModule.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 400,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", { children: "Module QCM" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 401,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "reader-quiz-intro",
					children: "Pass this to unlock the next module."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 402,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(Quiz, {
					quiz: courseModule.quiz,
					courseId: course.id,
					moduleId: courseModule.id,
					previousAttempt,
					onAttempt
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 403,
					columnNumber: 11
				}, this),
				passed && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "reader-next-button",
					onClick: onContinue,
					children: ["Continue ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 412,
						columnNumber: 24
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 411,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 389,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 382,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 381,
		columnNumber: 5
	}, this);
}
_c3 = QuizModal;
// Big, kid-friendly "you did it!" celebration — pops up as a modal (same
// pattern as QuizModal) the moment every module + QCM in the course is
// done, with a bouncy badge and a confetti burst so finishing a course
// feels like an event, not just a status line changing.
const CHEER_LINES = [
	"You crushed it! 🎉",
	"Look at you go! 🚀",
	"Superstar move! 🌟",
	"Boom — nailed it! 💥",
	"You're on fire! 🔥"
];
function CourseDoneModal({ course, allModulesDone, onClose }) {
	_s2();
	const [cheer] = useState(() => CHEER_LINES[Math.floor(Math.random() * CHEER_LINES.length)]);
	return /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "quiz-modal-backdrop",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		onClick: onClose,
		children: /* @__PURE__ */ _jsxDEV(motion.div, {
			className: "quiz-modal content-card course-done-modal",
			initial: {
				opacity: 0,
				y: 24,
				scale: .9
			},
			animate: {
				opacity: 1,
				y: 0,
				scale: 1
			},
			exit: {
				opacity: 0,
				y: 16,
				scale: .95
			},
			transition: {
				type: "spring",
				stiffness: 260,
				damping: 18
			},
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "quiz-modal-close",
					"aria-label": "Close",
					onClick: onClose,
					children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 453,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 452,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(DoneConfetti, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 456,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(motion.div, {
					className: "course-done-badge",
					initial: {
						scale: 0,
						rotate: -15
					},
					animate: {
						scale: 1,
						rotate: 0
					},
					transition: {
						type: "spring",
						stiffness: 320,
						damping: 12,
						delay: .1
					},
					children: /* @__PURE__ */ _jsxDEV(PartyPopper, { size: 36 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 464,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 458,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(motion.h1, {
					className: "course-done-title",
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .2 },
					children: cheer
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 467,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(motion.p, {
					className: "course-done-caption",
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					transition: { delay: .3 },
					children: [
						"You finished every module and passed every quiz in ",
						/* @__PURE__ */ _jsxDEV("strong", { children: course.title }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 481,
							columnNumber: 64
						}, this),
						". That's real work — be proud of it!"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 475,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(motion.div, {
					className: "course-done-actions",
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: .4 },
					children: allModulesDone && course.finalExam ? /* @__PURE__ */ _jsxDEV(Link, {
						to: `/courses/${course.slug}/exam`,
						className: "continue-card-cta",
						children: [/* @__PURE__ */ _jsxDEV(GraduationCap, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 493,
							columnNumber: 17
						}, this), " Take the final exam"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 492,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("p", {
						className: "hint",
						children: "This course doesn't have a final exam."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 496,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 485,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 444,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 437,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 436,
		columnNumber: 5
	}, this);
}
_s2(CourseDoneModal, "D51hXr5AYaQFW8G7QvSXi6jdahg=");
_c4 = CourseDoneModal;
// Cheap CSS-only confetti burst, same trick as ExamPage's Confetti — a
// handful of absolutely positioned dots animating outward + fading.
function DoneConfetti() {
	_s3();
	const [pieces] = useState(() => Array.from({ length: 24 }, (_, i) => ({
		id: i,
		x: (Math.random() - .5) * 360,
		y: Math.random() * -280 - 40,
		rotate: Math.random() * 360,
		color: [
			"#4f46e5",
			"#f59e0b",
			"#22c55e",
			"#ec4899",
			"#06b6d4"
		][i % 5],
		delay: Math.random() * .25
	})));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "confetti course-done-confetti",
		"aria-hidden": "true",
		children: pieces.map((p) => /* @__PURE__ */ _jsxDEV(motion.span, {
			className: "confetti-piece",
			style: { background: p.color },
			initial: {
				x: 0,
				y: 0,
				opacity: 1,
				rotate: 0
			},
			animate: {
				x: p.x,
				y: p.y,
				opacity: 0,
				rotate: p.rotate
			},
			transition: {
				duration: 1.2,
				delay: p.delay,
				ease: "easeOut"
			}
		}, p.id, false, {
			fileName: _jsxFileName,
			lineNumber: 521,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 519,
		columnNumber: 5
	}, this);
}
_s3(DoneConfetti, "iv4h3hYU2x9Ps+bgWDZHaHW3UBE=");
_c5 = DoneConfetti;
function ReaderSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "reader-shell",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "reader-topbar",
			children: /* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "6rem",
				height: "0.9rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 538,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 537,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "reader-body",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "reader-sidebar",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, { height: "1.5rem" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 542,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { height: "1.5rem" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 543,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, { height: "1.5rem" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 544,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 541,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "reader-content",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "content-card skeleton-block",
					children: [
						/* @__PURE__ */ _jsxDEV(Skeleton, {
							width: "40%",
							height: "1.2rem"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 548,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Skeleton, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 549,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Skeleton, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 550,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Skeleton, { width: "70%" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 551,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 547,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 546,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 540,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 536,
		columnNumber: 5
	}, this);
}
_c6 = ReaderSkeleton;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "CourseReaderPage");
$RefreshReg$(_c2, "PageView");
$RefreshReg$(_c3, "QuizModal");
$RefreshReg$(_c4, "CourseDoneModal");
$RefreshReg$(_c5, "DoneConfetti");
$RefreshReg$(_c6, "ReaderSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/CourseReaderPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/CourseReaderPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/CourseReaderPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/CourseReaderPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQVMsTUFBTSxXQUFXLHVCQUF1QjtBQUNqRCxTQUFTLGlCQUFpQixjQUFjO0FBQ3hDLFNBQVMsV0FBVyxZQUFZLGFBQWEsZUFBZSxhQUFhLFNBQVM7QUFDbEYsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsa0JBQWtCLG1CQUFtQjtBQUM5QyxTQUNFLGtCQUNBLGtCQUFrQixxQkFDbEIsa0JBQ0EsY0FDQSx3QkFDSztBQUNQLFNBQVMsT0FBTyxvQkFBb0I7Ozs7Ozs7QUFLcEMsU0FBUyxhQUFhLFFBQVE7Q0FDNUIsTUFBTSxPQUFPLENBQUM7Q0FDZCxPQUFPLFFBQVEsU0FBUyxjQUFjLGdCQUFnQjtFQUNwRCxhQUFhLFNBQVMsU0FBUyxZQUFZO0dBQ3pDLFFBQVEsTUFBTSxTQUFTLGVBQWU7SUFDcEMsS0FBSyxLQUFLO0tBQUU7S0FBYSxRQUFRO0tBQWM7S0FBUyxNQUFNO0lBQVcsQ0FBQztHQUM1RSxDQUFDO0VBQ0gsQ0FBQztDQUNILENBQUM7Q0FDRCxPQUFPO0FBQ1Q7Ozs7O0FBTUEsT0FBTyxTQUFTLG1CQUFtQjs7Q0FDakMsTUFBTSxFQUFFLFNBQVMsVUFBVTtDQUMzQixNQUFNLENBQUMsY0FBYyxtQkFBbUIsZ0JBQWdCO0NBQ3hELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxJQUFJO0NBQ3pDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLGVBQWUsSUFBSSxJQUFJLENBQUM7Q0FDeEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsQ0FBQyxDQUFDO0NBQ3JELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLGVBQWUsSUFBSSxJQUFJLENBQUM7Q0FDMUUsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLElBQUk7OztDQUdyQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLElBQUk7Q0FDekQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsSUFBSTtDQUUvQyxnQkFBZ0I7RUFDZCxJQUFJLFlBQVk7RUFDaEIsVUFBVSxJQUFJO0VBQ2QsYUFBYSxJQUFJO0VBQ2pCLFdBQVcsVUFBVSxJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sU0FBUztHQUM5QyxJQUFJLFdBQVc7R0FDZixVQUFVLElBQUk7R0FFZCxNQUFNLFdBQVcsTUFBTSxXQUFXLFlBQVksS0FBSyxFQUFFO0dBQ3JELElBQUksV0FBVztHQUNmLE1BQU0sWUFBWSxJQUFJLElBQUksU0FBUyxnQkFBZ0I7R0FDbkQsb0JBQW9CLFNBQVM7R0FDN0IsaUJBQWlCLFNBQVMsYUFBYTtHQUV2QyxNQUFNLE9BQU8sYUFBYSxJQUFJO0dBQzlCLE1BQU0sY0FBYyxPQUFPLEtBQUssTUFBTSxNQUFNLEVBQUUsS0FBSyxPQUFPLEVBQUU7R0FDNUQsTUFBTSxrQkFBa0IsZ0JBQWdCLG9CQUFvQixNQUFNLGFBQWEsQ0FBQyxHQUFHLFNBQVMsR0FBRyxTQUFTLGFBQWE7R0FFckgsTUFBTSxZQUFZLGFBQWEsSUFBSSxNQUFNO0dBQ3pDLE1BQU0sWUFBWSxhQUFhLElBQUksTUFBTTtHQUV6QyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxhQUFhLEtBQUssUUFBUSxNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVMsR0FBRztJQUM3RCxjQUFjO0tBQUUsTUFBTTtLQUFRLFVBQVU7SUFBVTtHQUNwRCxPQUFPLElBQUksYUFBYSxXQUFXLFNBQVMsR0FBRztJQUM3QyxNQUFNLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxLQUFLLE9BQU8sU0FBUztJQUN0RCxJQUFJLENBQUMsZUFBZSxNQUFNLFdBQVcsR0FBRyxjQUFjO0tBQUUsTUFBTTtLQUFRLFFBQVE7SUFBVTtHQUMxRjtHQUNBLElBQUksQ0FBQyxlQUFlLFdBQVcsU0FBUyxVQUFVLEdBQUc7SUFDbkQsTUFBTSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsS0FBSyxPQUFPLFNBQVMsVUFBVTtJQUNoRSxJQUFJLENBQUMsZUFBZSxNQUFNLFdBQVcsR0FBRyxjQUFjO0tBQUUsTUFBTTtLQUFRLFFBQVEsU0FBUztJQUFXO0dBQ3BHO0dBQ0EsSUFBSSxDQUFDLGFBQWE7SUFDaEIsTUFBTSxRQUFRLEtBQUs7SUFDbkIsY0FBYyxRQUFRO0tBQUUsTUFBTTtLQUFRLFFBQVEsTUFBTSxLQUFLO0lBQUcsSUFBSSxFQUFFLE1BQU0sT0FBTztHQUNqRjtHQUVBLFFBQVEsV0FBVztHQUNuQixJQUFJLFlBQVksU0FBUyxRQUFRLGtCQUFrQixZQUFZLE1BQU07R0FDckUsTUFBTSxvQkFBb0IsS0FBSyxNQUM1QixNQUFPLFlBQVksU0FBUyxVQUFVLEVBQUUsS0FBSyxPQUFPLFlBQVksVUFDOUQsWUFBWSxTQUFTLFVBQVUsRUFBRSxPQUFPLE9BQU8sWUFBWSxRQUNoRSxDQUFDLEVBQUUsZUFBZTtHQUNsQixxQkFBcUIsSUFBSSxJQUFJLENBQUMsS0FBSyxRQUFRLGtCQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUM7RUFDckYsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBQ2xCLElBQUksV0FBVzs7OztHQUlmLFFBQVEsTUFBTSwwQkFBMEIsS0FBSyxJQUFJLEtBQUs7R0FDdEQsYUFBYSxLQUFLO0VBQ3BCLENBQUM7RUFDRCxhQUFhO0dBQ1gsWUFBWTtFQUNkOztDQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxNQUFNLE9BQU8sY0FBZSxTQUFTLGFBQWEsTUFBTSxJQUFJLENBQUMsR0FBSSxDQUFDLE1BQU0sQ0FBQztDQUV6RSxJQUFJLFdBQVc7RUFDYixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxLQUFELFlBQUcsNkVBQTZFOzs7O2FBQ2hGLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO2NBQVc7R0FBcUI7Ozs7V0FDdEM7Ozs7OztDQUVUO0NBRUEsSUFBSSxXQUFXLFFBQVEsU0FBUyxNQUFNLE9BQU8sd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0NBRTlELE1BQU0sV0FBVyxpQkFBaUIsUUFBUSxDQUFDLEdBQUcsZ0JBQWdCLENBQUM7Q0FDL0QsTUFBTSxpQkFBaUIsaUJBQWlCLFFBQVEsQ0FBQyxHQUFHLGdCQUFnQixHQUFHLGFBQWE7Q0FFcEYsU0FBUyxhQUFhLGFBQWE7RUFDakMsT0FBTyxvQkFBb0IsUUFBUSxhQUFhLENBQUMsR0FBRyxnQkFBZ0IsR0FBRyxhQUFhO0NBQ3RGO0NBRUEsU0FBUyxvQkFBb0IsY0FBYztFQUN6QyxPQUFPLGlCQUFpQjtHQUFFLEdBQUc7R0FBYyxNQUFNO0VBQUssR0FBRyxDQUFDLEdBQUcsZ0JBQWdCLEdBQUcsYUFBYTtDQUMvRjtDQUVBLFNBQVMsaUJBQWlCLFVBQVU7RUFDbEMsT0FBTyxhQUFhLGNBQWMsU0FBUztDQUM3QztDQUVBLFNBQVMsU0FBUyxRQUFRO0VBQ3hCLFFBQVE7R0FBRSxNQUFNO0dBQVE7RUFBTyxDQUFDO0VBQ2hDLGtCQUFrQixNQUFNO0VBQ3hCLGdCQUFnQixFQUFFLE1BQU0sT0FBTyxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7OztFQUduRCxZQUFZLE9BQU8sSUFBSSxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUM3QyxNQUFNLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxLQUFLLE9BQU8sTUFBTTtFQUNuRCxJQUFJLE9BQU8sc0JBQXNCLFNBQVMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksTUFBTSxPQUFPLEVBQUUsQ0FBQztDQUM5RTtDQUVBLFNBQVMsaUJBQWlCO0VBQ3hCLElBQUksZ0JBQWdCLFNBQVMsY0FBYztDQUM3QztDQUVBLFNBQVMsU0FBUyxVQUFVO0VBQzFCLFFBQVE7R0FBRSxNQUFNO0dBQVE7RUFBUyxDQUFDO0VBQ2xDLGdCQUFnQixFQUFFLE1BQU0sU0FBUyxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDdkQ7Q0FFQSxTQUFTLGFBQWEsVUFBVTtFQUM5QixzQkFBc0IsU0FBUztHQUM3QixNQUFNLE9BQU8sSUFBSSxJQUFJLElBQUk7R0FDekIsSUFBSSxLQUFLLElBQUksUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRO1FBQ3ZDLEtBQUssSUFBSSxRQUFRO0dBQ3RCLE9BQU87RUFDVCxDQUFDO0NBQ0g7Q0FFQSxTQUFTLGFBQWEsUUFBUTtFQUM1QixpQkFBaUIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQ2xELHFCQUFxQixTQUFTLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQztDQUN6RDs7Ozs7Q0FNQSxTQUFTLE9BQU8sZUFBZTtFQUM3QixhQUFhLGFBQWE7RUFDMUIsTUFBTSxRQUFRLEtBQUssV0FBVyxNQUFNLEVBQUUsS0FBSyxPQUFPLGFBQWE7RUFDL0QsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxPQUFPLEtBQUssUUFBUTtFQUMxQixNQUFNLGdCQUFnQixDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsUUFBUTtFQUU1RCxJQUFJLGlCQUFpQixRQUFRLE9BQU8sUUFBUSxDQUFDLGFBQWEsY0FBYyxRQUFRLE9BQU8sR0FBRyxHQUFHO0dBQzNGLFNBQVMsUUFBUSxPQUFPLEVBQUU7R0FDMUI7RUFDRjtFQUNBLElBQUksTUFBTTtHQUNSLFNBQVMsS0FBSyxLQUFLLEVBQUU7R0FDckI7RUFDRjtFQUNBLFFBQVEsRUFBRSxNQUFNLE9BQU8sQ0FBQztDQUMxQjs7O0NBSUEsU0FBUyxPQUFPLGVBQWU7RUFDN0IsTUFBTSxRQUFRLEtBQUssV0FBVyxNQUFNLEVBQUUsS0FBSyxPQUFPLGFBQWE7RUFDL0QsTUFBTSxPQUFPLEtBQUssUUFBUTtFQUMxQixJQUFJLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRTtDQUNqQztDQUVBLFNBQVMsa0JBQWtCLFVBQVUsU0FBUztFQUM1QyxrQkFBa0IsVUFBVTtHQUFFLEdBQUc7SUFBTyxXQUFXLEVBQUUsR0FBRyxRQUFRO0VBQUUsRUFBRTtDQUN0RTtDQUVBLFNBQVMsa0JBQWtCLFVBQVU7RUFDbkMsTUFBTSxjQUFjLE9BQU8sUUFBUSxXQUFXLE1BQU0sRUFBRSxPQUFPLFFBQVE7RUFDckUsTUFBTSxhQUFhLE9BQU8sUUFBUSxjQUFjO0VBQ2hELElBQUksWUFBWTtHQUNkLE1BQU0sWUFBWSxLQUFLLE1BQU0sTUFBTSxFQUFFLGdCQUFnQixjQUFjLENBQUM7R0FDcEUsc0JBQXNCLFNBQVMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksV0FBVyxFQUFFLENBQUM7R0FDL0QsSUFBSSxXQUFXLFNBQVMsVUFBVSxLQUFLLEVBQUU7RUFDM0MsT0FBTztHQUNMLFFBQVEsRUFBRSxNQUFNLE9BQU8sQ0FBQztFQUMxQjtDQUNGO0NBRUEsTUFBTSxjQUFjLE9BQU8sUUFDdkI7RUFDRSxtQkFBbUIsT0FBTztFQUMxQix5QkFBeUIsTUFBTSxPQUFPLE9BQU8sQ0FBQyxFQUFFO0VBQ2hELHdCQUF3QixhQUFhLE9BQU8sS0FBSztDQUNuRCxJQUNBO0NBRUosT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFlLE9BQU87WUFBckM7R0FDRSx3QkFBQyxhQUFEO0lBQ1U7SUFDUixhQUFhLFNBQVM7SUFDSDtJQUNuQixnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLGlCQUFpQixPQUFPLGlCQUFpQixJQUFJLEVBQUU7SUFDL0MsdUJBQXVCO0lBQ3ZCLG9CQUFvQjtJQUNwQixZQUFZLEtBQUs7SUFDakIsY0FBYyxLQUFLLFNBQVMsU0FBUyxLQUFLLFNBQVM7SUFDbkQsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLEtBQUssV0FBVztJQUN2RCxjQUFjO0lBQ2QsY0FBYztJQUNFO2NBZGxCO0tBZ0JHLEtBQUssU0FBUyxVQUNiLHdCQUFDLFVBQUQ7TUFFVTtNQUNSLE9BQU8sS0FBSyxNQUFNLE1BQU0sRUFBRSxLQUFLLE9BQU8sS0FBSyxNQUFNO01BQ2pELFlBQVksS0FBSyxXQUFXLE1BQU0sRUFBRSxLQUFLLE9BQU8sS0FBSyxNQUFNLElBQUk7TUFDL0QsWUFBWSxLQUFLO01BQ2pCLFdBQVcsaUJBQWlCLElBQUksS0FBSyxNQUFNO01BQzNDLFNBQVMsS0FBSyxXQUFXLE1BQU0sRUFBRSxLQUFLLE9BQU8sS0FBSyxNQUFNLElBQUk7TUFDNUQsc0JBQXNCLGFBQWEsS0FBSyxNQUFNO01BQzlDLGNBQWMsT0FBTyxLQUFLLE1BQU07TUFDaEMsY0FBYyxPQUFPLEtBQUssTUFBTTtLQUNqQyxHQVZNLEtBQUs7Ozs7WUFVWDtLQUdGLEtBQUssU0FBUyxVQUFVLGtCQUN2Qix3QkFBQyxVQUFEO01BRVU7TUFDUixPQUFPLEtBQUssTUFBTSxNQUFNLEVBQUUsS0FBSyxPQUFPLGNBQWM7TUFDcEQsWUFBWSxLQUFLLFdBQVcsTUFBTSxFQUFFLEtBQUssT0FBTyxjQUFjLElBQUk7TUFDbEUsWUFBWSxLQUFLO01BQ2pCLFdBQVcsaUJBQWlCLElBQUksY0FBYztNQUM5QyxhQUFhO0tBQ2QsR0FQTTs7OztZQU9OO0tBR0YsS0FBSyxTQUFTLFVBQVUsa0JBQ3ZCLHdCQUFDLFVBQUQ7TUFFVTtNQUNSLE9BQU8sS0FBSyxNQUFNLE1BQU0sRUFBRSxLQUFLLE9BQU8sY0FBYztNQUNwRCxZQUFZLEtBQUssV0FBVyxNQUFNLEVBQUUsS0FBSyxPQUFPLGNBQWMsSUFBSTtNQUNsRSxZQUFZLEtBQUs7TUFDakIsV0FBVyxpQkFBaUIsSUFBSSxjQUFjO01BQzlDLGFBQWE7S0FDZCxHQVBNOzs7O1lBT047SUFFUTs7Ozs7O0dBRVosS0FBSyxTQUFTLFVBQ2Isd0JBQUMsV0FBRDtJQUVVO0lBQ1IsY0FBYyxPQUFPLFFBQVEsTUFBTSxNQUFNLEVBQUUsT0FBTyxLQUFLLFFBQVE7SUFDL0QsaUJBQWlCLGNBQWMsS0FBSztJQUNwQyxZQUFZLFlBQVksa0JBQWtCLEtBQUssVUFBVSxPQUFPO0lBQ2hFLFFBQVEsYUFBYSxjQUFjLEtBQUssU0FBUztJQUNqRCxrQkFBa0Isa0JBQWtCLEtBQUssUUFBUTtJQUNqRCxTQUFTO0dBQ1YsR0FSTSxLQUFLOzs7O1VBUVg7R0FHRixLQUFLLFNBQVMsVUFDYix3QkFBQyxpQkFBRDtJQUNVO0lBQ1E7SUFDaEIsU0FBUztHQUNWOzs7OztFQUVBOzs7Ozs7QUFFVDs7Ozs7QUFFQSxTQUFTLFNBQVMsRUFDaEIsT0FDQSxZQUNBLFlBQ0EsV0FDQSxTQUNBLGdCQUNBLFFBQ0EsUUFDQSxjQUFjLFFBQ2I7Q0FDRCxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLE1BQU0sRUFBRSxNQUFNLFlBQVksU0FBUyxRQUFRLGlCQUFpQjtDQUM1RCxNQUFNLFVBQVUsYUFBYSxLQUFLLE1BQU8sYUFBYSxhQUFjLEdBQUcsSUFBSTtDQUUzRSxPQUNFLHdCQUFDLE9BQU8sU0FBUjtFQUNFLFdBQVU7RUFDVixTQUFTO0dBQUUsU0FBUztHQUFHLEdBQUc7RUFBRTtFQUM1QixTQUFTO0dBQUUsU0FBUztHQUFHLEdBQUc7RUFBRTtFQUM1QixZQUFZLEVBQUUsVUFBVSxHQUFJO1lBSjlCO0dBTUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBK0M7T0FDdkM7T0FBVztPQUFLO01BQ2xCOzs7OztlQUNMLGVBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7UUFDVixVQUFVLENBQUM7UUFDWCxTQUFTO2tCQUpYLENBTUUsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztrQkFBQyxXQUNqQjs7Ozs7O09BQ1AsQ0FBQyxhQUNBLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUF3QixTQUFTO2tCQUFqRSxDQUNFLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7a0JBQUMsZUFDbkI7Ozs7OztPQUVWLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsV0FBVTtRQUFzRCxTQUFTO2tCQUEvRjtTQUNHLFlBQVksYUFBYTtTQUF1QjtTQUFDLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O1FBQ25FOzs7Ozs7TUFDTDs7Ozs7YUFFSjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQU8sS0FBUjtNQUNFLFdBQVU7TUFDVixTQUFTO01BQ1QsU0FBUyxFQUFFLE9BQU8sR0FBRyxRQUFRLEdBQUc7TUFDaEMsWUFBWTtPQUFFLFVBQVU7T0FBSyxNQUFNO01BQVU7S0FDOUM7Ozs7O0lBQ0U7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FDRyxhQUFhO0tBQU07S0FBSSxRQUFRO0lBQzVCOzs7Ozs7R0FDTix3QkFBQyxNQUFELFlBQUssV0FBVyxNQUFVOzs7OztHQUMxQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFdBQVcsUUFBUSxNQUFNLE1BQU0sQ0FBQyxDQUFDLEtBQUssV0FBVyxNQUNoRCx3QkFBQyxLQUFELFlBQVksVUFBYSxHQUFqQjs7OztXQUFpQixDQUMxQjtHQUNFOzs7OztFQUNTOzs7Ozs7QUFFcEI7O0FBRUEsU0FBUyxVQUFVLEVBQUUsUUFBUSxjQUFjLGlCQUFpQixXQUFXLFFBQVEsWUFBWSxXQUFXO0NBQ3BHLElBQUksQ0FBQyxjQUFjLE1BQU0sT0FBTztDQUNoQyxPQUNFLHdCQUFDLGlCQUFELFlBQ0Usd0JBQUMsT0FBTyxLQUFSO0VBQ0UsV0FBVTtFQUNWLFNBQVMsRUFBRSxTQUFTLEVBQUU7RUFDdEIsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixNQUFNLEVBQUUsU0FBUyxFQUFFO0VBQ25CLFNBQVM7WUFFVCx3QkFBQyxPQUFPLEtBQVI7R0FDRSxXQUFVO0dBQ1YsU0FBUztJQUFFLFNBQVM7SUFBRyxHQUFHO0lBQUksT0FBTztHQUFLO0dBQzFDLFNBQVM7SUFBRSxTQUFTO0lBQUcsR0FBRztJQUFHLE9BQU87R0FBRTtHQUN0QyxNQUFNO0lBQUUsU0FBUztJQUFHLEdBQUc7SUFBSSxPQUFPO0dBQUs7R0FDdkMsWUFBWTtJQUFFLFVBQVU7SUFBSyxNQUFNO0dBQVU7R0FDN0MsVUFBVSxNQUFNLEVBQUUsZ0JBQWdCO2FBTnBDO0lBUUUsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQW1CLGNBQVc7S0FBYSxTQUFTO2VBQ2xGLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0lBQ1I7Ozs7O0lBQ1Isd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBdUIsYUFBYTtJQUFZOzs7OztJQUNoRSx3QkFBQyxNQUFELFlBQUksYUFBYzs7Ozs7SUFDbEIsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBb0I7SUFBdUM7Ozs7O0lBQ3hFLHdCQUFDLE1BQUQ7S0FDRSxNQUFNLGFBQWE7S0FDbkIsVUFBVSxPQUFPO0tBQ2pCLFVBQVUsYUFBYTtLQUNOO0tBQ047SUFDWjs7Ozs7SUFDQSxVQUNDLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUFxQixTQUFTO2VBQTlELENBQTBFLGFBQy9ELHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7YUFDMUI7Ozs7OztHQUVBOzs7Ozs7Q0FDRjs7OztVQUNHOzs7OztBQUVyQjs7Ozs7O0FBTUEsTUFBTSxjQUFjO0NBQ2xCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUSxnQkFBZ0IsV0FBVzs7Q0FDNUQsTUFBTSxDQUFDLFNBQVMsZUFBZSxZQUFZLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxZQUFZLE1BQU0sRUFBRTtDQUMxRixPQUNFLHdCQUFDLGlCQUFELFlBQ0Usd0JBQUMsT0FBTyxLQUFSO0VBQ0UsV0FBVTtFQUNWLFNBQVMsRUFBRSxTQUFTLEVBQUU7RUFDdEIsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixNQUFNLEVBQUUsU0FBUyxFQUFFO0VBQ25CLFNBQVM7WUFFVCx3QkFBQyxPQUFPLEtBQVI7R0FDRSxXQUFVO0dBQ1YsU0FBUztJQUFFLFNBQVM7SUFBRyxHQUFHO0lBQUksT0FBTztHQUFJO0dBQ3pDLFNBQVM7SUFBRSxTQUFTO0lBQUcsR0FBRztJQUFHLE9BQU87R0FBRTtHQUN0QyxNQUFNO0lBQUUsU0FBUztJQUFHLEdBQUc7SUFBSSxPQUFPO0dBQUs7R0FDdkMsWUFBWTtJQUFFLE1BQU07SUFBVSxXQUFXO0lBQUssU0FBUztHQUFHO0dBQzFELFVBQVUsTUFBTSxFQUFFLGdCQUFnQjthQU5wQztJQVFFLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUFtQixjQUFXO0tBQVEsU0FBUztlQUM3RSx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztJQUNSOzs7OztJQUVSLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7SUFFZix3QkFBQyxPQUFPLEtBQVI7S0FDRSxXQUFVO0tBQ1YsU0FBUztNQUFFLE9BQU87TUFBRyxRQUFRLENBQUM7S0FBRztLQUNqQyxTQUFTO01BQUUsT0FBTztNQUFHLFFBQVE7S0FBRTtLQUMvQixZQUFZO01BQUUsTUFBTTtNQUFVLFdBQVc7TUFBSyxTQUFTO01BQUksT0FBTztLQUFJO2VBRXRFLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0lBQ2Q7Ozs7O0lBRVosd0JBQUMsT0FBTyxJQUFSO0tBQ0UsV0FBVTtLQUNWLFNBQVM7TUFBRSxTQUFTO01BQUcsR0FBRztLQUFFO0tBQzVCLFNBQVM7TUFBRSxTQUFTO01BQUcsR0FBRztLQUFFO0tBQzVCLFlBQVksRUFBRSxPQUFPLEdBQUk7ZUFFeEI7SUFDUTs7Ozs7SUFDWCx3QkFBQyxPQUFPLEdBQVI7S0FDRSxXQUFVO0tBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtLQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0tBQ3RCLFlBQVksRUFBRSxPQUFPLEdBQUk7ZUFKM0I7TUFLQztNQUNvRCx3QkFBQyxVQUFELFlBQVMsT0FBTyxNQUFjOzs7OztNQUFDO0tBRTFFOzs7Ozs7SUFFVix3QkFBQyxPQUFPLEtBQVI7S0FDRSxXQUFVO0tBQ1YsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO0tBQUU7S0FDNUIsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO0tBQUU7S0FDNUIsWUFBWSxFQUFFLE9BQU8sR0FBSTtlQUV4QixrQkFBa0IsT0FBTyxZQUN4Qix3QkFBQyxNQUFEO01BQU0sSUFBSSxZQUFZLE9BQU8sS0FBSztNQUFRLFdBQVU7Z0JBQXBELENBQ0Usd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7OztnQkFBQyxzQkFDdkI7Ozs7O2dCQUVOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFPO0tBQXlDOzs7OztJQUVyRDs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7VUFDRzs7Ozs7QUFFckI7Ozs7O0FBSUEsU0FBUyxlQUFlOztDQUN0QixNQUFNLENBQUMsVUFBVSxlQUNmLE1BQU0sS0FBSyxFQUFFLFFBQVEsR0FBRyxJQUFJLEdBQUcsT0FBTztFQUNwQyxJQUFJO0VBQ0osSUFBSSxLQUFLLE9BQU8sSUFBSSxNQUFPO0VBQzNCLEdBQUcsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0VBQzFCLFFBQVEsS0FBSyxPQUFPLElBQUk7RUFDeEIsT0FBTztHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUyxDQUFDLENBQUMsSUFBSTtFQUNuRSxPQUFPLEtBQUssT0FBTyxJQUFJO0NBQ3pCLEVBQUUsQ0FDSjtDQUNBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBZ0MsZUFBWTtZQUN4RCxPQUFPLEtBQUssTUFDWCx3QkFBQyxPQUFPLE1BQVI7R0FFRSxXQUFVO0dBQ1YsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNO0dBQzdCLFNBQVM7SUFBRSxHQUFHO0lBQUcsR0FBRztJQUFHLFNBQVM7SUFBRyxRQUFRO0dBQUU7R0FDN0MsU0FBUztJQUFFLEdBQUcsRUFBRTtJQUFHLEdBQUcsRUFBRTtJQUFHLFNBQVM7SUFBRyxRQUFRLEVBQUU7R0FBTztHQUN4RCxZQUFZO0lBQUUsVUFBVTtJQUFLLE9BQU8sRUFBRTtJQUFPLE1BQU07R0FBVTtFQUM5RCxHQU5NLEVBQUU7Ozs7U0FNUixDQUNGO0NBQ0U7Ozs7O0FBRVQ7OztBQUVBLFNBQVMsaUJBQWlCO0NBQ3hCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsVUFBRDtJQUFVLE9BQU07SUFBTyxRQUFPO0dBQVU7Ozs7O0VBQ3JDOzs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFELEVBQVUsUUFBTyxTQUFVOzs7OztLQUMzQix3QkFBQyxVQUFELEVBQVUsUUFBTyxTQUFVOzs7OztLQUMzQix3QkFBQyxVQUFELEVBQVUsUUFBTyxTQUFVOzs7OztJQUN4Qjs7Ozs7YUFDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQVUsT0FBTTtPQUFNLFFBQU87TUFBVTs7Ozs7TUFDdkMsd0JBQUMsVUFBRCxDQUFXOzs7OztNQUNYLHdCQUFDLFVBQUQsQ0FBVzs7Ozs7TUFDWCx3QkFBQyxVQUFELEVBQVUsT0FBTSxNQUFPOzs7OztLQUNwQjs7Ozs7O0dBQ0Y7Ozs7V0FDRjs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ291cnNlUmVhZGVyUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VQYXJhbXMsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IEFuaW1hdGVQcmVzZW5jZSwgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0J1xyXG5pbXBvcnQgeyBBcnJvd0xlZnQsIEFycm93UmlnaHQsIENoZWNrU3F1YXJlLCBHcmFkdWF0aW9uQ2FwLCBQYXJ0eVBvcHBlciwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgY291cnNlc0FwaSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvY291cnNlc0FwaSdcclxuaW1wb3J0IHsgUXVpeiB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvUXVpeidcclxuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tICcuLi9jb21wb25lbnRzL1NrZWxldG9uJ1xyXG5pbXBvcnQgeyBSZWFkZXJTaGVsbCB9IGZyb20gJy4uL2NvbXBvbmVudHMvcmVhZGVyL1JlYWRlclNoZWxsJ1xyXG5pbXBvcnQgeyBtYXJrUGFnZUNvbXBsZXRlLCBzZXRMYXN0UGFnZSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvcHJvZ3Jlc3NTdG9yZSdcclxuaW1wb3J0IHtcclxuICBsZWFybmluZ1Byb2dyZXNzLFxyXG4gIGlzTW9kdWxlTG9ja2VkIGFzIGNvbXB1dGVNb2R1bGVMb2NrZWQsXHJcbiAgaXNNb2R1bGVDb21wbGV0ZSxcclxuICBpc1F1aXpQYXNzZWQsXHJcbiAgaXNDb3Vyc2VDb21wbGV0ZSxcclxufSBmcm9tICcuLi9mZWF0dXJlcy9jb3Vyc2VzL3Byb2dyZXNzJ1xyXG5pbXBvcnQgeyBzaGFkZSwgY29udHJhc3RUZXh0IH0gZnJvbSAnLi4vdXRpbHMvY29sb3InXHJcblxyXG4vLyBGbGF0dGVucyBNb2R1bGUgPiBDaGFwdGVyID4gUGFnZSBpbnRvIGFuIG9yZGVyZWQgbGlzdCB3aXRoIGJhY2stcmVmcywgc29cclxuLy8gXCJuZXh0XCIvXCJlbmQgb2YgbW9kdWxlXCIgY2FuIGJlIGNvbXB1dGVkIGJ5IGFycmF5IHBvc2l0aW9uIGluc3RlYWQgb2ZcclxuLy8gcmUtd2Fsa2luZyB0aGUgdHJlZSBvbiBldmVyeSBjbGljay5cclxuZnVuY3Rpb24gZmxhdHRlblBhZ2VzKGNvdXJzZSkge1xyXG4gIGNvbnN0IGxpc3QgPSBbXVxyXG4gIGNvdXJzZS5tb2R1bGVzLmZvckVhY2goKGNvdXJzZU1vZHVsZSwgbW9kdWxlSW5kZXgpID0+IHtcclxuICAgIGNvdXJzZU1vZHVsZS5jaGFwdGVycy5mb3JFYWNoKChjaGFwdGVyKSA9PiB7XHJcbiAgICAgIGNoYXB0ZXIucGFnZXMuZm9yRWFjaCgoY291cnNlUGFnZSkgPT4ge1xyXG4gICAgICAgIGxpc3QucHVzaCh7IG1vZHVsZUluZGV4LCBtb2R1bGU6IGNvdXJzZU1vZHVsZSwgY2hhcHRlciwgcGFnZTogY291cnNlUGFnZSB9KVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICB9KVxyXG4gIHJldHVybiBsaXN0XHJcbn1cclxuXHJcbi8vIERvY3Mtc3R5bGUgcmVhZGVyIGZvciBhIHNpbmdsZSBjb3Vyc2Ug4oCUIG9wZW5lZCBpbiBpdHMgb3duIGJyb3dzZXIgdGFiXHJcbi8vIChzZWUgQ291cnNlQ2FyZC9Db250aW51ZUxlYXJuaW5nQ2FyZCksIG91dHNpZGUgdGhlIG1haW4gQXBwTGF5b3V0IHNoZWxsLlxyXG4vLyBSb3V0ZTogL2NvdXJzZXMvOnNsdWcvbGVhcm4gKHNlZSBBcHAuanN4KS4gT3ducyBhbGwgcHJvZ3Jlc3Mgc3RhdGUgZm9yXHJcbi8vIHRoZSBzZXNzaW9uIGFuZCBwZXJzaXN0cyBldmVyeSBjaGFuZ2UgdmlhIHByb2dyZXNzU3RvcmUuanMuXHJcbmV4cG9ydCBmdW5jdGlvbiBDb3Vyc2VSZWFkZXJQYWdlKCkge1xyXG4gIGNvbnN0IHsgc2x1ZyB9ID0gdXNlUGFyYW1zKClcclxuICBjb25zdCBbc2VhcmNoUGFyYW1zLCBzZXRTZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcclxuICBjb25zdCBbY291cnNlLCBzZXRDb3Vyc2VdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbY29tcGxldGVkUGFnZUlkcywgc2V0Q29tcGxldGVkUGFnZUlkc10gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgU2V0KCkpXHJcbiAgY29uc3QgW21vZHVsZVF1aXp6ZXMsIHNldE1vZHVsZVF1aXp6ZXNdID0gdXNlU3RhdGUoe30pXHJcbiAgY29uc3QgW2V4cGFuZGVkTW9kdWxlSWRzLCBzZXRFeHBhbmRlZE1vZHVsZUlkc10gPSB1c2VTdGF0ZSgoKSA9PiBuZXcgU2V0KCkpXHJcbiAgY29uc3QgW3ZpZXcsIHNldFZpZXddID0gdXNlU3RhdGUobnVsbCkgLy8geyBraW5kOiAncGFnZScsIHBhZ2VJZCB9IHwgeyBraW5kOiAncXVpeicsIG1vZHVsZUlkIH0gfCB7IGtpbmQ6ICdkb25lJyB9XHJcbiAgLy8gTGFzdCBub24tcXVpeiBwYWdlIHNob3duIOKAlCBrZXB0IHNvIHRoZSBxdWl6IGNhbiByZW5kZXIgYXMgYSBtb2RhbCBvblxyXG4gIC8vIHRvcCBvZiBpdCBpbnN0ZWFkIG9mIHJlcGxhY2luZyB0aGUgd2hvbGUgY29udGVudCBwYW5lLlxyXG4gIGNvbnN0IFtiYWNrZHJvcFBhZ2VJZCwgc2V0QmFja2Ryb3BQYWdlSWRdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbbG9hZEVycm9yLCBzZXRMb2FkRXJyb3JdID0gdXNlU3RhdGUobnVsbClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxyXG4gICAgc2V0Q291cnNlKG51bGwpXHJcbiAgICBzZXRMb2FkRXJyb3IobnVsbClcclxuICAgIGNvdXJzZXNBcGkuZ2V0Q291cnNlKHNsdWcpLnRoZW4oYXN5bmMgKGRhdGEpID0+IHtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgIHNldENvdXJzZShkYXRhKVxyXG5cclxuICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBhd2FpdCBjb3Vyc2VzQXBpLmdldFByb2dyZXNzKGRhdGEuaWQpXHJcbiAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVyblxyXG4gICAgICBjb25zdCBjb21wbGV0ZWQgPSBuZXcgU2V0KHByb2dyZXNzLmNvbXBsZXRlZFBhZ2VJZHMpXHJcbiAgICAgIHNldENvbXBsZXRlZFBhZ2VJZHMoY29tcGxldGVkKVxyXG4gICAgICBzZXRNb2R1bGVRdWl6emVzKHByb2dyZXNzLm1vZHVsZVF1aXp6ZXMpXHJcblxyXG4gICAgICBjb25zdCBmbGF0ID0gZmxhdHRlblBhZ2VzKGRhdGEpXHJcbiAgICAgIGNvbnN0IHBhZ2VFeGlzdHMgPSAoaWQpID0+IGZsYXQuc29tZSgoZikgPT4gZi5wYWdlLmlkID09PSBpZClcclxuICAgICAgY29uc3QgbW9kdWxlTG9ja2VkQXQgPSAobW9kdWxlSW5kZXgpID0+IGNvbXB1dGVNb2R1bGVMb2NrZWQoZGF0YSwgbW9kdWxlSW5kZXgsIFsuLi5jb21wbGV0ZWRdLCBwcm9ncmVzcy5tb2R1bGVRdWl6emVzKVxyXG5cclxuICAgICAgY29uc3QgcXVpelBhcmFtID0gc2VhcmNoUGFyYW1zLmdldCgncXVpeicpXHJcbiAgICAgIGNvbnN0IHBhZ2VQYXJhbSA9IHNlYXJjaFBhcmFtcy5nZXQoJ3BhZ2UnKVxyXG5cclxuICAgICAgbGV0IGluaXRpYWxWaWV3ID0gbnVsbFxyXG4gICAgICBpZiAocXVpelBhcmFtICYmIGRhdGEubW9kdWxlcy5zb21lKChtKSA9PiBtLmlkID09PSBxdWl6UGFyYW0pKSB7XHJcbiAgICAgICAgaW5pdGlhbFZpZXcgPSB7IGtpbmQ6ICdxdWl6JywgbW9kdWxlSWQ6IHF1aXpQYXJhbSB9XHJcbiAgICAgIH0gZWxzZSBpZiAocGFnZVBhcmFtICYmIHBhZ2VFeGlzdHMocGFnZVBhcmFtKSkge1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gZmxhdC5maW5kKChmKSA9PiBmLnBhZ2UuaWQgPT09IHBhZ2VQYXJhbSlcclxuICAgICAgICBpZiAoIW1vZHVsZUxvY2tlZEF0KGVudHJ5Lm1vZHVsZUluZGV4KSkgaW5pdGlhbFZpZXcgPSB7IGtpbmQ6ICdwYWdlJywgcGFnZUlkOiBwYWdlUGFyYW0gfVxyXG4gICAgICB9XHJcbiAgICAgIGlmICghaW5pdGlhbFZpZXcgJiYgcGFnZUV4aXN0cyhwcm9ncmVzcy5sYXN0UGFnZUlkKSkge1xyXG4gICAgICAgIGNvbnN0IGVudHJ5ID0gZmxhdC5maW5kKChmKSA9PiBmLnBhZ2UuaWQgPT09IHByb2dyZXNzLmxhc3RQYWdlSWQpXHJcbiAgICAgICAgaWYgKCFtb2R1bGVMb2NrZWRBdChlbnRyeS5tb2R1bGVJbmRleCkpIGluaXRpYWxWaWV3ID0geyBraW5kOiAncGFnZScsIHBhZ2VJZDogcHJvZ3Jlc3MubGFzdFBhZ2VJZCB9XHJcbiAgICAgIH1cclxuICAgICAgaWYgKCFpbml0aWFsVmlldykge1xyXG4gICAgICAgIGNvbnN0IGZpcnN0ID0gZmxhdFswXVxyXG4gICAgICAgIGluaXRpYWxWaWV3ID0gZmlyc3QgPyB7IGtpbmQ6ICdwYWdlJywgcGFnZUlkOiBmaXJzdC5wYWdlLmlkIH0gOiB7IGtpbmQ6ICdkb25lJyB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldFZpZXcoaW5pdGlhbFZpZXcpXHJcbiAgICAgIGlmIChpbml0aWFsVmlldy5raW5kID09PSAncGFnZScpIHNldEJhY2tkcm9wUGFnZUlkKGluaXRpYWxWaWV3LnBhZ2VJZClcclxuICAgICAgY29uc3QgYWN0aXZlTW9kdWxlSW5kZXggPSBmbGF0LmZpbmQoXHJcbiAgICAgICAgKGYpID0+IChpbml0aWFsVmlldy5raW5kID09PSAncGFnZScgJiYgZi5wYWdlLmlkID09PSBpbml0aWFsVmlldy5wYWdlSWQpIHx8XHJcbiAgICAgICAgICAoaW5pdGlhbFZpZXcua2luZCA9PT0gJ3F1aXonICYmIGYubW9kdWxlLmlkID09PSBpbml0aWFsVmlldy5tb2R1bGVJZCksXHJcbiAgICAgICk/Lm1vZHVsZUluZGV4ID8/IDBcclxuICAgICAgc2V0RXhwYW5kZWRNb2R1bGVJZHMobmV3IFNldChbZGF0YS5tb2R1bGVzW2FjdGl2ZU1vZHVsZUluZGV4XT8uaWRdLmZpbHRlcihCb29sZWFuKSkpXHJcbiAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgIC8vIENvdXJzZSBkb2Vzbid0IGV4aXN0LCBvciB0aGUgYmFja2VuZCBlcnJvcmVkIOKAlCBzdXJmYWNlIGEgcGxhaW5cclxuICAgICAgLy8gZXJyb3Igc3RhdGUgaW5zdGVhZCBvZiBsZWF2aW5nIHRoZSByZWFkZXIgc3R1Y2sgb24gaXRzIHNrZWxldG9uXHJcbiAgICAgIC8vIGZvcmV2ZXIgYW5kIHRocm93aW5nIGFuIHVuaGFuZGxlZCByZWplY3Rpb24gaW50byB0aGUgY29uc29sZS5cclxuICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIGxvYWQgY291cnNlIFwiJHtzbHVnfVwiYCwgZXJyb3IpXHJcbiAgICAgIHNldExvYWRFcnJvcihlcnJvcilcclxuICAgIH0pXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBjYW5jZWxsZWQgPSB0cnVlXHJcbiAgICB9XHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXHJcbiAgfSwgW3NsdWddKVxyXG5cclxuICBjb25zdCBmbGF0ID0gdXNlTWVtbygoKSA9PiAoY291cnNlID8gZmxhdHRlblBhZ2VzKGNvdXJzZSkgOiBbXSksIFtjb3Vyc2VdKVxyXG5cclxuICBpZiAobG9hZEVycm9yKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlYWRlci1zaGVsbCByZWFkZXItbG9hZC1lcnJvclwiPlxyXG4gICAgICAgIDxwPkNvdWxkbid0IGxvYWQgdGhpcyBjb3Vyc2UuIEl0IG1heSBub3QgZXhpc3QsIG9yIHRoZSBzZXJ2ZXIgaXMgdW5hdmFpbGFibGUuPC9wPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL2NvdXJzZXNcIj5CYWNrIHRvIGNvdXJzZXM8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgaWYgKGNvdXJzZSA9PT0gbnVsbCB8fCB2aWV3ID09PSBudWxsKSByZXR1cm4gPFJlYWRlclNrZWxldG9uIC8+XHJcblxyXG4gIGNvbnN0IGxlYXJuaW5nID0gbGVhcm5pbmdQcm9ncmVzcyhjb3Vyc2UsIFsuLi5jb21wbGV0ZWRQYWdlSWRzXSlcclxuICBjb25zdCBhbGxNb2R1bGVzRG9uZSA9IGlzQ291cnNlQ29tcGxldGUoY291cnNlLCBbLi4uY29tcGxldGVkUGFnZUlkc10sIG1vZHVsZVF1aXp6ZXMpXHJcblxyXG4gIGZ1bmN0aW9uIG1vZHVsZUxvY2tlZChtb2R1bGVJbmRleCkge1xyXG4gICAgcmV0dXJuIGNvbXB1dGVNb2R1bGVMb2NrZWQoY291cnNlLCBtb2R1bGVJbmRleCwgWy4uLmNvbXBsZXRlZFBhZ2VJZHNdLCBtb2R1bGVRdWl6emVzKVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gbW9kdWxlUGFnZXNDb21wbGV0ZShjb3Vyc2VNb2R1bGUpIHtcclxuICAgIHJldHVybiBpc01vZHVsZUNvbXBsZXRlKHsgLi4uY291cnNlTW9kdWxlLCBxdWl6OiBudWxsIH0sIFsuLi5jb21wbGV0ZWRQYWdlSWRzXSwgbW9kdWxlUXVpenplcylcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG1vZHVsZVF1aXpQYXNzZWQobW9kdWxlSWQpIHtcclxuICAgIHJldHVybiBpc1F1aXpQYXNzZWQobW9kdWxlUXVpenplc1ttb2R1bGVJZF0pXHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBnb1RvUGFnZShwYWdlSWQpIHtcclxuICAgIHNldFZpZXcoeyBraW5kOiAncGFnZScsIHBhZ2VJZCB9KVxyXG4gICAgc2V0QmFja2Ryb3BQYWdlSWQocGFnZUlkKVxyXG4gICAgc2V0U2VhcmNoUGFyYW1zKHsgcGFnZTogcGFnZUlkIH0sIHsgcmVwbGFjZTogdHJ1ZSB9KVxyXG4gICAgLy8gRmlyZS1hbmQtZm9yZ2V0OiBsb2NhbCBzdGF0ZSBhYm92ZSBhbHJlYWR5IHJlZmxlY3RzIHRoZSBtb3ZlLCB0aGlzXHJcbiAgICAvLyBqdXN0IHBlcnNpc3RzIGl0IOKAlCBhIGZhaWxlZCByZXF1ZXN0IHNob3VsZG4ndCBibG9jayBuYXZpZ2F0aW9uLlxyXG4gICAgc2V0TGFzdFBhZ2UoY291cnNlLmlkLCBwYWdlSWQpLmNhdGNoKCgpID0+IHt9KVxyXG4gICAgY29uc3QgZW50cnkgPSBmbGF0LmZpbmQoKGYpID0+IGYucGFnZS5pZCA9PT0gcGFnZUlkKVxyXG4gICAgaWYgKGVudHJ5KSBzZXRFeHBhbmRlZE1vZHVsZUlkcygocHJldikgPT4gbmV3IFNldChwcmV2KS5hZGQoZW50cnkubW9kdWxlLmlkKSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGNsb3NlUXVpek1vZGFsKCkge1xyXG4gICAgaWYgKGJhY2tkcm9wUGFnZUlkKSBnb1RvUGFnZShiYWNrZHJvcFBhZ2VJZClcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGdvVG9RdWl6KG1vZHVsZUlkKSB7XHJcbiAgICBzZXRWaWV3KHsga2luZDogJ3F1aXonLCBtb2R1bGVJZCB9KVxyXG4gICAgc2V0U2VhcmNoUGFyYW1zKHsgcXVpejogbW9kdWxlSWQgfSwgeyByZXBsYWNlOiB0cnVlIH0pXHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiB0b2dnbGVNb2R1bGUobW9kdWxlSWQpIHtcclxuICAgIHNldEV4cGFuZGVkTW9kdWxlSWRzKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IG5leHQgPSBuZXcgU2V0KHByZXYpXHJcbiAgICAgIGlmIChuZXh0Lmhhcyhtb2R1bGVJZCkpIG5leHQuZGVsZXRlKG1vZHVsZUlkKVxyXG4gICAgICBlbHNlIG5leHQuYWRkKG1vZHVsZUlkKVxyXG4gICAgICByZXR1cm4gbmV4dFxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIG1hcmtDb21wbGV0ZShwYWdlSWQpIHtcclxuICAgIG1hcmtQYWdlQ29tcGxldGUoY291cnNlLmlkLCBwYWdlSWQpLmNhdGNoKCgpID0+IHt9KVxyXG4gICAgc2V0Q29tcGxldGVkUGFnZUlkcygocHJldikgPT4gbmV3IFNldChwcmV2KS5hZGQocGFnZUlkKSlcclxuICB9XHJcblxyXG4gIC8vIFwiTmV4dFwiIGFkdmFuY2VzIHRocm91Z2ggcGFnZXMgaW4gcmVhZGluZyBvcmRlcjsgYXQgdGhlIGVuZCBvZiBhIG1vZHVsZVxyXG4gIC8vIGl0IHJvdXRlcyBpbnRvIHRoYXQgbW9kdWxlJ3MgUUNNIChpZiBhbnkgYW5kIG5vdCB5ZXQgcGFzc2VkKSBpbnN0ZWFkXHJcbiAgLy8gb2YgYSBwYWdlLCBhbmQgYXQgdGhlIHZlcnkgZW5kIG9mIHRoZSBjb3Vyc2UgaXQgc2hvd3MgYSBjb21wbGV0aW9uXHJcbiAgLy8gcGFuZWwgcG9pbnRpbmcgYXQgdGhlIGZpbmFsIGV4YW0uXHJcbiAgZnVuY3Rpb24gZ29OZXh0KGN1cnJlbnRQYWdlSWQpIHtcclxuICAgIG1hcmtDb21wbGV0ZShjdXJyZW50UGFnZUlkKVxyXG4gICAgY29uc3QgaW5kZXggPSBmbGF0LmZpbmRJbmRleCgoZikgPT4gZi5wYWdlLmlkID09PSBjdXJyZW50UGFnZUlkKVxyXG4gICAgY29uc3QgY3VycmVudCA9IGZsYXRbaW5kZXhdXHJcbiAgICBjb25zdCBuZXh0ID0gZmxhdFtpbmRleCArIDFdXHJcbiAgICBjb25zdCBsZWF2aW5nTW9kdWxlID0gIW5leHQgfHwgbmV4dC5tb2R1bGVJbmRleCAhPT0gY3VycmVudC5tb2R1bGVJbmRleFxyXG5cclxuICAgIGlmIChsZWF2aW5nTW9kdWxlICYmIGN1cnJlbnQubW9kdWxlLnF1aXogJiYgIWlzUXVpelBhc3NlZChtb2R1bGVRdWl6emVzW2N1cnJlbnQubW9kdWxlLmlkXSkpIHtcclxuICAgICAgZ29Ub1F1aXooY3VycmVudC5tb2R1bGUuaWQpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG4gICAgaWYgKG5leHQpIHtcclxuICAgICAgZ29Ub1BhZ2UobmV4dC5wYWdlLmlkKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuICAgIHNldFZpZXcoeyBraW5kOiAnZG9uZScgfSlcclxuICB9XHJcblxyXG4gIC8vIFwiUHJldmlvdXNcIiBqdXN0IHN0ZXBzIGJhY2sgaW4gcmVhZGluZyBvcmRlciDigJQgbm8gcXVpei1nYXRlIHRvIHdvcnJ5XHJcbiAgLy8gYWJvdXQgc2luY2UgYW55dGhpbmcgZWFybGllciB3YXMgYWxyZWFkeSB1bmxvY2tlZCB0byBnZXQgaGVyZS5cclxuICBmdW5jdGlvbiBnb1ByZXYoY3VycmVudFBhZ2VJZCkge1xyXG4gICAgY29uc3QgaW5kZXggPSBmbGF0LmZpbmRJbmRleCgoZikgPT4gZi5wYWdlLmlkID09PSBjdXJyZW50UGFnZUlkKVxyXG4gICAgY29uc3QgcHJldiA9IGZsYXRbaW5kZXggLSAxXVxyXG4gICAgaWYgKHByZXYpIGdvVG9QYWdlKHByZXYucGFnZS5pZClcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGhhbmRsZVF1aXpBdHRlbXB0KG1vZHVsZUlkLCBhdHRlbXB0KSB7XHJcbiAgICBzZXRNb2R1bGVRdWl6emVzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbW9kdWxlSWRdOiB7IC4uLmF0dGVtcHQgfSB9KSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGNvbnRpbnVlQWZ0ZXJRdWl6KG1vZHVsZUlkKSB7XHJcbiAgICBjb25zdCBtb2R1bGVJbmRleCA9IGNvdXJzZS5tb2R1bGVzLmZpbmRJbmRleCgobSkgPT4gbS5pZCA9PT0gbW9kdWxlSWQpXHJcbiAgICBjb25zdCBuZXh0TW9kdWxlID0gY291cnNlLm1vZHVsZXNbbW9kdWxlSW5kZXggKyAxXVxyXG4gICAgaWYgKG5leHRNb2R1bGUpIHtcclxuICAgICAgY29uc3QgZmlyc3RQYWdlID0gZmxhdC5maW5kKChmKSA9PiBmLm1vZHVsZUluZGV4ID09PSBtb2R1bGVJbmRleCArIDEpXHJcbiAgICAgIHNldEV4cGFuZGVkTW9kdWxlSWRzKChwcmV2KSA9PiBuZXcgU2V0KHByZXYpLmFkZChuZXh0TW9kdWxlLmlkKSlcclxuICAgICAgaWYgKGZpcnN0UGFnZSkgZ29Ub1BhZ2UoZmlyc3RQYWdlLnBhZ2UuaWQpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRWaWV3KHsga2luZDogJ2RvbmUnIH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBhY2NlbnRTdHlsZSA9IGNvdXJzZS5jb2xvclxyXG4gICAgPyB7XHJcbiAgICAgICAgJy0tY291cnNlLWFjY2VudCc6IGNvdXJzZS5jb2xvcixcclxuICAgICAgICAnLS1jb3Vyc2UtYWNjZW50LWhvdmVyJzogc2hhZGUoY291cnNlLmNvbG9yLCAtMTIpLFxyXG4gICAgICAgICctLWNvdXJzZS1hY2NlbnQtdGV4dCc6IGNvbnRyYXN0VGV4dChjb3Vyc2UuY29sb3IpLFxyXG4gICAgICB9XHJcbiAgICA6IHVuZGVmaW5lZFxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItdGhlbWVcIiBzdHlsZT17YWNjZW50U3R5bGV9PlxyXG4gICAgICA8UmVhZGVyU2hlbGxcclxuICAgICAgICBjb3Vyc2U9e2NvdXJzZX1cclxuICAgICAgICBsZWFybmluZ1BjdD17bGVhcm5pbmcucGN0fVxyXG4gICAgICAgIGV4cGFuZGVkTW9kdWxlSWRzPXtleHBhbmRlZE1vZHVsZUlkc31cclxuICAgICAgICBvblRvZ2dsZU1vZHVsZT17dG9nZ2xlTW9kdWxlfVxyXG4gICAgICAgIGlzTW9kdWxlTG9ja2VkPXttb2R1bGVMb2NrZWR9XHJcbiAgICAgICAgaXNQYWdlQ29tcGxldGU9eyhpZCkgPT4gY29tcGxldGVkUGFnZUlkcy5oYXMoaWQpfVxyXG4gICAgICAgIGlzTW9kdWxlUGFnZXNDb21wbGV0ZT17bW9kdWxlUGFnZXNDb21wbGV0ZX1cclxuICAgICAgICBpc01vZHVsZVF1aXpQYXNzZWQ9e21vZHVsZVF1aXpQYXNzZWR9XHJcbiAgICAgICAgYWN0aXZlS2luZD17dmlldy5raW5kfVxyXG4gICAgICAgIGFjdGl2ZVBhZ2VJZD17dmlldy5raW5kID09PSAncGFnZScgPyB2aWV3LnBhZ2VJZCA6IG51bGx9XHJcbiAgICAgICAgYWN0aXZlTW9kdWxlSWQ9e3ZpZXcua2luZCA9PT0gJ3F1aXonID8gdmlldy5tb2R1bGVJZCA6IG51bGx9XHJcbiAgICAgICAgb25TZWxlY3RQYWdlPXtnb1RvUGFnZX1cclxuICAgICAgICBvblNlbGVjdFF1aXo9e2dvVG9RdWl6fVxyXG4gICAgICAgIGFsbE1vZHVsZXNEb25lPXthbGxNb2R1bGVzRG9uZX1cclxuICAgICAgPlxyXG4gICAgICAgIHt2aWV3LmtpbmQgPT09ICdwYWdlJyAmJiAoXHJcbiAgICAgICAgICA8UGFnZVZpZXdcclxuICAgICAgICAgICAga2V5PXt2aWV3LnBhZ2VJZH1cclxuICAgICAgICAgICAgY291cnNlPXtjb3Vyc2V9XHJcbiAgICAgICAgICAgIGVudHJ5PXtmbGF0LmZpbmQoKGYpID0+IGYucGFnZS5pZCA9PT0gdmlldy5wYWdlSWQpfVxyXG4gICAgICAgICAgICBwYWdlTnVtYmVyPXtmbGF0LmZpbmRJbmRleCgoZikgPT4gZi5wYWdlLmlkID09PSB2aWV3LnBhZ2VJZCkgKyAxfVxyXG4gICAgICAgICAgICB0b3RhbFBhZ2VzPXtmbGF0Lmxlbmd0aH1cclxuICAgICAgICAgICAgY29tcGxldGVkPXtjb21wbGV0ZWRQYWdlSWRzLmhhcyh2aWV3LnBhZ2VJZCl9XHJcbiAgICAgICAgICAgIGhhc1ByZXY9e2ZsYXQuZmluZEluZGV4KChmKSA9PiBmLnBhZ2UuaWQgPT09IHZpZXcucGFnZUlkKSA+IDB9XHJcbiAgICAgICAgICAgIG9uTWFya0NvbXBsZXRlPXsoKSA9PiBtYXJrQ29tcGxldGUodmlldy5wYWdlSWQpfVxyXG4gICAgICAgICAgICBvbk5leHQ9eygpID0+IGdvTmV4dCh2aWV3LnBhZ2VJZCl9XHJcbiAgICAgICAgICAgIG9uUHJldj17KCkgPT4gZ29QcmV2KHZpZXcucGFnZUlkKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge3ZpZXcua2luZCA9PT0gJ3F1aXonICYmIGJhY2tkcm9wUGFnZUlkICYmIChcclxuICAgICAgICAgIDxQYWdlVmlld1xyXG4gICAgICAgICAgICBrZXk9e2JhY2tkcm9wUGFnZUlkfVxyXG4gICAgICAgICAgICBjb3Vyc2U9e2NvdXJzZX1cclxuICAgICAgICAgICAgZW50cnk9e2ZsYXQuZmluZCgoZikgPT4gZi5wYWdlLmlkID09PSBiYWNrZHJvcFBhZ2VJZCl9XHJcbiAgICAgICAgICAgIHBhZ2VOdW1iZXI9e2ZsYXQuZmluZEluZGV4KChmKSA9PiBmLnBhZ2UuaWQgPT09IGJhY2tkcm9wUGFnZUlkKSArIDF9XHJcbiAgICAgICAgICAgIHRvdGFsUGFnZXM9e2ZsYXQubGVuZ3RofVxyXG4gICAgICAgICAgICBjb21wbGV0ZWQ9e2NvbXBsZXRlZFBhZ2VJZHMuaGFzKGJhY2tkcm9wUGFnZUlkKX1cclxuICAgICAgICAgICAgaW50ZXJhY3RpdmU9e2ZhbHNlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7dmlldy5raW5kID09PSAnZG9uZScgJiYgYmFja2Ryb3BQYWdlSWQgJiYgKFxyXG4gICAgICAgICAgPFBhZ2VWaWV3XHJcbiAgICAgICAgICAgIGtleT17YmFja2Ryb3BQYWdlSWR9XHJcbiAgICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgICBlbnRyeT17ZmxhdC5maW5kKChmKSA9PiBmLnBhZ2UuaWQgPT09IGJhY2tkcm9wUGFnZUlkKX1cclxuICAgICAgICAgICAgcGFnZU51bWJlcj17ZmxhdC5maW5kSW5kZXgoKGYpID0+IGYucGFnZS5pZCA9PT0gYmFja2Ryb3BQYWdlSWQpICsgMX1cclxuICAgICAgICAgICAgdG90YWxQYWdlcz17ZmxhdC5sZW5ndGh9XHJcbiAgICAgICAgICAgIGNvbXBsZXRlZD17Y29tcGxldGVkUGFnZUlkcy5oYXMoYmFja2Ryb3BQYWdlSWQpfVxyXG4gICAgICAgICAgICBpbnRlcmFjdGl2ZT17ZmFsc2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvUmVhZGVyU2hlbGw+XHJcblxyXG4gICAgICB7dmlldy5raW5kID09PSAncXVpeicgJiYgKFxyXG4gICAgICAgIDxRdWl6TW9kYWxcclxuICAgICAgICAgIGtleT17dmlldy5tb2R1bGVJZH1cclxuICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgY291cnNlTW9kdWxlPXtjb3Vyc2UubW9kdWxlcy5maW5kKChtKSA9PiBtLmlkID09PSB2aWV3Lm1vZHVsZUlkKX1cclxuICAgICAgICAgIHByZXZpb3VzQXR0ZW1wdD17bW9kdWxlUXVpenplc1t2aWV3Lm1vZHVsZUlkXX1cclxuICAgICAgICAgIG9uQXR0ZW1wdD17KGF0dGVtcHQpID0+IGhhbmRsZVF1aXpBdHRlbXB0KHZpZXcubW9kdWxlSWQsIGF0dGVtcHQpfVxyXG4gICAgICAgICAgcGFzc2VkPXtpc1F1aXpQYXNzZWQobW9kdWxlUXVpenplc1t2aWV3Lm1vZHVsZUlkXSl9XHJcbiAgICAgICAgICBvbkNvbnRpbnVlPXsoKSA9PiBjb250aW51ZUFmdGVyUXVpeih2aWV3Lm1vZHVsZUlkKX1cclxuICAgICAgICAgIG9uQ2xvc2U9e2Nsb3NlUXVpek1vZGFsfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dmlldy5raW5kID09PSAnZG9uZScgJiYgKFxyXG4gICAgICAgIDxDb3Vyc2VEb25lTW9kYWxcclxuICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgYWxsTW9kdWxlc0RvbmU9e2FsbE1vZHVsZXNEb25lfVxyXG4gICAgICAgICAgb25DbG9zZT17Y2xvc2VRdWl6TW9kYWx9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gUGFnZVZpZXcoe1xyXG4gIGVudHJ5LFxyXG4gIHBhZ2VOdW1iZXIsXHJcbiAgdG90YWxQYWdlcyxcclxuICBjb21wbGV0ZWQsXHJcbiAgaGFzUHJldixcclxuICBvbk1hcmtDb21wbGV0ZSxcclxuICBvbk5leHQsXHJcbiAgb25QcmV2LFxyXG4gIGludGVyYWN0aXZlID0gdHJ1ZSxcclxufSkge1xyXG4gIGlmICghZW50cnkpIHJldHVybiBudWxsXHJcbiAgY29uc3QgeyBwYWdlOiBjb3Vyc2VQYWdlLCBjaGFwdGVyLCBtb2R1bGU6IGNvdXJzZU1vZHVsZSB9ID0gZW50cnlcclxuICBjb25zdCBwYWdlUGN0ID0gdG90YWxQYWdlcyA/IE1hdGgucm91bmQoKHBhZ2VOdW1iZXIgLyB0b3RhbFBhZ2VzKSAqIDEwMCkgOiAwXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bW90aW9uLmFydGljbGVcclxuICAgICAgY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UgY29udGVudC1jYXJkXCJcclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA2IH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxyXG4gICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItcGFnZS10b29sYmFyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItcGFnZS10b29sYmFyLXRvcFwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtdG9vbGJhci1wb3NpdGlvblwiPlxyXG4gICAgICAgICAgICBQYWdlIHtwYWdlTnVtYmVyfSBvZiB7dG90YWxQYWdlc31cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIHtpbnRlcmFjdGl2ZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtdG9vbGJhci1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWFkZXItdG9vbGJhci1idXR0b25cIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFoYXNQcmV2fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25QcmV2fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTV9IC8+IFByZXZpb3VzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgeyFjb21wbGV0ZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmVhZGVyLXRvb2xiYXItYnV0dG9uXCIgb25DbGljaz17b25NYXJrQ29tcGxldGV9PlxyXG4gICAgICAgICAgICAgICAgICA8Q2hlY2tTcXVhcmUgc2l6ZT17MTV9IC8+IE1hcmsgYXMgcmVhZFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJyZWFkZXItdG9vbGJhci1idXR0b24gcmVhZGVyLXRvb2xiYXItYnV0dG9uLXByaW1hcnlcIiBvbkNsaWNrPXtvbk5leHR9PlxyXG4gICAgICAgICAgICAgICAge2NvbXBsZXRlZCA/ICdDb250aW51ZScgOiAnTWFyayByZWFkICYgY29udGludWUnfSA8QXJyb3dSaWdodCBzaXplPXsxNX0gLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtdG9vbGJhci10cmFja1wiPlxyXG4gICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtdG9vbGJhci1maWxsXCJcclxuICAgICAgICAgICAgaW5pdGlhbD17ZmFsc2V9XHJcbiAgICAgICAgICAgIGFuaW1hdGU9e3sgd2lkdGg6IGAke3BhZ2VQY3R9JWAgfX1cclxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4zLCBlYXNlOiAnZWFzZU91dCcgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtZXllYnJvd1wiPlxyXG4gICAgICAgIHtjb3Vyc2VNb2R1bGUudGl0bGV9IMK3IHtjaGFwdGVyLnRpdGxlfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICAgIDxoMT57Y291cnNlUGFnZS50aXRsZX08L2gxPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlYWRlci1wYWdlLWJvZHlcIj5cclxuICAgICAgICB7Y291cnNlUGFnZS5jb250ZW50LnNwbGl0KCdcXG5cXG4nKS5tYXAoKHBhcmFncmFwaCwgaSkgPT4gKFxyXG4gICAgICAgICAgPHAga2V5PXtpfT57cGFyYWdyYXBofTwvcD5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L21vdGlvbi5hcnRpY2xlPlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gUXVpek1vZGFsKHsgY291cnNlLCBjb3Vyc2VNb2R1bGUsIHByZXZpb3VzQXR0ZW1wdCwgb25BdHRlbXB0LCBwYXNzZWQsIG9uQ29udGludWUsIG9uQ2xvc2UgfSkge1xyXG4gIGlmICghY291cnNlTW9kdWxlPy5xdWl6KSByZXR1cm4gbnVsbFxyXG4gIHJldHVybiAoXHJcbiAgICA8QW5pbWF0ZVByZXNlbmNlPlxyXG4gICAgICA8bW90aW9uLmRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT1cInF1aXotbW9kYWwtYmFja2Ryb3BcIlxyXG4gICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxyXG4gICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCB9fVxyXG4gICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgID5cclxuICAgICAgICA8bW90aW9uLmRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicXVpei1tb2RhbCBjb250ZW50LWNhcmQgbW9kdWxlLXF1aXotcGFuZWxcIlxyXG4gICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxNiwgc2NhbGU6IDAuOTcgfX1cclxuICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCwgc2NhbGU6IDEgfX1cclxuICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeTogMTYsIHNjYWxlOiAwLjk3IH19XHJcbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIsIGVhc2U6ICdlYXNlT3V0JyB9fVxyXG4gICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicXVpei1tb2RhbC1jbG9zZVwiIGFyaWEtbGFiZWw9XCJDbG9zZSBxdWl6XCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWFkZXItcGFnZS1leWVicm93XCI+e2NvdXJzZU1vZHVsZS50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICA8aDE+TW9kdWxlIFFDTTwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyZWFkZXItcXVpei1pbnRyb1wiPlBhc3MgdGhpcyB0byB1bmxvY2sgdGhlIG5leHQgbW9kdWxlLjwvcD5cclxuICAgICAgICAgIDxRdWl6XHJcbiAgICAgICAgICAgIHF1aXo9e2NvdXJzZU1vZHVsZS5xdWl6fVxyXG4gICAgICAgICAgICBjb3Vyc2VJZD17Y291cnNlLmlkfVxyXG4gICAgICAgICAgICBtb2R1bGVJZD17Y291cnNlTW9kdWxlLmlkfVxyXG4gICAgICAgICAgICBwcmV2aW91c0F0dGVtcHQ9e3ByZXZpb3VzQXR0ZW1wdH1cclxuICAgICAgICAgICAgb25BdHRlbXB0PXtvbkF0dGVtcHR9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAge3Bhc3NlZCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInJlYWRlci1uZXh0LWJ1dHRvblwiIG9uQ2xpY2s9e29uQ29udGludWV9PlxyXG4gICAgICAgICAgICAgIENvbnRpbnVlIDxBcnJvd1JpZ2h0IHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICA8L21vdGlvbi5kaXY+XHJcbiAgICA8L0FuaW1hdGVQcmVzZW5jZT5cclxuICApXHJcbn1cclxuXHJcbi8vIEJpZywga2lkLWZyaWVuZGx5IFwieW91IGRpZCBpdCFcIiBjZWxlYnJhdGlvbiDigJQgcG9wcyB1cCBhcyBhIG1vZGFsIChzYW1lXHJcbi8vIHBhdHRlcm4gYXMgUXVpek1vZGFsKSB0aGUgbW9tZW50IGV2ZXJ5IG1vZHVsZSArIFFDTSBpbiB0aGUgY291cnNlIGlzXHJcbi8vIGRvbmUsIHdpdGggYSBib3VuY3kgYmFkZ2UgYW5kIGEgY29uZmV0dGkgYnVyc3Qgc28gZmluaXNoaW5nIGEgY291cnNlXHJcbi8vIGZlZWxzIGxpa2UgYW4gZXZlbnQsIG5vdCBqdXN0IGEgc3RhdHVzIGxpbmUgY2hhbmdpbmcuXHJcbmNvbnN0IENIRUVSX0xJTkVTID0gW1xyXG4gIFwiWW91IGNydXNoZWQgaXQhIPCfjolcIixcclxuICBcIkxvb2sgYXQgeW91IGdvISDwn5qAXCIsXHJcbiAgXCJTdXBlcnN0YXIgbW92ZSEg8J+Mn1wiLFxyXG4gIFwiQm9vbSDigJQgbmFpbGVkIGl0ISDwn5KlXCIsXHJcbiAgXCJZb3UncmUgb24gZmlyZSEg8J+UpVwiLFxyXG5dXHJcblxyXG5mdW5jdGlvbiBDb3Vyc2VEb25lTW9kYWwoeyBjb3Vyc2UsIGFsbE1vZHVsZXNEb25lLCBvbkNsb3NlIH0pIHtcclxuICBjb25zdCBbY2hlZXJdID0gdXNlU3RhdGUoKCkgPT4gQ0hFRVJfTElORVNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogQ0hFRVJfTElORVMubGVuZ3RoKV0pXHJcbiAgcmV0dXJuIChcclxuICAgIDxBbmltYXRlUHJlc2VuY2U+XHJcbiAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPVwicXVpei1tb2RhbC1iYWNrZHJvcFwiXHJcbiAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XHJcbiAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgPlxyXG4gICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJxdWl6LW1vZGFsIGNvbnRlbnQtY2FyZCBjb3Vyc2UtZG9uZS1tb2RhbFwiXHJcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDI0LCBzY2FsZTogMC45IH19XHJcbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAsIHNjYWxlOiAxIH19XHJcbiAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDE2LCBzY2FsZTogMC45NSB9fVxyXG4gICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgc3RpZmZuZXNzOiAyNjAsIGRhbXBpbmc6IDE4IH19XHJcbiAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJxdWl6LW1vZGFsLWNsb3NlXCIgYXJpYS1sYWJlbD1cIkNsb3NlXCIgb25DbGljaz17b25DbG9zZX0+XHJcbiAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgPERvbmVDb25mZXR0aSAvPlxyXG5cclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvdXJzZS1kb25lLWJhZGdlXCJcclxuICAgICAgICAgICAgaW5pdGlhbD17eyBzY2FsZTogMCwgcm90YXRlOiAtMTUgfX1cclxuICAgICAgICAgICAgYW5pbWF0ZT17eyBzY2FsZTogMSwgcm90YXRlOiAwIH19XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgdHlwZTogJ3NwcmluZycsIHN0aWZmbmVzczogMzIwLCBkYW1waW5nOiAxMiwgZGVsYXk6IDAuMSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8UGFydHlQb3BwZXIgc2l6ZT17MzZ9IC8+XHJcbiAgICAgICAgICA8L21vdGlvbi5kaXY+XHJcblxyXG4gICAgICAgICAgPG1vdGlvbi5oMVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjb3Vyc2UtZG9uZS10aXRsZVwiXHJcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogOCB9fVxyXG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cclxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC4yIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtjaGVlcn1cclxuICAgICAgICAgIDwvbW90aW9uLmgxPlxyXG4gICAgICAgICAgPG1vdGlvbi5wXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImNvdXJzZS1kb25lLWNhcHRpb25cIlxyXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cclxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMyB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBZb3UgZmluaXNoZWQgZXZlcnkgbW9kdWxlIGFuZCBwYXNzZWQgZXZlcnkgcXVpeiBpbiA8c3Ryb25nPntjb3Vyc2UudGl0bGV9PC9zdHJvbmc+LiBUaGF0J3NcclxuICAgICAgICAgICAgcmVhbCB3b3JrIOKAlCBiZSBwcm91ZCBvZiBpdCFcclxuICAgICAgICAgIDwvbW90aW9uLnA+XHJcblxyXG4gICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY291cnNlLWRvbmUtYWN0aW9uc1wiXHJcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogOCB9fVxyXG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cclxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC40IH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHthbGxNb2R1bGVzRG9uZSAmJiBjb3Vyc2UuZmluYWxFeGFtID8gKFxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2NvdXJzZXMvJHtjb3Vyc2Uuc2x1Z30vZXhhbWB9IGNsYXNzTmFtZT1cImNvbnRpbnVlLWNhcmQtY3RhXCI+XHJcbiAgICAgICAgICAgICAgICA8R3JhZHVhdGlvbkNhcCBzaXplPXsxNn0gLz4gVGFrZSB0aGUgZmluYWwgZXhhbVxyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoaW50XCI+VGhpcyBjb3Vyc2UgZG9lc24ndCBoYXZlIGEgZmluYWwgZXhhbS48L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L21vdGlvbi5kaXY+XHJcbiAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICA8L21vdGlvbi5kaXY+XHJcbiAgICA8L0FuaW1hdGVQcmVzZW5jZT5cclxuICApXHJcbn1cclxuXHJcbi8vIENoZWFwIENTUy1vbmx5IGNvbmZldHRpIGJ1cnN0LCBzYW1lIHRyaWNrIGFzIEV4YW1QYWdlJ3MgQ29uZmV0dGkg4oCUIGFcclxuLy8gaGFuZGZ1bCBvZiBhYnNvbHV0ZWx5IHBvc2l0aW9uZWQgZG90cyBhbmltYXRpbmcgb3V0d2FyZCArIGZhZGluZy5cclxuZnVuY3Rpb24gRG9uZUNvbmZldHRpKCkge1xyXG4gIGNvbnN0IFtwaWVjZXNdID0gdXNlU3RhdGUoKCkgPT5cclxuICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IDI0IH0sIChfLCBpKSA9PiAoe1xyXG4gICAgICBpZDogaSxcclxuICAgICAgeDogKE1hdGgucmFuZG9tKCkgLSAwLjUpICogMzYwLFxyXG4gICAgICB5OiBNYXRoLnJhbmRvbSgpICogLTI4MCAtIDQwLFxyXG4gICAgICByb3RhdGU6IE1hdGgucmFuZG9tKCkgKiAzNjAsXHJcbiAgICAgIGNvbG9yOiBbJyM0ZjQ2ZTUnLCAnI2Y1OWUwYicsICcjMjJjNTVlJywgJyNlYzQ4OTknLCAnIzA2YjZkNCddW2kgJSA1XSxcclxuICAgICAgZGVsYXk6IE1hdGgucmFuZG9tKCkgKiAwLjI1LFxyXG4gICAgfSkpLFxyXG4gIClcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb25mZXR0aSBjb3Vyc2UtZG9uZS1jb25mZXR0aVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICB7cGllY2VzLm1hcCgocCkgPT4gKFxyXG4gICAgICAgIDxtb3Rpb24uc3BhblxyXG4gICAgICAgICAga2V5PXtwLmlkfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY29uZmV0dGktcGllY2VcIlxyXG4gICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogcC5jb2xvciB9fVxyXG4gICAgICAgICAgaW5pdGlhbD17eyB4OiAwLCB5OiAwLCBvcGFjaXR5OiAxLCByb3RhdGU6IDAgfX1cclxuICAgICAgICAgIGFuaW1hdGU9e3sgeDogcC54LCB5OiBwLnksIG9wYWNpdHk6IDAsIHJvdGF0ZTogcC5yb3RhdGUgfX1cclxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDEuMiwgZGVsYXk6IHAuZGVsYXksIGVhc2U6ICdlYXNlT3V0JyB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBSZWFkZXJTa2VsZXRvbigpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItc2hlbGxcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItdG9wYmFyXCI+XHJcbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNnJlbVwiIGhlaWdodD1cIjAuOXJlbVwiIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlYWRlci1ib2R5XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItc2lkZWJhclwiPlxyXG4gICAgICAgICAgPFNrZWxldG9uIGhlaWdodD1cIjEuNXJlbVwiIC8+XHJcbiAgICAgICAgICA8U2tlbGV0b24gaGVpZ2h0PVwiMS41cmVtXCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiBoZWlnaHQ9XCIxLjVyZW1cIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZGVyLWNvbnRlbnRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudC1jYXJkIHNrZWxldG9uLWJsb2NrXCI+XHJcbiAgICAgICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjQwJVwiIGhlaWdodD1cIjEuMnJlbVwiIC8+XHJcbiAgICAgICAgICAgIDxTa2VsZXRvbiAvPlxyXG4gICAgICAgICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNzAlXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXX0=