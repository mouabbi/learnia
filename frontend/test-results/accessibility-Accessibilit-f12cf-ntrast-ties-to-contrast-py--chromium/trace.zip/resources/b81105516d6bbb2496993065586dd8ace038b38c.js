import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DashboardPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { ArrowRight, BookOpen, Flame, Trophy, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { dashboardApi } from "/src/features/dashboard/dashboardApi.js";
import { CourseCard, CourseCardSkeleton } from "/src/features/courses/CourseCard.jsx?t=1790187136361";
import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/DashboardPage.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Landing view built from ONE aggregation call (GET /api/v1/dashboard — see
// backend/src/learnia_backend/routers/dashboard.py): a "continue learning"
// card, the full course grid (with this user's own progress on each),
// simple rule-based recommendations, and basic counts. No time-tracking in
// v1 — stats are counts/percentages only (see generated-prompts/
// 17-dashboard/prompts.md's resolved open questions).
//
// Self-contained: does not assume it's mounted at any particular route (see
// this file's own history/PR for the suggested route).
export function DashboardPage() {
	_s();
	const [data, setData] = useState(null);
	const [error, setError] = useState(false);
	useEffect(() => {
		let cancelled = false;
		dashboardApi.getDashboard().then((res) => {
			if (!cancelled) setData(res);
		}).catch((err) => {
			if (cancelled) return;
			console.error("Failed to load dashboard", err);
			setError(true);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home",
		children: [
			/* @__PURE__ */ _jsxDEV("section", {
				className: "content-card home-hello",
				children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Dashboard" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Your courses, progress, and what to learn next." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "hint courses-empty",
				children: "Couldn't load your dashboard. Try refreshing."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this),
			data && /* @__PURE__ */ _jsxDEV(StatsRow, { stats: data.stats }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 16
			}, this),
			data === null && !error && /* @__PURE__ */ _jsxDEV(ContinueCardSkeleton, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 35
			}, this),
			data?.continueLearning && /* @__PURE__ */ _jsxDEV(ContinueLearningCard, { entry: data.continueLearning }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 34
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "home-section",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "home-section-header",
					children: /* @__PURE__ */ _jsxDEV("h2", { children: "Your courses" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "course-grid",
					children: [
						data === null && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this),
						data?.courses.map((course, index) => /* @__PURE__ */ _jsxDEV(motion.div, {
							initial: {
								opacity: 0,
								y: 8
							},
							animate: {
								opacity: 1,
								y: 0
							},
							transition: { delay: index * .05 },
							children: /* @__PURE__ */ _jsxDEV(CourseCard, {
								course,
								progressPct: course.progressPct
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 15
							}, this)
						}, course.id, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this)),
						data && data.courses.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
							className: "hint courses-empty",
							children: "No courses published yet."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			data && data.recommendations.length > 0 && /* @__PURE__ */ _jsxDEV("section", {
				className: "home-section",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "home-section-header",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Recommended for you" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/courses",
						className: "home-see-all",
						children: ["See all ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 23
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "course-grid",
					children: data.recommendations.map((course, index) => /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 8
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: index * .05 },
						children: /* @__PURE__ */ _jsxDEV(CourseCard, { course }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 17
						}, this)
					}, course.id, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s(DashboardPage, "dY3p1imSHEXvLIZkgi2c26/BYFw=");
_c = DashboardPage;
function ContinueLearningCard({ entry }) {
	const { course, progressPct, lastPageTitle } = entry;
	const complete = progressPct >= 100;
	const resumeHref = `/courses/${course.slug}/learn`;
	return /* @__PURE__ */ _jsxDEV(motion.section, {
		className: `continue-card continue-card-hero${complete ? " continue-card-complete" : ""}`,
		initial: {
			opacity: 0,
			y: 8
		},
		animate: {
			opacity: 1,
			y: 0
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "continue-card-hero-top",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: `continue-card-icon${course.image ? " continue-card-icon-image" : ""}`,
					children: course.image ? /* @__PURE__ */ _jsxDEV("img", {
						src: course.image,
						alt: "",
						className: "continue-card-icon-img"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 13
					}, this) : complete ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 26 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(BookOpen, { size: 26 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "continue-card-body",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "continue-card-eyebrow",
							children: complete ? "Course complete" : "Continue learning"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: course.title }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 11
						}, this),
						complete ? /* @__PURE__ */ _jsxDEV("p", { children: "Every page done." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this) : lastPageTitle && /* @__PURE__ */ _jsxDEV("p", { children: ["Next up: ", lastPageTitle] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 30
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "continue-card-hero-actions",
					children: /* @__PURE__ */ _jsxDEV("a", {
						href: resumeHref,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "continue-card-cta",
						children: [
							complete ? "Review" : "Resume",
							" ",
							/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 46
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "chapter-track",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "chapter-track-header",
				children: /* @__PURE__ */ _jsxDEV("span", { children: [progressPct, "% complete"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "course-card-progress-track",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: `course-card-progress-fill${complete ? " course-card-progress-fill-done" : ""}`,
					style: { width: `${progressPct}%` }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 5
	}, this);
}
_c2 = ContinueLearningCard;
function ContinueCardSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "continue-card continue-card-skeleton",
		children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
			circle: true,
			width: "3rem",
			height: "3rem"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 164,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "continue-card-body",
			children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "30%",
				height: "0.75rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 166,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "55%",
				height: "1.2rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 165,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 163,
		columnNumber: 5
	}, this);
}
_c3 = ContinueCardSkeleton;
function StatsRow({ stats }) {
	const items = [
		{
			icon: Flame,
			label: "In progress",
			value: stats.inProgressCount
		},
		{
			icon: Trophy,
			label: "Completed",
			value: stats.completedCount
		},
		{
			icon: BookOpen,
			label: "Courses available",
			value: stats.totalCount
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "stats-strip",
		children: items.map(({ icon: Icon, label, value }) => /* @__PURE__ */ _jsxDEV("div", {
			className: "stat-tile",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "stat-tile-icon",
				children: /* @__PURE__ */ _jsxDEV(Icon, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "stat-tile-value",
				children: value
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "stat-tile-label",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 188,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 186,
				columnNumber: 11
			}, this)]
		}, label, true, {
			fileName: _jsxFileName,
			lineNumber: 182,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 180,
		columnNumber: 5
	}, this);
}
_c4 = StatsRow;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "DashboardPage");
$RefreshReg$(_c2, "ContinueLearningCard");
$RefreshReg$(_c3, "ContinueCardSkeleton");
$RefreshReg$(_c4, "StatsRow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/DashboardPage.jsx?t=1790187136361";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/DashboardPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/DashboardPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/DashboardPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLFlBQVk7QUFDckIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsWUFBWSxVQUFVLE9BQU8sUUFBUSxvQkFBb0I7QUFDbEUsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxZQUFZLDBCQUEwQjtBQUMvQyxTQUFTLGdCQUFnQjs7Ozs7Ozs7Ozs7OztBQVd6QixPQUFPLFNBQVMsZ0JBQWdCOztDQUM5QixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsSUFBSTtDQUNyQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsS0FBSztDQUV4QyxnQkFBZ0I7RUFDZCxJQUFJLFlBQVk7RUFDaEIsYUFBYSxhQUFhLENBQUMsQ0FBQyxNQUFNLFFBQVE7R0FDeEMsSUFBSSxDQUFDLFdBQVcsUUFBUSxHQUFHO0VBQzdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUTtHQUNoQixJQUFJLFdBQVc7R0FDZixRQUFRLE1BQU0sNEJBQTRCLEdBQUc7R0FDN0MsU0FBUyxJQUFJO0VBQ2YsQ0FBQztFQUNELGFBQWE7R0FDWCxZQUFZO0VBQ2Q7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFlBQWE7Ozs7Y0FDakIsd0JBQUMsS0FBRCxZQUFHLGtEQUFrRDs7OztZQUM5Qzs7Ozs7O0dBRVIsU0FDQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFxQjtHQUFnRDs7Ozs7R0FHbkYsUUFBUSx3QkFBQyxVQUFELEVBQVUsT0FBTyxLQUFLLE1BQVE7Ozs7O0dBRXRDLFNBQVMsUUFBUSxDQUFDLFNBQVMsd0JBQUMsc0JBQUQsQ0FBdUI7Ozs7O0dBQ2xELE1BQU0sb0JBQW9CLHdCQUFDLHNCQUFELEVBQXNCLE9BQU8sS0FBSyxpQkFBbUI7Ozs7O0dBRWhGLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxNQUFELFlBQUksZUFBZ0I7Ozs7O0lBQ2pCOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNHLFNBQVMsUUFDUixnREFDRSx3QkFBQyxvQkFBRCxDQUFxQjs7OztnQkFDckIsd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7Y0FDckI7Ozs7O01BRUgsTUFBTSxRQUFRLEtBQUssUUFBUSxVQUMxQix3QkFBQyxPQUFPLEtBQVI7T0FFRSxTQUFTO1FBQUUsU0FBUztRQUFHLEdBQUc7T0FBRTtPQUM1QixTQUFTO1FBQUUsU0FBUztRQUFHLEdBQUc7T0FBRTtPQUM1QixZQUFZLEVBQUUsT0FBTyxRQUFRLElBQUs7aUJBRWxDLHdCQUFDLFlBQUQ7UUFBb0I7UUFBUSxhQUFhLE9BQU87T0FBYzs7Ozs7TUFDcEQsR0FOTCxPQUFPOzs7O2FBTUYsQ0FDYjtNQUNBLFFBQVEsS0FBSyxRQUFRLFdBQVcsS0FDL0Isd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXFCO01BQTRCOzs7OztLQUU3RDs7Ozs7WUFDRTs7Ozs7O0dBRVIsUUFBUSxLQUFLLGdCQUFnQixTQUFTLEtBQ3JDLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7ZUFDM0Isd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBVyxXQUFVO2dCQUE5QixDQUE2QyxZQUNuQyx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O2NBQzNCOzs7OzthQUNIOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osS0FBSyxnQkFBZ0IsS0FBSyxRQUFRLFVBQ2pDLHdCQUFDLE9BQU8sS0FBUjtNQUVFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLFlBQVksRUFBRSxPQUFPLFFBQVEsSUFBSztnQkFFbEMsd0JBQUMsWUFBRCxFQUFvQixPQUFTOzs7OztLQUNuQixHQU5MLE9BQU87Ozs7WUFNRixDQUNiO0lBQ0U7Ozs7WUFDRTs7Ozs7O0VBRVI7Ozs7OztBQUVUOzs7QUFFQSxTQUFTLHFCQUFxQixFQUFFLFNBQVM7Q0FDdkMsTUFBTSxFQUFFLFFBQVEsYUFBYSxrQkFBa0I7Q0FDL0MsTUFBTSxXQUFXLGVBQWU7Q0FDaEMsTUFBTSxhQUFhLFlBQVksT0FBTyxLQUFLO0NBRTNDLE9BQ0Usd0JBQUMsT0FBTyxTQUFSO0VBQ0UsV0FBVyxtQ0FBbUMsV0FBVyw0QkFBNEI7RUFDckYsU0FBUztHQUFFLFNBQVM7R0FBRyxHQUFHO0VBQUU7RUFDNUIsU0FBUztHQUFFLFNBQVM7R0FBRyxHQUFHO0VBQUU7WUFIOUIsQ0FLRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVcscUJBQXFCLE9BQU8sUUFBUSw4QkFBOEI7ZUFDL0UsT0FBTyxRQUNOLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLE9BQU87TUFBTyxLQUFJO01BQUcsV0FBVTtLQUEwQjs7OztnQkFDakUsV0FDRix3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2dCQUV6Qix3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztJQUVwQjs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsV0FBVyxvQkFBb0I7TUFDNUI7Ozs7O01BQ04sd0JBQUMsTUFBRCxZQUFLLE9BQU8sTUFBVTs7Ozs7TUFDckIsV0FDQyx3QkFBQyxLQUFELFlBQUcsbUJBQW1COzs7O2lCQUV0QixpQkFBaUIsd0JBQUMsS0FBRCxhQUFHLGFBQVUsYUFBaUI7Ozs7O0tBRTlDOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUdiLHdCQUFDLEtBQUQ7TUFBRyxNQUFNO01BQVksUUFBTztNQUFTLEtBQUk7TUFBc0IsV0FBVTtnQkFBekU7T0FDRyxXQUFXLFdBQVc7T0FBUztPQUFDLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O01BQ3ZEOzs7Ozs7SUFDQTs7Ozs7R0FDRjs7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxRQUFELGFBQU8sYUFBWSxZQUFnQjs7Ozs7R0FDaEM7Ozs7YUFDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FDRSxXQUFXLDRCQUE0QixXQUFXLG9DQUFvQztLQUN0RixPQUFPLEVBQUUsT0FBTyxHQUFHLFlBQVksR0FBRztJQUNuQzs7Ozs7R0FDRTs7OztXQUNGOzs7OztVQUNTOzs7Ozs7QUFFcEI7O0FBRUEsU0FBUyx1QkFBdUI7Q0FDOUIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsVUFBRDtHQUFVO0dBQU8sT0FBTTtHQUFPLFFBQU87RUFBUTs7OztZQUM3Qyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsVUFBRDtJQUFVLE9BQU07SUFBTSxRQUFPO0dBQVc7Ozs7YUFDeEMsd0JBQUMsVUFBRDtJQUFVLE9BQU07SUFBTSxRQUFPO0dBQVU7Ozs7V0FDcEM7Ozs7O1VBQ0Y7Ozs7OztBQUVUOztBQUVBLFNBQVMsU0FBUyxFQUFFLFNBQVM7Q0FDM0IsTUFBTSxRQUFRO0VBQ1o7R0FBRSxNQUFNO0dBQU8sT0FBTztHQUFlLE9BQU8sTUFBTTtFQUFnQjtFQUNsRTtHQUFFLE1BQU07R0FBUSxPQUFPO0dBQWEsT0FBTyxNQUFNO0VBQWU7RUFDaEU7R0FBRSxNQUFNO0dBQVUsT0FBTztHQUFxQixPQUFPLE1BQU07RUFBVztDQUN4RTtDQUNBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFDaEIsTUFBTSxLQUFLLEVBQUUsTUFBTSxNQUFNLE9BQU8sWUFDL0Isd0JBQUMsT0FBRDtHQUFpQixXQUFVO2FBQTNCLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztHQUNiOzs7O2FBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQW1CO0dBQVc7Ozs7YUFDN0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBbUI7R0FBVzs7OztXQUMxQzs7OztXQUNGO0tBUks7Ozs7U0FRTCxDQUNOO0NBQ007Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdtb3Rpb24vcmVhY3QnXG5pbXBvcnQgeyBBcnJvd1JpZ2h0LCBCb29rT3BlbiwgRmxhbWUsIFRyb3BoeSwgQ2hlY2tDaXJjbGUyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgZGFzaGJvYXJkQXBpIH0gZnJvbSAnLi4vZmVhdHVyZXMvZGFzaGJvYXJkL2Rhc2hib2FyZEFwaSdcbmltcG9ydCB7IENvdXJzZUNhcmQsIENvdXJzZUNhcmRTa2VsZXRvbiB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvQ291cnNlQ2FyZCdcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnLi4vY29tcG9uZW50cy9Ta2VsZXRvbidcblxuLy8gTGFuZGluZyB2aWV3IGJ1aWx0IGZyb20gT05FIGFnZ3JlZ2F0aW9uIGNhbGwgKEdFVCAvYXBpL3YxL2Rhc2hib2FyZCDigJQgc2VlXG4vLyBiYWNrZW5kL3NyYy9sZWFybmlhX2JhY2tlbmQvcm91dGVycy9kYXNoYm9hcmQucHkpOiBhIFwiY29udGludWUgbGVhcm5pbmdcIlxuLy8gY2FyZCwgdGhlIGZ1bGwgY291cnNlIGdyaWQgKHdpdGggdGhpcyB1c2VyJ3Mgb3duIHByb2dyZXNzIG9uIGVhY2gpLFxuLy8gc2ltcGxlIHJ1bGUtYmFzZWQgcmVjb21tZW5kYXRpb25zLCBhbmQgYmFzaWMgY291bnRzLiBObyB0aW1lLXRyYWNraW5nIGluXG4vLyB2MSDigJQgc3RhdHMgYXJlIGNvdW50cy9wZXJjZW50YWdlcyBvbmx5IChzZWUgZ2VuZXJhdGVkLXByb21wdHMvXG4vLyAxNy1kYXNoYm9hcmQvcHJvbXB0cy5tZCdzIHJlc29sdmVkIG9wZW4gcXVlc3Rpb25zKS5cbi8vXG4vLyBTZWxmLWNvbnRhaW5lZDogZG9lcyBub3QgYXNzdW1lIGl0J3MgbW91bnRlZCBhdCBhbnkgcGFydGljdWxhciByb3V0ZSAoc2VlXG4vLyB0aGlzIGZpbGUncyBvd24gaGlzdG9yeS9QUiBmb3IgdGhlIHN1Z2dlc3RlZCByb3V0ZSkuXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkUGFnZSgpIHtcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxuICAgIGRhc2hib2FyZEFwaS5nZXREYXNoYm9hcmQoKS50aGVuKChyZXMpID0+IHtcbiAgICAgIGlmICghY2FuY2VsbGVkKSBzZXREYXRhKHJlcylcbiAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm5cbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGRhc2hib2FyZCcsIGVycilcbiAgICAgIHNldEVycm9yKHRydWUpXG4gICAgfSlcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZVxuICAgIH1cbiAgfSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhvbWVcIj5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRlbnQtY2FyZCBob21lLWhlbGxvXCI+XG4gICAgICAgIDxoMT5EYXNoYm9hcmQ8L2gxPlxuICAgICAgICA8cD5Zb3VyIGNvdXJzZXMsIHByb2dyZXNzLCBhbmQgd2hhdCB0byBsZWFybiBuZXh0LjwvcD5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiaGludCBjb3Vyc2VzLWVtcHR5XCI+Q291bGRuJ3QgbG9hZCB5b3VyIGRhc2hib2FyZC4gVHJ5IHJlZnJlc2hpbmcuPC9wPlxuICAgICAgKX1cblxuICAgICAge2RhdGEgJiYgPFN0YXRzUm93IHN0YXRzPXtkYXRhLnN0YXRzfSAvPn1cblxuICAgICAge2RhdGEgPT09IG51bGwgJiYgIWVycm9yICYmIDxDb250aW51ZUNhcmRTa2VsZXRvbiAvPn1cbiAgICAgIHtkYXRhPy5jb250aW51ZUxlYXJuaW5nICYmIDxDb250aW51ZUxlYXJuaW5nQ2FyZCBlbnRyeT17ZGF0YS5jb250aW51ZUxlYXJuaW5nfSAvPn1cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiaG9tZS1zZWN0aW9uXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaG9tZS1zZWN0aW9uLWhlYWRlclwiPlxuICAgICAgICAgIDxoMj5Zb3VyIGNvdXJzZXM8L2gyPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtZ3JpZFwiPlxuICAgICAgICAgIHtkYXRhID09PSBudWxsICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxDb3Vyc2VDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgICAgICAgPENvdXJzZUNhcmRTa2VsZXRvbiAvPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7ZGF0YT8uY291cnNlcy5tYXAoKGNvdXJzZSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGtleT17Y291cnNlLmlkfVxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDggfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IGluZGV4ICogMC4wNSB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q291cnNlQ2FyZCBjb3Vyc2U9e2NvdXJzZX0gcHJvZ3Jlc3NQY3Q9e2NvdXJzZS5wcm9ncmVzc1BjdH0gLz5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgICB7ZGF0YSAmJiBkYXRhLmNvdXJzZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnQgY291cnNlcy1lbXB0eVwiPk5vIGNvdXJzZXMgcHVibGlzaGVkIHlldC48L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHtkYXRhICYmIGRhdGEucmVjb21tZW5kYXRpb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJob21lLXNlY3Rpb25cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhvbWUtc2VjdGlvbi1oZWFkZXJcIj5cbiAgICAgICAgICAgIDxoMj5SZWNvbW1lbmRlZCBmb3IgeW91PC9oMj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2NvdXJzZXNcIiBjbGFzc05hbWU9XCJob21lLXNlZS1hbGxcIj5cbiAgICAgICAgICAgICAgU2VlIGFsbCA8QXJyb3dSaWdodCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvdXJzZS1ncmlkXCI+XG4gICAgICAgICAgICB7ZGF0YS5yZWNvbW1lbmRhdGlvbnMubWFwKChjb3Vyc2UsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAga2V5PXtjb3Vyc2UuaWR9XG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA4IH19XG4gICAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogaW5kZXggKiAwLjA1IH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q291cnNlQ2FyZCBjb3Vyc2U9e2NvdXJzZX0gLz5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gQ29udGludWVMZWFybmluZ0NhcmQoeyBlbnRyeSB9KSB7XG4gIGNvbnN0IHsgY291cnNlLCBwcm9ncmVzc1BjdCwgbGFzdFBhZ2VUaXRsZSB9ID0gZW50cnlcbiAgY29uc3QgY29tcGxldGUgPSBwcm9ncmVzc1BjdCA+PSAxMDBcbiAgY29uc3QgcmVzdW1lSHJlZiA9IGAvY291cnNlcy8ke2NvdXJzZS5zbHVnfS9sZWFybmBcblxuICByZXR1cm4gKFxuICAgIDxtb3Rpb24uc2VjdGlvblxuICAgICAgY2xhc3NOYW1lPXtgY29udGludWUtY2FyZCBjb250aW51ZS1jYXJkLWhlcm8ke2NvbXBsZXRlID8gJyBjb250aW51ZS1jYXJkLWNvbXBsZXRlJyA6ICcnfWB9XG4gICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDggfX1cbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGludWUtY2FyZC1oZXJvLXRvcFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGNvbnRpbnVlLWNhcmQtaWNvbiR7Y291cnNlLmltYWdlID8gJyBjb250aW51ZS1jYXJkLWljb24taW1hZ2UnIDogJyd9YH0+XG4gICAgICAgICAge2NvdXJzZS5pbWFnZSA/IChcbiAgICAgICAgICAgIDxpbWcgc3JjPXtjb3Vyc2UuaW1hZ2V9IGFsdD1cIlwiIGNsYXNzTmFtZT1cImNvbnRpbnVlLWNhcmQtaWNvbi1pbWdcIiAvPlxuICAgICAgICAgICkgOiBjb21wbGV0ZSA/IChcbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MjZ9IC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxCb29rT3BlbiBzaXplPXsyNn0gLz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWJvZHlcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWV5ZWJyb3dcIj5cbiAgICAgICAgICAgIHtjb21wbGV0ZSA/ICdDb3Vyc2UgY29tcGxldGUnIDogJ0NvbnRpbnVlIGxlYXJuaW5nJ31cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGgyPntjb3Vyc2UudGl0bGV9PC9oMj5cbiAgICAgICAgICB7Y29tcGxldGUgPyAoXG4gICAgICAgICAgICA8cD5FdmVyeSBwYWdlIGRvbmUuPC9wPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICBsYXN0UGFnZVRpdGxlICYmIDxwPk5leHQgdXA6IHtsYXN0UGFnZVRpdGxlfTwvcD5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWhlcm8tYWN0aW9uc1wiPlxuICAgICAgICAgIHsvKiBPcGVucyB0aGUgcmVhZGVyIGluIGl0cyBvd24gdGFiIOKAlCBzZWUgQ291cnNlQ2FyZC5qc3ggZm9yIHdoeSBhXG4gICAgICAgICAgICAgIHBsYWluIDxhPiBpcyB1c2VkIGluc3RlYWQgb2YgUmVhY3QgUm91dGVyJ3MgPExpbms+LiAqL31cbiAgICAgICAgICA8YSBocmVmPXtyZXN1bWVIcmVmfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiY29udGludWUtY2FyZC1jdGFcIj5cbiAgICAgICAgICAgIHtjb21wbGV0ZSA/ICdSZXZpZXcnIDogJ1Jlc3VtZSd9IDxBcnJvd1JpZ2h0IHNpemU9ezE2fSAvPlxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGFwdGVyLXRyYWNrXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhcHRlci10cmFjay1oZWFkZXJcIj5cbiAgICAgICAgICA8c3Bhbj57cHJvZ3Jlc3NQY3R9JSBjb21wbGV0ZTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291cnNlLWNhcmQtcHJvZ3Jlc3MtdHJhY2tcIj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Bjb3Vyc2UtY2FyZC1wcm9ncmVzcy1maWxsJHtjb21wbGV0ZSA/ICcgY291cnNlLWNhcmQtcHJvZ3Jlc3MtZmlsbC1kb25lJyA6ICcnfWB9XG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cHJvZ3Jlc3NQY3R9JWAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvbW90aW9uLnNlY3Rpb24+XG4gIClcbn1cblxuZnVuY3Rpb24gQ29udGludWVDYXJkU2tlbGV0b24oKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkIGNvbnRpbnVlLWNhcmQtc2tlbGV0b25cIj5cbiAgICAgIDxTa2VsZXRvbiBjaXJjbGUgd2lkdGg9XCIzcmVtXCIgaGVpZ2h0PVwiM3JlbVwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRpbnVlLWNhcmQtYm9keVwiPlxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCIzMCVcIiBoZWlnaHQ9XCIwLjc1cmVtXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNTUlXCIgaGVpZ2h0PVwiMS4ycmVtXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIFN0YXRzUm93KHsgc3RhdHMgfSkge1xuICBjb25zdCBpdGVtcyA9IFtcbiAgICB7IGljb246IEZsYW1lLCBsYWJlbDogJ0luIHByb2dyZXNzJywgdmFsdWU6IHN0YXRzLmluUHJvZ3Jlc3NDb3VudCB9LFxuICAgIHsgaWNvbjogVHJvcGh5LCBsYWJlbDogJ0NvbXBsZXRlZCcsIHZhbHVlOiBzdGF0cy5jb21wbGV0ZWRDb3VudCB9LFxuICAgIHsgaWNvbjogQm9va09wZW4sIGxhYmVsOiAnQ291cnNlcyBhdmFpbGFibGUnLCB2YWx1ZTogc3RhdHMudG90YWxDb3VudCB9LFxuICBdXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3RhdHMtc3RyaXBcIj5cbiAgICAgIHtpdGVtcy5tYXAoKHsgaWNvbjogSWNvbiwgbGFiZWwsIHZhbHVlIH0pID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2xhYmVsfSBjbGFzc05hbWU9XCJzdGF0LXRpbGVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0LXRpbGUtaWNvblwiPlxuICAgICAgICAgICAgPEljb24gc2l6ZT17MTh9IC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXQtdGlsZS12YWx1ZVwiPnt2YWx1ZX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdC10aWxlLWxhYmVsXCI+e2xhYmVsfTwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkpfVxuICAgIDwvc2VjdGlvbj5cbiAgKVxufVxuIl19