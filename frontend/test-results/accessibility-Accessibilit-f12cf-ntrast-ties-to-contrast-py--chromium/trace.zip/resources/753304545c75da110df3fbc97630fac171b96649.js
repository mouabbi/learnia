import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/AssessmentsTab.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Plus, Trash2, Sparkles, Save } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { cmsApi } from "/src/features/cms/cmsApi.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AssessmentsTab.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
function emptyQuestion() {
	return {
		text: "",
		options: [{
			id: null,
			text: ""
		}, {
			id: null,
			text: ""
		}],
		correctOptionIds: [],
		explanation: "",
		difficulty: "medium"
	};
}
function QuestionForm({ question, onChange, onSave, onDelete, saving }) {
	const updateOption = (i, text) => {
		const options = question.options.map((o, idx) => idx === i ? {
			...o,
			text
		} : o);
		onChange({
			...question,
			options
		});
	};
	const addOption = () => onChange({
		...question,
		options: [...question.options, {
			id: null,
			text: ""
		}]
	});
	const removeOption = (i) => {
		const removedId = question.options[i].id;
		onChange({
			...question,
			options: question.options.filter((_, idx) => idx !== i),
			correctOptionIds: question.correctOptionIds.filter((id) => id !== removedId)
		});
	};
	const toggleCorrect = (id, checked) => {
		// options created client-side have no id yet (assigned by the backend
		// on save) — correctness by index-derived placeholder isn't reliable
		// before the first save, so correct-option toggling only works cleanly
		// once options have real ids (after at least one save).
		const next = checked ? [...question.correctOptionIds, id] : question.correctOptionIds.filter((x) => x !== id);
		onChange({
			...question,
			correctOptionIds: next
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-block-card",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				className: "cms-field",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Question text" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("textarea", {
					rows: 2,
					value: question.text,
					onChange: (e) => onChange({
						...question,
						text: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 7
			}, this),
			question.options.map((option, i) => /* @__PURE__ */ _jsxDEV("div", {
				className: "cms-row cms-option-row",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: !!option.id && question.correctOptionIds.includes(option.id),
						disabled: !option.id,
						title: option.id ? "Mark correct" : "Save once to assign this option an id",
						onChange: (e) => option.id && toggleCorrect(option.id, e.target.checked)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						value: option.text,
						onChange: (e) => updateOption(i, e.target.value),
						placeholder: `Option ${i + 1}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "cms-btn-icon",
						onClick: () => removeOption(i),
						children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this)
				]
			}, i, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this)),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "cms-btn-secondary",
				onClick: addOption,
				children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this), " Add option"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				className: "cms-field",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Explanation" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("textarea", {
					rows: 2,
					value: question.explanation || "",
					onChange: (e) => onChange({
						...question,
						explanation: e.target.value
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				className: "cms-field",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Difficulty" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("select", {
					value: question.difficulty || "medium",
					onChange: (e) => onChange({
						...question,
						difficulty: e.target.value
					}),
					children: [
						"easy",
						"medium",
						"hard"
					].map((d) => /* @__PURE__ */ _jsxDEV("option", {
						value: d,
						children: d
					}, d, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cms-modal-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "cms-btn-primary",
					onClick: onSave,
					disabled: saving,
					children: [
						/* @__PURE__ */ _jsxDEV(Save, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 11
						}, this),
						" ",
						question.id ? "Update" : "Create"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this), question.id && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "cms-btn-danger",
					onClick: onDelete,
					children: [/* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 13
					}, this), " Delete"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
_c = QuestionForm;
/**
* Assessments tab — list + add/edit/delete for a module's question bank or
* the course's final exam bank. `target` is either {kind:'module', id} or
* {kind:'final-exam', courseId}.
*/
export function AssessmentsTab({ target, courseId, onGenerateWithAi }) {
	_s();
	const [questions, setQuestions] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const [draft, setDraft] = useState(null);
	const [savingId, setSavingId] = useState(null);
	const load = () => {
		if (!target) return;
		setLoading(true);
		const promise = target.kind === "module" ? cmsApi.listModuleQuestions(target.id) : cmsApi.listFinalExamQuestions(courseId);
		promise.then(setQuestions).catch((err) => setError(err.message)).finally(() => setLoading(false));
	};
	useEffect(load, [target, courseId]);
	if (!target) {
		return /* @__PURE__ */ _jsxDEV("p", {
			className: "cms-empty-hint",
			children: "Select a module (or the final exam) to manage its questions."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 12
		}, this);
	}
	const saveQuestion = async (question, isDraft) => {
		setSavingId(question.id || "draft");
		setError(null);
		try {
			const body = {
				text: question.text,
				options: question.options.map((o) => ({
					id: o.id || undefined,
					text: o.text
				})),
				correctOptionIds: question.correctOptionIds,
				explanation: question.explanation || null,
				difficulty: question.difficulty || null
			};
			if (question.id) {
				await cmsApi.updateQuestion(question.id, body);
			} else if (target.kind === "module") {
				await cmsApi.createModuleQuestion(target.id, body);
			} else {
				await cmsApi.createFinalExamQuestion(courseId, body);
			}
			if (isDraft) setDraft(null);
			load();
		} catch (err) {
			setError(err.message);
		} finally {
			setSavingId(null);
		}
	};
	const deleteQuestion = async (id) => {
		if (!window.confirm("Delete this question?")) return;
		await cmsApi.deleteQuestion(id);
		load();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-assessments",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cms-content-header",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: target.kind === "module" ? "Module question bank" : "Final exam question bank" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "cms-modal-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "cms-btn-ai",
						onClick: () => onGenerateWithAi(target.kind === "module" ? {
							scope: "module-qcm",
							moduleId: target.id
						} : { scope: "final-exam" }),
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 13
						}, this), " Generate with AI"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 11
					}, this), !draft && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "cms-btn-secondary",
						onClick: () => setDraft(emptyQuestion()),
						children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 15
						}, this), " Add question"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 17
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-loading",
				children: "Loading…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 19
			}, this),
			draft && /* @__PURE__ */ _jsxDEV(QuestionForm, {
				question: draft,
				onChange: setDraft,
				onSave: () => saveQuestion(draft, true),
				saving: savingId === "draft"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 9
			}, this),
			!loading && questions.length === 0 && !draft && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-empty-hint",
				children: "No questions yet."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "cms-block-list-editor",
				children: questions.map((q) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(QuestionForm, {
					question: q,
					onChange: (next) => setQuestions((prev) => prev.map((p) => p.id === q.id ? next : p)),
					onSave: () => saveQuestion(questions.find((p) => p.id === q.id), false),
					onDelete: () => deleteQuestion(q.id),
					saving: savingId === q.id
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 226,
					columnNumber: 13
				}, this) }, q.id, false, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 223,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 182,
		columnNumber: 5
	}, this);
}
_s(AssessmentsTab, "XTRUy6wQXsNysi8EyYF1cDtd6IE=");
_c2 = AssessmentsTab;
var _c, _c2;
$RefreshReg$(_c, "QuestionForm");
$RefreshReg$(_c2, "AssessmentsTab");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/AssessmentsTab.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AssessmentsTab.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AssessmentsTab.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AssessmentsTab.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLE1BQU0sUUFBUSxVQUFVLFlBQVk7QUFDN0MsU0FBUyxjQUFjOzs7O0FBRXZCLFNBQVMsZ0JBQWdCO0NBQ3ZCLE9BQU87RUFDTCxNQUFNO0VBQ04sU0FBUyxDQUNQO0dBQUUsSUFBSTtHQUFNLE1BQU07RUFBRyxHQUNyQjtHQUFFLElBQUk7R0FBTSxNQUFNO0VBQUcsQ0FDdkI7RUFDQSxrQkFBa0IsQ0FBQztFQUNuQixhQUFhO0VBQ2IsWUFBWTtDQUNkO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsRUFBRSxVQUFVLFVBQVUsUUFBUSxVQUFVLFVBQVU7Q0FDdEUsTUFBTSxnQkFBZ0IsR0FBRyxTQUFTO0VBQ2hDLE1BQU0sVUFBVSxTQUFTLFFBQVEsS0FBSyxHQUFHLFFBQVMsUUFBUSxJQUFJO0dBQUUsR0FBRztHQUFHO0VBQUssSUFBSSxDQUFFO0VBQ2pGLFNBQVM7R0FBRSxHQUFHO0dBQVU7RUFBUSxDQUFDO0NBQ25DO0NBRUEsTUFBTSxrQkFBa0IsU0FBUztFQUFFLEdBQUc7RUFBVSxTQUFTLENBQUMsR0FBRyxTQUFTLFNBQVM7R0FBRSxJQUFJO0dBQU0sTUFBTTtFQUFHLENBQUM7Q0FBRSxDQUFDO0NBRXhHLE1BQU0sZ0JBQWdCLE1BQU07RUFDMUIsTUFBTSxZQUFZLFNBQVMsUUFBUSxFQUFFLENBQUM7RUFDdEMsU0FBUztHQUNQLEdBQUc7R0FDSCxTQUFTLFNBQVMsUUFBUSxRQUFRLEdBQUcsUUFBUSxRQUFRLENBQUM7R0FDdEQsa0JBQWtCLFNBQVMsaUJBQWlCLFFBQVEsT0FBTyxPQUFPLFNBQVM7RUFDN0UsQ0FBQztDQUNIO0NBRUEsTUFBTSxpQkFBaUIsSUFBSSxZQUFZOzs7OztFQUtyQyxNQUFNLE9BQU8sVUFDVCxDQUFDLEdBQUcsU0FBUyxrQkFBa0IsRUFBRSxJQUNqQyxTQUFTLGlCQUFpQixRQUFRLE1BQU0sTUFBTSxFQUFFO0VBQ3BELFNBQVM7R0FBRSxHQUFHO0dBQVUsa0JBQWtCO0VBQUssQ0FBQztDQUNsRDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWpCLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OztjQUN6Qix3QkFBQyxZQUFEO0tBQ0UsTUFBTTtLQUNOLE9BQU8sU0FBUztLQUNoQixXQUFXLE1BQU0sU0FBUztNQUFFLEdBQUc7TUFBVSxNQUFNLEVBQUUsT0FBTztLQUFNLENBQUM7SUFDaEU7Ozs7WUFDSTs7Ozs7O0dBRU4sU0FBUyxRQUFRLEtBQUssUUFBUSxNQUM3Qix3QkFBQyxPQUFEO0lBQWEsV0FBVTtjQUF2QjtLQUNFLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUyxDQUFDLENBQUMsT0FBTyxNQUFNLFNBQVMsaUJBQWlCLFNBQVMsT0FBTyxFQUFFO01BQ3BFLFVBQVUsQ0FBQyxPQUFPO01BQ2xCLE9BQU8sT0FBTyxLQUFLLGlCQUFpQjtNQUNwQyxXQUFXLE1BQU0sT0FBTyxNQUFNLGNBQWMsT0FBTyxJQUFJLEVBQUUsT0FBTyxPQUFPO0tBQ3hFOzs7OztLQUNELHdCQUFDLFNBQUQ7TUFDRSxPQUFPLE9BQU87TUFDZCxXQUFXLE1BQU0sYUFBYSxHQUFHLEVBQUUsT0FBTyxLQUFLO01BQy9DLGFBQWEsVUFBVSxJQUFJO0tBQzVCOzs7OztLQUNELHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFlLGVBQWUsYUFBYSxDQUFDO2dCQUMxRSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztLQUNiOzs7OztJQUNMO01BaEJLOzs7O1VBZ0JMLENBQ047R0FDRCx3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLFdBQVU7SUFBb0IsU0FBUztjQUE3RCxDQUNFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7Y0FBQyxhQUNaOzs7Ozs7R0FFUix3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztjQUN2Qix3QkFBQyxZQUFEO0tBQ0UsTUFBTTtLQUNOLE9BQU8sU0FBUyxlQUFlO0tBQy9CLFdBQVcsTUFBTSxTQUFTO01BQUUsR0FBRztNQUFVLGFBQWEsRUFBRSxPQUFPO0tBQU0sQ0FBQztJQUN2RTs7OztZQUNJOzs7Ozs7R0FFUCx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztjQUN0Qix3QkFBQyxVQUFEO0tBQ0UsT0FBTyxTQUFTLGNBQWM7S0FDOUIsV0FBVyxNQUFNLFNBQVM7TUFBRSxHQUFHO01BQVUsWUFBWSxFQUFFLE9BQU87S0FBTSxDQUFDO2VBRXBFO01BQUM7TUFBUTtNQUFVO0tBQU0sQ0FBQyxDQUFDLEtBQUssTUFDL0Isd0JBQUMsVUFBRDtNQUFnQixPQUFPO2dCQUNwQjtLQUNLLEdBRks7Ozs7WUFFTCxDQUNUO0lBQ0s7Ozs7WUFDSDs7Ozs7O0dBRVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsV0FBVTtLQUFrQixTQUFTO0tBQVEsVUFBVTtlQUE3RTtNQUNFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O01BQUM7TUFBRSxTQUFTLEtBQUssV0FBVztLQUN2Qzs7Ozs7Y0FDUCxTQUFTLE1BQ1Isd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQWlCLFNBQVM7ZUFBMUQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7O2VBQUMsU0FDZDs7Ozs7WUFFUDs7Ozs7O0VBQ0Y7Ozs7OztBQUVUOzs7Ozs7O0FBT0EsT0FBTyxTQUFTLGVBQWUsRUFBRSxRQUFRLFVBQVUsb0JBQW9COztDQUNyRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLElBQUk7Q0FFN0MsTUFBTSxhQUFhO0VBQ2pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsV0FBVyxJQUFJO0VBQ2YsTUFBTSxVQUNKLE9BQU8sU0FBUyxXQUNaLE9BQU8sb0JBQW9CLE9BQU8sRUFBRSxJQUNwQyxPQUFPLHVCQUF1QixRQUFRO0VBQzVDLFFBQ0csS0FBSyxZQUFZLENBQUMsQ0FDbEIsT0FBTyxRQUFRLFNBQVMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUNyQyxjQUFjLFdBQVcsS0FBSyxDQUFDO0NBQ3BDO0NBRUEsVUFBVSxNQUFNLENBQUMsUUFBUSxRQUFRLENBQUM7Q0FFbEMsSUFBSSxDQUFDLFFBQVE7RUFDWCxPQUFPLHdCQUFDLEtBQUQ7R0FBRyxXQUFVO2FBQWlCO0VBQStEOzs7OztDQUN0RztDQUVBLE1BQU0sZUFBZSxPQUFPLFVBQVUsWUFBWTtFQUNoRCxZQUFZLFNBQVMsTUFBTSxPQUFPO0VBQ2xDLFNBQVMsSUFBSTtFQUNiLElBQUk7R0FDRixNQUFNLE9BQU87SUFDWCxNQUFNLFNBQVM7SUFDZixTQUFTLFNBQVMsUUFBUSxLQUFLLE9BQU87S0FBRSxJQUFJLEVBQUUsTUFBTTtLQUFXLE1BQU0sRUFBRTtJQUFLLEVBQUU7SUFDOUUsa0JBQWtCLFNBQVM7SUFDM0IsYUFBYSxTQUFTLGVBQWU7SUFDckMsWUFBWSxTQUFTLGNBQWM7R0FDckM7R0FDQSxJQUFJLFNBQVMsSUFBSTtJQUNmLE1BQU0sT0FBTyxlQUFlLFNBQVMsSUFBSSxJQUFJO0dBQy9DLE9BQU8sSUFBSSxPQUFPLFNBQVMsVUFBVTtJQUNuQyxNQUFNLE9BQU8scUJBQXFCLE9BQU8sSUFBSSxJQUFJO0dBQ25ELE9BQU87SUFDTCxNQUFNLE9BQU8sd0JBQXdCLFVBQVUsSUFBSTtHQUNyRDtHQUNBLElBQUksU0FBUyxTQUFTLElBQUk7R0FDMUIsS0FBSztFQUNQLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxPQUFPO0VBQ3RCLFVBQVU7R0FDUixZQUFZLElBQUk7RUFDbEI7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLE9BQU8sT0FBTztFQUNuQyxJQUFJLENBQUMsT0FBTyxRQUFRLHVCQUF1QixHQUFHO0VBQzlDLE1BQU0sT0FBTyxlQUFlLEVBQUU7RUFDOUIsS0FBSztDQUNQO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQsWUFBSyxPQUFPLFNBQVMsV0FBVyx5QkFBeUIsMkJBQStCOzs7O2NBQ3hGLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7TUFDVixlQUNFLGlCQUNFLE9BQU8sU0FBUyxXQUNaO09BQUUsT0FBTztPQUFjLFVBQVUsT0FBTztNQUFHLElBQzNDLEVBQUUsT0FBTyxhQUFhLENBQzVCO2dCQVJKLENBV0Usd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztnQkFBQyxtQkFDaEI7Ozs7O2VBQ1AsQ0FBQyxTQUNBLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFvQixlQUFlLFNBQVMsY0FBYyxDQUFDO2dCQUEzRixDQUNFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7Z0JBQUMsZUFDWjs7Ozs7YUFFUDs7Ozs7WUFDRjs7Ozs7O0dBRUosU0FBUyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFhO0dBQVM7Ozs7O0dBQzVDLFdBQVcsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYztHQUFXOzs7OztHQUVqRCxTQUNDLHdCQUFDLGNBQUQ7SUFDRSxVQUFVO0lBQ1YsVUFBVTtJQUNWLGNBQWMsYUFBYSxPQUFPLElBQUk7SUFDdEMsUUFBUSxhQUFhO0dBQ3RCOzs7OztHQUdGLENBQUMsV0FBVyxVQUFVLFdBQVcsS0FBSyxDQUFDLFNBQ3RDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWlCO0dBQW9COzs7OztHQUdwRCx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUNYLFVBQVUsS0FBSyxNQUNkLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxjQUFEO0tBQ0UsVUFBVTtLQUNWLFdBQVcsU0FDVCxjQUFjLFNBQVMsS0FBSyxLQUFLLE1BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxPQUFPLENBQUUsQ0FBQztLQUVwRSxjQUFjLGFBQWEsVUFBVSxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRSxHQUFHLEtBQUs7S0FDdEUsZ0JBQWdCLGVBQWUsRUFBRSxFQUFFO0tBQ25DLFFBQVEsYUFBYSxFQUFFO0lBQ3hCOzs7O2FBQ0MsR0FWSyxFQUFFOzs7O1dBVVAsQ0FDTDtHQUNDOzs7OztFQUNEOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBc3Nlc3NtZW50c1RhYi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUGx1cywgVHJhc2gyLCBTcGFya2xlcywgU2F2ZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IGNtc0FwaSB9IGZyb20gJy4vY21zQXBpJ1xuXG5mdW5jdGlvbiBlbXB0eVF1ZXN0aW9uKCkge1xuICByZXR1cm4ge1xuICAgIHRleHQ6ICcnLFxuICAgIG9wdGlvbnM6IFtcbiAgICAgIHsgaWQ6IG51bGwsIHRleHQ6ICcnIH0sXG4gICAgICB7IGlkOiBudWxsLCB0ZXh0OiAnJyB9LFxuICAgIF0sXG4gICAgY29ycmVjdE9wdGlvbklkczogW10sXG4gICAgZXhwbGFuYXRpb246ICcnLFxuICAgIGRpZmZpY3VsdHk6ICdtZWRpdW0nLFxuICB9XG59XG5cbmZ1bmN0aW9uIFF1ZXN0aW9uRm9ybSh7IHF1ZXN0aW9uLCBvbkNoYW5nZSwgb25TYXZlLCBvbkRlbGV0ZSwgc2F2aW5nIH0pIHtcbiAgY29uc3QgdXBkYXRlT3B0aW9uID0gKGksIHRleHQpID0+IHtcbiAgICBjb25zdCBvcHRpb25zID0gcXVlc3Rpb24ub3B0aW9ucy5tYXAoKG8sIGlkeCkgPT4gKGlkeCA9PT0gaSA/IHsgLi4ubywgdGV4dCB9IDogbykpXG4gICAgb25DaGFuZ2UoeyAuLi5xdWVzdGlvbiwgb3B0aW9ucyB9KVxuICB9XG5cbiAgY29uc3QgYWRkT3B0aW9uID0gKCkgPT4gb25DaGFuZ2UoeyAuLi5xdWVzdGlvbiwgb3B0aW9uczogWy4uLnF1ZXN0aW9uLm9wdGlvbnMsIHsgaWQ6IG51bGwsIHRleHQ6ICcnIH1dIH0pXG5cbiAgY29uc3QgcmVtb3ZlT3B0aW9uID0gKGkpID0+IHtcbiAgICBjb25zdCByZW1vdmVkSWQgPSBxdWVzdGlvbi5vcHRpb25zW2ldLmlkXG4gICAgb25DaGFuZ2Uoe1xuICAgICAgLi4ucXVlc3Rpb24sXG4gICAgICBvcHRpb25zOiBxdWVzdGlvbi5vcHRpb25zLmZpbHRlcigoXywgaWR4KSA9PiBpZHggIT09IGkpLFxuICAgICAgY29ycmVjdE9wdGlvbklkczogcXVlc3Rpb24uY29ycmVjdE9wdGlvbklkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gcmVtb3ZlZElkKSxcbiAgICB9KVxuICB9XG5cbiAgY29uc3QgdG9nZ2xlQ29ycmVjdCA9IChpZCwgY2hlY2tlZCkgPT4ge1xuICAgIC8vIG9wdGlvbnMgY3JlYXRlZCBjbGllbnQtc2lkZSBoYXZlIG5vIGlkIHlldCAoYXNzaWduZWQgYnkgdGhlIGJhY2tlbmRcbiAgICAvLyBvbiBzYXZlKSDigJQgY29ycmVjdG5lc3MgYnkgaW5kZXgtZGVyaXZlZCBwbGFjZWhvbGRlciBpc24ndCByZWxpYWJsZVxuICAgIC8vIGJlZm9yZSB0aGUgZmlyc3Qgc2F2ZSwgc28gY29ycmVjdC1vcHRpb24gdG9nZ2xpbmcgb25seSB3b3JrcyBjbGVhbmx5XG4gICAgLy8gb25jZSBvcHRpb25zIGhhdmUgcmVhbCBpZHMgKGFmdGVyIGF0IGxlYXN0IG9uZSBzYXZlKS5cbiAgICBjb25zdCBuZXh0ID0gY2hlY2tlZFxuICAgICAgPyBbLi4ucXVlc3Rpb24uY29ycmVjdE9wdGlvbklkcywgaWRdXG4gICAgICA6IHF1ZXN0aW9uLmNvcnJlY3RPcHRpb25JZHMuZmlsdGVyKCh4KSA9PiB4ICE9PSBpZClcbiAgICBvbkNoYW5nZSh7IC4uLnF1ZXN0aW9uLCBjb3JyZWN0T3B0aW9uSWRzOiBuZXh0IH0pXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLWJsb2NrLWNhcmRcIj5cbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjbXMtZmllbGRcIj5cbiAgICAgICAgPHNwYW4+UXVlc3Rpb24gdGV4dDwvc3Bhbj5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICB2YWx1ZT17cXVlc3Rpb24udGV4dH1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHsgLi4ucXVlc3Rpb24sIHRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD5cblxuICAgICAge3F1ZXN0aW9uLm9wdGlvbnMubWFwKChvcHRpb24sIGkpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImNtcy1yb3cgY21zLW9wdGlvbi1yb3dcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICBjaGVja2VkPXshIW9wdGlvbi5pZCAmJiBxdWVzdGlvbi5jb3JyZWN0T3B0aW9uSWRzLmluY2x1ZGVzKG9wdGlvbi5pZCl9XG4gICAgICAgICAgICBkaXNhYmxlZD17IW9wdGlvbi5pZH1cbiAgICAgICAgICAgIHRpdGxlPXtvcHRpb24uaWQgPyAnTWFyayBjb3JyZWN0JyA6ICdTYXZlIG9uY2UgdG8gYXNzaWduIHRoaXMgb3B0aW9uIGFuIGlkJ31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb3B0aW9uLmlkICYmIHRvZ2dsZUNvcnJlY3Qob3B0aW9uLmlkLCBlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdmFsdWU9e29wdGlvbi50ZXh0fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVPcHRpb24oaSwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BPcHRpb24gJHtpICsgMX1gfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1pY29uXCIgb25DbGljaz17KCkgPT4gcmVtb3ZlT3B0aW9uKGkpfT5cbiAgICAgICAgICAgIDxUcmFzaDIgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSl9XG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjbXMtYnRuLXNlY29uZGFyeVwiIG9uQ2xpY2s9e2FkZE9wdGlvbn0+XG4gICAgICAgIDxQbHVzIHNpemU9ezE0fSAvPiBBZGQgb3B0aW9uXG4gICAgICA8L2J1dHRvbj5cblxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNtcy1maWVsZFwiPlxuICAgICAgICA8c3Bhbj5FeHBsYW5hdGlvbjwvc3Bhbj5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICB2YWx1ZT17cXVlc3Rpb24uZXhwbGFuYXRpb24gfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZSh7IC4uLnF1ZXN0aW9uLCBleHBsYW5hdGlvbjogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgIC8+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY21zLWZpZWxkXCI+XG4gICAgICAgIDxzcGFuPkRpZmZpY3VsdHk8L3NwYW4+XG4gICAgICAgIDxzZWxlY3RcbiAgICAgICAgICB2YWx1ZT17cXVlc3Rpb24uZGlmZmljdWx0eSB8fCAnbWVkaXVtJ31cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHsgLi4ucXVlc3Rpb24sIGRpZmZpY3VsdHk6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICA+XG4gICAgICAgICAge1snZWFzeScsICdtZWRpdW0nLCAnaGFyZCddLm1hcCgoZCkgPT4gKFxuICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2R9IHZhbHVlPXtkfT5cbiAgICAgICAgICAgICAge2R9XG4gICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy1tb2RhbC1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNtcy1idG4tcHJpbWFyeVwiIG9uQ2xpY2s9e29uU2F2ZX0gZGlzYWJsZWQ9e3NhdmluZ30+XG4gICAgICAgICAgPFNhdmUgc2l6ZT17MTR9IC8+IHtxdWVzdGlvbi5pZCA/ICdVcGRhdGUnIDogJ0NyZWF0ZSd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7cXVlc3Rpb24uaWQgJiYgKFxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNtcy1idG4tZGFuZ2VyXCIgb25DbGljaz17b25EZWxldGV9PlxuICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz4gRGVsZXRlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vKipcbiAqIEFzc2Vzc21lbnRzIHRhYiDigJQgbGlzdCArIGFkZC9lZGl0L2RlbGV0ZSBmb3IgYSBtb2R1bGUncyBxdWVzdGlvbiBiYW5rIG9yXG4gKiB0aGUgY291cnNlJ3MgZmluYWwgZXhhbSBiYW5rLiBgdGFyZ2V0YCBpcyBlaXRoZXIge2tpbmQ6J21vZHVsZScsIGlkfSBvclxuICoge2tpbmQ6J2ZpbmFsLWV4YW0nLCBjb3Vyc2VJZH0uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBBc3Nlc3NtZW50c1RhYih7IHRhcmdldCwgY291cnNlSWQsIG9uR2VuZXJhdGVXaXRoQWkgfSkge1xuICBjb25zdCBbcXVlc3Rpb25zLCBzZXRRdWVzdGlvbnNdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtkcmFmdCwgc2V0RHJhZnRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3NhdmluZ0lkLCBzZXRTYXZpbmdJZF0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IGxvYWQgPSAoKSA9PiB7XG4gICAgaWYgKCF0YXJnZXQpIHJldHVyblxuICAgIHNldExvYWRpbmcodHJ1ZSlcbiAgICBjb25zdCBwcm9taXNlID1cbiAgICAgIHRhcmdldC5raW5kID09PSAnbW9kdWxlJ1xuICAgICAgICA/IGNtc0FwaS5saXN0TW9kdWxlUXVlc3Rpb25zKHRhcmdldC5pZClcbiAgICAgICAgOiBjbXNBcGkubGlzdEZpbmFsRXhhbVF1ZXN0aW9ucyhjb3Vyc2VJZClcbiAgICBwcm9taXNlXG4gICAgICAudGhlbihzZXRRdWVzdGlvbnMpXG4gICAgICAuY2F0Y2goKGVycikgPT4gc2V0RXJyb3IoZXJyLm1lc3NhZ2UpKVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpXG4gIH1cblxuICB1c2VFZmZlY3QobG9hZCwgW3RhcmdldCwgY291cnNlSWRdKVxuXG4gIGlmICghdGFyZ2V0KSB7XG4gICAgcmV0dXJuIDxwIGNsYXNzTmFtZT1cImNtcy1lbXB0eS1oaW50XCI+U2VsZWN0IGEgbW9kdWxlIChvciB0aGUgZmluYWwgZXhhbSkgdG8gbWFuYWdlIGl0cyBxdWVzdGlvbnMuPC9wPlxuICB9XG5cbiAgY29uc3Qgc2F2ZVF1ZXN0aW9uID0gYXN5bmMgKHF1ZXN0aW9uLCBpc0RyYWZ0KSA9PiB7XG4gICAgc2V0U2F2aW5nSWQocXVlc3Rpb24uaWQgfHwgJ2RyYWZ0JylcbiAgICBzZXRFcnJvcihudWxsKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICB0ZXh0OiBxdWVzdGlvbi50ZXh0LFxuICAgICAgICBvcHRpb25zOiBxdWVzdGlvbi5vcHRpb25zLm1hcCgobykgPT4gKHsgaWQ6IG8uaWQgfHwgdW5kZWZpbmVkLCB0ZXh0OiBvLnRleHQgfSkpLFxuICAgICAgICBjb3JyZWN0T3B0aW9uSWRzOiBxdWVzdGlvbi5jb3JyZWN0T3B0aW9uSWRzLFxuICAgICAgICBleHBsYW5hdGlvbjogcXVlc3Rpb24uZXhwbGFuYXRpb24gfHwgbnVsbCxcbiAgICAgICAgZGlmZmljdWx0eTogcXVlc3Rpb24uZGlmZmljdWx0eSB8fCBudWxsLFxuICAgICAgfVxuICAgICAgaWYgKHF1ZXN0aW9uLmlkKSB7XG4gICAgICAgIGF3YWl0IGNtc0FwaS51cGRhdGVRdWVzdGlvbihxdWVzdGlvbi5pZCwgYm9keSlcbiAgICAgIH0gZWxzZSBpZiAodGFyZ2V0LmtpbmQgPT09ICdtb2R1bGUnKSB7XG4gICAgICAgIGF3YWl0IGNtc0FwaS5jcmVhdGVNb2R1bGVRdWVzdGlvbih0YXJnZXQuaWQsIGJvZHkpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBjbXNBcGkuY3JlYXRlRmluYWxFeGFtUXVlc3Rpb24oY291cnNlSWQsIGJvZHkpXG4gICAgICB9XG4gICAgICBpZiAoaXNEcmFmdCkgc2V0RHJhZnQobnVsbClcbiAgICAgIGxvYWQoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNhdmluZ0lkKG51bGwpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZGVsZXRlUXVlc3Rpb24gPSBhc3luYyAoaWQpID0+IHtcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKCdEZWxldGUgdGhpcyBxdWVzdGlvbj8nKSkgcmV0dXJuXG4gICAgYXdhaXQgY21zQXBpLmRlbGV0ZVF1ZXN0aW9uKGlkKVxuICAgIGxvYWQoKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy1hc3Nlc3NtZW50c1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtY29udGVudC1oZWFkZXJcIj5cbiAgICAgICAgPGgzPnt0YXJnZXQua2luZCA9PT0gJ21vZHVsZScgPyAnTW9kdWxlIHF1ZXN0aW9uIGJhbmsnIDogJ0ZpbmFsIGV4YW0gcXVlc3Rpb24gYmFuayd9PC9oMz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtbW9kYWwtYWN0aW9uc1wiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY21zLWJ0bi1haVwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICBvbkdlbmVyYXRlV2l0aEFpKFxuICAgICAgICAgICAgICAgIHRhcmdldC5raW5kID09PSAnbW9kdWxlJ1xuICAgICAgICAgICAgICAgICAgPyB7IHNjb3BlOiAnbW9kdWxlLXFjbScsIG1vZHVsZUlkOiB0YXJnZXQuaWQgfVxuICAgICAgICAgICAgICAgICAgOiB7IHNjb3BlOiAnZmluYWwtZXhhbScgfSxcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxNn0gLz4gR2VuZXJhdGUgd2l0aCBBSVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIHshZHJhZnQgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXREcmFmdChlbXB0eVF1ZXN0aW9uKCkpfT5cbiAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTZ9IC8+IEFkZCBxdWVzdGlvblxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImNtcy1lcnJvclwiPntlcnJvcn08L3A+fVxuICAgICAge2xvYWRpbmcgJiYgPHAgY2xhc3NOYW1lPVwiY21zLWxvYWRpbmdcIj5Mb2FkaW5n4oCmPC9wPn1cblxuICAgICAge2RyYWZ0ICYmIChcbiAgICAgICAgPFF1ZXN0aW9uRm9ybVxuICAgICAgICAgIHF1ZXN0aW9uPXtkcmFmdH1cbiAgICAgICAgICBvbkNoYW5nZT17c2V0RHJhZnR9XG4gICAgICAgICAgb25TYXZlPXsoKSA9PiBzYXZlUXVlc3Rpb24oZHJhZnQsIHRydWUpfVxuICAgICAgICAgIHNhdmluZz17c2F2aW5nSWQgPT09ICdkcmFmdCd9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7IWxvYWRpbmcgJiYgcXVlc3Rpb25zLmxlbmd0aCA9PT0gMCAmJiAhZHJhZnQgJiYgKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJjbXMtZW1wdHktaGludFwiPk5vIHF1ZXN0aW9ucyB5ZXQuPC9wPlxuICAgICAgKX1cblxuICAgICAgPHVsIGNsYXNzTmFtZT1cImNtcy1ibG9jay1saXN0LWVkaXRvclwiPlxuICAgICAgICB7cXVlc3Rpb25zLm1hcCgocSkgPT4gKFxuICAgICAgICAgIDxsaSBrZXk9e3EuaWR9PlxuICAgICAgICAgICAgPFF1ZXN0aW9uRm9ybVxuICAgICAgICAgICAgICBxdWVzdGlvbj17cX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhuZXh0KSA9PlxuICAgICAgICAgICAgICAgIHNldFF1ZXN0aW9ucygocHJldikgPT4gcHJldi5tYXAoKHApID0+IChwLmlkID09PSBxLmlkID8gbmV4dCA6IHApKSlcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBvblNhdmU9eygpID0+IHNhdmVRdWVzdGlvbihxdWVzdGlvbnMuZmluZCgocCkgPT4gcC5pZCA9PT0gcS5pZCksIGZhbHNlKX1cbiAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IGRlbGV0ZVF1ZXN0aW9uKHEuaWQpfVxuICAgICAgICAgICAgICBzYXZpbmc9e3NhdmluZ0lkID09PSBxLmlkfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2xpPlxuICAgICAgICApKX1cbiAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==