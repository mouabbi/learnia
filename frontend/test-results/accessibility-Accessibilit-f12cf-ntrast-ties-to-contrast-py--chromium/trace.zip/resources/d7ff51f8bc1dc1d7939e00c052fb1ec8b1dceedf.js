import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/StructureTree.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { ChevronDown, ChevronRight, ArrowUp, ArrowDown, Plus, Pencil, Trash2, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/StructureTree.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
/**
* Structure tab — Module > Chapter > Page tree with add/rename/delete and
* up/down reordering (arrow buttons, not drag-and-drop — simpler and
* dependency-free for v1, see the workspace report for the tradeoff).
* Clicking a page selects it (drives the Content tab).
*
* Props: course (with modules/chapters/pages tree already loaded),
* onChange() to refetch after any mutation, onSelectPage(page),
* selectedPageId, onGenerateWithAi({scope, moduleId?, chapterId?}).
*/
export function StructureTree({ course, actions, onChange, onSelectPage, selectedPageId, onGenerateWithAi }) {
	_s();
	const [expandedModules, setExpandedModules] = useState(() => new Set());
	const [expandedChapters, setExpandedChapters] = useState(() => new Set());
	const toggle = (set, setSet, id) => {
		const next = new Set(set);
		next.has(id) ? next.delete(id) : next.add(id);
		setSet(next);
	};
	const addModule = async () => {
		const title = window.prompt("New module title");
		if (!title) return;
		await actions.createModule(course.id, title);
		onChange();
	};
	const renameNode = async (kind, node) => {
		const title = window.prompt("Rename", node.title);
		if (!title || title === node.title) return;
		if (kind === "module") await actions.renameModule(node.id, title);
		if (kind === "chapter") await actions.renameChapter(node.id, title);
		if (kind === "page") await actions.renamePage(node.id, title);
		onChange();
	};
	const deleteNode = async (kind, node) => {
		if (!window.confirm(`Delete "${node.title}"? This cannot be undone.`)) return;
		if (kind === "module") await actions.deleteModule(node.id);
		if (kind === "chapter") await actions.deleteChapter(node.id);
		if (kind === "page") await actions.deletePage(node.id);
		onChange();
	};
	const move = async (kind, parentId, ids, index, dir) => {
		const next = [...ids];
		const target = index + dir;
		if (target < 0 || target >= next.length) return;
		[next[index], next[target]] = [next[target], next[index]];
		if (kind === "module") await actions.reorderModules(course.id, next);
		if (kind === "chapter") await actions.reorderChapters(parentId, next);
		if (kind === "page") await actions.reorderPages(parentId, next);
		onChange();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-tree",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cms-tree-toolbar",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "cms-btn-secondary",
					onClick: addModule,
					children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this), " Add module"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "cms-btn-ai",
					onClick: () => onGenerateWithAi({ scope: "module" }),
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 11
					}, this), " Generate module with AI"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			(course.modules || []).length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-empty-hint",
				children: "No modules yet — add one to get started."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "cms-tree-list",
				children: (course.modules || []).map((module, mi) => {
					const moduleIds = (course.modules || []).map((m) => m.id);
					const isOpen = expandedModules.has(module.id);
					return /* @__PURE__ */ _jsxDEV("li", {
						className: "cms-tree-node",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "cms-tree-row",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "cms-tree-toggle",
									onClick: () => toggle(expandedModules, setExpandedModules, module.id),
									children: isOpen ? /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 29
									}, this) : /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 57
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "cms-tree-label",
									children: module.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "cms-tree-actions",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => move("module", null, moduleIds, mi, -1),
											title: "Move up",
											children: /* @__PURE__ */ _jsxDEV(ArrowUp, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 95,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 94,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => move("module", null, moduleIds, mi, 1),
											title: "Move down",
											children: /* @__PURE__ */ _jsxDEV(ArrowDown, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 98,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 97,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => renameNode("module", module),
											title: "Rename",
											children: /* @__PURE__ */ _jsxDEV(Pencil, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 101,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 100,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => deleteNode("module", module),
											title: "Delete",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 104,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 103,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => onGenerateWithAi({
												scope: "chapter",
												moduleId: module.id
											}),
											title: "Generate chapter with AI",
											children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 111,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 106,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => onGenerateWithAi({
												scope: "module-qcm",
												moduleId: module.id
											}),
											title: "Generate module quiz with AI",
											children: "QCM"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 113,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 15
						}, this), isOpen && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "cms-btn-secondary cms-tree-add-child",
							onClick: async () => {
								const title = window.prompt("New chapter title");
								if (!title) return;
								await actions.createChapter(module.id, title);
								onChange();
							},
							children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 21
							}, this), " Add chapter"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("ul", {
							className: "cms-tree-list cms-tree-indent",
							children: (module.chapters || []).map((chapter, ci) => {
								const chapterIds = (module.chapters || []).map((c) => c.id);
								const chOpen = expandedChapters.has(chapter.id);
								return /* @__PURE__ */ _jsxDEV("li", {
									className: "cms-tree-node",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "cms-tree-row",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												className: "cms-tree-toggle",
												onClick: () => toggle(expandedChapters, setExpandedChapters, chapter.id),
												children: chOpen ? /* @__PURE__ */ _jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 150,
													columnNumber: 41
												}, this) : /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 150,
													columnNumber: 69
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 145,
												columnNumber: 29
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "cms-tree-label",
												children: chapter.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 152,
												columnNumber: 29
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "cms-tree-actions",
												children: [
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => move("chapter", module.id, chapterIds, ci, -1),
														title: "Move up",
														children: /* @__PURE__ */ _jsxDEV(ArrowUp, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 155,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 154,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => move("chapter", module.id, chapterIds, ci, 1),
														title: "Move down",
														children: /* @__PURE__ */ _jsxDEV(ArrowDown, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 158,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 157,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => renameNode("chapter", chapter),
														title: "Rename",
														children: /* @__PURE__ */ _jsxDEV(Pencil, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 161,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 160,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => deleteNode("chapter", chapter),
														title: "Delete",
														children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 164,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 163,
														columnNumber: 31
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: () => onGenerateWithAi({
															scope: "page",
															chapterId: chapter.id
														}),
														title: "Generate page with AI",
														children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 14 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 171,
															columnNumber: 33
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 166,
														columnNumber: 31
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 153,
												columnNumber: 29
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 27
									}, this), chOpen && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-secondary cms-tree-add-child",
										onClick: async () => {
											const title = window.prompt("New page title");
											if (!title) return;
											await actions.createPage(chapter.id, title);
											onChange();
										},
										children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 188,
											columnNumber: 33
										}, this), " Add page"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 31
									}, this), /* @__PURE__ */ _jsxDEV("ul", {
										className: "cms-tree-list cms-tree-indent",
										children: (chapter.pages || []).map((page, pi) => {
											const pageIds = (chapter.pages || []).map((p) => p.id);
											return /* @__PURE__ */ _jsxDEV("li", {
												className: "cms-tree-node",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "cms-tree-row",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														className: `cms-tree-page-btn${selectedPageId === page.id ? " cms-tree-page-selected" : ""}`,
														onClick: () => onSelectPage({
															...page,
															chapterId: chapter.id
														}),
														children: page.title
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 197,
														columnNumber: 41
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "cms-tree-actions",
														children: [
															/* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => move("page", chapter.id, pageIds, pi, -1),
																title: "Move up",
																children: /* @__PURE__ */ _jsxDEV(ArrowUp, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 208,
																	columnNumber: 45
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 207,
																columnNumber: 43
															}, this),
															/* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => move("page", chapter.id, pageIds, pi, 1),
																title: "Move down",
																children: /* @__PURE__ */ _jsxDEV(ArrowDown, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 211,
																	columnNumber: 45
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 210,
																columnNumber: 43
															}, this),
															/* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => renameNode("page", page),
																title: "Rename",
																children: /* @__PURE__ */ _jsxDEV(Pencil, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 214,
																	columnNumber: 45
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 213,
																columnNumber: 43
															}, this),
															/* @__PURE__ */ _jsxDEV("button", {
																type: "button",
																onClick: () => deleteNode("page", page),
																title: "Delete",
																children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 217,
																	columnNumber: 45
																}, this)
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 216,
																columnNumber: 43
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 206,
														columnNumber: 41
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 196,
													columnNumber: 39
												}, this)
											}, page.id, false, {
												fileName: _jsxFileName,
												lineNumber: 195,
												columnNumber: 37
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 31
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 29
									}, this)]
								}, chapter.id, true, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 25
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 17
						}, this)]
					}, module.id, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_s(StructureTree, "thzr1m3hlawVp2T/2oZbrNPt9gs=");
_c = StructureTree;
var _c;
$RefreshReg$(_c, "StructureTree");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/StructureTree.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/StructureTree.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/StructureTree.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/StructureTree.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxhQUFhLGNBQWMsU0FBUyxXQUFXLE1BQU0sUUFBUSxRQUFRLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7QUFZOUYsT0FBTyxTQUFTLGNBQWMsRUFBRSxRQUFRLFNBQVMsVUFBVSxjQUFjLGdCQUFnQixvQkFBb0I7O0NBQzNHLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLGVBQWUsSUFBSSxJQUFJLENBQUM7Q0FDdEUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsZUFBZSxJQUFJLElBQUksQ0FBQztDQUV4RSxNQUFNLFVBQVUsS0FBSyxRQUFRLE9BQU87RUFDbEMsTUFBTSxPQUFPLElBQUksSUFBSSxHQUFHO0VBQ3hCLEtBQUssSUFBSSxFQUFFLElBQUksS0FBSyxPQUFPLEVBQUUsSUFBSSxLQUFLLElBQUksRUFBRTtFQUM1QyxPQUFPLElBQUk7Q0FDYjtDQUVBLE1BQU0sWUFBWSxZQUFZO0VBQzVCLE1BQU0sUUFBUSxPQUFPLE9BQU8sa0JBQWtCO0VBQzlDLElBQUksQ0FBQyxPQUFPO0VBQ1osTUFBTSxRQUFRLGFBQWEsT0FBTyxJQUFJLEtBQUs7RUFDM0MsU0FBUztDQUNYO0NBRUEsTUFBTSxhQUFhLE9BQU8sTUFBTSxTQUFTO0VBQ3ZDLE1BQU0sUUFBUSxPQUFPLE9BQU8sVUFBVSxLQUFLLEtBQUs7RUFDaEQsSUFBSSxDQUFDLFNBQVMsVUFBVSxLQUFLLE9BQU87RUFDcEMsSUFBSSxTQUFTLFVBQVUsTUFBTSxRQUFRLGFBQWEsS0FBSyxJQUFJLEtBQUs7RUFDaEUsSUFBSSxTQUFTLFdBQVcsTUFBTSxRQUFRLGNBQWMsS0FBSyxJQUFJLEtBQUs7RUFDbEUsSUFBSSxTQUFTLFFBQVEsTUFBTSxRQUFRLFdBQVcsS0FBSyxJQUFJLEtBQUs7RUFDNUQsU0FBUztDQUNYO0NBRUEsTUFBTSxhQUFhLE9BQU8sTUFBTSxTQUFTO0VBQ3ZDLElBQUksQ0FBQyxPQUFPLFFBQVEsV0FBVyxLQUFLLE1BQU0sMEJBQTBCLEdBQUc7RUFDdkUsSUFBSSxTQUFTLFVBQVUsTUFBTSxRQUFRLGFBQWEsS0FBSyxFQUFFO0VBQ3pELElBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxjQUFjLEtBQUssRUFBRTtFQUMzRCxJQUFJLFNBQVMsUUFBUSxNQUFNLFFBQVEsV0FBVyxLQUFLLEVBQUU7RUFDckQsU0FBUztDQUNYO0NBRUEsTUFBTSxPQUFPLE9BQU8sTUFBTSxVQUFVLEtBQUssT0FBTyxRQUFRO0VBQ3RELE1BQU0sT0FBTyxDQUFDLEdBQUcsR0FBRztFQUNwQixNQUFNLFNBQVMsUUFBUTtFQUN2QixJQUFJLFNBQVMsS0FBSyxVQUFVLEtBQUssUUFBUTtFQUN4QyxDQUFDLEtBQUssUUFBUSxLQUFLLFdBQVcsQ0FBQyxLQUFLLFNBQVMsS0FBSyxNQUFNO0VBQ3pELElBQUksU0FBUyxVQUFVLE1BQU0sUUFBUSxlQUFlLE9BQU8sSUFBSSxJQUFJO0VBQ25FLElBQUksU0FBUyxXQUFXLE1BQU0sUUFBUSxnQkFBZ0IsVUFBVSxJQUFJO0VBQ3BFLElBQUksU0FBUyxRQUFRLE1BQU0sUUFBUSxhQUFhLFVBQVUsSUFBSTtFQUM5RCxTQUFTO0NBQ1g7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQW9CLFNBQVM7ZUFBN0QsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2VBQUMsYUFDWjs7Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixlQUFlLGlCQUFpQixFQUFFLE9BQU8sU0FBUyxDQUFDO2VBSHJELENBS0Usd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztlQUFDLDBCQUNoQjs7Ozs7WUFDTDs7Ozs7O0lBRUgsT0FBTyxXQUFXLENBQUMsRUFBQyxDQUFFLFdBQVcsS0FDakMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBaUI7R0FBMkM7Ozs7O0dBRzNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2VBQ1YsT0FBTyxXQUFXLENBQUMsRUFBQyxDQUFFLEtBQUssUUFBUSxPQUFPO0tBQzFDLE1BQU0sYUFBYSxPQUFPLFdBQVcsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNLEVBQUUsRUFBRTtLQUN4RCxNQUFNLFNBQVMsZ0JBQWdCLElBQUksT0FBTyxFQUFFO0tBQzVDLE9BQ0Usd0JBQUMsTUFBRDtNQUFvQixXQUFVO2dCQUE5QixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxXQUFVO1NBQ1YsZUFBZSxPQUFPLGlCQUFpQixvQkFBb0IsT0FBTyxFQUFFO21CQUVuRSxTQUFTLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7b0JBQUksd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7UUFDekQ7Ozs7O1FBQ1Isd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWtCLE9BQU87UUFBWTs7Ozs7UUFDckQsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLGVBQWUsS0FBSyxVQUFVLE1BQU0sV0FBVyxJQUFJLENBQUMsQ0FBQztXQUFHLE9BQU07cUJBQ2xGLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O1VBQ2Q7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLEtBQUssVUFBVSxNQUFNLFdBQVcsSUFBSSxDQUFDO1dBQUcsT0FBTTtxQkFDakYsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7VUFDaEI7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLFdBQVcsVUFBVSxNQUFNO1dBQUcsT0FBTTtxQkFDdkUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7VUFDYjs7Ozs7VUFDUix3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLGVBQWUsV0FBVyxVQUFVLE1BQU07V0FBRyxPQUFNO3FCQUN2RSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztVQUNiOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDRSxNQUFLO1dBQ0wsZUFBZSxpQkFBaUI7WUFBRSxPQUFPO1lBQVcsVUFBVSxPQUFPO1dBQUcsQ0FBQztXQUN6RSxPQUFNO3FCQUVOLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O1VBQ2Y7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxlQUFlLGlCQUFpQjtZQUFFLE9BQU87WUFBYyxVQUFVLE9BQU87V0FBRyxDQUFDO1dBQzVFLE9BQU07cUJBQ1A7VUFFTzs7Ozs7U0FDTDs7Ozs7O09BQ0Y7Ozs7O2dCQUVKLFVBQ0MsZ0RBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxXQUFVO09BQ1YsU0FBUyxZQUFZO1FBQ25CLE1BQU0sUUFBUSxPQUFPLE9BQU8sbUJBQW1CO1FBQy9DLElBQUksQ0FBQyxPQUFPO1FBQ1osTUFBTSxRQUFRLGNBQWMsT0FBTyxJQUFJLEtBQUs7UUFDNUMsU0FBUztPQUNYO2lCQVJGLENBVUUsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztpQkFBQyxjQUNaOzs7OztnQkFFUix3QkFBQyxNQUFEO09BQUksV0FBVTtrQkFDVixPQUFPLFlBQVksQ0FBQyxFQUFDLENBQUUsS0FBSyxTQUFTLE9BQU87UUFDNUMsTUFBTSxjQUFjLE9BQU8sWUFBWSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU0sRUFBRSxFQUFFO1FBQzFELE1BQU0sU0FBUyxpQkFBaUIsSUFBSSxRQUFRLEVBQUU7UUFDOUMsT0FDRSx3QkFBQyxNQUFEO1NBQXFCLFdBQVU7bUJBQS9CLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLFdBQVU7WUFDVixlQUFlLE9BQU8sa0JBQWtCLHFCQUFxQixRQUFRLEVBQUU7c0JBRXRFLFNBQVMsd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozt1QkFBSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztXQUN6RDs7Ozs7V0FDUix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBa0IsUUFBUTtXQUFZOzs7OztXQUN0RCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLFVBQUQ7Y0FBUSxNQUFLO2NBQVMsZUFBZSxLQUFLLFdBQVcsT0FBTyxJQUFJLFlBQVksSUFBSSxDQUFDLENBQUM7Y0FBRyxPQUFNO3dCQUN6Rix3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OzthQUNkOzs7OzthQUNSLHdCQUFDLFVBQUQ7Y0FBUSxNQUFLO2NBQVMsZUFBZSxLQUFLLFdBQVcsT0FBTyxJQUFJLFlBQVksSUFBSSxDQUFDO2NBQUcsT0FBTTt3QkFDeEYsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7YUFDaEI7Ozs7O2FBQ1Isd0JBQUMsVUFBRDtjQUFRLE1BQUs7Y0FBUyxlQUFlLFdBQVcsV0FBVyxPQUFPO2NBQUcsT0FBTTt3QkFDekUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7YUFDYjs7Ozs7YUFDUix3QkFBQyxVQUFEO2NBQVEsTUFBSztjQUFTLGVBQWUsV0FBVyxXQUFXLE9BQU87Y0FBRyxPQUFNO3dCQUN6RSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OzthQUNiOzs7OzthQUNSLHdCQUFDLFVBQUQ7Y0FDRSxNQUFLO2NBQ0wsZUFBZSxpQkFBaUI7ZUFBRSxPQUFPO2VBQVEsV0FBVyxRQUFRO2NBQUcsQ0FBQztjQUN4RSxPQUFNO3dCQUVOLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O2FBQ2Y7Ozs7O1lBQ0w7Ozs7OztVQUNGOzs7OzttQkFFSixVQUNDLGdEQUNFLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsV0FBVTtVQUNWLFNBQVMsWUFBWTtXQUNuQixNQUFNLFFBQVEsT0FBTyxPQUFPLGdCQUFnQjtXQUM1QyxJQUFJLENBQUMsT0FBTztXQUNaLE1BQU0sUUFBUSxXQUFXLFFBQVEsSUFBSSxLQUFLO1dBQzFDLFNBQVM7VUFDWDtvQkFSRixDQVVFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7b0JBQUMsV0FDWjs7Ozs7bUJBRVIsd0JBQUMsTUFBRDtVQUFJLFdBQVU7cUJBQ1YsUUFBUSxTQUFTLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTSxPQUFPO1dBQ3ZDLE1BQU0sV0FBVyxRQUFRLFNBQVMsQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNLEVBQUUsRUFBRTtXQUNyRCxPQUNFLHdCQUFDLE1BQUQ7WUFBa0IsV0FBVTtzQkFDMUIsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxVQUFEO2NBQ0UsTUFBSztjQUNMLFdBQVcsb0JBQ1QsbUJBQW1CLEtBQUssS0FBSyw0QkFBNEI7Y0FFM0QsZUFBZSxhQUFhO2VBQUUsR0FBRztlQUFNLFdBQVcsUUFBUTtjQUFHLENBQUM7d0JBRTdELEtBQUs7YUFDQTs7Ozt1QkFDUix3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZjtlQUNFLHdCQUFDLFVBQUQ7Z0JBQVEsTUFBSztnQkFBUyxlQUFlLEtBQUssUUFBUSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUMsQ0FBQztnQkFBRyxPQUFNOzBCQUNwRix3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztlQUNkOzs7OztlQUNSLHdCQUFDLFVBQUQ7Z0JBQVEsTUFBSztnQkFBUyxlQUFlLEtBQUssUUFBUSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUM7Z0JBQUcsT0FBTTswQkFDbkYsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7ZUFDaEI7Ozs7O2VBQ1Isd0JBQUMsVUFBRDtnQkFBUSxNQUFLO2dCQUFTLGVBQWUsV0FBVyxRQUFRLElBQUk7Z0JBQUcsT0FBTTswQkFDbkUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7ZUFDYjs7Ozs7ZUFDUix3QkFBQyxVQUFEO2dCQUFRLE1BQUs7Z0JBQVMsZUFBZSxXQUFXLFFBQVEsSUFBSTtnQkFBRyxPQUFNOzBCQUNuRSx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztlQUNiOzs7OztjQUNMOzs7OztxQkFDRjs7Ozs7O1dBQ0gsR0ExQkssS0FBSzs7OztrQkEwQlY7VUFFUixDQUFDO1NBQ0M7Ozs7aUJBQ0o7Ozs7aUJBRUY7V0FwRkssUUFBUTs7OztlQW9GYjtPQUVSLENBQUM7TUFDQzs7OztjQUNKOzs7O2NBRUY7UUF0SkssT0FBTzs7OztZQXNKWjtJQUVSLENBQUM7R0FDQzs7Ozs7RUFDRDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RydWN0dXJlVHJlZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IENoZXZyb25Eb3duLCBDaGV2cm9uUmlnaHQsIEFycm93VXAsIEFycm93RG93biwgUGx1cywgUGVuY2lsLCBUcmFzaDIsIFNwYXJrbGVzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuXG4vKipcbiAqIFN0cnVjdHVyZSB0YWIg4oCUIE1vZHVsZSA+IENoYXB0ZXIgPiBQYWdlIHRyZWUgd2l0aCBhZGQvcmVuYW1lL2RlbGV0ZSBhbmRcbiAqIHVwL2Rvd24gcmVvcmRlcmluZyAoYXJyb3cgYnV0dG9ucywgbm90IGRyYWctYW5kLWRyb3Ag4oCUIHNpbXBsZXIgYW5kXG4gKiBkZXBlbmRlbmN5LWZyZWUgZm9yIHYxLCBzZWUgdGhlIHdvcmtzcGFjZSByZXBvcnQgZm9yIHRoZSB0cmFkZW9mZikuXG4gKiBDbGlja2luZyBhIHBhZ2Ugc2VsZWN0cyBpdCAoZHJpdmVzIHRoZSBDb250ZW50IHRhYikuXG4gKlxuICogUHJvcHM6IGNvdXJzZSAod2l0aCBtb2R1bGVzL2NoYXB0ZXJzL3BhZ2VzIHRyZWUgYWxyZWFkeSBsb2FkZWQpLFxuICogb25DaGFuZ2UoKSB0byByZWZldGNoIGFmdGVyIGFueSBtdXRhdGlvbiwgb25TZWxlY3RQYWdlKHBhZ2UpLFxuICogc2VsZWN0ZWRQYWdlSWQsIG9uR2VuZXJhdGVXaXRoQWkoe3Njb3BlLCBtb2R1bGVJZD8sIGNoYXB0ZXJJZD99KS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFN0cnVjdHVyZVRyZWUoeyBjb3Vyc2UsIGFjdGlvbnMsIG9uQ2hhbmdlLCBvblNlbGVjdFBhZ2UsIHNlbGVjdGVkUGFnZUlkLCBvbkdlbmVyYXRlV2l0aEFpIH0pIHtcbiAgY29uc3QgW2V4cGFuZGVkTW9kdWxlcywgc2V0RXhwYW5kZWRNb2R1bGVzXSA9IHVzZVN0YXRlKCgpID0+IG5ldyBTZXQoKSlcbiAgY29uc3QgW2V4cGFuZGVkQ2hhcHRlcnMsIHNldEV4cGFuZGVkQ2hhcHRlcnNdID0gdXNlU3RhdGUoKCkgPT4gbmV3IFNldCgpKVxuXG4gIGNvbnN0IHRvZ2dsZSA9IChzZXQsIHNldFNldCwgaWQpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gbmV3IFNldChzZXQpXG4gICAgbmV4dC5oYXMoaWQpID8gbmV4dC5kZWxldGUoaWQpIDogbmV4dC5hZGQoaWQpXG4gICAgc2V0U2V0KG5leHQpXG4gIH1cblxuICBjb25zdCBhZGRNb2R1bGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdGl0bGUgPSB3aW5kb3cucHJvbXB0KCdOZXcgbW9kdWxlIHRpdGxlJylcbiAgICBpZiAoIXRpdGxlKSByZXR1cm5cbiAgICBhd2FpdCBhY3Rpb25zLmNyZWF0ZU1vZHVsZShjb3Vyc2UuaWQsIHRpdGxlKVxuICAgIG9uQ2hhbmdlKClcbiAgfVxuXG4gIGNvbnN0IHJlbmFtZU5vZGUgPSBhc3luYyAoa2luZCwgbm9kZSkgPT4ge1xuICAgIGNvbnN0IHRpdGxlID0gd2luZG93LnByb21wdCgnUmVuYW1lJywgbm9kZS50aXRsZSlcbiAgICBpZiAoIXRpdGxlIHx8IHRpdGxlID09PSBub2RlLnRpdGxlKSByZXR1cm5cbiAgICBpZiAoa2luZCA9PT0gJ21vZHVsZScpIGF3YWl0IGFjdGlvbnMucmVuYW1lTW9kdWxlKG5vZGUuaWQsIHRpdGxlKVxuICAgIGlmIChraW5kID09PSAnY2hhcHRlcicpIGF3YWl0IGFjdGlvbnMucmVuYW1lQ2hhcHRlcihub2RlLmlkLCB0aXRsZSlcbiAgICBpZiAoa2luZCA9PT0gJ3BhZ2UnKSBhd2FpdCBhY3Rpb25zLnJlbmFtZVBhZ2Uobm9kZS5pZCwgdGl0bGUpXG4gICAgb25DaGFuZ2UoKVxuICB9XG5cbiAgY29uc3QgZGVsZXRlTm9kZSA9IGFzeW5jIChraW5kLCBub2RlKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cuY29uZmlybShgRGVsZXRlIFwiJHtub2RlLnRpdGxlfVwiPyBUaGlzIGNhbm5vdCBiZSB1bmRvbmUuYCkpIHJldHVyblxuICAgIGlmIChraW5kID09PSAnbW9kdWxlJykgYXdhaXQgYWN0aW9ucy5kZWxldGVNb2R1bGUobm9kZS5pZClcbiAgICBpZiAoa2luZCA9PT0gJ2NoYXB0ZXInKSBhd2FpdCBhY3Rpb25zLmRlbGV0ZUNoYXB0ZXIobm9kZS5pZClcbiAgICBpZiAoa2luZCA9PT0gJ3BhZ2UnKSBhd2FpdCBhY3Rpb25zLmRlbGV0ZVBhZ2Uobm9kZS5pZClcbiAgICBvbkNoYW5nZSgpXG4gIH1cblxuICBjb25zdCBtb3ZlID0gYXN5bmMgKGtpbmQsIHBhcmVudElkLCBpZHMsIGluZGV4LCBkaXIpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gWy4uLmlkc11cbiAgICBjb25zdCB0YXJnZXQgPSBpbmRleCArIGRpclxuICAgIGlmICh0YXJnZXQgPCAwIHx8IHRhcmdldCA+PSBuZXh0Lmxlbmd0aCkgcmV0dXJuXG4gICAgO1tuZXh0W2luZGV4XSwgbmV4dFt0YXJnZXRdXSA9IFtuZXh0W3RhcmdldF0sIG5leHRbaW5kZXhdXVxuICAgIGlmIChraW5kID09PSAnbW9kdWxlJykgYXdhaXQgYWN0aW9ucy5yZW9yZGVyTW9kdWxlcyhjb3Vyc2UuaWQsIG5leHQpXG4gICAgaWYgKGtpbmQgPT09ICdjaGFwdGVyJykgYXdhaXQgYWN0aW9ucy5yZW9yZGVyQ2hhcHRlcnMocGFyZW50SWQsIG5leHQpXG4gICAgaWYgKGtpbmQgPT09ICdwYWdlJykgYXdhaXQgYWN0aW9ucy5yZW9yZGVyUGFnZXMocGFyZW50SWQsIG5leHQpXG4gICAgb25DaGFuZ2UoKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlLXRvb2xiYXJcIj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXthZGRNb2R1bGV9PlxuICAgICAgICAgIDxQbHVzIHNpemU9ezE2fSAvPiBBZGQgbW9kdWxlXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiY21zLWJ0bi1haVwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25HZW5lcmF0ZVdpdGhBaSh7IHNjb3BlOiAnbW9kdWxlJyB9KX1cbiAgICAgICAgPlxuICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxNn0gLz4gR2VuZXJhdGUgbW9kdWxlIHdpdGggQUlcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgeyhjb3Vyc2UubW9kdWxlcyB8fCBbXSkubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiY21zLWVtcHR5LWhpbnRcIj5ObyBtb2R1bGVzIHlldCDigJQgYWRkIG9uZSB0byBnZXQgc3RhcnRlZC48L3A+XG4gICAgICApfVxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiY21zLXRyZWUtbGlzdFwiPlxuICAgICAgICB7KGNvdXJzZS5tb2R1bGVzIHx8IFtdKS5tYXAoKG1vZHVsZSwgbWkpID0+IHtcbiAgICAgICAgICBjb25zdCBtb2R1bGVJZHMgPSAoY291cnNlLm1vZHVsZXMgfHwgW10pLm1hcCgobSkgPT4gbS5pZClcbiAgICAgICAgICBjb25zdCBpc09wZW4gPSBleHBhbmRlZE1vZHVsZXMuaGFzKG1vZHVsZS5pZClcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpIGtleT17bW9kdWxlLmlkfSBjbGFzc05hbWU9XCJjbXMtdHJlZS1ub2RlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXRyZWUtcm93XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjbXMtdHJlZS10b2dnbGVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlKGV4cGFuZGVkTW9kdWxlcywgc2V0RXhwYW5kZWRNb2R1bGVzLCBtb2R1bGUuaWQpfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc09wZW4gPyA8Q2hldnJvbkRvd24gc2l6ZT17MTZ9IC8+IDogPENoZXZyb25SaWdodCBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY21zLXRyZWUtbGFiZWxcIj57bW9kdWxlLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlLWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG1vdmUoJ21vZHVsZScsIG51bGwsIG1vZHVsZUlkcywgbWksIC0xKX0gdGl0bGU9XCJNb3ZlIHVwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBtb3ZlKCdtb2R1bGUnLCBudWxsLCBtb2R1bGVJZHMsIG1pLCAxKX0gdGl0bGU9XCJNb3ZlIGRvd25cIj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93RG93biBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gcmVuYW1lTm9kZSgnbW9kdWxlJywgbW9kdWxlKX0gdGl0bGU9XCJSZW5hbWVcIj5cbiAgICAgICAgICAgICAgICAgICAgPFBlbmNpbCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZGVsZXRlTm9kZSgnbW9kdWxlJywgbW9kdWxlKX0gdGl0bGU9XCJEZWxldGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25HZW5lcmF0ZVdpdGhBaSh7IHNjb3BlOiAnY2hhcHRlcicsIG1vZHVsZUlkOiBtb2R1bGUuaWQgfSl9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiR2VuZXJhdGUgY2hhcHRlciB3aXRoIEFJXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkdlbmVyYXRlV2l0aEFpKHsgc2NvcGU6ICdtb2R1bGUtcWNtJywgbW9kdWxlSWQ6IG1vZHVsZS5pZCB9KX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJHZW5lcmF0ZSBtb2R1bGUgcXVpeiB3aXRoIEFJXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgUUNNXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNtcy1idG4tc2Vjb25kYXJ5IGNtcy10cmVlLWFkZC1jaGlsZFwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0aXRsZSA9IHdpbmRvdy5wcm9tcHQoJ05ldyBjaGFwdGVyIHRpdGxlJylcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRpdGxlKSByZXR1cm5cbiAgICAgICAgICAgICAgICAgICAgICBhd2FpdCBhY3Rpb25zLmNyZWF0ZUNoYXB0ZXIobW9kdWxlLmlkLCB0aXRsZSlcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZSgpXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE0fSAvPiBBZGQgY2hhcHRlclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJjbXMtdHJlZS1saXN0IGNtcy10cmVlLWluZGVudFwiPlxuICAgICAgICAgICAgICAgICAgICB7KG1vZHVsZS5jaGFwdGVycyB8fCBbXSkubWFwKChjaGFwdGVyLCBjaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYXB0ZXJJZHMgPSAobW9kdWxlLmNoYXB0ZXJzIHx8IFtdKS5tYXAoKGMpID0+IGMuaWQpXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hPcGVuID0gZXhwYW5kZWRDaGFwdGVycy5oYXMoY2hhcHRlci5pZClcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17Y2hhcHRlci5pZH0gY2xhc3NOYW1lPVwiY21zLXRyZWUtbm9kZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY21zLXRyZWUtdG9nZ2xlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZShleHBhbmRlZENoYXB0ZXJzLCBzZXRFeHBhbmRlZENoYXB0ZXJzLCBjaGFwdGVyLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hPcGVuID8gPENoZXZyb25Eb3duIHNpemU9ezE2fSAvPiA6IDxDaGV2cm9uUmlnaHQgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNtcy10cmVlLWxhYmVsXCI+e2NoYXB0ZXIudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXRyZWUtYWN0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gbW92ZSgnY2hhcHRlcicsIG1vZHVsZS5pZCwgY2hhcHRlcklkcywgY2ksIC0xKX0gdGl0bGU9XCJNb3ZlIHVwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBtb3ZlKCdjaGFwdGVyJywgbW9kdWxlLmlkLCBjaGFwdGVySWRzLCBjaSwgMSl9IHRpdGxlPVwiTW92ZSBkb3duXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0Rvd24gc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHJlbmFtZU5vZGUoJ2NoYXB0ZXInLCBjaGFwdGVyKX0gdGl0bGU9XCJSZW5hbWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBlbmNpbCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gZGVsZXRlTm9kZSgnY2hhcHRlcicsIGNoYXB0ZXIpfSB0aXRsZT1cIkRlbGV0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkdlbmVyYXRlV2l0aEFpKHsgc2NvcGU6ICdwYWdlJywgY2hhcHRlcklkOiBjaGFwdGVyLmlkIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkdlbmVyYXRlIHBhZ2Ugd2l0aCBBSVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnkgY21zLXRyZWUtYWRkLWNoaWxkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpdGxlID0gd2luZG93LnByb21wdCgnTmV3IHBhZ2UgdGl0bGUnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdGl0bGUpIHJldHVyblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGFjdGlvbnMuY3JlYXRlUGFnZShjaGFwdGVyLmlkLCB0aXRsZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZSgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE0fSAvPiBBZGQgcGFnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJjbXMtdHJlZS1saXN0IGNtcy10cmVlLWluZGVudFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGNoYXB0ZXIucGFnZXMgfHwgW10pLm1hcCgocGFnZSwgcGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYWdlSWRzID0gKGNoYXB0ZXIucGFnZXMgfHwgW10pLm1hcCgocCkgPT4gcC5pZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17cGFnZS5pZH0gY2xhc3NOYW1lPVwiY21zLXRyZWUtbm9kZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlLXJvd1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY21zLXRyZWUtcGFnZS1idG4ke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFBhZ2VJZCA9PT0gcGFnZS5pZCA/ICcgY21zLXRyZWUtcGFnZS1zZWxlY3RlZCcgOiAnJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdFBhZ2UoeyAuLi5wYWdlLCBjaGFwdGVySWQ6IGNoYXB0ZXIuaWQgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BhZ2UudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtdHJlZS1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBtb3ZlKCdwYWdlJywgY2hhcHRlci5pZCwgcGFnZUlkcywgcGksIC0xKX0gdGl0bGU9XCJNb3ZlIHVwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBtb3ZlKCdwYWdlJywgY2hhcHRlci5pZCwgcGFnZUlkcywgcGksIDEpfSB0aXRsZT1cIk1vdmUgZG93blwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dEb3duIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiByZW5hbWVOb2RlKCdwYWdlJywgcGFnZSl9IHRpdGxlPVwiUmVuYW1lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5jaWwgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGRlbGV0ZU5vZGUoJ3BhZ2UnLCBwYWdlKX0gdGl0bGU9XCJEZWxldGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgPC91bD5cbiAgICA8L2Rpdj5cbiAgKVxufVxuIl19