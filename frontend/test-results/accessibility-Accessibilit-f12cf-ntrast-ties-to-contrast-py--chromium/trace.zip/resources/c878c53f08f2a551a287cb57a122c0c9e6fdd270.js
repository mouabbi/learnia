import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/AuthContext.jsx");const createContext = __vite__cjsImport0_react["createContext"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { authApi } from "/src/features/auth/authApi.js";
import { createLogger } from "/src/utils/logger.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/AuthContext.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const log = createLogger("auth");
const AuthContext = createContext(null);
_c = AuthContext;
/**
* App-wide auth state, per 02-architecture's "frontend: auth state
* available app-wide" requirement. Wraps the whole app once (see App.jsx)
* so any component can call useAuth() instead of each page fetching /me
* and managing its own "am I logged in" state independently.
*/
export function AuthProvider({ children }) {
	_s();
	const [user, setUser] = useState(null);
	// Distinguishes "haven't checked yet" from "checked, not logged in" —
	// without this, a protected route would flash a redirect-to-login
	// before the initial GET /auth/me call even resolves.
	const [isLoading, setIsLoading] = useState(true);
	useEffect(() => {
		authApi.getMe().then((me) => {
			log.info("session check: logged in", { userId: me.id });
			setUser(me);
		}).catch(() => {
			log.info("session check: not logged in");
			setUser(null);
		}).finally(() => setIsLoading(false));
	}, []);
	// Two possible outcomes (see backend AuthService.login's docstring):
	//   { mfaRequired: false, user }      — logged in, session cookie set
	//   { mfaRequired: true, mfaTicket }  — password ok, still needs a TOTP/
	//                                       recovery code (see completeMfaLogin)
	const login = useCallback(async (email, password) => {
		try {
			const result = await authApi.loginPassword(email, password);
			if (result.mfa_required) {
				log.info("login: password ok, MFA challenge required");
				return {
					mfaRequired: true,
					mfaTicket: result.mfa_ticket
				};
			}
			log.info("login ok", { userId: result.user.id });
			setUser(result.user);
			return {
				mfaRequired: false,
				user: result.user
			};
		} catch (error) {
			log.warn("login failed", { reason: error.code ?? error.message });
			throw error;
		}
	}, []);
	const completeMfaLogin = useCallback(async (mfaTicket, code) => {
		try {
			const loggedInUser = await authApi.loginMfa(mfaTicket, code);
			log.info("MFA challenge ok", { userId: loggedInUser.id });
			setUser(loggedInUser);
			return loggedInUser;
		} catch (error) {
			log.warn("MFA challenge failed", { reason: error.code ?? error.message });
			throw error;
		}
	}, []);
	const register = useCallback(async (email, password) => {
		try {
			const newUser = await authApi.register(email, password);
			log.info("register ok", { userId: newUser.id });
			setUser(newUser);
			return newUser;
		} catch (error) {
			log.warn("register failed", { reason: error.code ?? error.message });
			throw error;
		}
	}, []);
	const logout = useCallback(async () => {
		await authApi.logout();
		log.info("logout ok");
		setUser(null);
	}, []);
	const value = {
		user,
		isLoading,
		isAuthenticated: user !== null,
		login,
		completeMfaLogin,
		register,
		logout
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 96,
		columnNumber: 10
	}, this);
}
_s(AuthProvider, "K+ebRBjF8rr35dnKLT4Z4tT7G8o=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const context = useContext(AuthContext);
	if (context === null) {
		throw new Error("useAuth() must be used inside an <AuthProvider>");
	}
	return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/AuthContext.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/AuthContext.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLGFBQWEsWUFBWSxXQUFXLGdCQUFnQjtBQUM1RSxTQUFTLGVBQWU7QUFDeEIsU0FBUyxvQkFBb0I7Ozs7QUFFN0IsTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUUvQixNQUFNLGNBQWMsY0FBYyxJQUFJOzs7Ozs7OztBQVF0QyxPQUFPLFNBQVMsYUFBYSxFQUFFLFlBQVk7O0NBQ3pDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxJQUFJOzs7O0NBSXJDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FFL0MsZ0JBQWdCO0VBQ2QsUUFDRyxNQUFNLENBQUMsQ0FDUCxNQUFNLE9BQU87R0FDWixJQUFJLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxHQUFHLEdBQUcsQ0FBQztHQUN0RCxRQUFRLEVBQUU7RUFDWixDQUFDLENBQUMsQ0FDRCxZQUFZO0dBQ1gsSUFBSSxLQUFLLDhCQUE4QjtHQUN2QyxRQUFRLElBQUk7RUFDZCxDQUFDLENBQUMsQ0FDRCxjQUFjLGFBQWEsS0FBSyxDQUFDO0NBQ3RDLEdBQUcsQ0FBQyxDQUFDOzs7OztDQU1MLE1BQU0sUUFBUSxZQUFZLE9BQU8sT0FBTyxhQUFhO0VBQ25ELElBQUk7R0FDRixNQUFNLFNBQVMsTUFBTSxRQUFRLGNBQWMsT0FBTyxRQUFRO0dBQzFELElBQUksT0FBTyxjQUFjO0lBQ3ZCLElBQUksS0FBSyw0Q0FBNEM7SUFDckQsT0FBTztLQUFFLGFBQWE7S0FBTSxXQUFXLE9BQU87SUFBVztHQUMzRDtHQUNBLElBQUksS0FBSyxZQUFZLEVBQUUsUUFBUSxPQUFPLEtBQUssR0FBRyxDQUFDO0dBQy9DLFFBQVEsT0FBTyxJQUFJO0dBQ25CLE9BQU87SUFBRSxhQUFhO0lBQU8sTUFBTSxPQUFPO0dBQUs7RUFDakQsU0FBUyxPQUFPO0dBQ2QsSUFBSSxLQUFLLGdCQUFnQixFQUFFLFFBQVEsTUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDO0dBQ2hFLE1BQU07RUFDUjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxtQkFBbUIsWUFBWSxPQUFPLFdBQVcsU0FBUztFQUM5RCxJQUFJO0dBQ0YsTUFBTSxlQUFlLE1BQU0sUUFBUSxTQUFTLFdBQVcsSUFBSTtHQUMzRCxJQUFJLEtBQUssb0JBQW9CLEVBQUUsUUFBUSxhQUFhLEdBQUcsQ0FBQztHQUN4RCxRQUFRLFlBQVk7R0FDcEIsT0FBTztFQUNULFNBQVMsT0FBTztHQUNkLElBQUksS0FBSyx3QkFBd0IsRUFBRSxRQUFRLE1BQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQztHQUN4RSxNQUFNO0VBQ1I7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sV0FBVyxZQUFZLE9BQU8sT0FBTyxhQUFhO0VBQ3RELElBQUk7R0FDRixNQUFNLFVBQVUsTUFBTSxRQUFRLFNBQVMsT0FBTyxRQUFRO0dBQ3RELElBQUksS0FBSyxlQUFlLEVBQUUsUUFBUSxRQUFRLEdBQUcsQ0FBQztHQUM5QyxRQUFRLE9BQU87R0FDZixPQUFPO0VBQ1QsU0FBUyxPQUFPO0dBQ2QsSUFBSSxLQUFLLG1CQUFtQixFQUFFLFFBQVEsTUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDO0dBQ25FLE1BQU07RUFDUjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxTQUFTLFlBQVksWUFBWTtFQUNyQyxNQUFNLFFBQVEsT0FBTztFQUNyQixJQUFJLEtBQUssV0FBVztFQUNwQixRQUFRLElBQUk7Q0FDZCxHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sUUFBUTtFQUNaO0VBQ0E7RUFDQSxpQkFBaUIsU0FBUztFQUMxQjtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBRUEsT0FBTyx3QkFBQyxZQUFZLFVBQWI7RUFBNkI7RUFBUTtDQUErQjs7Ozs7QUFDN0U7OztBQUVBLE9BQU8sU0FBUyxVQUFVOztDQUN4QixNQUFNLFVBQVUsV0FBVyxXQUFXO0NBQ3RDLElBQUksWUFBWSxNQUFNO0VBQ3BCLE1BQU0sSUFBSSxNQUFNLGlEQUFpRDtDQUNuRTtDQUNBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gJy4vYXV0aEFwaSdcclxuaW1wb3J0IHsgY3JlYXRlTG9nZ2VyIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2VyJ1xyXG5cclxuY29uc3QgbG9nID0gY3JlYXRlTG9nZ2VyKCdhdXRoJylcclxuXHJcbmNvbnN0IEF1dGhDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKVxyXG5cclxuLyoqXHJcbiAqIEFwcC13aWRlIGF1dGggc3RhdGUsIHBlciAwMi1hcmNoaXRlY3R1cmUncyBcImZyb250ZW5kOiBhdXRoIHN0YXRlXHJcbiAqIGF2YWlsYWJsZSBhcHAtd2lkZVwiIHJlcXVpcmVtZW50LiBXcmFwcyB0aGUgd2hvbGUgYXBwIG9uY2UgKHNlZSBBcHAuanN4KVxyXG4gKiBzbyBhbnkgY29tcG9uZW50IGNhbiBjYWxsIHVzZUF1dGgoKSBpbnN0ZWFkIG9mIGVhY2ggcGFnZSBmZXRjaGluZyAvbWVcclxuICogYW5kIG1hbmFnaW5nIGl0cyBvd24gXCJhbSBJIGxvZ2dlZCBpblwiIHN0YXRlIGluZGVwZW5kZW50bHkuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfSkge1xyXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgLy8gRGlzdGluZ3Vpc2hlcyBcImhhdmVuJ3QgY2hlY2tlZCB5ZXRcIiBmcm9tIFwiY2hlY2tlZCwgbm90IGxvZ2dlZCBpblwiIOKAlFxyXG4gIC8vIHdpdGhvdXQgdGhpcywgYSBwcm90ZWN0ZWQgcm91dGUgd291bGQgZmxhc2ggYSByZWRpcmVjdC10by1sb2dpblxyXG4gIC8vIGJlZm9yZSB0aGUgaW5pdGlhbCBHRVQgL2F1dGgvbWUgY2FsbCBldmVuIHJlc29sdmVzLlxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYXV0aEFwaVxyXG4gICAgICAuZ2V0TWUoKVxyXG4gICAgICAudGhlbigobWUpID0+IHtcclxuICAgICAgICBsb2cuaW5mbygnc2Vzc2lvbiBjaGVjazogbG9nZ2VkIGluJywgeyB1c2VySWQ6IG1lLmlkIH0pXHJcbiAgICAgICAgc2V0VXNlcihtZSlcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICBsb2cuaW5mbygnc2Vzc2lvbiBjaGVjazogbm90IGxvZ2dlZCBpbicpXHJcbiAgICAgICAgc2V0VXNlcihudWxsKVxyXG4gICAgICB9KVxyXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRJc0xvYWRpbmcoZmFsc2UpKVxyXG4gIH0sIFtdKVxyXG5cclxuICAvLyBUd28gcG9zc2libGUgb3V0Y29tZXMgKHNlZSBiYWNrZW5kIEF1dGhTZXJ2aWNlLmxvZ2luJ3MgZG9jc3RyaW5nKTpcclxuICAvLyAgIHsgbWZhUmVxdWlyZWQ6IGZhbHNlLCB1c2VyIH0gICAgICDigJQgbG9nZ2VkIGluLCBzZXNzaW9uIGNvb2tpZSBzZXRcclxuICAvLyAgIHsgbWZhUmVxdWlyZWQ6IHRydWUsIG1mYVRpY2tldCB9ICDigJQgcGFzc3dvcmQgb2ssIHN0aWxsIG5lZWRzIGEgVE9UUC9cclxuICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlY292ZXJ5IGNvZGUgKHNlZSBjb21wbGV0ZU1mYUxvZ2luKVxyXG4gIGNvbnN0IGxvZ2luID0gdXNlQ2FsbGJhY2soYXN5bmMgKGVtYWlsLCBwYXNzd29yZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYXV0aEFwaS5sb2dpblBhc3N3b3JkKGVtYWlsLCBwYXNzd29yZClcclxuICAgICAgaWYgKHJlc3VsdC5tZmFfcmVxdWlyZWQpIHtcclxuICAgICAgICBsb2cuaW5mbygnbG9naW46IHBhc3N3b3JkIG9rLCBNRkEgY2hhbGxlbmdlIHJlcXVpcmVkJylcclxuICAgICAgICByZXR1cm4geyBtZmFSZXF1aXJlZDogdHJ1ZSwgbWZhVGlja2V0OiByZXN1bHQubWZhX3RpY2tldCB9XHJcbiAgICAgIH1cclxuICAgICAgbG9nLmluZm8oJ2xvZ2luIG9rJywgeyB1c2VySWQ6IHJlc3VsdC51c2VyLmlkIH0pXHJcbiAgICAgIHNldFVzZXIocmVzdWx0LnVzZXIpXHJcbiAgICAgIHJldHVybiB7IG1mYVJlcXVpcmVkOiBmYWxzZSwgdXNlcjogcmVzdWx0LnVzZXIgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nLndhcm4oJ2xvZ2luIGZhaWxlZCcsIHsgcmVhc29uOiBlcnJvci5jb2RlID8/IGVycm9yLm1lc3NhZ2UgfSlcclxuICAgICAgdGhyb3cgZXJyb3JcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgY29tcGxldGVNZmFMb2dpbiA9IHVzZUNhbGxiYWNrKGFzeW5jIChtZmFUaWNrZXQsIGNvZGUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGxvZ2dlZEluVXNlciA9IGF3YWl0IGF1dGhBcGkubG9naW5NZmEobWZhVGlja2V0LCBjb2RlKVxyXG4gICAgICBsb2cuaW5mbygnTUZBIGNoYWxsZW5nZSBvaycsIHsgdXNlcklkOiBsb2dnZWRJblVzZXIuaWQgfSlcclxuICAgICAgc2V0VXNlcihsb2dnZWRJblVzZXIpXHJcbiAgICAgIHJldHVybiBsb2dnZWRJblVzZXJcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZy53YXJuKCdNRkEgY2hhbGxlbmdlIGZhaWxlZCcsIHsgcmVhc29uOiBlcnJvci5jb2RlID8/IGVycm9yLm1lc3NhZ2UgfSlcclxuICAgICAgdGhyb3cgZXJyb3JcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgcmVnaXN0ZXIgPSB1c2VDYWxsYmFjayhhc3luYyAoZW1haWwsIHBhc3N3b3JkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBuZXdVc2VyID0gYXdhaXQgYXV0aEFwaS5yZWdpc3RlcihlbWFpbCwgcGFzc3dvcmQpXHJcbiAgICAgIGxvZy5pbmZvKCdyZWdpc3RlciBvaycsIHsgdXNlcklkOiBuZXdVc2VyLmlkIH0pXHJcbiAgICAgIHNldFVzZXIobmV3VXNlcikgLy8gYmFja2VuZCBsb2dzIHRoZSB1c2VyIGluIGltbWVkaWF0ZWx5IG9uIHJlZ2lzdGVyXHJcbiAgICAgIHJldHVybiBuZXdVc2VyXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2cud2FybigncmVnaXN0ZXIgZmFpbGVkJywgeyByZWFzb246IGVycm9yLmNvZGUgPz8gZXJyb3IubWVzc2FnZSB9KVxyXG4gICAgICB0aHJvdyBlcnJvclxyXG4gICAgfVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBsb2dvdXQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBhdXRoQXBpLmxvZ291dCgpXHJcbiAgICBsb2cuaW5mbygnbG9nb3V0IG9rJylcclxuICAgIHNldFVzZXIobnVsbClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgdmFsdWUgPSB7XHJcbiAgICB1c2VyLFxyXG4gICAgaXNMb2FkaW5nLFxyXG4gICAgaXNBdXRoZW50aWNhdGVkOiB1c2VyICE9PSBudWxsLFxyXG4gICAgbG9naW4sXHJcbiAgICBjb21wbGV0ZU1mYUxvZ2luLFxyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBsb2dvdXQsXHJcbiAgfVxyXG5cclxuICByZXR1cm4gPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+e2NoaWxkcmVufTwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1c2VBdXRoKCkge1xyXG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KEF1dGhDb250ZXh0KVxyXG4gIGlmIChjb250ZXh0ID09PSBudWxsKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ3VzZUF1dGgoKSBtdXN0IGJlIHVzZWQgaW5zaWRlIGFuIDxBdXRoUHJvdmlkZXI+JylcclxuICB9XHJcbiAgcmV0dXJuIGNvbnRleHRcclxufVxyXG4iXX0=