import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/AiImportModal.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { X, Copy, Check, Loader2, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { cmsApi } from "/src/features/cms/cmsApi.js";
import { BlockRenderer } from "/src/features/cms/BlockRenderer.jsx?t=1790183660675";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AiImportModal.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
/**
* AiImportModal — the manual AI workflow (12 + 13), reachable as a
* "Generate with AI" button from the Structure/Content/Assessments tabs.
*
* Step 1: fetch + show the copy-pasteable prompt (12).
* Step 2: paste the JSON the user got back, Validate it (13), preview it,
*         then Commit (only enabled once valid) — with an explicit
*         replace-confirmation if the target already has content.
*
* Props:
*  - open, onClose
*  - courseId, scope ("course"|"module"|"chapter"|"page"|"module-qcm"|"final-exam")
*  - targetIds: { moduleId?, chapterId?, pageId? } — passed straight through
*    to the prompt-builder and commit endpoints.
*  - onCommitted(result): called after a successful commit.
*/
export function AiImportModal({ open, onClose, courseId, scope, targetIds = {}, onCommitted }) {
	_s();
	const [step, setStep] = useState(1);
	const [prompt, setPrompt] = useState("");
	const [promptLoading, setPromptLoading] = useState(false);
	const [promptError, setPromptError] = useState(null);
	const [copied, setCopied] = useState(false);
	const [pastedJson, setPastedJson] = useState("");
	const [validating, setValidating] = useState(false);
	const [validateResult, setValidateResult] = useState(null);
	const [needsReplaceConfirm, setNeedsReplaceConfirm] = useState(false);
	const [committing, setCommitting] = useState(false);
	const [commitError, setCommitError] = useState(null);
	useEffect(() => {
		if (!open) return;
		setStep(1);
		setPastedJson("");
		setValidateResult(null);
		setNeedsReplaceConfirm(false);
		setCommitError(null);
		setPromptError(null);
		setPromptLoading(true);
		cmsApi.getPrompt(courseId, scope, targetIds).then((res) => setPrompt(res.prompt)).catch((err) => setPromptError(err.message || "Failed to build prompt")).finally(() => setPromptLoading(false));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		open,
		courseId,
		scope
	]);
	if (!open) return null;
	const copyPrompt = async () => {
		try {
			await navigator.clipboard.writeText(prompt);
			setCopied(true);
			setTimeout(() => setCopied(false), 1500);
		} catch {}
	};
	const runValidate = async () => {
		setValidating(true);
		setValidateResult(null);
		setCommitError(null);
		try {
			const result = await cmsApi.validateImport(courseId, scope, pastedJson);
			setValidateResult(result);
		} catch (err) {
			setValidateResult({
				valid: false,
				errors: [{
					field: "(request)",
					message: err.message
				}]
			});
		} finally {
			setValidating(false);
		}
	};
	const runCommit = async (replace) => {
		setCommitting(true);
		setCommitError(null);
		try {
			const result = await cmsApi.commitImport(courseId, scope, pastedJson, {
				replace,
				...targetIds
			});
			setNeedsReplaceConfirm(false);
			onCommitted?.(result);
			onClose();
		} catch (err) {
			if (err.code === "VALIDATION_ERROR" && /replace:true/.test(err.message || "")) {
				setNeedsReplaceConfirm(true);
				setCommitError(err.message);
			} else {
				setCommitError(err.message || "Commit failed");
			}
		} finally {
			setCommitting(false);
		}
	};
	const parsedPreview = validateResult?.valid ? validateResult.parsed : null;
	return /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "cms-modal-overlay",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		onClick: onClose,
		children: /* @__PURE__ */ _jsxDEV(motion.div, {
			className: "cms-modal",
			initial: {
				opacity: 0,
				y: 16,
				scale: .98
			},
			animate: {
				opacity: 1,
				y: 0,
				scale: 1
			},
			exit: {
				opacity: 0,
				y: 16,
				scale: .98
			},
			transition: {
				duration: .18,
				ease: "easeOut"
			},
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "cms-modal-header",
					children: [/* @__PURE__ */ _jsxDEV("h3", { children: ["Generate with AI — ", scope] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "cms-btn-icon",
						onClick: onClose,
						"aria-label": "Close",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "cms-modal-steps",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: step === 1 ? "cms-step-active" : "",
						children: "1. Copy prompt"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: step === 2 ? "cms-step-active" : "",
						children: "2. Paste JSON"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(AnimatePresence, {
					mode: "wait",
					children: step === 1 ? /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							x: 12
						},
						animate: {
							opacity: 1,
							x: 0
						},
						exit: {
							opacity: 0,
							x: -12
						},
						transition: { duration: .15 },
						className: "cms-modal-body",
						children: [
							promptLoading && /* @__PURE__ */ _jsxDEV("p", {
								className: "cms-loading",
								children: [/* @__PURE__ */ _jsxDEV(Loader2, {
									className: "cms-spin",
									size: 16
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 21
								}, this), " Building prompt…"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 19
							}, this),
							promptError && /* @__PURE__ */ _jsxDEV("p", {
								className: "cms-error",
								children: promptError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 33
							}, this),
							!promptLoading && !promptError && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("p", {
									className: "cms-hint",
									children: "Copy this into your AI chat tool of choice, then paste the JSON it gives back in the next step."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									className: "cms-prompt-textarea",
									rows: 14,
									readOnly: true,
									value: prompt
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "cms-modal-actions",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-secondary",
										onClick: copyPrompt,
										children: [copied ? /* @__PURE__ */ _jsxDEV(Check, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 160,
											columnNumber: 35
										}, this) : /* @__PURE__ */ _jsxDEV(Copy, { size: 16 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 160,
											columnNumber: 57
										}, this), copied ? "Copied" : "Copy to clipboard"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 159,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-primary",
										onClick: () => setStep(2),
										children: "Next: paste JSON"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 21
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 19
							}, this)
						]
					}, "step1", true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							x: 12
						},
						animate: {
							opacity: 1,
							x: 0
						},
						exit: {
							opacity: 0,
							x: -12
						},
						transition: { duration: .15 },
						className: "cms-modal-body",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "cms-hint",
								children: "Paste the JSON your AI tool returned:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								className: "cms-prompt-textarea cms-mono",
								rows: 10,
								value: pastedJson,
								onChange: (e) => {
									setPastedJson(e.target.value);
									setValidateResult(null);
									setNeedsReplaceConfirm(false);
								},
								placeholder: "{ ... }"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "cms-modal-actions",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-secondary",
										onClick: () => setStep(1),
										children: "Back"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-secondary",
										onClick: runValidate,
										disabled: !pastedJson.trim() || validating,
										children: [validating ? /* @__PURE__ */ _jsxDEV(Loader2, {
											className: "cms-spin",
											size: 16
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 35
										}, this) : null, "Validate"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "cms-btn-primary",
										disabled: !validateResult?.valid || committing,
										onClick: () => runCommit(false),
										children: [committing ? /* @__PURE__ */ _jsxDEV(Loader2, {
											className: "cms-spin",
											size: 16
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 211,
											columnNumber: 35
										}, this) : null, "Commit"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 205,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 17
							}, this),
							validateResult && !validateResult.valid && /* @__PURE__ */ _jsxDEV("div", {
								className: "cms-error-list",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "cms-error",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 14 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 23
									}, this), " Invalid JSON — fix these and re-validate:"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("ul", { children: validateResult.errors.map((e, i) => /* @__PURE__ */ _jsxDEV("li", { children: [
									/* @__PURE__ */ _jsxDEV("code", { children: e.field }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 224,
										columnNumber: 27
									}, this),
									": ",
									e.message
								] }, i, true, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 25
								}, this)) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 19
							}, this),
							validateResult?.valid && /* @__PURE__ */ _jsxDEV("div", {
								className: "cms-preview",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "cms-hint",
									children: "Looks valid. Preview:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 21
								}, this), scope === "page" ? /* @__PURE__ */ _jsxDEV(BlockRenderer, { blocks: parsedPreview?.blocks }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 235,
									columnNumber: 23
								}, this) : Array.isArray(parsedPreview) ? /* @__PURE__ */ _jsxDEV("ul", {
									className: "cms-question-preview-list",
									children: parsedPreview.map((q, i) => /* @__PURE__ */ _jsxDEV("li", { children: q.text }, i, false, {
										fileName: _jsxFileName,
										lineNumber: 239,
										columnNumber: 27
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 237,
									columnNumber: 23
								}, this) : /* @__PURE__ */ _jsxDEV("pre", {
									className: "cms-mono",
									children: JSON.stringify(parsedPreview, null, 2)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 243,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 19
							}, this),
							commitError && /* @__PURE__ */ _jsxDEV("div", {
								className: "cms-error-list",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "cms-error",
									children: [
										/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 23
										}, this),
										" ",
										commitError
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 21
								}, this), needsReplaceConfirm && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "cms-btn-danger",
									onClick: () => runCommit(true),
									disabled: committing,
									children: "Overwrite existing content"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 19
							}, this)
						]
					}, "step2", true, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 115,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 107,
		columnNumber: 5
	}, this);
}
_s(AiImportModal, "eMccggB4VPliCwMFLCOdOaaQ/EY=");
_c = AiImportModal;
var _c;
$RefreshReg$(_c, "AiImportModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/AiImportModal.jsx?t=1790183660675";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AiImportModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AiImportModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/AiImportModal.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGlCQUFpQixjQUFjO0FBQ3hDLFNBQVMsR0FBRyxNQUFNLE9BQU8sU0FBUyxxQkFBcUI7QUFDdkQsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCOUIsT0FBTyxTQUFTLGNBQWMsRUFBRSxNQUFNLFNBQVMsVUFBVSxPQUFPLFlBQVksQ0FBQyxHQUFHLGVBQWU7O0NBQzdGLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBQ2xDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7Q0FDeEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsSUFBSTtDQUNuRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUUxQyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxJQUFJO0NBQ3pELE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUNwRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLElBQUk7Q0FFbkQsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE1BQU07RUFDWCxRQUFRLENBQUM7RUFDVCxjQUFjLEVBQUU7RUFDaEIsa0JBQWtCLElBQUk7RUFDdEIsdUJBQXVCLEtBQUs7RUFDNUIsZUFBZSxJQUFJO0VBQ25CLGVBQWUsSUFBSTtFQUNuQixpQkFBaUIsSUFBSTtFQUNyQixPQUNHLFVBQVUsVUFBVSxPQUFPLFNBQVMsQ0FBQyxDQUNyQyxNQUFNLFFBQVEsVUFBVSxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQ3BDLE9BQU8sUUFBUSxlQUFlLElBQUksV0FBVyx3QkFBd0IsQ0FBQyxDQUFDLENBQ3ZFLGNBQWMsaUJBQWlCLEtBQUssQ0FBQzs7Q0FFMUMsR0FBRztFQUFDO0VBQU07RUFBVTtDQUFLLENBQUM7Q0FFMUIsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUVsQixNQUFNLGFBQWEsWUFBWTtFQUM3QixJQUFJO0dBQ0YsTUFBTSxVQUFVLFVBQVUsVUFBVSxNQUFNO0dBQzFDLFVBQVUsSUFBSTtHQUNkLGlCQUFpQixVQUFVLEtBQUssR0FBRyxJQUFJO0VBQ3pDLFFBQVEsQ0FHUjtDQUNGO0NBRUEsTUFBTSxjQUFjLFlBQVk7RUFDOUIsY0FBYyxJQUFJO0VBQ2xCLGtCQUFrQixJQUFJO0VBQ3RCLGVBQWUsSUFBSTtFQUNuQixJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0sT0FBTyxlQUFlLFVBQVUsT0FBTyxVQUFVO0dBQ3RFLGtCQUFrQixNQUFNO0VBQzFCLFNBQVMsS0FBSztHQUNaLGtCQUFrQjtJQUFFLE9BQU87SUFBTyxRQUFRLENBQUM7S0FBRSxPQUFPO0tBQWEsU0FBUyxJQUFJO0lBQVEsQ0FBQztHQUFFLENBQUM7RUFDNUYsVUFBVTtHQUNSLGNBQWMsS0FBSztFQUNyQjtDQUNGO0NBRUEsTUFBTSxZQUFZLE9BQU8sWUFBWTtFQUNuQyxjQUFjLElBQUk7RUFDbEIsZUFBZSxJQUFJO0VBQ25CLElBQUk7R0FDRixNQUFNLFNBQVMsTUFBTSxPQUFPLGFBQWEsVUFBVSxPQUFPLFlBQVk7SUFDcEU7SUFDQSxHQUFHO0dBQ0wsQ0FBQztHQUNELHVCQUF1QixLQUFLO0dBQzVCLGNBQWMsTUFBTTtHQUNwQixRQUFRO0VBQ1YsU0FBUyxLQUFLO0dBQ1osSUFBSSxJQUFJLFNBQVMsc0JBQXNCLGVBQWUsS0FBSyxJQUFJLFdBQVcsRUFBRSxHQUFHO0lBQzdFLHVCQUF1QixJQUFJO0lBQzNCLGVBQWUsSUFBSSxPQUFPO0dBQzVCLE9BQU87SUFDTCxlQUFlLElBQUksV0FBVyxlQUFlO0dBQy9DO0VBQ0YsVUFBVTtHQUNSLGNBQWMsS0FBSztFQUNyQjtDQUNGO0NBRUEsTUFBTSxnQkFBZ0IsZ0JBQWdCLFFBQVEsZUFBZSxTQUFTO0NBRXRFLE9BQ0Usd0JBQUMsaUJBQUQsWUFDRSx3QkFBQyxPQUFPLEtBQVI7RUFDRSxXQUFVO0VBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7RUFDbkIsU0FBUztZQUVULHdCQUFDLE9BQU8sS0FBUjtHQUNFLFdBQVU7R0FDVixTQUFTO0lBQUUsU0FBUztJQUFHLEdBQUc7SUFBSSxPQUFPO0dBQUs7R0FDMUMsU0FBUztJQUFFLFNBQVM7SUFBRyxHQUFHO0lBQUcsT0FBTztHQUFFO0dBQ3RDLE1BQU07SUFBRSxTQUFTO0lBQUcsR0FBRztJQUFJLE9BQU87R0FBSztHQUN2QyxZQUFZO0lBQUUsVUFBVTtJQUFNLE1BQU07R0FBVTtHQUM5QyxVQUFVLE1BQU0sRUFBRSxnQkFBZ0I7YUFOcEM7SUFRRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRCxhQUFJLHVCQUFvQixLQUFVOzs7O2VBQ2xDLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFlLFNBQVM7TUFBUyxjQUFXO2dCQUMxRSx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztLQUNSOzs7O2FBQ0w7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVyxTQUFTLElBQUksb0JBQW9CO2dCQUFJO0tBQW9COzs7O2VBQzFFLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLFNBQVMsSUFBSSxvQkFBb0I7Z0JBQUk7S0FBbUI7Ozs7YUFDdEU7Ozs7OztJQUVMLHdCQUFDLGlCQUFEO0tBQWlCLE1BQUs7ZUFDbkIsU0FBUyxJQUNSLHdCQUFDLE9BQU8sS0FBUjtNQUVFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFHO01BQzdCLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLE1BQU07T0FBRSxTQUFTO09BQUcsR0FBRyxDQUFDO01BQUc7TUFDM0IsWUFBWSxFQUFFLFVBQVUsSUFBSztNQUM3QixXQUFVO2dCQU5aO09BUUcsaUJBQ0Msd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FDRSx3QkFBQyxTQUFEO1NBQVMsV0FBVTtTQUFXLE1BQU07UUFBSzs7OztrQkFBQyxtQkFDekM7Ozs7OztPQUVKLGVBQWUsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWE7T0FBZTs7Ozs7T0FDeEQsQ0FBQyxpQkFBaUIsQ0FBQyxlQUNsQjtRQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFXO1FBR3JCOzs7OztRQUNILHdCQUFDLFlBQUQ7U0FBVSxXQUFVO1NBQXNCLE1BQU07U0FBSTtTQUFTLE9BQU87UUFBUzs7Ozs7UUFDN0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLFdBQVU7VUFBb0IsU0FBUztvQkFBN0QsQ0FDRyxTQUFTLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7cUJBQUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztvQkFDaEQsU0FBUyxXQUFXLG1CQUNmOzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLFdBQVU7VUFBa0IsZUFBZSxRQUFRLENBQUM7b0JBQUc7U0FFckU7Ozs7aUJBQ0w7Ozs7OztPQUNMOzs7OztNQUVNO1FBL0JOOzs7O1lBK0JNLElBRVosd0JBQUMsT0FBTyxLQUFSO01BRUUsU0FBUztPQUFFLFNBQVM7T0FBRyxHQUFHO01BQUc7TUFDN0IsU0FBUztPQUFFLFNBQVM7T0FBRyxHQUFHO01BQUU7TUFDNUIsTUFBTTtPQUFFLFNBQVM7T0FBRyxHQUFHLENBQUM7TUFBRztNQUMzQixZQUFZLEVBQUUsVUFBVSxJQUFLO01BQzdCLFdBQVU7Z0JBTlo7T0FRRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBVztPQUF3Qzs7Ozs7T0FDaEUsd0JBQUMsWUFBRDtRQUNFLFdBQVU7UUFDVixNQUFNO1FBQ04sT0FBTztRQUNQLFdBQVcsTUFBTTtTQUNmLGNBQWMsRUFBRSxPQUFPLEtBQUs7U0FDNUIsa0JBQWtCLElBQUk7U0FDdEIsdUJBQXVCLEtBQUs7UUFDOUI7UUFDQSxhQUFZO09BQ2I7Ozs7O09BRUQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFEO1VBQVEsTUFBSztVQUFTLFdBQVU7VUFBb0IsZUFBZSxRQUFRLENBQUM7b0JBQUc7U0FFdkU7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxXQUFVO1VBQ1YsU0FBUztVQUNULFVBQVUsQ0FBQyxXQUFXLEtBQUssS0FBSztvQkFKbEMsQ0FNRyxhQUFhLHdCQUFDLFNBQUQ7V0FBUyxXQUFVO1dBQVcsTUFBTTtVQUFLOzs7O3FCQUFJLE1BQUssVUFFMUQ7Ozs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsV0FBVTtVQUNWLFVBQVUsQ0FBQyxnQkFBZ0IsU0FBUztVQUNwQyxlQUFlLFVBQVUsS0FBSztvQkFKaEMsQ0FNRyxhQUFhLHdCQUFDLFNBQUQ7V0FBUyxXQUFVO1dBQVcsTUFBTTtVQUFLOzs7O3FCQUFJLE1BQUssUUFFMUQ7Ozs7OztRQUNMOzs7Ozs7T0FFSixrQkFBa0IsQ0FBQyxlQUFlLFNBQ2pDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FDRSx3QkFBQyxlQUFELEVBQWUsTUFBTSxHQUFLOzs7O21CQUFDLDRDQUMxQjs7Ozs7a0JBQ0gsd0JBQUMsTUFBRCxZQUNHLGVBQWUsT0FBTyxLQUFLLEdBQUcsTUFDN0Isd0JBQUMsTUFBRDtTQUNFLHdCQUFDLFFBQUQsWUFBTyxFQUFFLE1BQVk7Ozs7O1NBQUM7U0FBRyxFQUFFO1FBQ3pCLEtBRks7Ozs7ZUFFTCxDQUNMLEVBQ0M7Ozs7Z0JBQ0Q7Ozs7OztPQUdOLGdCQUFnQixTQUNmLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQVc7UUFBd0I7Ozs7a0JBQy9DLFVBQVUsU0FDVCx3QkFBQyxlQUFELEVBQWUsUUFBUSxlQUFlLE9BQVM7Ozs7bUJBQzdDLE1BQU0sUUFBUSxhQUFhLElBQzdCLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLGNBQWMsS0FBSyxHQUFHLE1BQ3JCLHdCQUFDLE1BQUQsWUFBYSxFQUFFLEtBQVMsR0FBZjs7OztnQkFBZSxDQUN6QjtRQUNDOzs7O21CQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFZLEtBQUssVUFBVSxlQUFlLE1BQU0sQ0FBQztRQUFPOzs7O2dCQUV0RTs7Ozs7O09BR04sZUFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQ0Usd0JBQUMsZUFBRCxFQUFlLE1BQU0sR0FBSzs7Ozs7VUFBQztVQUFFO1NBQzVCOzs7OztrQkFDRix1QkFDQyx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7U0FDVixlQUFlLFVBQVUsSUFBSTtTQUM3QixVQUFVO21CQUNYO1FBRU87Ozs7Z0JBRVA7Ozs7OztNQUVHO1FBN0ZOOzs7O1lBNkZNO0lBRUM7Ozs7O0dBQ1A7Ozs7OztDQUNGOzs7O1VBQ0c7Ozs7O0FBRXJCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFpSW1wb3J0TW9kYWwuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IEFuaW1hdGVQcmVzZW5jZSwgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0J1xuaW1wb3J0IHsgWCwgQ29weSwgQ2hlY2ssIExvYWRlcjIsIEFsZXJ0VHJpYW5nbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBjbXNBcGkgfSBmcm9tICcuL2Ntc0FwaSdcbmltcG9ydCB7IEJsb2NrUmVuZGVyZXIgfSBmcm9tICcuL0Jsb2NrUmVuZGVyZXInXG5cbi8qKlxuICogQWlJbXBvcnRNb2RhbCDigJQgdGhlIG1hbnVhbCBBSSB3b3JrZmxvdyAoMTIgKyAxMyksIHJlYWNoYWJsZSBhcyBhXG4gKiBcIkdlbmVyYXRlIHdpdGggQUlcIiBidXR0b24gZnJvbSB0aGUgU3RydWN0dXJlL0NvbnRlbnQvQXNzZXNzbWVudHMgdGFicy5cbiAqXG4gKiBTdGVwIDE6IGZldGNoICsgc2hvdyB0aGUgY29weS1wYXN0ZWFibGUgcHJvbXB0ICgxMikuXG4gKiBTdGVwIDI6IHBhc3RlIHRoZSBKU09OIHRoZSB1c2VyIGdvdCBiYWNrLCBWYWxpZGF0ZSBpdCAoMTMpLCBwcmV2aWV3IGl0LFxuICogICAgICAgICB0aGVuIENvbW1pdCAob25seSBlbmFibGVkIG9uY2UgdmFsaWQpIOKAlCB3aXRoIGFuIGV4cGxpY2l0XG4gKiAgICAgICAgIHJlcGxhY2UtY29uZmlybWF0aW9uIGlmIHRoZSB0YXJnZXQgYWxyZWFkeSBoYXMgY29udGVudC5cbiAqXG4gKiBQcm9wczpcbiAqICAtIG9wZW4sIG9uQ2xvc2VcbiAqICAtIGNvdXJzZUlkLCBzY29wZSAoXCJjb3Vyc2VcInxcIm1vZHVsZVwifFwiY2hhcHRlclwifFwicGFnZVwifFwibW9kdWxlLXFjbVwifFwiZmluYWwtZXhhbVwiKVxuICogIC0gdGFyZ2V0SWRzOiB7IG1vZHVsZUlkPywgY2hhcHRlcklkPywgcGFnZUlkPyB9IOKAlCBwYXNzZWQgc3RyYWlnaHQgdGhyb3VnaFxuICogICAgdG8gdGhlIHByb21wdC1idWlsZGVyIGFuZCBjb21taXQgZW5kcG9pbnRzLlxuICogIC0gb25Db21taXR0ZWQocmVzdWx0KTogY2FsbGVkIGFmdGVyIGEgc3VjY2Vzc2Z1bCBjb21taXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBBaUltcG9ydE1vZGFsKHsgb3Blbiwgb25DbG9zZSwgY291cnNlSWQsIHNjb3BlLCB0YXJnZXRJZHMgPSB7fSwgb25Db21taXR0ZWQgfSkge1xuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKVxuICBjb25zdCBbcHJvbXB0LCBzZXRQcm9tcHRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwcm9tcHRMb2FkaW5nLCBzZXRQcm9tcHRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbcHJvbXB0RXJyb3IsIHNldFByb21wdEVycm9yXSA9IHVzZVN0YXRlKG51bGwpXG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBbcGFzdGVkSnNvbiwgc2V0UGFzdGVkSnNvbl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3ZhbGlkYXRpbmcsIHNldFZhbGlkYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFt2YWxpZGF0ZVJlc3VsdCwgc2V0VmFsaWRhdGVSZXN1bHRdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25lZWRzUmVwbGFjZUNvbmZpcm0sIHNldE5lZWRzUmVwbGFjZUNvbmZpcm1dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtjb21taXR0aW5nLCBzZXRDb21taXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbY29tbWl0RXJyb3IsIHNldENvbW1pdEVycm9yXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHJldHVyblxuICAgIHNldFN0ZXAoMSlcbiAgICBzZXRQYXN0ZWRKc29uKCcnKVxuICAgIHNldFZhbGlkYXRlUmVzdWx0KG51bGwpXG4gICAgc2V0TmVlZHNSZXBsYWNlQ29uZmlybShmYWxzZSlcbiAgICBzZXRDb21taXRFcnJvcihudWxsKVxuICAgIHNldFByb21wdEVycm9yKG51bGwpXG4gICAgc2V0UHJvbXB0TG9hZGluZyh0cnVlKVxuICAgIGNtc0FwaVxuICAgICAgLmdldFByb21wdChjb3Vyc2VJZCwgc2NvcGUsIHRhcmdldElkcylcbiAgICAgIC50aGVuKChyZXMpID0+IHNldFByb21wdChyZXMucHJvbXB0KSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBzZXRQcm9tcHRFcnJvcihlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGJ1aWxkIHByb21wdCcpKVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0UHJvbXB0TG9hZGluZyhmYWxzZSkpXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbb3BlbiwgY291cnNlSWQsIHNjb3BlXSlcblxuICBpZiAoIW9wZW4pIHJldHVybiBudWxsXG5cbiAgY29uc3QgY29weVByb21wdCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocHJvbXB0KVxuICAgICAgc2V0Q29waWVkKHRydWUpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZChmYWxzZSksIDE1MDApXG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBDbGlwYm9hcmQgQVBJIGNhbiBmYWlsIChwZXJtaXNzaW9ucywgbm9uLXNlY3VyZSBjb250ZXh0KSDigJQgdGhlXG4gICAgICAvLyB0ZXh0YXJlYSBpcyBzdGlsbCBzZWxlY3RhYmxlL2NvcHlhYmxlIG1hbnVhbGx5LCBzbyB0aGlzIGlzIHNpbGVudC5cbiAgICB9XG4gIH1cblxuICBjb25zdCBydW5WYWxpZGF0ZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRWYWxpZGF0aW5nKHRydWUpXG4gICAgc2V0VmFsaWRhdGVSZXN1bHQobnVsbClcbiAgICBzZXRDb21taXRFcnJvcihudWxsKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbXNBcGkudmFsaWRhdGVJbXBvcnQoY291cnNlSWQsIHNjb3BlLCBwYXN0ZWRKc29uKVxuICAgICAgc2V0VmFsaWRhdGVSZXN1bHQocmVzdWx0KVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0VmFsaWRhdGVSZXN1bHQoeyB2YWxpZDogZmFsc2UsIGVycm9yczogW3sgZmllbGQ6ICcocmVxdWVzdCknLCBtZXNzYWdlOiBlcnIubWVzc2FnZSB9XSB9KVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRWYWxpZGF0aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJ1bkNvbW1pdCA9IGFzeW5jIChyZXBsYWNlKSA9PiB7XG4gICAgc2V0Q29tbWl0dGluZyh0cnVlKVxuICAgIHNldENvbW1pdEVycm9yKG51bGwpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNtc0FwaS5jb21taXRJbXBvcnQoY291cnNlSWQsIHNjb3BlLCBwYXN0ZWRKc29uLCB7XG4gICAgICAgIHJlcGxhY2UsXG4gICAgICAgIC4uLnRhcmdldElkcyxcbiAgICAgIH0pXG4gICAgICBzZXROZWVkc1JlcGxhY2VDb25maXJtKGZhbHNlKVxuICAgICAgb25Db21taXR0ZWQ/LihyZXN1bHQpXG4gICAgICBvbkNsb3NlKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIuY29kZSA9PT0gJ1ZBTElEQVRJT05fRVJST1InICYmIC9yZXBsYWNlOnRydWUvLnRlc3QoZXJyLm1lc3NhZ2UgfHwgJycpKSB7XG4gICAgICAgIHNldE5lZWRzUmVwbGFjZUNvbmZpcm0odHJ1ZSlcbiAgICAgICAgc2V0Q29tbWl0RXJyb3IoZXJyLm1lc3NhZ2UpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRDb21taXRFcnJvcihlcnIubWVzc2FnZSB8fCAnQ29tbWl0IGZhaWxlZCcpXG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldENvbW1pdHRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgcGFyc2VkUHJldmlldyA9IHZhbGlkYXRlUmVzdWx0Py52YWxpZCA/IHZhbGlkYXRlUmVzdWx0LnBhcnNlZCA6IG51bGxcblxuICByZXR1cm4gKFxuICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICA8bW90aW9uLmRpdlxuICAgICAgICBjbGFzc05hbWU9XCJjbXMtbW9kYWwtb3ZlcmxheVwiXG4gICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX1cbiAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwIH19XG4gICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICA+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiY21zLW1vZGFsXCJcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE2LCBzY2FsZTogMC45OCB9fVxuICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCwgc2NhbGU6IDEgfX1cbiAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHk6IDE2LCBzY2FsZTogMC45OCB9fVxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMTgsIGVhc2U6ICdlYXNlT3V0JyB9fVxuICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtbW9kYWwtaGVhZGVyXCI+XG4gICAgICAgICAgICA8aDM+R2VuZXJhdGUgd2l0aCBBSSDigJQge3Njb3BlfTwvaDM+XG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjbXMtYnRuLWljb25cIiBvbkNsaWNrPXtvbkNsb3NlfSBhcmlhLWxhYmVsPVwiQ2xvc2VcIj5cbiAgICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLW1vZGFsLXN0ZXBzXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0ZXAgPT09IDEgPyAnY21zLXN0ZXAtYWN0aXZlJyA6ICcnfT4xLiBDb3B5IHByb21wdDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17c3RlcCA9PT0gMiA/ICdjbXMtc3RlcC1hY3RpdmUnIDogJyd9PjIuIFBhc3RlIEpTT048L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8QW5pbWF0ZVByZXNlbmNlIG1vZGU9XCJ3YWl0XCI+XG4gICAgICAgICAgICB7c3RlcCA9PT0gMSA/IChcbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBrZXk9XCJzdGVwMVwiXG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB4OiAxMiB9fVxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeDogMCB9fVxuICAgICAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeDogLTEyIH19XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4xNSB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNtcy1tb2RhbC1ib2R5XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtwcm9tcHRMb2FkaW5nICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNtcy1sb2FkaW5nXCI+XG4gICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cImNtcy1zcGluXCIgc2l6ZT17MTZ9IC8+IEJ1aWxkaW5nIHByb21wdOKAplxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge3Byb21wdEVycm9yICYmIDxwIGNsYXNzTmFtZT1cImNtcy1lcnJvclwiPntwcm9tcHRFcnJvcn08L3A+fVxuICAgICAgICAgICAgICAgIHshcHJvbXB0TG9hZGluZyAmJiAhcHJvbXB0RXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY21zLWhpbnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBDb3B5IHRoaXMgaW50byB5b3VyIEFJIGNoYXQgdG9vbCBvZiBjaG9pY2UsIHRoZW4gcGFzdGUgdGhlIEpTT04gaXQgZ2l2ZXNcbiAgICAgICAgICAgICAgICAgICAgICBiYWNrIGluIHRoZSBuZXh0IHN0ZXAuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIGNsYXNzTmFtZT1cImNtcy1wcm9tcHQtdGV4dGFyZWFcIiByb3dzPXsxNH0gcmVhZE9ubHkgdmFsdWU9e3Byb21wdH0gLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtbW9kYWwtYWN0aW9uc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNtcy1idG4tc2Vjb25kYXJ5XCIgb25DbGljaz17Y29weVByb21wdH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y29waWVkID8gPENoZWNrIHNpemU9ezE2fSAvPiA6IDxDb3B5IHNpemU9ezE2fSAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb3BpZWQgPyAnQ29waWVkJyA6ICdDb3B5IHRvIGNsaXBib2FyZCd9XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0U3RlcCgyKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICBOZXh0OiBwYXN0ZSBKU09OXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBrZXk9XCJzdGVwMlwiXG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB4OiAxMiB9fVxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeDogMCB9fVxuICAgICAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgeDogLTEyIH19XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4xNSB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNtcy1tb2RhbC1ib2R5XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNtcy1oaW50XCI+UGFzdGUgdGhlIEpTT04geW91ciBBSSB0b29sIHJldHVybmVkOjwvcD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNtcy1wcm9tcHQtdGV4dGFyZWEgY21zLW1vbm9cIlxuICAgICAgICAgICAgICAgICAgcm93cz17MTB9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzdGVkSnNvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRQYXN0ZWRKc29uKGUudGFyZ2V0LnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICBzZXRWYWxpZGF0ZVJlc3VsdChudWxsKVxuICAgICAgICAgICAgICAgICAgICBzZXROZWVkc1JlcGxhY2VDb25maXJtKGZhbHNlKVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwieyAuLi4gfVwiXG4gICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLW1vZGFsLWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNtcy1idG4tc2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0U3RlcCgxKX0+XG4gICAgICAgICAgICAgICAgICAgIEJhY2tcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtydW5WYWxpZGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFwYXN0ZWRKc29uLnRyaW0oKSB8fCB2YWxpZGF0aW5nfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dmFsaWRhdGluZyA/IDxMb2FkZXIyIGNsYXNzTmFtZT1cImNtcy1zcGluXCIgc2l6ZT17MTZ9IC8+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgVmFsaWRhdGVcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY21zLWJ0bi1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF2YWxpZGF0ZVJlc3VsdD8udmFsaWQgfHwgY29tbWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcnVuQ29tbWl0KGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2NvbW1pdHRpbmcgPyA8TG9hZGVyMiBjbGFzc05hbWU9XCJjbXMtc3BpblwiIHNpemU9ezE2fSAvPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgIENvbW1pdFxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7dmFsaWRhdGVSZXN1bHQgJiYgIXZhbGlkYXRlUmVzdWx0LnZhbGlkICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLWVycm9yLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY21zLWVycm9yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgc2l6ZT17MTR9IC8+IEludmFsaWQgSlNPTiDigJQgZml4IHRoZXNlIGFuZCByZS12YWxpZGF0ZTpcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgICAgICAge3ZhbGlkYXRlUmVzdWx0LmVycm9ycy5tYXAoKGUsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Y29kZT57ZS5maWVsZH08L2NvZGU+OiB7ZS5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7dmFsaWRhdGVSZXN1bHQ/LnZhbGlkICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXByZXZpZXdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY21zLWhpbnRcIj5Mb29rcyB2YWxpZC4gUHJldmlldzo8L3A+XG4gICAgICAgICAgICAgICAgICAgIHtzY29wZSA9PT0gJ3BhZ2UnID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxCbG9ja1JlbmRlcmVyIGJsb2Nrcz17cGFyc2VkUHJldmlldz8uYmxvY2tzfSAvPlxuICAgICAgICAgICAgICAgICAgICApIDogQXJyYXkuaXNBcnJheShwYXJzZWRQcmV2aWV3KSA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiY21zLXF1ZXN0aW9uLXByZXZpZXctbGlzdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3BhcnNlZFByZXZpZXcubWFwKChxLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PntxLnRleHR9PC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJjbXMtbW9ub1wiPntKU09OLnN0cmluZ2lmeShwYXJzZWRQcmV2aWV3LCBudWxsLCAyKX08L3ByZT5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7Y29tbWl0RXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtZXJyb3ItbGlzdFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjbXMtZXJyb3JcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsxNH0gLz4ge2NvbW1pdEVycm9yfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIHtuZWVkc1JlcGxhY2VDb25maXJtICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImNtcy1idG4tZGFuZ2VyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJ1bkNvbW1pdCh0cnVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjb21taXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIE92ZXJ3cml0ZSBleGlzdGluZyBjb250ZW50XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L21vdGlvbi5kaXY+XG4gICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gIClcbn1cbiJdfQ==