import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/MfaSettings.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { authApi } from "/src/features/auth/authApi.js";
import { ApiError } from "/src/api/client.js";
import { Skeleton } from "/src/components/Skeleton.jsx";
import { ButtonSpinner } from "/src/components/ButtonSpinner.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/MfaSettings.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Used on AccountPage. Three states, in order: disabled -> enrolling
// (QR shown, unconfirmed) -> enabled. See backend services/mfa_service.py
// for why enrollment is two steps (generate, then confirm with one code).
//
// `onStatusChange(enabled)` is optional: AccountPage uses it to keep the
// On/Off badge in its settings nav in sync, since that badge is fetched
// once on mount and would otherwise go stale after enabling/disabling here
// without a page reload.
export function MfaSettings({ onStatusChange } = {}) {
	_s();
	const [status, setStatus] = useState("loading");
	const [enrollment, setEnrollment] = useState(null);
	const [recoveryCodes, setRecoveryCodes] = useState(null);
	const [error, setError] = useState(null);
	// Each async action gets its own pending flag so its button can disable
	// itself and show a spinner. This also guards against a double-click
	// firing startMfaEnrollment twice — each call REPLACES the stored secret
	// (see backend MfaService.start_enrollment), so a second click before the
	// first request lands would overwrite it and the QR you scanned would no
	// longer match what's saved, making every code look "invalid".
	const [isStartingEnrollment, setIsStartingEnrollment] = useState(false);
	const [isConfirming, setIsConfirming] = useState(false);
	const [isDisabling, setIsDisabling] = useState(false);
	const [confirmCode, setConfirmCode] = useState("");
	function handleConfirmCodeChange(event) {
		// Authenticator apps show digits only — strip anything else (spaces,
		// pasted dashes, ...) so what's submitted always matches what's typed,
		// and cap at 6 so a stray extra digit can't shift the whole code.
		setConfirmCode(event.target.value.replace(/\D/g, "").slice(0, 6));
	}
	useEffect(() => {
		authApi.getMfaStatus().then((res) => {
			setStatus(res.enabled ? "enabled" : "disabled");
			onStatusChange?.(res.enabled);
		}).catch(() => {
			setStatus("disabled");
			onStatusChange?.(false);
		});
		// Only meant to run once, on mount — onStatusChange is a fresh function
		// identity on every AccountPage render and must not restart this fetch.
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	async function handleStartEnrollment() {
		if (isStartingEnrollment) return;
		setError(null);
		setIsStartingEnrollment(true);
		try {
			const res = await authApi.startMfaEnrollment();
			setEnrollment(res);
			setStatus("enrolling");
			setConfirmCode("");
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsStartingEnrollment(false);
		}
	}
	async function submitConfirmCode(code) {
		if (isConfirming) return;
		setError(null);
		setIsConfirming(true);
		try {
			const res = await authApi.confirmMfaEnrollment(code);
			setRecoveryCodes(res.recovery_codes);
			setStatus("enabled");
			setConfirmCode("");
			onStatusChange?.(true);
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsConfirming(false);
		}
	}
	// Submits the moment the 6th digit is typed — no separate "Confirm" click.
	// The button stays as a manual fallback (Enter key, retrying after an
	// error without retyping the whole code).
	useEffect(() => {
		if (status !== "enrolling" || confirmCode.length !== 6) return;
		// Deferred a tick so this isn't a setState call directly in the effect
		// body (see react-hooks/no-set-state-in-effect) — still fires before
		// the next paint, so it reads as instant.
		queueMicrotask(() => submitConfirmCode(confirmCode));
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [confirmCode, status]);
	function handleConfirm(event) {
		event.preventDefault();
		submitConfirmCode(confirmCode);
	}
	async function handleDisable(event) {
		event.preventDefault();
		if (isDisabling) return;
		setError(null);
		setIsDisabling(true);
		const password = new FormData(event.target).get("current_password");
		try {
			await authApi.disableMfa(password);
			setStatus("disabled");
			setEnrollment(null);
			setRecoveryCodes(null);
			onStatusChange?.(false);
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsDisabling(false);
		}
	}
	// Placeholder shapes standing in for the real title/status/button while
	// getMfaStatus() is in flight, instead of a blank gap on the page.
	if (status === "loading") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "mfa-skeleton",
			"aria-busy": "true",
			"aria-label": "Loading two-factor authentication settings",
			children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "60%",
					height: "1.5em"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "40%",
					height: "1em"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "10rem",
					height: "2.4rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 127,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		error && /* @__PURE__ */ _jsxDEV("p", {
			role: "alert",
			className: "error",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 141,
			columnNumber: 9
		}, this),
		status === "disabled" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", { children: "Not enabled." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 148,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			onClick: handleStartEnrollment,
			disabled: isStartingEnrollment,
			children: [isStartingEnrollment && /* @__PURE__ */ _jsxDEV(ButtonSpinner, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 38
			}, this), isStartingEnrollment ? "Starting..." : "Enable two-factor authentication"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 149,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 9
		}, this),
		status === "enrolling" && enrollment && /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleConfirm,
			children: [
				/* @__PURE__ */ _jsxDEV("p", { children: "Scan this QR code with your authenticator app (e.g. Google Authenticator):" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("img", {
					src: enrollment.qr_code_data_uri,
					alt: "MFA enrollment QR code",
					width: 200
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "hint",
					children: ["Can't scan it? Enter this code manually: ", /* @__PURE__ */ _jsxDEV("code", { children: enrollment.secret }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 54
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "mfa-confirm-code",
					children: "Enter the 6-digit code to confirm"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 164,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "mfa-confirm-code",
					name: "code",
					type: "text",
					inputMode: "numeric",
					autoComplete: "one-time-code",
					pattern: "[0-9]{6}",
					maxLength: 6,
					value: confirmCode,
					onChange: handleConfirmCodeChange,
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 163,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isConfirming || confirmCode.length !== 6,
					children: [isConfirming && /* @__PURE__ */ _jsxDEV(ButtonSpinner, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 30
					}, this), isConfirming ? "Confirming..." : "Confirm"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 178,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 9
		}, this),
		status === "enabled" && recoveryCodes && /* @__PURE__ */ _jsxDEV("div", {
			role: "status",
			children: [
				/* @__PURE__ */ _jsxDEV("p", { children: "Two-factor authentication is on. Save these recovery codes somewhere safe — each works once, and this is the only time they're shown:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("ul", { children: recoveryCodes.map((code) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("code", { children: code }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 17
				}, this) }, code, false, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 15
				}, this)) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setRecoveryCodes(null),
					children: "I've saved them"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 9
		}, this),
		status === "enabled" && !recoveryCodes && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", { children: "Two-factor authentication is on." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 206,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleDisable,
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "mfa-disable-password",
				children: "Current password"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 209,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				id: "mfa-disable-password",
				name: "current_password",
				type: "password",
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 15
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isDisabling,
				children: [isDisabling && /* @__PURE__ */ _jsxDEV(ButtonSpinner, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 31
				}, this), isDisabling ? "Disabling..." : "Disable two-factor authentication"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 205,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 136,
		columnNumber: 5
	}, this);
}
_s(MfaSettings, "D/bEiPZwJV4BWesUdsxeunAIaBg=");
_c = MfaSettings;
var _c;
$RefreshReg$(_c, "MfaSettings");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/MfaSettings.jsx?t=1790183762308";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/MfaSettings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/MfaSettings.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/MfaSettings.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxxQkFBcUI7Ozs7Ozs7Ozs7OztBQVU5QixPQUFPLFNBQVMsWUFBWSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7O0NBQ25ELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxTQUFTO0NBQzlDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FDakQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsSUFBSTtDQUN2RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsSUFBSTs7Ozs7OztDQU92QyxNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFTLEtBQUs7Q0FDdEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FFakQsU0FBUyx3QkFBd0IsT0FBTzs7OztFQUl0QyxlQUFlLE1BQU0sT0FBTyxNQUFNLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0NBQ2xFO0NBRUEsZ0JBQWdCO0VBQ2QsUUFDRyxhQUFhLENBQUMsQ0FDZCxNQUFNLFFBQVE7R0FDYixVQUFVLElBQUksVUFBVSxZQUFZLFVBQVU7R0FDOUMsaUJBQWlCLElBQUksT0FBTztFQUM5QixDQUFDLENBQUMsQ0FDRCxZQUFZO0dBQ1gsVUFBVSxVQUFVO0dBQ3BCLGlCQUFpQixLQUFLO0VBQ3hCLENBQUM7Ozs7Q0FJTCxHQUFHLENBQUMsQ0FBQztDQUVMLGVBQWUsd0JBQXdCO0VBQ3JDLElBQUksc0JBQXNCO0VBQzFCLFNBQVMsSUFBSTtFQUNiLHdCQUF3QixJQUFJO0VBQzVCLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxRQUFRLG1CQUFtQjtHQUM3QyxjQUFjLEdBQUc7R0FDakIsVUFBVSxXQUFXO0dBQ3JCLGVBQWUsRUFBRTtFQUNuQixTQUFTLEtBQUs7R0FDWixTQUFTLGVBQWUsV0FBVyxJQUFJLFVBQVUsc0JBQXNCO0VBQ3pFLFVBQVU7R0FDUix3QkFBd0IsS0FBSztFQUMvQjtDQUNGO0NBRUEsZUFBZSxrQkFBa0IsTUFBTTtFQUNyQyxJQUFJLGNBQWM7RUFDbEIsU0FBUyxJQUFJO0VBQ2IsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFFBQVEscUJBQXFCLElBQUk7R0FDbkQsaUJBQWlCLElBQUksY0FBYztHQUNuQyxVQUFVLFNBQVM7R0FDbkIsZUFBZSxFQUFFO0dBQ2pCLGlCQUFpQixJQUFJO0VBQ3ZCLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxXQUFXLElBQUksVUFBVSxzQkFBc0I7RUFDekUsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Ozs7Q0FLQSxnQkFBZ0I7RUFDZCxJQUFJLFdBQVcsZUFBZSxZQUFZLFdBQVcsR0FBRzs7OztFQUl4RCxxQkFBcUIsa0JBQWtCLFdBQVcsQ0FBQzs7Q0FFckQsR0FBRyxDQUFDLGFBQWEsTUFBTSxDQUFDO0NBRXhCLFNBQVMsY0FBYyxPQUFPO0VBQzVCLE1BQU0sZUFBZTtFQUNyQixrQkFBa0IsV0FBVztDQUMvQjtDQUVBLGVBQWUsY0FBYyxPQUFPO0VBQ2xDLE1BQU0sZUFBZTtFQUNyQixJQUFJLGFBQWE7RUFDakIsU0FBUyxJQUFJO0VBQ2IsZUFBZSxJQUFJO0VBQ25CLE1BQU0sV0FBVyxJQUFJLFNBQVMsTUFBTSxNQUFNLENBQUMsQ0FBQyxJQUFJLGtCQUFrQjtFQUNsRSxJQUFJO0dBQ0YsTUFBTSxRQUFRLFdBQVcsUUFBUTtHQUNqQyxVQUFVLFVBQVU7R0FDcEIsY0FBYyxJQUFJO0dBQ2xCLGlCQUFpQixJQUFJO0dBQ3JCLGlCQUFpQixLQUFLO0VBQ3hCLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxXQUFXLElBQUksVUFBVSxzQkFBc0I7RUFDekUsVUFBVTtHQUNSLGVBQWUsS0FBSztFQUN0QjtDQUNGOzs7Q0FJQSxJQUFJLFdBQVcsV0FBVztFQUN4QixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWUsYUFBVTtHQUFPLGNBQVc7YUFBMUQ7SUFDRSx3QkFBQyxVQUFEO0tBQVUsT0FBTTtLQUFNLFFBQU87SUFBUzs7Ozs7SUFDdEMsd0JBQUMsVUFBRDtLQUFVLE9BQU07S0FBTSxRQUFPO0lBQU87Ozs7O0lBQ3BDLHdCQUFDLFVBQUQ7S0FBVSxPQUFNO0tBQVEsUUFBTztJQUFVOzs7OztHQUN0Qzs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFJRyxTQUNDLHdCQUFDLEtBQUQ7R0FBRyxNQUFLO0dBQVEsV0FBVTthQUN2QjtFQUNBOzs7OztFQUdKLFdBQVcsY0FDVixnREFDRSx3QkFBQyxLQUFELFlBQUcsZUFBZTs7OztZQUNsQix3QkFBQyxVQUFEO0dBQVEsTUFBSztHQUFTLFNBQVM7R0FBdUIsVUFBVTthQUFoRSxDQUNHLHdCQUF3Qix3QkFBQyxlQUFELENBQWdCOzs7O2FBQ3hDLHVCQUF1QixnQkFBZ0Isa0NBQ2xDOzs7OztVQUNSOzs7OztFQUdILFdBQVcsZUFBZSxjQUN6Qix3QkFBQyxRQUFEO0dBQU0sVUFBVTthQUFoQjtJQUNFLHdCQUFDLEtBQUQsWUFBRyw2RUFBNkU7Ozs7O0lBQ2hGLHdCQUFDLE9BQUQ7S0FBSyxLQUFLLFdBQVc7S0FBa0IsS0FBSTtLQUF5QixPQUFPO0lBQU07Ozs7O0lBQ2pGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FBb0IsNkNBQ3VCLHdCQUFDLFFBQUQsWUFBTyxXQUFXLE9BQWE7Ozs7YUFDdkU7Ozs7OztJQUNILHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO0tBQU8sU0FBUTtlQUFtQjtJQUF3Qzs7OztjQUMxRSx3QkFBQyxTQUFEO0tBQ0UsSUFBRztLQUNILE1BQUs7S0FDTCxNQUFLO0tBQ0wsV0FBVTtLQUNWLGNBQWE7S0FDYixTQUFRO0tBQ1IsV0FBVztLQUNYLE9BQU87S0FDUCxVQUFVO0tBQ1Y7SUFDRDs7OztZQUNFOzs7OztJQUNMLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVSxnQkFBZ0IsWUFBWSxXQUFXO2VBQXZFLENBQ0csZ0JBQWdCLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7ZUFDaEMsZUFBZSxrQkFBa0IsU0FDNUI7Ozs7OztHQUNKOzs7Ozs7RUFHUCxXQUFXLGFBQWEsaUJBQ3ZCLHdCQUFDLE9BQUQ7R0FBSyxNQUFLO2FBQVY7SUFDRSx3QkFBQyxLQUFELFlBQUcsd0lBR0E7Ozs7O0lBQ0gsd0JBQUMsTUFBRCxZQUNHLGNBQWMsS0FBSyxTQUNsQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7YUFDaEIsR0FGSzs7OztXQUVMLENBQ0wsRUFDQzs7Ozs7SUFDSix3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLGVBQWUsaUJBQWlCLElBQUk7ZUFBRztJQUVyRDs7Ozs7R0FDTDs7Ozs7O0VBR04sV0FBVyxhQUFhLENBQUMsaUJBQ3hCLGdEQUNFLHdCQUFDLEtBQUQsWUFBRyxtQ0FBbUM7Ozs7WUFDdEMsd0JBQUMsUUFBRDtHQUFNLFVBQVU7YUFBaEIsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBdUI7R0FBdUI7Ozs7YUFDN0Qsd0JBQUMsU0FBRDtJQUFPLElBQUc7SUFBdUIsTUFBSztJQUFtQixNQUFLO0lBQVc7R0FBVTs7OztXQUNoRjs7OzthQUNMLHdCQUFDLFVBQUQ7SUFBUSxNQUFLO0lBQVMsVUFBVTtjQUFoQyxDQUNHLGVBQWUsd0JBQUMsZUFBRCxDQUFnQjs7OztjQUMvQixjQUFjLGlCQUFpQixtQ0FDMUI7Ozs7O1dBQ0o7Ozs7O1VBQ047Ozs7O0NBRUQ7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWZhU2V0dGluZ3MuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gJy4vYXV0aEFwaSdcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi8uLi9hcGkvY2xpZW50J1xyXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvU2tlbGV0b24nXHJcbmltcG9ydCB7IEJ1dHRvblNwaW5uZXIgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvblNwaW5uZXInXHJcblxyXG4vLyBVc2VkIG9uIEFjY291bnRQYWdlLiBUaHJlZSBzdGF0ZXMsIGluIG9yZGVyOiBkaXNhYmxlZCAtPiBlbnJvbGxpbmdcclxuLy8gKFFSIHNob3duLCB1bmNvbmZpcm1lZCkgLT4gZW5hYmxlZC4gU2VlIGJhY2tlbmQgc2VydmljZXMvbWZhX3NlcnZpY2UucHlcclxuLy8gZm9yIHdoeSBlbnJvbGxtZW50IGlzIHR3byBzdGVwcyAoZ2VuZXJhdGUsIHRoZW4gY29uZmlybSB3aXRoIG9uZSBjb2RlKS5cclxuLy9cclxuLy8gYG9uU3RhdHVzQ2hhbmdlKGVuYWJsZWQpYCBpcyBvcHRpb25hbDogQWNjb3VudFBhZ2UgdXNlcyBpdCB0byBrZWVwIHRoZVxyXG4vLyBPbi9PZmYgYmFkZ2UgaW4gaXRzIHNldHRpbmdzIG5hdiBpbiBzeW5jLCBzaW5jZSB0aGF0IGJhZGdlIGlzIGZldGNoZWRcclxuLy8gb25jZSBvbiBtb3VudCBhbmQgd291bGQgb3RoZXJ3aXNlIGdvIHN0YWxlIGFmdGVyIGVuYWJsaW5nL2Rpc2FibGluZyBoZXJlXHJcbi8vIHdpdGhvdXQgYSBwYWdlIHJlbG9hZC5cclxuZXhwb3J0IGZ1bmN0aW9uIE1mYVNldHRpbmdzKHsgb25TdGF0dXNDaGFuZ2UgfSA9IHt9KSB7XHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKCdsb2FkaW5nJykgLy8gbG9hZGluZyB8IGRpc2FibGVkIHwgZW5yb2xsaW5nIHwgZW5hYmxlZFxyXG4gIGNvbnN0IFtlbnJvbGxtZW50LCBzZXRFbnJvbGxtZW50XSA9IHVzZVN0YXRlKG51bGwpIC8vIHsgc2VjcmV0LCBvdHBhdXRoX3VyaSwgcXJfY29kZV9kYXRhX3VyaSB9XHJcbiAgY29uc3QgW3JlY292ZXJ5Q29kZXMsIHNldFJlY292ZXJ5Q29kZXNdID0gdXNlU3RhdGUobnVsbCkgLy8gc2hvd24gb25jZSwgcmlnaHQgYWZ0ZXIgY29uZmlybWluZ1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcclxuICAvLyBFYWNoIGFzeW5jIGFjdGlvbiBnZXRzIGl0cyBvd24gcGVuZGluZyBmbGFnIHNvIGl0cyBidXR0b24gY2FuIGRpc2FibGVcclxuICAvLyBpdHNlbGYgYW5kIHNob3cgYSBzcGlubmVyLiBUaGlzIGFsc28gZ3VhcmRzIGFnYWluc3QgYSBkb3VibGUtY2xpY2tcclxuICAvLyBmaXJpbmcgc3RhcnRNZmFFbnJvbGxtZW50IHR3aWNlIOKAlCBlYWNoIGNhbGwgUkVQTEFDRVMgdGhlIHN0b3JlZCBzZWNyZXRcclxuICAvLyAoc2VlIGJhY2tlbmQgTWZhU2VydmljZS5zdGFydF9lbnJvbGxtZW50KSwgc28gYSBzZWNvbmQgY2xpY2sgYmVmb3JlIHRoZVxyXG4gIC8vIGZpcnN0IHJlcXVlc3QgbGFuZHMgd291bGQgb3ZlcndyaXRlIGl0IGFuZCB0aGUgUVIgeW91IHNjYW5uZWQgd291bGQgbm9cclxuICAvLyBsb25nZXIgbWF0Y2ggd2hhdCdzIHNhdmVkLCBtYWtpbmcgZXZlcnkgY29kZSBsb29rIFwiaW52YWxpZFwiLlxyXG4gIGNvbnN0IFtpc1N0YXJ0aW5nRW5yb2xsbWVudCwgc2V0SXNTdGFydGluZ0Vucm9sbG1lbnRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2lzQ29uZmlybWluZywgc2V0SXNDb25maXJtaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFtpc0Rpc2FibGluZywgc2V0SXNEaXNhYmxpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2NvbmZpcm1Db2RlLCBzZXRDb25maXJtQ29kZV0gPSB1c2VTdGF0ZSgnJylcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ29uZmlybUNvZGVDaGFuZ2UoZXZlbnQpIHtcclxuICAgIC8vIEF1dGhlbnRpY2F0b3IgYXBwcyBzaG93IGRpZ2l0cyBvbmx5IOKAlCBzdHJpcCBhbnl0aGluZyBlbHNlIChzcGFjZXMsXHJcbiAgICAvLyBwYXN0ZWQgZGFzaGVzLCAuLi4pIHNvIHdoYXQncyBzdWJtaXR0ZWQgYWx3YXlzIG1hdGNoZXMgd2hhdCdzIHR5cGVkLFxyXG4gICAgLy8gYW5kIGNhcCBhdCA2IHNvIGEgc3RyYXkgZXh0cmEgZGlnaXQgY2FuJ3Qgc2hpZnQgdGhlIHdob2xlIGNvZGUuXHJcbiAgICBzZXRDb25maXJtQ29kZShldmVudC50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKS5zbGljZSgwLCA2KSlcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBhdXRoQXBpXHJcbiAgICAgIC5nZXRNZmFTdGF0dXMoKVxyXG4gICAgICAudGhlbigocmVzKSA9PiB7XHJcbiAgICAgICAgc2V0U3RhdHVzKHJlcy5lbmFibGVkID8gJ2VuYWJsZWQnIDogJ2Rpc2FibGVkJylcclxuICAgICAgICBvblN0YXR1c0NoYW5nZT8uKHJlcy5lbmFibGVkKVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgIHNldFN0YXR1cygnZGlzYWJsZWQnKVxyXG4gICAgICAgIG9uU3RhdHVzQ2hhbmdlPy4oZmFsc2UpXHJcbiAgICAgIH0pXHJcbiAgICAvLyBPbmx5IG1lYW50IHRvIHJ1biBvbmNlLCBvbiBtb3VudCDigJQgb25TdGF0dXNDaGFuZ2UgaXMgYSBmcmVzaCBmdW5jdGlvblxyXG4gICAgLy8gaWRlbnRpdHkgb24gZXZlcnkgQWNjb3VudFBhZ2UgcmVuZGVyIGFuZCBtdXN0IG5vdCByZXN0YXJ0IHRoaXMgZmV0Y2guXHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXHJcbiAgfSwgW10pXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN0YXJ0RW5yb2xsbWVudCgpIHtcclxuICAgIGlmIChpc1N0YXJ0aW5nRW5yb2xsbWVudCkgcmV0dXJuXHJcbiAgICBzZXRFcnJvcihudWxsKVxyXG4gICAgc2V0SXNTdGFydGluZ0Vucm9sbG1lbnQodHJ1ZSlcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGF1dGhBcGkuc3RhcnRNZmFFbnJvbGxtZW50KClcclxuICAgICAgc2V0RW5yb2xsbWVudChyZXMpXHJcbiAgICAgIHNldFN0YXR1cygnZW5yb2xsaW5nJylcclxuICAgICAgc2V0Q29uZmlybUNvZGUoJycpXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N0YXJ0aW5nRW5yb2xsbWVudChmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdENvbmZpcm1Db2RlKGNvZGUpIHtcclxuICAgIGlmIChpc0NvbmZpcm1pbmcpIHJldHVyblxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldElzQ29uZmlybWluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXV0aEFwaS5jb25maXJtTWZhRW5yb2xsbWVudChjb2RlKVxyXG4gICAgICBzZXRSZWNvdmVyeUNvZGVzKHJlcy5yZWNvdmVyeV9jb2RlcylcclxuICAgICAgc2V0U3RhdHVzKCdlbmFibGVkJylcclxuICAgICAgc2V0Q29uZmlybUNvZGUoJycpXHJcbiAgICAgIG9uU3RhdHVzQ2hhbmdlPy4odHJ1ZSlcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogJ1NvbWV0aGluZyB3ZW50IHdyb25nJylcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzQ29uZmlybWluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIFN1Ym1pdHMgdGhlIG1vbWVudCB0aGUgNnRoIGRpZ2l0IGlzIHR5cGVkIOKAlCBubyBzZXBhcmF0ZSBcIkNvbmZpcm1cIiBjbGljay5cclxuICAvLyBUaGUgYnV0dG9uIHN0YXlzIGFzIGEgbWFudWFsIGZhbGxiYWNrIChFbnRlciBrZXksIHJldHJ5aW5nIGFmdGVyIGFuXHJcbiAgLy8gZXJyb3Igd2l0aG91dCByZXR5cGluZyB0aGUgd2hvbGUgY29kZSkuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzdGF0dXMgIT09ICdlbnJvbGxpbmcnIHx8IGNvbmZpcm1Db2RlLmxlbmd0aCAhPT0gNikgcmV0dXJuXHJcbiAgICAvLyBEZWZlcnJlZCBhIHRpY2sgc28gdGhpcyBpc24ndCBhIHNldFN0YXRlIGNhbGwgZGlyZWN0bHkgaW4gdGhlIGVmZmVjdFxyXG4gICAgLy8gYm9keSAoc2VlIHJlYWN0LWhvb2tzL25vLXNldC1zdGF0ZS1pbi1lZmZlY3QpIOKAlCBzdGlsbCBmaXJlcyBiZWZvcmVcclxuICAgIC8vIHRoZSBuZXh0IHBhaW50LCBzbyBpdCByZWFkcyBhcyBpbnN0YW50LlxyXG4gICAgcXVldWVNaWNyb3Rhc2soKCkgPT4gc3VibWl0Q29uZmlybUNvZGUoY29uZmlybUNvZGUpKVxyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFtjb25maXJtQ29kZSwgc3RhdHVzXSlcclxuXHJcbiAgZnVuY3Rpb24gaGFuZGxlQ29uZmlybShldmVudCkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc3VibWl0Q29uZmlybUNvZGUoY29uZmlybUNvZGUpXHJcbiAgfVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVEaXNhYmxlKGV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBpZiAoaXNEaXNhYmxpbmcpIHJldHVyblxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldElzRGlzYWJsaW5nKHRydWUpXHJcbiAgICBjb25zdCBwYXNzd29yZCA9IG5ldyBGb3JtRGF0YShldmVudC50YXJnZXQpLmdldCgnY3VycmVudF9wYXNzd29yZCcpXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhdXRoQXBpLmRpc2FibGVNZmEocGFzc3dvcmQpXHJcbiAgICAgIHNldFN0YXR1cygnZGlzYWJsZWQnKVxyXG4gICAgICBzZXRFbnJvbGxtZW50KG51bGwpXHJcbiAgICAgIHNldFJlY292ZXJ5Q29kZXMobnVsbClcclxuICAgICAgb25TdGF0dXNDaGFuZ2U/LihmYWxzZSlcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogJ1NvbWV0aGluZyB3ZW50IHdyb25nJylcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzRGlzYWJsaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gUGxhY2Vob2xkZXIgc2hhcGVzIHN0YW5kaW5nIGluIGZvciB0aGUgcmVhbCB0aXRsZS9zdGF0dXMvYnV0dG9uIHdoaWxlXHJcbiAgLy8gZ2V0TWZhU3RhdHVzKCkgaXMgaW4gZmxpZ2h0LCBpbnN0ZWFkIG9mIGEgYmxhbmsgZ2FwIG9uIHRoZSBwYWdlLlxyXG4gIGlmIChzdGF0dXMgPT09ICdsb2FkaW5nJykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZmEtc2tlbGV0b25cIiBhcmlhLWJ1c3k9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIkxvYWRpbmcgdHdvLWZhY3RvciBhdXRoZW50aWNhdGlvbiBzZXR0aW5nc1wiPlxyXG4gICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjYwJVwiIGhlaWdodD1cIjEuNWVtXCIgLz5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCI0MCVcIiBoZWlnaHQ9XCIxZW1cIiAvPlxyXG4gICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjEwcmVtXCIgaGVpZ2h0PVwiMi40cmVtXCIgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgey8qIEFjY291bnRQYWdlLmpzeCBhbHJlYWR5IHJlbmRlcnMgdGhpcyBzZXR0aW5nJ3Mgb3duIGgyICh0aGUgaXRlbSdzXHJcbiAgICAgICAgICBsYWJlbCkgcmlnaHQgYWJvdmUgPEFjdGl2ZUNvbnRlbnQ+LCBzbyB0aGlzIGNvbXBvbmVudCBkb2Vzbid0XHJcbiAgICAgICAgICByZXBlYXQgaXQuICovfVxyXG4gICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImVycm9yXCI+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3N0YXR1cyA9PT0gJ2Rpc2FibGVkJyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxwPk5vdCBlbmFibGVkLjwvcD5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVN0YXJ0RW5yb2xsbWVudH0gZGlzYWJsZWQ9e2lzU3RhcnRpbmdFbnJvbGxtZW50fT5cclxuICAgICAgICAgICAge2lzU3RhcnRpbmdFbnJvbGxtZW50ICYmIDxCdXR0b25TcGlubmVyIC8+fVxyXG4gICAgICAgICAgICB7aXNTdGFydGluZ0Vucm9sbG1lbnQgPyAnU3RhcnRpbmcuLi4nIDogJ0VuYWJsZSB0d28tZmFjdG9yIGF1dGhlbnRpY2F0aW9uJ31cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3N0YXR1cyA9PT0gJ2Vucm9sbGluZycgJiYgZW5yb2xsbWVudCAmJiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNvbmZpcm19PlxyXG4gICAgICAgICAgPHA+U2NhbiB0aGlzIFFSIGNvZGUgd2l0aCB5b3VyIGF1dGhlbnRpY2F0b3IgYXBwIChlLmcuIEdvb2dsZSBBdXRoZW50aWNhdG9yKTo8L3A+XHJcbiAgICAgICAgICA8aW1nIHNyYz17ZW5yb2xsbWVudC5xcl9jb2RlX2RhdGFfdXJpfSBhbHQ9XCJNRkEgZW5yb2xsbWVudCBRUiBjb2RlXCIgd2lkdGg9ezIwMH0gLz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnRcIj5cclxuICAgICAgICAgICAgQ2FuJ3Qgc2NhbiBpdD8gRW50ZXIgdGhpcyBjb2RlIG1hbnVhbGx5OiA8Y29kZT57ZW5yb2xsbWVudC5zZWNyZXR9PC9jb2RlPlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtZmEtY29uZmlybS1jb2RlXCI+RW50ZXIgdGhlIDYtZGlnaXQgY29kZSB0byBjb25maXJtPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgaWQ9XCJtZmEtY29uZmlybS1jb2RlXCJcclxuICAgICAgICAgICAgICBuYW1lPVwiY29kZVwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxyXG4gICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cIm9uZS10aW1lLWNvZGVcIlxyXG4gICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XXs2fVwiXHJcbiAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs2fVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtQ29kZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29uZmlybUNvZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzQ29uZmlybWluZyB8fCBjb25maXJtQ29kZS5sZW5ndGggIT09IDZ9PlxyXG4gICAgICAgICAgICB7aXNDb25maXJtaW5nICYmIDxCdXR0b25TcGlubmVyIC8+fVxyXG4gICAgICAgICAgICB7aXNDb25maXJtaW5nID8gJ0NvbmZpcm1pbmcuLi4nIDogJ0NvbmZpcm0nfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3N0YXR1cyA9PT0gJ2VuYWJsZWQnICYmIHJlY292ZXJ5Q29kZXMgJiYgKFxyXG4gICAgICAgIDxkaXYgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIFR3by1mYWN0b3IgYXV0aGVudGljYXRpb24gaXMgb24uIFNhdmUgdGhlc2UgcmVjb3ZlcnkgY29kZXMgc29tZXdoZXJlIHNhZmUg4oCUIGVhY2hcclxuICAgICAgICAgICAgd29ya3Mgb25jZSwgYW5kIHRoaXMgaXMgdGhlIG9ubHkgdGltZSB0aGV5J3JlIHNob3duOlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHVsPlxyXG4gICAgICAgICAgICB7cmVjb3ZlcnlDb2Rlcy5tYXAoKGNvZGUpID0+IChcclxuICAgICAgICAgICAgICA8bGkga2V5PXtjb2RlfT5cclxuICAgICAgICAgICAgICAgIDxjb2RlPntjb2RlfTwvY29kZT5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRSZWNvdmVyeUNvZGVzKG51bGwpfT5cclxuICAgICAgICAgICAgSSd2ZSBzYXZlZCB0aGVtXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtzdGF0dXMgPT09ICdlbmFibGVkJyAmJiAhcmVjb3ZlcnlDb2RlcyAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxwPlR3by1mYWN0b3IgYXV0aGVudGljYXRpb24gaXMgb24uPC9wPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZURpc2FibGV9PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibWZhLWRpc2FibGUtcGFzc3dvcmRcIj5DdXJyZW50IHBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJtZmEtZGlzYWJsZS1wYXNzd29yZFwiIG5hbWU9XCJjdXJyZW50X3Bhc3N3b3JkXCIgdHlwZT1cInBhc3N3b3JkXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtpc0Rpc2FibGluZ30+XHJcbiAgICAgICAgICAgICAge2lzRGlzYWJsaW5nICYmIDxCdXR0b25TcGlubmVyIC8+fVxyXG4gICAgICAgICAgICAgIHtpc0Rpc2FibGluZyA/ICdEaXNhYmxpbmcuLi4nIDogJ0Rpc2FibGUgdHdvLWZhY3RvciBhdXRoZW50aWNhdGlvbid9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==