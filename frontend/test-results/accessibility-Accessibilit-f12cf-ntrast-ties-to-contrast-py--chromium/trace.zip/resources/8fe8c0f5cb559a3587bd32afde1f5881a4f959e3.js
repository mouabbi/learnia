const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
const STORAGE_KEY = "learnia:theme";
function readStoredTheme() {
	try {
		return localStorage.getItem(STORAGE_KEY) || "system";
	} catch {
		// Private browsing / storage blocked — fall back to system, the
		// toggle still works, it just won't persist across reloads.
		return "system";
	}
}
function applyTheme(theme) {
	const root = document.documentElement;
	if (theme === "system") {
		root.removeAttribute("data-theme");
	} else {
		root.setAttribute("data-theme", theme);
	}
}
// Manual light/dark override on top of the `prefers-color-scheme` media
// query already baked into index.css. `theme` is 'light' | 'dark' | 'system'
// (system = defer to the OS, the pre-existing default behavior).
export function useTheme() {
	const [theme, setTheme] = useState(readStoredTheme);
	useEffect(() => {
		applyTheme(theme);
	}, [theme]);
	const toggleTheme = useCallback(() => {
		setTheme((prev) => {
			// Toggle flips between light/dark. If we were following the system
			// preference, jump to the opposite of whatever the system is now.
			const systemPrefersDark = typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;
			const current = prev === "system" ? systemPrefersDark ? "dark" : "light" : prev;
			const next = current === "dark" ? "light" : "dark";
			try {
				localStorage.setItem(STORAGE_KEY, next);
			} catch {}
			return next;
		});
	}, []);
	return {
		theme,
		toggleTheme
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBRWpELE1BQU0sY0FBYztBQUVwQixTQUFTLGtCQUFrQjtDQUN6QixJQUFJO0VBQ0YsT0FBTyxhQUFhLFFBQVEsV0FBVyxLQUFLO0NBQzlDLFFBQVE7OztFQUdOLE9BQU87Q0FDVDtBQUNGO0FBRUEsU0FBUyxXQUFXLE9BQU87Q0FDekIsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsSUFBSSxVQUFVLFVBQVU7RUFDdEIsS0FBSyxnQkFBZ0IsWUFBWTtDQUNuQyxPQUFPO0VBQ0wsS0FBSyxhQUFhLGNBQWMsS0FBSztDQUN2QztBQUNGOzs7O0FBS0EsT0FBTyxTQUFTLFdBQVc7Q0FDekIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLGVBQWU7Q0FFbEQsZ0JBQWdCO0VBQ2QsV0FBVyxLQUFLO0NBQ2xCLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixNQUFNLGNBQWMsa0JBQWtCO0VBQ3BDLFVBQVUsU0FBUzs7O0dBR2pCLE1BQU0sb0JBQ0osT0FBTyxXQUFXLGVBQWUsT0FBTyxhQUFhLDhCQUE4QixDQUFDLENBQUM7R0FDdkYsTUFBTSxVQUFVLFNBQVMsV0FBWSxvQkFBb0IsU0FBUyxVQUFXO0dBQzdFLE1BQU0sT0FBTyxZQUFZLFNBQVMsVUFBVTtHQUM1QyxJQUFJO0lBQ0YsYUFBYSxRQUFRLGFBQWEsSUFBSTtHQUN4QyxRQUFRLENBRVI7R0FDQSxPQUFPO0VBQ1QsQ0FBQztDQUNILEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FBTztFQUFFO0VBQU87Q0FBWTtBQUM5QiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ1c2VUaGVtZS5qcyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxuY29uc3QgU1RPUkFHRV9LRVkgPSAnbGVhcm5pYTp0aGVtZSdcclxuXHJcbmZ1bmN0aW9uIHJlYWRTdG9yZWRUaGVtZSgpIHtcclxuICB0cnkge1xyXG4gICAgcmV0dXJuIGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JBR0VfS0VZKSB8fCAnc3lzdGVtJ1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgLy8gUHJpdmF0ZSBicm93c2luZyAvIHN0b3JhZ2UgYmxvY2tlZCDigJQgZmFsbCBiYWNrIHRvIHN5c3RlbSwgdGhlXHJcbiAgICAvLyB0b2dnbGUgc3RpbGwgd29ya3MsIGl0IGp1c3Qgd29uJ3QgcGVyc2lzdCBhY3Jvc3MgcmVsb2Fkcy5cclxuICAgIHJldHVybiAnc3lzdGVtJ1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gYXBwbHlUaGVtZSh0aGVtZSkge1xyXG4gIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcclxuICBpZiAodGhlbWUgPT09ICdzeXN0ZW0nKSB7XHJcbiAgICByb290LnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS10aGVtZScpXHJcbiAgfSBlbHNlIHtcclxuICAgIHJvb3Quc2V0QXR0cmlidXRlKCdkYXRhLXRoZW1lJywgdGhlbWUpXHJcbiAgfVxyXG59XHJcblxyXG4vLyBNYW51YWwgbGlnaHQvZGFyayBvdmVycmlkZSBvbiB0b3Agb2YgdGhlIGBwcmVmZXJzLWNvbG9yLXNjaGVtZWAgbWVkaWFcclxuLy8gcXVlcnkgYWxyZWFkeSBiYWtlZCBpbnRvIGluZGV4LmNzcy4gYHRoZW1lYCBpcyAnbGlnaHQnIHwgJ2RhcmsnIHwgJ3N5c3RlbSdcclxuLy8gKHN5c3RlbSA9IGRlZmVyIHRvIHRoZSBPUywgdGhlIHByZS1leGlzdGluZyBkZWZhdWx0IGJlaGF2aW9yKS5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZVRoZW1lKCkge1xyXG4gIGNvbnN0IFt0aGVtZSwgc2V0VGhlbWVdID0gdXNlU3RhdGUocmVhZFN0b3JlZFRoZW1lKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYXBwbHlUaGVtZSh0aGVtZSlcclxuICB9LCBbdGhlbWVdKVxyXG5cclxuICBjb25zdCB0b2dnbGVUaGVtZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIHNldFRoZW1lKChwcmV2KSA9PiB7XHJcbiAgICAgIC8vIFRvZ2dsZSBmbGlwcyBiZXR3ZWVuIGxpZ2h0L2RhcmsuIElmIHdlIHdlcmUgZm9sbG93aW5nIHRoZSBzeXN0ZW1cclxuICAgICAgLy8gcHJlZmVyZW5jZSwganVtcCB0byB0aGUgb3Bwb3NpdGUgb2Ygd2hhdGV2ZXIgdGhlIHN5c3RlbSBpcyBub3cuXHJcbiAgICAgIGNvbnN0IHN5c3RlbVByZWZlcnNEYXJrID1cclxuICAgICAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cubWF0Y2hNZWRpYT8uKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspJykubWF0Y2hlc1xyXG4gICAgICBjb25zdCBjdXJyZW50ID0gcHJldiA9PT0gJ3N5c3RlbScgPyAoc3lzdGVtUHJlZmVyc0RhcmsgPyAnZGFyaycgOiAnbGlnaHQnKSA6IHByZXZcclxuICAgICAgY29uc3QgbmV4dCA9IGN1cnJlbnQgPT09ICdkYXJrJyA/ICdsaWdodCcgOiAnZGFyaydcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWSwgbmV4dClcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgLy8gaWdub3JlIOKAlCBzZWUgcmVhZFN0b3JlZFRoZW1lKClcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbmV4dFxyXG4gICAgfSlcclxuICB9LCBbXSlcclxuXHJcbiAgcmV0dXJuIHsgdGhlbWUsIHRvZ2dsZVRoZW1lIH1cclxufVxyXG4iXX0=