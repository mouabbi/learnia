import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/exam/ExamPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=7d918b77";
import { Timer, GitCommitHorizontal, CircleCheck, CircleDashed, Truck, PartyPopper, RotateCcw, X, ArrowLeft, ArrowRight, ShieldAlert, Eye, Sun, Moon } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { coursesApi } from "/src/features/courses/coursesApi.js";
import { recordFinalExamAttempt } from "/src/features/courses/progressStore.js";
import { PASSING_PCT, isCourseComplete } from "/src/features/courses/progress.js";
import { playExamStartCue, playExamAlertCue, playExamGradingTick, playExamResultCue } from "/src/features/exam/examSound.js";
import { useTheme } from "/src/hooks/useTheme.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/exam/ExamPage.jsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$();
// Reads the exam's own amber accent (--exam-accent, set on .exam-shell in
// index.css — deliberately distinct from the app's default --accent) so
// the calm mascot below matches the exam's own color, not the course
// theme.
function currentExamAccent() {
	if (typeof window === "undefined") return "#f59e0b";
	// --exam-accent is scoped to .exam-shell (not :root), so read it off
	// that element specifically rather than <html>.
	const shellEl = document.querySelector(".exam-shell") || document.documentElement;
	return getComputedStyle(shellEl).getPropertyValue("--exam-accent").trim() || "#f59e0b";
}
// A small, friendly creature that just... floats. Slowly. No bursts, no
// bounce, no sudden movement — replaces the old confetti-and-spring
// celebration, which some learners found overstimulating. It drifts up
// and down and tilts gently, like it's breathing, so passing feels calm
// rather than an assault of motion.
function CalmMascot() {
	_s();
	const color = useMemo(() => currentExamAccent(), []);
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-mascot",
		initial: {
			opacity: 0,
			y: 6
		},
		animate: {
			opacity: 1,
			y: [
				0,
				-10,
				0
			],
			rotate: [
				0,
				-3,
				0,
				3,
				0
			]
		},
		transition: {
			opacity: { duration: .8 },
			y: {
				duration: 4,
				repeat: Infinity,
				ease: "easeInOut"
			},
			rotate: {
				duration: 6,
				repeat: Infinity,
				ease: "easeInOut"
			}
		},
		"aria-hidden": "true",
		children: /* @__PURE__ */ _jsxDEV("svg", {
			width: "72",
			height: "72",
			viewBox: "0 0 72 72",
			fill: "none",
			children: [
				/* @__PURE__ */ _jsxDEV("ellipse", {
					cx: "36",
					cy: "62",
					rx: "20",
					ry: "4",
					fill: color,
					opacity: "0.15"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "36",
					cy: "34",
					r: "26",
					fill: color,
					opacity: "0.18"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "36",
					cy: "34",
					r: "19",
					fill: color
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "29",
					cy: "31",
					r: "2.6",
					fill: "#1a1200"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("circle", {
					cx: "43",
					cy: "31",
					r: "2.6",
					fill: "#1a1200"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("path", {
					d: "M28 41c2.5 3 13.5 3 16 0",
					stroke: "#1a1200",
					strokeWidth: "2.4",
					strokeLinecap: "round",
					fill: "none"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
_s(CalmMascot, "/WjuwVs/0HBZwnTqmkaDvvE9h4w=");
_c = CalmMascot;
// Small count-up used for the final score/percentage — ticks up from 0 to
// the target value over `duration` seconds instead of just appearing.
function CountUpNumber({ value, duration = 1.6 }) {
	_s2();
	const [display, setDisplay] = useState(0);
	useEffect(() => {
		let raf;
		const start = performance.now();
		function tick(now) {
			const t = Math.min(1, (now - start) / (duration * 1e3));
			const eased = 1 - Math.pow(1 - t, 3);
			setDisplay(Math.round(eased * value));
			if (t < 1) raf = requestAnimationFrame(tick);
		}
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [value, duration]);
	return display;
}
_s2(CountUpNumber, "YC4bHdbS7grPMaJGkLxluoBaccI=");
_c2 = CountUpNumber;
// Mock "grading pipeline" steps shown during the processing stage — pure
// theatre, no backend call. Each has its own duration so the sequence feels
// alive instead of one flat progress bar. Sums to exactly 30s.
const PROCESSING_STEPS = [
	{
		label: "Submitting your answers…",
		ms: 4e3
	},
	{
		label: "Verifying against the answer key…",
		ms: 5500
	},
	{
		label: "Calculating your score…",
		ms: 5500
	},
	{
		label: "Checking the passing threshold…",
		ms: 5500
	},
	{
		label: "Finalizing your result…",
		ms: 5500
	},
	{
		label: "Preparing your certificate status…",
		ms: 4e3
	}
];
// Full-screen final exam runner. Rendered as its own route (see App.jsx),
// deliberately outside AppLayout — no topbar/sidebar chrome while an exam
// is active, closer to a real proctored-exam feel.
// Requests true browser fullscreen — a progressive enhancement over the
// existing fixed-overlay `.exam-shell`, which already provides a soft
// in-page fullscreen fallback if the browser blocks/rejects the API (e.g.
// no user-gesture context, or an iframe without the `allow` attribute).
async function tryEnterFullscreen(element) {
	try {
		if (element && !document.fullscreenElement) {
			await element.requestFullscreen?.();
		}
	} catch {}
}
async function tryExitFullscreen() {
	try {
		if (document.fullscreenElement) {
			await document.exitFullscreen?.();
		}
	} catch {}
}
export function ExamPage() {
	_s3();
	const { slug } = useParams();
	const navigate = useNavigate();
	const shellRef = useRef(null);
	const [course, setCourse] = useState(null);
	const [allModulesDone, setAllModulesDone] = useState(false);
	const [stage, setStage] = useState("intro");
	const [answers, setAnswers] = useState({});
	const [activeIndex, setActiveIndex] = useState(0);
	const [secondsLeft, setSecondsLeft] = useState(0);
	const [tabSwitchCount, setTabSwitchCount] = useState(0);
	useEffect(() => {
		coursesApi.getCourse(slug).then(async (data) => {
			setCourse(data);
			setSecondsLeft((data.finalExam?.durationMinutes ?? 5) * 60);
			const progress = await coursesApi.getProgress(data.id);
			setAllModulesDone(isCourseComplete(data, progress.completedPageIds, progress.moduleQuizzes));
		});
	}, [slug]);
	// Leave fullscreen automatically once we're off the "active" stage
	// (finished, exited, or the whole page unmounts) — never leave the
	// learner stuck in fullscreen after the exam ends.
	useEffect(() => {
		if (stage !== "active") tryExitFullscreen();
		return () => {
			if (stage === "active") tryExitFullscreen();
		};
	}, [stage]);
	// Tab-switch / minimize detection during the timed stage. This can't
	// enforce anything (no backend to report to) — it just warns the
	// learner that leaving was noticed.
	useEffect(() => {
		if (stage !== "active") return undefined;
		function handleVisibility() {
			if (document.hidden) {
				playExamAlertCue();
				setTabSwitchCount((n) => n + 1);
			}
		}
		document.addEventListener("visibilitychange", handleVisibility);
		return () => document.removeEventListener("visibilitychange", handleVisibility);
	}, [stage]);
	if (!course) return /* @__PURE__ */ _jsxDEV("div", {
		className: "exam-shell exam-loading",
		"aria-busy": "true"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 174,
		columnNumber: 23
	}, this);
	if (!course.finalExam) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "exam-shell exam-loading",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: "This course doesn't have a final exam yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => navigate(`/courses/${slug}/learn`),
				children: "Back to course"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 7
		}, this);
	}
	if (!allModulesDone) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "exam-shell exam-loading",
			children: [/* @__PURE__ */ _jsxDEV("p", { children: "Finish every module (and pass its QCM) before the final exam unlocks." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 188,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => navigate(`/courses/${slug}/learn`),
				children: "Back to course"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 187,
			columnNumber: 7
		}, this);
	}
	const exam = course.finalExam;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "exam-shell exam-shell-serious",
		ref: shellRef,
		children: [/* @__PURE__ */ _jsxDEV(ExamThemeToggle, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(AnimatePresence, {
			mode: "wait",
			children: [
				stage === "intro" && /* @__PURE__ */ _jsxDEV(ExamIntro, {
					course,
					exam,
					onStart: () => {
						setTabSwitchCount(0);
						tryEnterFullscreen(shellRef.current);
						playExamStartCue();
						setStage("active");
					}
				}, "intro", false, {
					fileName: _jsxFileName,
					lineNumber: 203,
					columnNumber: 11
				}, this),
				stage === "active" && /* @__PURE__ */ _jsxDEV(ExamActive, {
					course,
					exam,
					answers,
					setAnswers,
					activeIndex,
					setActiveIndex,
					secondsLeft,
					setSecondsLeft,
					tabSwitchCount,
					onFinish: () => setStage("review")
				}, "active", false, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 11
				}, this),
				stage === "review" && /* @__PURE__ */ _jsxDEV(ExamReview, {
					course,
					exam,
					answers,
					onBackToExam: () => setStage("active"),
					onCommit: () => setStage("processing")
				}, "review", false, {
					fileName: _jsxFileName,
					lineNumber: 231,
					columnNumber: 11
				}, this),
				stage === "processing" && /* @__PURE__ */ _jsxDEV(ExamProcessing, { onDone: () => {
					const score = exam.questions.reduce((total, q) => answers[q.id] === q.correctOptionId ? total + 1 : total, 0);
					const pct = Math.round(score / exam.questions.length * 100);
					recordFinalExamAttempt(course.id, {
						score,
						total: exam.questions.length
					}).catch(() => {});
					playExamResultCue(pct, PASSING_PCT);
					setStage("result");
				} }, "processing", false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 11
				}, this),
				stage === "result" && /* @__PURE__ */ _jsxDEV(ExamResult, {
					course,
					exam,
					answers,
					onRetry: () => {
						setAnswers({});
						setActiveIndex(0);
						setSecondsLeft(exam.durationMinutes * 60);
						setStage("intro");
					}
				}, "result", false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 201,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 199,
		columnNumber: 5
	}, this);
}
_s3(ExamPage, "pDJ4PDNsd/GhbOgvOwP2b5R4lNw=", false, function() {
	return [useParams, useNavigate];
});
_c3 = ExamPage;
// Persistent dark/light toggle, rendered once at the top of .exam-shell so
// it's reachable from every stage (intro, active, review, processing,
// result) instead of only the final result screen.
function ExamThemeToggle() {
	_s4();
	const { theme, toggleTheme } = useTheme();
	const isDark = theme === "dark" || theme === "system" && typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;
	return /* @__PURE__ */ _jsxDEV("button", {
		type: "button",
		className: "reader-theme-toggle exam-theme-toggle",
		"aria-label": isDark ? "Switch to light mode" : "Switch to dark mode",
		onClick: toggleTheme,
		children: isDark ? /* @__PURE__ */ _jsxDEV(Sun, {
			"aria-hidden": "true",
			size: 17
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 291,
			columnNumber: 17
		}, this) : /* @__PURE__ */ _jsxDEV(Moon, {
			"aria-hidden": "true",
			size: 17
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 291,
			columnNumber: 56
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 285,
		columnNumber: 5
	}, this);
}
_s4(ExamThemeToggle, "Q4eAjrIZ0CuRuhycs6byifK2KBk=", false, function() {
	return [useTheme];
});
_c4 = ExamThemeToggle;
function ExamIntro({ course, exam, onStart }) {
	_s5();
	const navigate = useNavigate();
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-panel exam-intro",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "exam-close",
				onClick: () => navigate(`/courses/${course.slug}/learn`),
				children: /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 306,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ShieldAlert, {
				size: 40,
				className: "exam-intro-icon"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 308,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "exam-intro-eyebrow",
				children: "Final exam · certification attempt"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 309,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: course.title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 310,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "exam-intro-tagline",
				children: "This is the proctored assessment for this course — separate from the module QCMs. One timed, single attempt: read carefully, answer deliberately."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-intro-stats",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV(Timer, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 11
						}, this),
						" ",
						exam.durationMinutes,
						" min"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 317,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV(GitCommitHorizontal, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 11
						}, this),
						" ",
						exam.questions.length,
						" questions"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV(CircleCheck, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 11
						}, this),
						" pass at ",
						PASSING_PCT,
						"%+"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "exam-intro-rules",
				children: [
					/* @__PURE__ */ _jsxDEV("li", { children: "The timer starts the moment you begin — it cannot be paused." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 329,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("li", { children: "You can move between questions freely before submitting." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 330,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("li", { children: "Once submitted, your answers are final and immediately graded." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("li", { children: "Switching tabs or leaving the window during the exam will be flagged." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 328,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "exam-start-button",
				onClick: onStart,
				children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 16 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 336,
					columnNumber: 9
				}, this), " Begin final exam"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 335,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 299,
		columnNumber: 5
	}, this);
}
_s5(ExamIntro, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
	return [useNavigate];
});
_c5 = ExamIntro;
function ExamActive({ course, exam, answers, setAnswers, activeIndex, setActiveIndex, secondsLeft, setSecondsLeft, tabSwitchCount, onFinish }) {
	_s6();
	const intervalRef = useRef(null);
	useEffect(() => {
		intervalRef.current = setInterval(() => {
			setSecondsLeft((prev) => {
				if (prev <= 1) {
					clearInterval(intervalRef.current);
					onFinish();
					return 0;
				}
				return prev - 1;
			});
		}, 1e3);
		return () => clearInterval(intervalRef.current);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const question = exam.questions[activeIndex];
	const answeredCount = Object.keys(answers).length;
	const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
	const seconds = String(secondsLeft % 60).padStart(2, "0");
	const low = secondsLeft <= 30;
	const totalSeconds = exam.durationMinutes * 60;
	const timeLeftPct = totalSeconds > 0 ? secondsLeft / totalSeconds * 100 : 0;
	function select(optionId) {
		setAnswers((prev) => ({
			...prev,
			[question.id]: optionId
		}));
	}
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-panel exam-active",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-topbar",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "exam-topbar-title",
					children: [course.title, " — Final Exam"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 391,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: `exam-timer ${low ? "exam-timer-low" : ""}`,
					children: [
						/* @__PURE__ */ _jsxDEV(Timer, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 393,
							columnNumber: 11
						}, this),
						" ",
						minutes,
						":",
						seconds
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 392,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 390,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-timer-track",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					className: `exam-timer-fill ${low ? "exam-timer-fill-low" : ""}`,
					animate: { width: `${timeLeftPct}%` },
					transition: {
						duration: 1,
						ease: "linear"
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 397,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 396,
				columnNumber: 7
			}, this),
			tabSwitchCount > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "exam-tab-warning",
				role: "alert",
				children: [
					/* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 406,
						columnNumber: 11
					}, this),
					"Tab-switch detected (",
					tabSwitchCount,
					"). Stay on this window until you submit."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 405,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-progress-dots",
				children: exam.questions.map((q, i) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: [
						"exam-dot",
						i === activeIndex ? "exam-dot-active" : "",
						answers[q.id] ? "exam-dot-answered" : ""
					].filter(Boolean).join(" "),
					onClick: () => setActiveIndex(i),
					"aria-label": `Question ${i + 1}${answers[q.id] ? " (answered)" : ""}`
				}, q.id, false, {
					fileName: _jsxFileName,
					lineNumber: 413,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 411,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-question-card",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "exam-question-index",
						children: [
							"Question ",
							activeIndex + 1,
							" of ",
							exam.questions.length
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", { children: question.prompt }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 433,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "exam-options",
						children: question.options.map((option) => /* @__PURE__ */ _jsxDEV("label", {
							className: `exam-option ${answers[question.id] === option.id ? "exam-option-selected" : ""}`,
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "radio",
								name: question.id,
								checked: answers[question.id] === option.id,
								onChange: () => select(option.id)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 440,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: option.text }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 446,
								columnNumber: 15
							}, this)]
						}, option.id, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 429,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-nav",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: activeIndex === 0,
						onClick: () => setActiveIndex((i) => Math.max(0, i - 1)),
						children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 458,
							columnNumber: 11
						}, this), " Previous"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 453,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "exam-answered-count",
						children: [
							answeredCount,
							"/",
							exam.questions.length,
							" answered"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 460,
						columnNumber: 9
					}, this),
					activeIndex < exam.questions.length - 1 ? /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setActiveIndex((i) => i + 1),
						children: ["Next ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 465,
							columnNumber: 18
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 464,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "exam-review-button",
						onClick: onFinish,
						children: "Review & commit"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 468,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 452,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 384,
		columnNumber: 5
	}, this);
}
_s6(ExamActive, "BCZoY83JxN7+UHynqiOtAbJbBWM=");
_c6 = ExamActive;
function ExamReview({ course, exam, answers, onBackToExam, onCommit }) {
	_s7();
	const [message, setMessage] = useState(`Complete final exam for ${course.title}`);
	const unanswered = exam.questions.filter((q) => !answers[q.id]);
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-panel exam-review",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "exam-intro-eyebrow",
				children: "Final review — before you submit"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 488,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: "Review your answers" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 489,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-terminal",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "exam-terminal-line exam-terminal-muted",
					children: "Answer summary"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 492,
					columnNumber: 9
				}, this), exam.questions.map((q, i) => /* @__PURE__ */ _jsxDEV("p", {
					className: "exam-terminal-line",
					children: [
						answers[q.id] ? /* @__PURE__ */ _jsxDEV(CircleCheck, {
							size: 14,
							className: "exam-terminal-check"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 496,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(CircleDashed, {
							size: 14,
							className: "exam-terminal-dash"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 498,
							columnNumber: 15
						}, this),
						" ",
						"Question ",
						i + 1,
						" ",
						answers[q.id] ? "(answered)" : /* @__PURE__ */ _jsxDEV("em", { children: "(unanswered — will count as wrong)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 501,
							columnNumber: 45
						}, this)
					]
				}, q.id, true, {
					fileName: _jsxFileName,
					lineNumber: 494,
					columnNumber: 11
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 491,
				columnNumber: 7
			}, this),
			unanswered.length > 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "exam-review-warning",
				children: [
					unanswered.length,
					" question",
					unanswered.length === 1 ? "" : "s",
					" still unanswered. You can go back, or submit anyway."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 507,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				className: "exam-commit-label",
				htmlFor: "commit-message",
				children: "Final note (optional)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 513,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "commit-message",
				className: "exam-commit-input",
				value: message,
				onChange: (e) => setMessage(e.target.value)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 516,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-review-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "exam-back-button",
					onClick: onBackToExam,
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 525,
						columnNumber: 11
					}, this), " Back to exam"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 524,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "exam-commit-button",
					onClick: onCommit,
					children: [/* @__PURE__ */ _jsxDEV(GitCommitHorizontal, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 528,
						columnNumber: 11
					}, this), " Submit final answers"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 527,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 523,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 482,
		columnNumber: 5
	}, this);
}
_s7(ExamReview, "8N4RLzpjQn/PMKJ7TRZKAMcZBrg=");
_c7 = ExamReview;
function ExamProcessing({ onDone }) {
	_s8();
	const [stepIndex, setStepIndex] = useState(0);
	const totalMs = useMemo(() => PROCESSING_STEPS.reduce((sum, s) => sum + s.ms, 0), []);
	useEffect(() => {
		const timeouts = [];
		let elapsed = 0;
		PROCESSING_STEPS.forEach((step, i) => {
			elapsed += step.ms;
			timeouts.push(setTimeout(() => {
				playExamGradingTick();
				if (i === PROCESSING_STEPS.length - 1) {
					setTimeout(onDone, 400);
				} else {
					setStepIndex(i + 1);
				}
			}, elapsed));
		});
		return () => timeouts.forEach(clearTimeout);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-panel exam-processing",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "exam-intro-eyebrow",
				children: "Hang tight"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 566,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: "Grading in progress…" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 567,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "exam-processing-caption",
				children: "Your submission is being scored automatically."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 568,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-road",
				children: [/* @__PURE__ */ _jsxDEV(motion.div, {
					className: "exam-truck",
					animate: { left: `${stepIndex / (PROCESSING_STEPS.length - 1) * 100}%` },
					transition: {
						duration: totalMs === 0 ? 0 : PROCESSING_STEPS[stepIndex]?.ms / 1e3,
						ease: "linear"
					},
					children: /* @__PURE__ */ _jsxDEV(Truck, { size: 28 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 576,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 571,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", { className: "exam-road-track" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 578,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 570,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("ul", {
				className: "exam-processing-steps",
				children: PROCESSING_STEPS.map((step, i) => /* @__PURE__ */ _jsxDEV("li", {
					className: [
						"exam-processing-step",
						i < stepIndex ? "exam-processing-step-done" : "",
						i === stepIndex ? "exam-processing-step-active" : ""
					].filter(Boolean).join(" "),
					children: [i < stepIndex ? /* @__PURE__ */ _jsxDEV(CircleCheck, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 593,
						columnNumber: 30
					}, this) : /* @__PURE__ */ _jsxDEV(CircleDashed, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 593,
						columnNumber: 58
					}, this), step.label]
				}, step.label, true, {
					fileName: _jsxFileName,
					lineNumber: 583,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 581,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 560,
		columnNumber: 5
	}, this);
}
_s8(ExamProcessing, "w6CIW+9t23vcwteMAVngXkRUTXk=");
_c8 = ExamProcessing;
function ExamResult({ course, exam, answers, onRetry }) {
	_s9();
	const navigate = useNavigate();
	const score = exam.questions.reduce((total, q) => answers[q.id] === q.correctOptionId ? total + 1 : total, 0);
	const total = exam.questions.length;
	const pct = Math.round(score / total * 100);
	const passed = pct >= PASSING_PCT;
	const perfect = pct === 100;
	const great = passed && !perfect && pct >= 90;
	// One short, restrained confetti burst on a pass — same idea as the
	// module-quiz congrats (features/courses/Quiz.jsx), not the old
	// multi-angle fireworks: a single quick burst in the exam's own amber,
	// sized a little bigger for a perfect/great score.
	useEffect(() => {
		if (!passed) return;
		confetti({
			colors: [currentExamAccent()],
			origin: { y: .3 },
			particleCount: perfect ? 90 : great ? 70 : 55,
			spread: 70,
			startVelocity: 30,
			ticks: 150,
			gravity: 1,
			scalar: .9
		});
	}, [
		passed,
		perfect,
		great
	]);
	return /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "exam-panel exam-result",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		transition: { duration: .5 },
		children: [
			passed && /* @__PURE__ */ _jsxDEV(CalmMascot, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 641,
				columnNumber: 18
			}, this),
			/* @__PURE__ */ _jsxDEV(motion.div, {
				className: `exam-result-badge ${passed ? "exam-result-badge-pass" : "exam-result-badge-fail"}`,
				initial: {
					scale: .6,
					opacity: 0
				},
				animate: {
					scale: 1,
					opacity: 1
				},
				transition: {
					type: "spring",
					stiffness: 240,
					damping: 20
				},
				children: passed ? /* @__PURE__ */ _jsxDEV(PartyPopper, { size: 32 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 649,
					columnNumber: 19
				}, this) : /* @__PURE__ */ _jsxDEV(ShieldAlert, { size: 32 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 649,
					columnNumber: 47
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 643,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h1", { children: perfect ? "Perfect score!" : great ? "Great score!" : passed ? "Exam passed" : "Not a passing score" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 652,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "exam-result-caption",
				children: passed ? `You passed the ${course.title} final exam.` : `You didn't reach the passing score for ${course.title} this time. Review the material and try again when you're ready.`
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 653,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-result-score",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "exam-result-score-value",
						children: /* @__PURE__ */ _jsxDEV(CountUpNumber, { value: score }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 661,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 660,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "exam-result-score-total",
						children: ["/ ", total]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 663,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "exam-result-score-pct",
						children: [
							"(",
							/* @__PURE__ */ _jsxDEV(CountUpNumber, { value: pct }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 665,
								columnNumber: 12
							}, this),
							"%)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 664,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 659,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-result-pct-track",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					className: `exam-result-pct-fill ${passed ? "" : "exam-result-pct-fill-fail"}`,
					initial: { width: 0 },
					animate: { width: `${pct}%` },
					transition: {
						duration: 1.6,
						ease: "easeInOut"
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 669,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 668,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "hint",
				children: [
					"Passing score: ",
					PASSING_PCT,
					"%+"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 676,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "exam-result-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "exam-back-button",
					onClick: onRetry,
					children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 682,
						columnNumber: 11
					}, this), " Retry exam"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 681,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => navigate(`/courses/${course.slug}/learn`),
					children: "Back to course"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 684,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 680,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 634,
		columnNumber: 5
	}, this);
}
_s9(ExamResult, "r6Y4cxllxeSwx3b1nMjC3P/JySI=", false, function() {
	return [useNavigate];
});
_c9 = ExamResult;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "CalmMascot");
$RefreshReg$(_c2, "CountUpNumber");
$RefreshReg$(_c3, "ExamPage");
$RefreshReg$(_c4, "ExamThemeToggle");
$RefreshReg$(_c5, "ExamIntro");
$RefreshReg$(_c6, "ExamActive");
$RefreshReg$(_c7, "ExamReview");
$RefreshReg$(_c8, "ExamProcessing");
$RefreshReg$(_c9, "ExamResult");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/exam/ExamPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/exam/ExamPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/exam/ExamPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/exam/ExamPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsUUFBUSxnQkFBZ0I7QUFDckQsU0FBUyxhQUFhLGlCQUFpQjtBQUN2QyxTQUFTLGlCQUFpQixjQUFjO0FBQ3hDLE9BQU8sY0FBYztBQUNyQixTQUNFLE9BQ0EscUJBQ0EsYUFDQSxjQUNBLE9BQ0EsYUFDQSxXQUNBLEdBQ0EsV0FDQSxZQUNBLGFBQ0EsS0FDQSxLQUNBLFlBQ0s7QUFDUCxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLGFBQWEsd0JBQXdCO0FBQzlDLFNBQVMsa0JBQWtCLGtCQUFrQixxQkFBcUIseUJBQXlCO0FBQzNGLFNBQVMsZ0JBQWdCOzs7Ozs7OztBQU16QixTQUFTLG9CQUFvQjtDQUMzQixJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87OztDQUcxQyxNQUFNLFVBQVUsU0FBUyxjQUFjLGFBQWEsS0FBSyxTQUFTO0NBQ2xFLE9BQU8saUJBQWlCLE9BQU8sQ0FBQyxDQUFDLGlCQUFpQixlQUFlLENBQUMsQ0FBQyxLQUFLLEtBQUs7QUFDL0U7Ozs7OztBQU9BLFNBQVMsYUFBYTs7Q0FDcEIsTUFBTSxRQUFRLGNBQWMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO0NBQ25ELE9BQ0Usd0JBQUMsT0FBTyxLQUFSO0VBQ0UsV0FBVTtFQUNWLFNBQVM7R0FBRSxTQUFTO0dBQUcsR0FBRztFQUFFO0VBQzVCLFNBQVM7R0FBRSxTQUFTO0dBQUcsR0FBRztJQUFDO0lBQUcsQ0FBQztJQUFJO0dBQUM7R0FBRyxRQUFRO0lBQUM7SUFBRyxDQUFDO0lBQUc7SUFBRztJQUFHO0dBQUM7RUFBRTtFQUNoRSxZQUFZO0dBQ1YsU0FBUyxFQUFFLFVBQVUsR0FBSTtHQUN6QixHQUFHO0lBQUUsVUFBVTtJQUFHLFFBQVE7SUFBVSxNQUFNO0dBQVk7R0FDdEQsUUFBUTtJQUFFLFVBQVU7SUFBRyxRQUFRO0lBQVUsTUFBTTtHQUFZO0VBQzdEO0VBQ0EsZUFBWTtZQUVaLHdCQUFDLE9BQUQ7R0FBSyxPQUFNO0dBQUssUUFBTztHQUFLLFNBQVE7R0FBWSxNQUFLO2FBQXJEO0lBQ0Usd0JBQUMsV0FBRDtLQUFTLElBQUc7S0FBSyxJQUFHO0tBQUssSUFBRztLQUFLLElBQUc7S0FBSSxNQUFNO0tBQU8sU0FBUTtJQUFROzs7OztJQUNyRSx3QkFBQyxVQUFEO0tBQVEsSUFBRztLQUFLLElBQUc7S0FBSyxHQUFFO0tBQUssTUFBTTtLQUFPLFNBQVE7SUFBUTs7Ozs7SUFDNUQsd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBSyxJQUFHO0tBQUssR0FBRTtLQUFLLE1BQU07SUFBUTs7Ozs7SUFDN0Msd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBSyxJQUFHO0tBQUssR0FBRTtLQUFNLE1BQUs7SUFBVzs7Ozs7SUFDaEQsd0JBQUMsVUFBRDtLQUFRLElBQUc7S0FBSyxJQUFHO0tBQUssR0FBRTtLQUFNLE1BQUs7SUFBVzs7Ozs7SUFDaEQsd0JBQUMsUUFBRDtLQUFNLEdBQUU7S0FBMkIsUUFBTztLQUFVLGFBQVk7S0FBTSxlQUFjO0tBQVEsTUFBSztJQUFROzs7OztHQUN0Rzs7Ozs7O0NBQ0s7Ozs7O0FBRWhCOzs7OztBQUlBLFNBQVMsY0FBYyxFQUFFLE9BQU8sV0FBVyxPQUFPOztDQUNoRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQztDQUN4QyxnQkFBZ0I7RUFDZCxJQUFJO0VBQ0osTUFBTSxRQUFRLFlBQVksSUFBSTtFQUM5QixTQUFTLEtBQUssS0FBSztHQUNqQixNQUFNLElBQUksS0FBSyxJQUFJLElBQUksTUFBTSxVQUFVLFdBQVcsSUFBSztHQUN2RCxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHLENBQUM7R0FDbkMsV0FBVyxLQUFLLE1BQU0sUUFBUSxLQUFLLENBQUM7R0FDcEMsSUFBSSxJQUFJLEdBQUcsTUFBTSxzQkFBc0IsSUFBSTtFQUM3QztFQUNBLE1BQU0sc0JBQXNCLElBQUk7RUFDaEMsYUFBYSxxQkFBcUIsR0FBRztDQUN2QyxHQUFHLENBQUMsT0FBTyxRQUFRLENBQUM7Q0FDcEIsT0FBTztBQUNUOzs7Ozs7QUFLQSxNQUFNLG1CQUFtQjtDQUN2QjtFQUFFLE9BQU87RUFBNEIsSUFBSTtDQUFLO0NBQzlDO0VBQUUsT0FBTztFQUFxQyxJQUFJO0NBQUs7Q0FDdkQ7RUFBRSxPQUFPO0VBQTJCLElBQUk7Q0FBSztDQUM3QztFQUFFLE9BQU87RUFBbUMsSUFBSTtDQUFLO0NBQ3JEO0VBQUUsT0FBTztFQUEyQixJQUFJO0NBQUs7Q0FDN0M7RUFBRSxPQUFPO0VBQXNDLElBQUk7Q0FBSztBQUMxRDs7Ozs7Ozs7QUFTQSxlQUFlLG1CQUFtQixTQUFTO0NBQ3pDLElBQUk7RUFDRixJQUFJLFdBQVcsQ0FBQyxTQUFTLG1CQUFtQjtHQUMxQyxNQUFNLFFBQVEsb0JBQW9CO0VBQ3BDO0NBQ0YsUUFBUSxDQUVSO0FBQ0Y7QUFFQSxlQUFlLG9CQUFvQjtDQUNqQyxJQUFJO0VBQ0YsSUFBSSxTQUFTLG1CQUFtQjtHQUM5QixNQUFNLFNBQVMsaUJBQWlCO0VBQ2xDO0NBQ0YsUUFBUSxDQUVSO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsV0FBVzs7Q0FDekIsTUFBTSxFQUFFLFNBQVMsVUFBVTtDQUMzQixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsT0FBTyxJQUFJO0NBQzVCLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxJQUFJO0NBQ3pDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsT0FBTztDQUMxQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsQ0FBQyxDQUFDO0NBQ3pDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLENBQUM7Q0FDaEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsQ0FBQztDQUNoRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLENBQUM7Q0FFdEQsZ0JBQWdCO0VBQ2QsV0FBVyxVQUFVLElBQUksQ0FBQyxDQUFDLEtBQUssT0FBTyxTQUFTO0dBQzlDLFVBQVUsSUFBSTtHQUNkLGdCQUFnQixLQUFLLFdBQVcsbUJBQW1CLEtBQUssRUFBRTtHQUMxRCxNQUFNLFdBQVcsTUFBTSxXQUFXLFlBQVksS0FBSyxFQUFFO0dBQ3JELGtCQUFrQixpQkFBaUIsTUFBTSxTQUFTLGtCQUFrQixTQUFTLGFBQWEsQ0FBQztFQUM3RixDQUFDO0NBQ0gsR0FBRyxDQUFDLElBQUksQ0FBQzs7OztDQUtULGdCQUFnQjtFQUNkLElBQUksVUFBVSxVQUFVLGtCQUFrQjtFQUMxQyxhQUFhO0dBQ1gsSUFBSSxVQUFVLFVBQVUsa0JBQWtCO0VBQzVDO0NBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQzs7OztDQUtWLGdCQUFnQjtFQUNkLElBQUksVUFBVSxVQUFVLE9BQU87RUFDL0IsU0FBUyxtQkFBbUI7R0FDMUIsSUFBSSxTQUFTLFFBQVE7SUFDbkIsaUJBQWlCO0lBQ2pCLG1CQUFtQixNQUFNLElBQUksQ0FBQztHQUNoQztFQUNGO0VBQ0EsU0FBUyxpQkFBaUIsb0JBQW9CLGdCQUFnQjtFQUM5RCxhQUFhLFNBQVMsb0JBQW9CLG9CQUFvQixnQkFBZ0I7Q0FDaEYsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLElBQUksQ0FBQyxRQUFRLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBMEIsYUFBVTtDQUFROzs7OztDQUMvRSxJQUFJLENBQUMsT0FBTyxXQUFXO0VBQ3JCLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLEtBQUQsWUFBRyw2Q0FBNkM7Ozs7YUFDaEQsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxlQUFlLFNBQVMsWUFBWSxLQUFLLE9BQU87Y0FBRztHQUVqRTs7OztXQUNMOzs7Ozs7Q0FFVDtDQUNBLElBQUksQ0FBQyxnQkFBZ0I7RUFDbkIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsS0FBRCxZQUFHLHdFQUF3RTs7OzthQUMzRSx3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLGVBQWUsU0FBUyxZQUFZLEtBQUssT0FBTztjQUFHO0dBRWpFOzs7O1dBQ0w7Ozs7OztDQUVUO0NBRUEsTUFBTSxPQUFPLE9BQU87Q0FFcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtFQUFnQyxLQUFLO1lBQXBELENBQ0Usd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7WUFDbEIsd0JBQUMsaUJBQUQ7R0FBaUIsTUFBSzthQUF0QjtJQUNHLFVBQVUsV0FDVCx3QkFBQyxXQUFEO0tBRVU7S0FDRjtLQUNOLGVBQWU7TUFDYixrQkFBa0IsQ0FBQztNQUNuQixtQkFBbUIsU0FBUyxPQUFPO01BQ25DLGlCQUFpQjtNQUNqQixTQUFTLFFBQVE7S0FDbkI7SUFDRCxHQVRLOzs7O1dBU0w7SUFFRixVQUFVLFlBQ1Qsd0JBQUMsWUFBRDtLQUVVO0tBQ0Y7S0FDRztLQUNHO0tBQ0M7S0FDRztLQUNIO0tBQ0c7S0FDQTtLQUNoQixnQkFBZ0IsU0FBUyxRQUFRO0lBQ2xDLEdBWEs7Ozs7V0FXTDtJQUVGLFVBQVUsWUFDVCx3QkFBQyxZQUFEO0tBRVU7S0FDRjtLQUNHO0tBQ1Qsb0JBQW9CLFNBQVMsUUFBUTtLQUNyQyxnQkFBZ0IsU0FBUyxZQUFZO0lBQ3RDLEdBTks7Ozs7V0FNTDtJQUVGLFVBQVUsZ0JBQ1Qsd0JBQUMsZ0JBQUQsRUFFRSxjQUFjO0tBQ1osTUFBTSxRQUFRLEtBQUssVUFBVSxRQUMxQixPQUFPLE1BQU8sUUFBUSxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsUUFBUSxJQUFJLE9BQ2pFLENBQ0Y7S0FDQSxNQUFNLE1BQU0sS0FBSyxNQUFPLFFBQVEsS0FBSyxVQUFVLFNBQVUsR0FBRztLQUM1RCx1QkFBdUIsT0FBTyxJQUFJO01BQUU7TUFBTyxPQUFPLEtBQUssVUFBVTtLQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0tBQ3pGLGtCQUFrQixLQUFLLFdBQVc7S0FDbEMsU0FBUyxRQUFRO0lBQ25CLEVBQ0QsR0FYSzs7OztXQVdMO0lBRUYsVUFBVSxZQUNULHdCQUFDLFlBQUQ7S0FFVTtLQUNGO0tBQ0c7S0FDVCxlQUFlO01BQ2IsV0FBVyxDQUFDLENBQUM7TUFDYixlQUFlLENBQUM7TUFDaEIsZUFBZSxLQUFLLGtCQUFrQixFQUFFO01BQ3hDLFNBQVMsT0FBTztLQUNsQjtJQUNELEdBVks7Ozs7V0FVTDtHQUVZOzs7OztVQUNkOzs7Ozs7QUFFVDs7Ozs7Ozs7QUFLQSxTQUFTLGtCQUFrQjs7Q0FDekIsTUFBTSxFQUFFLE9BQU8sZ0JBQWdCLFNBQVM7Q0FDeEMsTUFBTSxTQUNKLFVBQVUsVUFDVCxVQUFVLFlBQ1QsT0FBTyxXQUFXLGVBQ2xCLE9BQU8sYUFBYSw4QkFBOEIsQ0FBQyxDQUFDO0NBQ3hELE9BQ0Usd0JBQUMsVUFBRDtFQUNFLE1BQUs7RUFDTCxXQUFVO0VBQ1YsY0FBWSxTQUFTLHlCQUF5QjtFQUM5QyxTQUFTO1lBRVIsU0FBUyx3QkFBQyxLQUFEO0dBQUssZUFBWTtHQUFPLE1BQU07RUFBSzs7OzthQUFJLHdCQUFDLE1BQUQ7R0FBTSxlQUFZO0dBQU8sTUFBTTtFQUFLOzs7OztDQUMvRTs7Ozs7QUFFWjs7Ozs7QUFFQSxTQUFTLFVBQVUsRUFBRSxRQUFRLE1BQU0sV0FBVzs7Q0FDNUMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsT0FDRSx3QkFBQyxPQUFPLEtBQVI7RUFDRSxXQUFVO0VBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7WUFKckI7R0FNRSx3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLFdBQVU7SUFBYSxlQUFlLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTztjQUNsRyx3QkFBQyxHQUFELEVBQUcsTUFBTSxHQUFLOzs7OztHQUNSOzs7OztHQUNSLHdCQUFDLGFBQUQ7SUFBYSxNQUFNO0lBQUksV0FBVTtHQUFtQjs7Ozs7R0FDcEQsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBcUI7R0FBd0M7Ozs7O0dBQzdFLHdCQUFDLE1BQUQsWUFBSyxPQUFPLE1BQVU7Ozs7O0dBQ3RCLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXFCO0dBRy9COzs7OztHQUVILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7TUFBQztNQUFFLEtBQUs7TUFBZ0I7S0FDdkM7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLHFCQUFELEVBQXFCLE1BQU0sR0FBSzs7Ozs7TUFBQztNQUFFLEtBQUssVUFBVTtNQUFPO0tBQ3REOzs7OztLQUNMLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztNQUFDO01BQVU7TUFBWTtLQUM1Qzs7Ozs7SUFDRjs7Ozs7O0dBRUwsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZDtLQUNFLHdCQUFDLE1BQUQsWUFBSSwrREFBZ0U7Ozs7O0tBQ3BFLHdCQUFDLE1BQUQsWUFBSSwyREFBNEQ7Ozs7O0tBQ2hFLHdCQUFDLE1BQUQsWUFBSSxpRUFBa0U7Ozs7O0tBQ3RFLHdCQUFDLE1BQUQsWUFBSSx3RUFBeUU7Ozs7O0lBQzNFOzs7Ozs7R0FFSix3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLFdBQVU7SUFBb0IsU0FBUztjQUE3RCxDQUNFLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7Y0FBQyxtQkFDbkI7Ozs7OztFQUNFOzs7Ozs7QUFFaEI7Ozs7O0FBRUEsU0FBUyxXQUFXLEVBQ2xCLFFBQ0EsTUFDQSxTQUNBLFlBQ0EsYUFDQSxnQkFDQSxhQUNBLGdCQUNBLGdCQUNBLFlBQ0M7O0NBQ0QsTUFBTSxjQUFjLE9BQU8sSUFBSTtDQUUvQixnQkFBZ0I7RUFDZCxZQUFZLFVBQVUsa0JBQWtCO0dBQ3RDLGdCQUFnQixTQUFTO0lBQ3ZCLElBQUksUUFBUSxHQUFHO0tBQ2IsY0FBYyxZQUFZLE9BQU87S0FDakMsU0FBUztLQUNULE9BQU87SUFDVDtJQUNBLE9BQU8sT0FBTztHQUNoQixDQUFDO0VBQ0gsR0FBRyxHQUFJO0VBQ1AsYUFBYSxjQUFjLFlBQVksT0FBTzs7Q0FFaEQsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFdBQVcsS0FBSyxVQUFVO0NBQ2hDLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQztDQUMzQyxNQUFNLFVBQVUsT0FBTyxLQUFLLE1BQU0sY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQ3BFLE1BQU0sVUFBVSxPQUFPLGNBQWMsRUFBRSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDeEQsTUFBTSxNQUFNLGVBQWU7Q0FDM0IsTUFBTSxlQUFlLEtBQUssa0JBQWtCO0NBQzVDLE1BQU0sY0FBYyxlQUFlLElBQUssY0FBYyxlQUFnQixNQUFNO0NBRTVFLFNBQVMsT0FBTyxVQUFVO0VBQ3hCLFlBQVksVUFBVTtHQUFFLEdBQUc7SUFBTyxTQUFTLEtBQUs7RUFBUyxFQUFFO0NBQzdEO0NBRUEsT0FDRSx3QkFBQyxPQUFPLEtBQVI7RUFDRSxXQUFVO0VBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7WUFKckI7R0FNRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBcUMsT0FBTyxPQUFNLGVBQW1COzs7OztjQUNyRSx3QkFBQyxRQUFEO0tBQU0sV0FBVyxjQUFjLE1BQU0sbUJBQW1CO2VBQXhEO01BQ0Usd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7Ozs7TUFBQztNQUFFO01BQVE7TUFBRTtLQUMzQjs7Ozs7WUFDSDs7Ozs7O0dBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFPLEtBQVI7S0FDRSxXQUFXLG1CQUFtQixNQUFNLHdCQUF3QjtLQUM1RCxTQUFTLEVBQUUsT0FBTyxHQUFHLFlBQVksR0FBRztLQUNwQyxZQUFZO01BQUUsVUFBVTtNQUFHLE1BQU07S0FBUztJQUMzQzs7Ozs7R0FDRTs7Ozs7R0FFSixpQkFBaUIsS0FDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBbUIsTUFBSztjQUF2QztLQUNFLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O0tBQUM7S0FDSztLQUFlO0lBQ2xDOzs7Ozs7R0FHUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLEtBQUssVUFBVSxLQUFLLEdBQUcsTUFDdEIsd0JBQUMsVUFBRDtLQUVFLE1BQUs7S0FDTCxXQUFXO01BQ1Q7TUFDQSxNQUFNLGNBQWMsb0JBQW9CO01BQ3hDLFFBQVEsRUFBRSxNQUFNLHNCQUFzQjtLQUN4QyxDQUFDLENBQ0UsT0FBTyxPQUFPLENBQUMsQ0FDZixLQUFLLEdBQUc7S0FDWCxlQUFlLGVBQWUsQ0FBQztLQUMvQixjQUFZLFlBQVksSUFBSSxJQUFJLFFBQVEsRUFBRSxNQUFNLGdCQUFnQjtJQUNqRSxHQVhNLEVBQUU7Ozs7V0FXUixDQUNGO0dBQ0U7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUFzQztPQUMxQixjQUFjO09BQUU7T0FBSyxLQUFLLFVBQVU7TUFDMUM7Ozs7OztLQUNOLHdCQUFDLE1BQUQsWUFBSyxTQUFTLE9BQVc7Ozs7O0tBQ3pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFNBQVMsUUFBUSxLQUFLLFdBQ3JCLHdCQUFDLFNBQUQ7T0FFRSxXQUFXLGVBQWUsUUFBUSxTQUFTLFFBQVEsT0FBTyxLQUFLLHlCQUF5QjtpQkFGMUYsQ0FJRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE1BQU0sU0FBUztRQUNmLFNBQVMsUUFBUSxTQUFTLFFBQVEsT0FBTztRQUN6QyxnQkFBZ0IsT0FBTyxPQUFPLEVBQUU7T0FDakM7Ozs7aUJBQ0Qsd0JBQUMsUUFBRCxZQUFPLE9BQU8sS0FBVzs7OztlQUNwQjtTQVZBLE9BQU87Ozs7YUFVUCxDQUNSO0tBQ0U7Ozs7O0lBQ0Y7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFVBQVUsZ0JBQWdCO01BQzFCLGVBQWUsZ0JBQWdCLE1BQU0sS0FBSyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7Z0JBSHpELENBS0Usd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztnQkFBQyxXQUNqQjs7Ozs7O0tBQ1Isd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQ0c7T0FBYztPQUFFLEtBQUssVUFBVTtPQUFPO01BQ25DOzs7Ozs7S0FDTCxjQUFjLEtBQUssVUFBVSxTQUFTLElBQ3JDLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsZUFBZSxnQkFBZ0IsTUFBTSxJQUFJLENBQUM7Z0JBQWhFLENBQW1FLFNBQzVELHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7Y0FDdEI7Ozs7O2dCQUVSLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsV0FBVTtNQUFxQixTQUFTO2dCQUFVO0tBRWhFOzs7OztJQUVQOzs7Ozs7RUFDSzs7Ozs7O0FBRWhCOzs7QUFFQSxTQUFTLFdBQVcsRUFBRSxRQUFRLE1BQU0sU0FBUyxjQUFjLFlBQVk7O0NBQ3JFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUywyQkFBMkIsT0FBTyxPQUFPO0NBQ2hGLE1BQU0sYUFBYSxLQUFLLFVBQVUsUUFBUSxNQUFNLENBQUMsUUFBUSxFQUFFLEdBQUc7Q0FFOUQsT0FDRSx3QkFBQyxPQUFPLEtBQVI7RUFDRSxXQUFVO0VBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7WUFKckI7R0FNRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFxQjtHQUFzQzs7Ozs7R0FDM0Usd0JBQUMsTUFBRCxZQUFJLHNCQUF1Qjs7Ozs7R0FFM0Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlDO0lBQWlCOzs7O2NBQ3RFLEtBQUssVUFBVSxLQUFLLEdBQUcsTUFDdEIsd0JBQUMsS0FBRDtLQUFjLFdBQVU7ZUFBeEI7TUFDRyxRQUFRLEVBQUUsTUFDVCx3QkFBQyxhQUFEO09BQWEsTUFBTTtPQUFJLFdBQVU7TUFBdUI7Ozs7aUJBRXhELHdCQUFDLGNBQUQ7T0FBYyxNQUFNO09BQUksV0FBVTtNQUFzQjs7Ozs7TUFDdkQ7TUFBSTtNQUNHLElBQUk7TUFBRztNQUNoQixRQUFRLEVBQUUsTUFBTSxlQUFlLHdCQUFDLE1BQUQsWUFBSSxxQ0FBc0M7Ozs7O0tBQ3pFO09BUkssRUFBRTs7OztXQVFQLENBQ0osQ0FDRTs7Ozs7O0dBRUosV0FBVyxTQUFTLEtBQ25CLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWI7S0FDRyxXQUFXO0tBQU87S0FBVSxXQUFXLFdBQVcsSUFBSSxLQUFLO0tBQUk7SUFFL0Q7Ozs7OztHQUdMLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO0lBQW9CLFNBQVE7Y0FBaUI7R0FFdkQ7Ozs7O0dBQ1Asd0JBQUMsU0FBRDtJQUNFLElBQUc7SUFDSCxXQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVcsTUFBTSxXQUFXLEVBQUUsT0FBTyxLQUFLO0dBQzNDOzs7OztHQUVELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7S0FBbUIsU0FBUztlQUE1RCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7ZUFBQyxlQUNqQjs7Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7S0FBcUIsU0FBUztlQUE5RCxDQUNFLHdCQUFDLHFCQUFELEVBQXFCLE1BQU0sR0FBSzs7OztlQUFDLHVCQUMzQjs7Ozs7WUFDTDs7Ozs7O0VBQ0s7Ozs7OztBQUVoQjs7O0FBRUEsU0FBUyxlQUFlLEVBQUUsVUFBVTs7Q0FDbEMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsQ0FBQztDQUM1QyxNQUFNLFVBQVUsY0FBYyxpQkFBaUIsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztDQUVwRixnQkFBZ0I7RUFDZCxNQUFNLFdBQVcsQ0FBQztFQUNsQixJQUFJLFVBQVU7RUFDZCxpQkFBaUIsU0FBUyxNQUFNLE1BQU07R0FDcEMsV0FBVyxLQUFLO0dBQ2hCLFNBQVMsS0FDUCxpQkFBaUI7SUFDZixvQkFBb0I7SUFDcEIsSUFBSSxNQUFNLGlCQUFpQixTQUFTLEdBQUc7S0FDckMsV0FBVyxRQUFRLEdBQUc7SUFDeEIsT0FBTztLQUNMLGFBQWEsSUFBSSxDQUFDO0lBQ3BCO0dBQ0YsR0FBRyxPQUFPLENBQ1o7RUFDRixDQUFDO0VBQ0QsYUFBYSxTQUFTLFFBQVEsWUFBWTs7Q0FFNUMsR0FBRyxDQUFDLENBQUM7Q0FFTCxPQUNFLHdCQUFDLE9BQU8sS0FBUjtFQUNFLFdBQVU7RUFDVixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLFNBQVMsRUFBRSxTQUFTLEVBQUU7RUFDdEIsTUFBTSxFQUFFLFNBQVMsRUFBRTtZQUpyQjtHQU1FLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQXFCO0dBQWdCOzs7OztHQUNyRCx3QkFBQyxNQUFELFlBQUksdUJBQXdCOzs7OztHQUM1Qix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUEwQjtHQUFpRDs7Ozs7R0FFeEYsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQU8sS0FBUjtLQUNFLFdBQVU7S0FDVixTQUFTLEVBQUUsTUFBTSxHQUFJLGFBQWEsaUJBQWlCLFNBQVMsS0FBTSxJQUFJLEdBQUc7S0FDekUsWUFBWTtNQUFFLFVBQVUsWUFBWSxJQUFJLElBQUksaUJBQWlCLFVBQVUsRUFBRSxLQUFLO01BQU0sTUFBTTtLQUFTO2VBRW5HLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7O0lBQ1I7Ozs7Y0FDWix3QkFBQyxPQUFELEVBQUssV0FBVSxrQkFBbUI7Ozs7WUFDL0I7Ozs7OztHQUVMLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQ1gsaUJBQWlCLEtBQUssTUFBTSxNQUMzQix3QkFBQyxNQUFEO0tBRUUsV0FBVztNQUNUO01BQ0EsSUFBSSxZQUFZLDhCQUE4QjtNQUM5QyxNQUFNLFlBQVksZ0NBQWdDO0tBQ3BELENBQUMsQ0FDRSxPQUFPLE9BQU8sQ0FBQyxDQUNmLEtBQUssR0FBRztlQVJiLENBVUcsSUFBSSxZQUFZLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7Z0JBQUksd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztlQUNyRSxLQUFLLEtBQ0o7T0FYRyxLQUFLOzs7O1dBV1IsQ0FDTDtHQUNDOzs7OztFQUNNOzs7Ozs7QUFFaEI7OztBQUVBLFNBQVMsV0FBVyxFQUFFLFFBQVEsTUFBTSxTQUFTLFdBQVc7O0NBQ3RELE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sUUFBUSxLQUFLLFVBQVUsUUFDMUIsT0FBTyxNQUFPLFFBQVEsRUFBRSxRQUFRLEVBQUUsa0JBQWtCLFFBQVEsSUFBSSxPQUNqRSxDQUNGO0NBQ0EsTUFBTSxRQUFRLEtBQUssVUFBVTtDQUM3QixNQUFNLE1BQU0sS0FBSyxNQUFPLFFBQVEsUUFBUyxHQUFHO0NBQzVDLE1BQU0sU0FBUyxPQUFPO0NBQ3RCLE1BQU0sVUFBVSxRQUFRO0NBQ3hCLE1BQU0sUUFBUSxVQUFVLENBQUMsV0FBVyxPQUFPOzs7OztDQU0zQyxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsUUFBUTtFQUNiLFNBQVM7R0FDUCxRQUFRLENBQUMsa0JBQWtCLENBQUM7R0FDNUIsUUFBUSxFQUFFLEdBQUcsR0FBSTtHQUNqQixlQUFlLFVBQVUsS0FBSyxRQUFRLEtBQUs7R0FDM0MsUUFBUTtHQUNSLGVBQWU7R0FDZixPQUFPO0dBQ1AsU0FBUztHQUNULFFBQVE7RUFDVixDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQVE7RUFBUztDQUFLLENBQUM7Q0FFM0IsT0FDRSx3QkFBQyxPQUFPLEtBQVI7RUFDRSxXQUFVO0VBQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7RUFDbkIsWUFBWSxFQUFFLFVBQVUsR0FBSTtZQUw5QjtHQU9HLFVBQVUsd0JBQUMsWUFBRCxDQUFhOzs7OztHQUV4Qix3QkFBQyxPQUFPLEtBQVI7SUFDRSxXQUFXLHFCQUFxQixTQUFTLDJCQUEyQjtJQUNwRSxTQUFTO0tBQUUsT0FBTztLQUFLLFNBQVM7SUFBRTtJQUNsQyxTQUFTO0tBQUUsT0FBTztLQUFHLFNBQVM7SUFBRTtJQUNoQyxZQUFZO0tBQUUsTUFBTTtLQUFVLFdBQVc7S0FBSyxTQUFTO0lBQUc7Y0FFekQsU0FBUyx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2VBQUksd0JBQUMsYUFBRCxFQUFhLE1BQU0sR0FBSzs7Ozs7R0FDcEQ7Ozs7O0dBRVosd0JBQUMsTUFBRCxZQUFLLFVBQVUsbUJBQW1CLFFBQVEsaUJBQWlCLFNBQVMsZ0JBQWdCLHNCQUEwQjs7Ozs7R0FDOUcsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FDVixTQUNHLGtCQUFrQixPQUFPLE1BQU0sZ0JBQy9CLDBDQUEwQyxPQUFPLE1BQU07R0FDMUQ7Ozs7O0dBRUgsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNkLHdCQUFDLGVBQUQsRUFBZSxPQUFPLE1BQVE7Ozs7O0tBQzFCOzs7OztLQUNOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUEwQyxNQUFHLEtBQVk7Ozs7OztLQUN6RCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBd0M7T0FDckMsd0JBQUMsZUFBRCxFQUFlLE9BQU8sSUFBTTs7Ozs7T0FBQztNQUMxQjs7Ozs7O0lBQ0g7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBTyxLQUFSO0tBQ0UsV0FBVyx3QkFBd0IsU0FBUyxLQUFLO0tBQ2pELFNBQVMsRUFBRSxPQUFPLEVBQUU7S0FDcEIsU0FBUyxFQUFFLE9BQU8sR0FBRyxJQUFJLEdBQUc7S0FDNUIsWUFBWTtNQUFFLFVBQVU7TUFBSyxNQUFNO0tBQVk7SUFDaEQ7Ozs7O0dBQ0U7Ozs7O0dBQ0wsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYjtLQUFvQjtLQUNGO0tBQVk7SUFDM0I7Ozs7OztHQUVILHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLFdBQVU7S0FBbUIsU0FBUztlQUE1RCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7ZUFBQyxhQUNqQjs7Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFTLGVBQWUsU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPO2VBQUc7SUFFeEU7Ozs7WUFDTDs7Ozs7O0VBQ0s7Ozs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFeGFtUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBBbmltYXRlUHJlc2VuY2UsIG1vdGlvbiB9IGZyb20gJ21vdGlvbi9yZWFjdCdcclxuaW1wb3J0IGNvbmZldHRpIGZyb20gJ2NhbnZhcy1jb25mZXR0aSdcclxuaW1wb3J0IHtcclxuICBUaW1lcixcclxuICBHaXRDb21taXRIb3Jpem9udGFsLFxyXG4gIENpcmNsZUNoZWNrLFxyXG4gIENpcmNsZURhc2hlZCxcclxuICBUcnVjayxcclxuICBQYXJ0eVBvcHBlcixcclxuICBSb3RhdGVDY3csXHJcbiAgWCxcclxuICBBcnJvd0xlZnQsXHJcbiAgQXJyb3dSaWdodCxcclxuICBTaGllbGRBbGVydCxcclxuICBFeWUsXHJcbiAgU3VuLFxyXG4gIE1vb24sXHJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBjb3Vyc2VzQXBpIH0gZnJvbSAnLi4vY291cnNlcy9jb3Vyc2VzQXBpJ1xyXG5pbXBvcnQgeyByZWNvcmRGaW5hbEV4YW1BdHRlbXB0IH0gZnJvbSAnLi4vY291cnNlcy9wcm9ncmVzc1N0b3JlJ1xyXG5pbXBvcnQgeyBQQVNTSU5HX1BDVCwgaXNDb3Vyc2VDb21wbGV0ZSB9IGZyb20gJy4uL2NvdXJzZXMvcHJvZ3Jlc3MnXHJcbmltcG9ydCB7IHBsYXlFeGFtU3RhcnRDdWUsIHBsYXlFeGFtQWxlcnRDdWUsIHBsYXlFeGFtR3JhZGluZ1RpY2ssIHBsYXlFeGFtUmVzdWx0Q3VlIH0gZnJvbSAnLi9leGFtU291bmQnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlVGhlbWUnXHJcblxyXG4vLyBSZWFkcyB0aGUgZXhhbSdzIG93biBhbWJlciBhY2NlbnQgKC0tZXhhbS1hY2NlbnQsIHNldCBvbiAuZXhhbS1zaGVsbCBpblxyXG4vLyBpbmRleC5jc3Mg4oCUIGRlbGliZXJhdGVseSBkaXN0aW5jdCBmcm9tIHRoZSBhcHAncyBkZWZhdWx0IC0tYWNjZW50KSBzb1xyXG4vLyB0aGUgY2FsbSBtYXNjb3QgYmVsb3cgbWF0Y2hlcyB0aGUgZXhhbSdzIG93biBjb2xvciwgbm90IHRoZSBjb3Vyc2VcclxuLy8gdGhlbWUuXHJcbmZ1bmN0aW9uIGN1cnJlbnRFeGFtQWNjZW50KCkge1xyXG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuICcjZjU5ZTBiJ1xyXG4gIC8vIC0tZXhhbS1hY2NlbnQgaXMgc2NvcGVkIHRvIC5leGFtLXNoZWxsIChub3QgOnJvb3QpLCBzbyByZWFkIGl0IG9mZlxyXG4gIC8vIHRoYXQgZWxlbWVudCBzcGVjaWZpY2FsbHkgcmF0aGVyIHRoYW4gPGh0bWw+LlxyXG4gIGNvbnN0IHNoZWxsRWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZXhhbS1zaGVsbCcpIHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxyXG4gIHJldHVybiBnZXRDb21wdXRlZFN0eWxlKHNoZWxsRWwpLmdldFByb3BlcnR5VmFsdWUoJy0tZXhhbS1hY2NlbnQnKS50cmltKCkgfHwgJyNmNTllMGInXHJcbn1cclxuXHJcbi8vIEEgc21hbGwsIGZyaWVuZGx5IGNyZWF0dXJlIHRoYXQganVzdC4uLiBmbG9hdHMuIFNsb3dseS4gTm8gYnVyc3RzLCBub1xyXG4vLyBib3VuY2UsIG5vIHN1ZGRlbiBtb3ZlbWVudCDigJQgcmVwbGFjZXMgdGhlIG9sZCBjb25mZXR0aS1hbmQtc3ByaW5nXHJcbi8vIGNlbGVicmF0aW9uLCB3aGljaCBzb21lIGxlYXJuZXJzIGZvdW5kIG92ZXJzdGltdWxhdGluZy4gSXQgZHJpZnRzIHVwXHJcbi8vIGFuZCBkb3duIGFuZCB0aWx0cyBnZW50bHksIGxpa2UgaXQncyBicmVhdGhpbmcsIHNvIHBhc3NpbmcgZmVlbHMgY2FsbVxyXG4vLyByYXRoZXIgdGhhbiBhbiBhc3NhdWx0IG9mIG1vdGlvbi5cclxuZnVuY3Rpb24gQ2FsbU1hc2NvdCgpIHtcclxuICBjb25zdCBjb2xvciA9IHVzZU1lbW8oKCkgPT4gY3VycmVudEV4YW1BY2NlbnQoKSwgW10pXHJcbiAgcmV0dXJuIChcclxuICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cImV4YW0tbWFzY290XCJcclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA2IH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogWzAsIC0xMCwgMF0sIHJvdGF0ZTogWzAsIC0zLCAwLCAzLCAwXSB9fVxyXG4gICAgICB0cmFuc2l0aW9uPXt7XHJcbiAgICAgICAgb3BhY2l0eTogeyBkdXJhdGlvbjogMC44IH0sXHJcbiAgICAgICAgeTogeyBkdXJhdGlvbjogNCwgcmVwZWF0OiBJbmZpbml0eSwgZWFzZTogJ2Vhc2VJbk91dCcgfSxcclxuICAgICAgICByb3RhdGU6IHsgZHVyYXRpb246IDYsIHJlcGVhdDogSW5maW5pdHksIGVhc2U6ICdlYXNlSW5PdXQnIH0sXHJcbiAgICAgIH19XHJcbiAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICA+XHJcbiAgICAgIDxzdmcgd2lkdGg9XCI3MlwiIGhlaWdodD1cIjcyXCIgdmlld0JveD1cIjAgMCA3MiA3MlwiIGZpbGw9XCJub25lXCI+XHJcbiAgICAgICAgPGVsbGlwc2UgY3g9XCIzNlwiIGN5PVwiNjJcIiByeD1cIjIwXCIgcnk9XCI0XCIgZmlsbD17Y29sb3J9IG9wYWNpdHk9XCIwLjE1XCIgLz5cclxuICAgICAgICA8Y2lyY2xlIGN4PVwiMzZcIiBjeT1cIjM0XCIgcj1cIjI2XCIgZmlsbD17Y29sb3J9IG9wYWNpdHk9XCIwLjE4XCIgLz5cclxuICAgICAgICA8Y2lyY2xlIGN4PVwiMzZcIiBjeT1cIjM0XCIgcj1cIjE5XCIgZmlsbD17Y29sb3J9IC8+XHJcbiAgICAgICAgPGNpcmNsZSBjeD1cIjI5XCIgY3k9XCIzMVwiIHI9XCIyLjZcIiBmaWxsPVwiIzFhMTIwMFwiIC8+XHJcbiAgICAgICAgPGNpcmNsZSBjeD1cIjQzXCIgY3k9XCIzMVwiIHI9XCIyLjZcIiBmaWxsPVwiIzFhMTIwMFwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0yOCA0MWMyLjUgMyAxMy41IDMgMTYgMFwiIHN0cm9rZT1cIiMxYTEyMDBcIiBzdHJva2VXaWR0aD1cIjIuNFwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIGZpbGw9XCJub25lXCIgLz5cclxuICAgICAgPC9zdmc+XHJcbiAgICA8L21vdGlvbi5kaXY+XHJcbiAgKVxyXG59XHJcblxyXG4vLyBTbWFsbCBjb3VudC11cCB1c2VkIGZvciB0aGUgZmluYWwgc2NvcmUvcGVyY2VudGFnZSDigJQgdGlja3MgdXAgZnJvbSAwIHRvXHJcbi8vIHRoZSB0YXJnZXQgdmFsdWUgb3ZlciBgZHVyYXRpb25gIHNlY29uZHMgaW5zdGVhZCBvZiBqdXN0IGFwcGVhcmluZy5cclxuZnVuY3Rpb24gQ291bnRVcE51bWJlcih7IHZhbHVlLCBkdXJhdGlvbiA9IDEuNiB9KSB7XHJcbiAgY29uc3QgW2Rpc3BsYXksIHNldERpc3BsYXldID0gdXNlU3RhdGUoMClcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IHJhZlxyXG4gICAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKVxyXG4gICAgZnVuY3Rpb24gdGljayhub3cpIHtcclxuICAgICAgY29uc3QgdCA9IE1hdGgubWluKDEsIChub3cgLSBzdGFydCkgLyAoZHVyYXRpb24gKiAxMDAwKSlcclxuICAgICAgY29uc3QgZWFzZWQgPSAxIC0gTWF0aC5wb3coMSAtIHQsIDMpXHJcbiAgICAgIHNldERpc3BsYXkoTWF0aC5yb3VuZChlYXNlZCAqIHZhbHVlKSlcclxuICAgICAgaWYgKHQgPCAxKSByYWYgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljaylcclxuICAgIH1cclxuICAgIHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKVxyXG4gICAgcmV0dXJuICgpID0+IGNhbmNlbEFuaW1hdGlvbkZyYW1lKHJhZilcclxuICB9LCBbdmFsdWUsIGR1cmF0aW9uXSlcclxuICByZXR1cm4gZGlzcGxheVxyXG59XHJcblxyXG4vLyBNb2NrIFwiZ3JhZGluZyBwaXBlbGluZVwiIHN0ZXBzIHNob3duIGR1cmluZyB0aGUgcHJvY2Vzc2luZyBzdGFnZSDigJQgcHVyZVxyXG4vLyB0aGVhdHJlLCBubyBiYWNrZW5kIGNhbGwuIEVhY2ggaGFzIGl0cyBvd24gZHVyYXRpb24gc28gdGhlIHNlcXVlbmNlIGZlZWxzXHJcbi8vIGFsaXZlIGluc3RlYWQgb2Ygb25lIGZsYXQgcHJvZ3Jlc3MgYmFyLiBTdW1zIHRvIGV4YWN0bHkgMzBzLlxyXG5jb25zdCBQUk9DRVNTSU5HX1NURVBTID0gW1xyXG4gIHsgbGFiZWw6ICdTdWJtaXR0aW5nIHlvdXIgYW5zd2Vyc+KApicsIG1zOiA0MDAwIH0sXHJcbiAgeyBsYWJlbDogJ1ZlcmlmeWluZyBhZ2FpbnN0IHRoZSBhbnN3ZXIga2V54oCmJywgbXM6IDU1MDAgfSxcclxuICB7IGxhYmVsOiAnQ2FsY3VsYXRpbmcgeW91ciBzY29yZeKApicsIG1zOiA1NTAwIH0sXHJcbiAgeyBsYWJlbDogJ0NoZWNraW5nIHRoZSBwYXNzaW5nIHRocmVzaG9sZOKApicsIG1zOiA1NTAwIH0sXHJcbiAgeyBsYWJlbDogJ0ZpbmFsaXppbmcgeW91ciByZXN1bHTigKYnLCBtczogNTUwMCB9LFxyXG4gIHsgbGFiZWw6ICdQcmVwYXJpbmcgeW91ciBjZXJ0aWZpY2F0ZSBzdGF0dXPigKYnLCBtczogNDAwMCB9LFxyXG5dXHJcblxyXG4vLyBGdWxsLXNjcmVlbiBmaW5hbCBleGFtIHJ1bm5lci4gUmVuZGVyZWQgYXMgaXRzIG93biByb3V0ZSAoc2VlIEFwcC5qc3gpLFxyXG4vLyBkZWxpYmVyYXRlbHkgb3V0c2lkZSBBcHBMYXlvdXQg4oCUIG5vIHRvcGJhci9zaWRlYmFyIGNocm9tZSB3aGlsZSBhbiBleGFtXHJcbi8vIGlzIGFjdGl2ZSwgY2xvc2VyIHRvIGEgcmVhbCBwcm9jdG9yZWQtZXhhbSBmZWVsLlxyXG4vLyBSZXF1ZXN0cyB0cnVlIGJyb3dzZXIgZnVsbHNjcmVlbiDigJQgYSBwcm9ncmVzc2l2ZSBlbmhhbmNlbWVudCBvdmVyIHRoZVxyXG4vLyBleGlzdGluZyBmaXhlZC1vdmVybGF5IGAuZXhhbS1zaGVsbGAsIHdoaWNoIGFscmVhZHkgcHJvdmlkZXMgYSBzb2Z0XHJcbi8vIGluLXBhZ2UgZnVsbHNjcmVlbiBmYWxsYmFjayBpZiB0aGUgYnJvd3NlciBibG9ja3MvcmVqZWN0cyB0aGUgQVBJIChlLmcuXHJcbi8vIG5vIHVzZXItZ2VzdHVyZSBjb250ZXh0LCBvciBhbiBpZnJhbWUgd2l0aG91dCB0aGUgYGFsbG93YCBhdHRyaWJ1dGUpLlxyXG5hc3luYyBmdW5jdGlvbiB0cnlFbnRlckZ1bGxzY3JlZW4oZWxlbWVudCkge1xyXG4gIHRyeSB7XHJcbiAgICBpZiAoZWxlbWVudCAmJiAhZG9jdW1lbnQuZnVsbHNjcmVlbkVsZW1lbnQpIHtcclxuICAgICAgYXdhaXQgZWxlbWVudC5yZXF1ZXN0RnVsbHNjcmVlbj8uKClcclxuICAgIH1cclxuICB9IGNhdGNoIHtcclxuICAgIC8vIElnbm9yZWQg4oCUIHRoZSBpbi1wYWdlIGV4YW0tc2hlbGwgb3ZlcmxheSBhbHJlYWR5IGxvb2tzIGZ1bGwtc2NyZWVuLlxyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gdHJ5RXhpdEZ1bGxzY3JlZW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmIChkb2N1bWVudC5mdWxsc2NyZWVuRWxlbWVudCkge1xyXG4gICAgICBhd2FpdCBkb2N1bWVudC5leGl0RnVsbHNjcmVlbj8uKClcclxuICAgIH1cclxuICB9IGNhdGNoIHtcclxuICAgIC8vIE5vdGhpbmcgdG8gZG8g4oCUIGFscmVhZHkgb3V0IG9mIGZ1bGxzY3JlZW4sIG9yIHRoZSBicm93c2VyIHJlZnVzZWQuXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRXhhbVBhZ2UoKSB7XHJcbiAgY29uc3QgeyBzbHVnIH0gPSB1c2VQYXJhbXMoKVxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IHNoZWxsUmVmID0gdXNlUmVmKG51bGwpXHJcbiAgY29uc3QgW2NvdXJzZSwgc2V0Q291cnNlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW2FsbE1vZHVsZXNEb25lLCBzZXRBbGxNb2R1bGVzRG9uZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbc3RhZ2UsIHNldFN0YWdlXSA9IHVzZVN0YXRlKCdpbnRybycpIC8vIGludHJvIHwgYWN0aXZlIHwgcmV2aWV3IHwgcHJvY2Vzc2luZyB8IHJlc3VsdFxyXG4gIGNvbnN0IFthbnN3ZXJzLCBzZXRBbnN3ZXJzXSA9IHVzZVN0YXRlKHt9KVxyXG4gIGNvbnN0IFthY3RpdmVJbmRleCwgc2V0QWN0aXZlSW5kZXhdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCBbc2Vjb25kc0xlZnQsIHNldFNlY29uZHNMZWZ0XSA9IHVzZVN0YXRlKDApXHJcbiAgY29uc3QgW3RhYlN3aXRjaENvdW50LCBzZXRUYWJTd2l0Y2hDb3VudF0gPSB1c2VTdGF0ZSgwKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY291cnNlc0FwaS5nZXRDb3Vyc2Uoc2x1ZykudGhlbihhc3luYyAoZGF0YSkgPT4ge1xyXG4gICAgICBzZXRDb3Vyc2UoZGF0YSlcclxuICAgICAgc2V0U2Vjb25kc0xlZnQoKGRhdGEuZmluYWxFeGFtPy5kdXJhdGlvbk1pbnV0ZXMgPz8gNSkgKiA2MClcclxuICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBhd2FpdCBjb3Vyc2VzQXBpLmdldFByb2dyZXNzKGRhdGEuaWQpXHJcbiAgICAgIHNldEFsbE1vZHVsZXNEb25lKGlzQ291cnNlQ29tcGxldGUoZGF0YSwgcHJvZ3Jlc3MuY29tcGxldGVkUGFnZUlkcywgcHJvZ3Jlc3MubW9kdWxlUXVpenplcykpXHJcbiAgICB9KVxyXG4gIH0sIFtzbHVnXSlcclxuXHJcbiAgLy8gTGVhdmUgZnVsbHNjcmVlbiBhdXRvbWF0aWNhbGx5IG9uY2Ugd2UncmUgb2ZmIHRoZSBcImFjdGl2ZVwiIHN0YWdlXHJcbiAgLy8gKGZpbmlzaGVkLCBleGl0ZWQsIG9yIHRoZSB3aG9sZSBwYWdlIHVubW91bnRzKSDigJQgbmV2ZXIgbGVhdmUgdGhlXHJcbiAgLy8gbGVhcm5lciBzdHVjayBpbiBmdWxsc2NyZWVuIGFmdGVyIHRoZSBleGFtIGVuZHMuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzdGFnZSAhPT0gJ2FjdGl2ZScpIHRyeUV4aXRGdWxsc2NyZWVuKClcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGlmIChzdGFnZSA9PT0gJ2FjdGl2ZScpIHRyeUV4aXRGdWxsc2NyZWVuKClcclxuICAgIH1cclxuICB9LCBbc3RhZ2VdKVxyXG5cclxuICAvLyBUYWItc3dpdGNoIC8gbWluaW1pemUgZGV0ZWN0aW9uIGR1cmluZyB0aGUgdGltZWQgc3RhZ2UuIFRoaXMgY2FuJ3RcclxuICAvLyBlbmZvcmNlIGFueXRoaW5nIChubyBiYWNrZW5kIHRvIHJlcG9ydCB0bykg4oCUIGl0IGp1c3Qgd2FybnMgdGhlXHJcbiAgLy8gbGVhcm5lciB0aGF0IGxlYXZpbmcgd2FzIG5vdGljZWQuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzdGFnZSAhPT0gJ2FjdGl2ZScpIHJldHVybiB1bmRlZmluZWRcclxuICAgIGZ1bmN0aW9uIGhhbmRsZVZpc2liaWxpdHkoKSB7XHJcbiAgICAgIGlmIChkb2N1bWVudC5oaWRkZW4pIHtcclxuICAgICAgICBwbGF5RXhhbUFsZXJ0Q3VlKClcclxuICAgICAgICBzZXRUYWJTd2l0Y2hDb3VudCgobikgPT4gbiArIDEpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBoYW5kbGVWaXNpYmlsaXR5KVxyXG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBoYW5kbGVWaXNpYmlsaXR5KVxyXG4gIH0sIFtzdGFnZV0pXHJcblxyXG4gIGlmICghY291cnNlKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJleGFtLXNoZWxsIGV4YW0tbG9hZGluZ1wiIGFyaWEtYnVzeT1cInRydWVcIiAvPlxyXG4gIGlmICghY291cnNlLmZpbmFsRXhhbSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXNoZWxsIGV4YW0tbG9hZGluZ1wiPlxyXG4gICAgICAgIDxwPlRoaXMgY291cnNlIGRvZXNuJ3QgaGF2ZSBhIGZpbmFsIGV4YW0geWV0LjwvcD5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2NvdXJzZXMvJHtzbHVnfS9sZWFybmApfT5cclxuICAgICAgICAgIEJhY2sgdG8gY291cnNlXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKVxyXG4gIH1cclxuICBpZiAoIWFsbE1vZHVsZXNEb25lKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4YW0tc2hlbGwgZXhhbS1sb2FkaW5nXCI+XHJcbiAgICAgICAgPHA+RmluaXNoIGV2ZXJ5IG1vZHVsZSAoYW5kIHBhc3MgaXRzIFFDTSkgYmVmb3JlIHRoZSBmaW5hbCBleGFtIHVubG9ja3MuPC9wPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvY291cnNlcy8ke3NsdWd9L2xlYXJuYCl9PlxyXG4gICAgICAgICAgQmFjayB0byBjb3Vyc2VcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjb25zdCBleGFtID0gY291cnNlLmZpbmFsRXhhbVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXNoZWxsIGV4YW0tc2hlbGwtc2VyaW91c1wiIHJlZj17c2hlbGxSZWZ9PlxyXG4gICAgICA8RXhhbVRoZW1lVG9nZ2xlIC8+XHJcbiAgICAgIDxBbmltYXRlUHJlc2VuY2UgbW9kZT1cIndhaXRcIj5cclxuICAgICAgICB7c3RhZ2UgPT09ICdpbnRybycgJiYgKFxyXG4gICAgICAgICAgPEV4YW1JbnRyb1xyXG4gICAgICAgICAgICBrZXk9XCJpbnRyb1wiXHJcbiAgICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgICBleGFtPXtleGFtfVxyXG4gICAgICAgICAgICBvblN0YXJ0PXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0VGFiU3dpdGNoQ291bnQoMClcclxuICAgICAgICAgICAgICB0cnlFbnRlckZ1bGxzY3JlZW4oc2hlbGxSZWYuY3VycmVudClcclxuICAgICAgICAgICAgICBwbGF5RXhhbVN0YXJ0Q3VlKClcclxuICAgICAgICAgICAgICBzZXRTdGFnZSgnYWN0aXZlJylcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7c3RhZ2UgPT09ICdhY3RpdmUnICYmIChcclxuICAgICAgICAgIDxFeGFtQWN0aXZlXHJcbiAgICAgICAgICAgIGtleT1cImFjdGl2ZVwiXHJcbiAgICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgICBleGFtPXtleGFtfVxyXG4gICAgICAgICAgICBhbnN3ZXJzPXthbnN3ZXJzfVxyXG4gICAgICAgICAgICBzZXRBbnN3ZXJzPXtzZXRBbnN3ZXJzfVxyXG4gICAgICAgICAgICBhY3RpdmVJbmRleD17YWN0aXZlSW5kZXh9XHJcbiAgICAgICAgICAgIHNldEFjdGl2ZUluZGV4PXtzZXRBY3RpdmVJbmRleH1cclxuICAgICAgICAgICAgc2Vjb25kc0xlZnQ9e3NlY29uZHNMZWZ0fVxyXG4gICAgICAgICAgICBzZXRTZWNvbmRzTGVmdD17c2V0U2Vjb25kc0xlZnR9XHJcbiAgICAgICAgICAgIHRhYlN3aXRjaENvdW50PXt0YWJTd2l0Y2hDb3VudH1cclxuICAgICAgICAgICAgb25GaW5pc2g9eygpID0+IHNldFN0YWdlKCdyZXZpZXcnKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7c3RhZ2UgPT09ICdyZXZpZXcnICYmIChcclxuICAgICAgICAgIDxFeGFtUmV2aWV3XHJcbiAgICAgICAgICAgIGtleT1cInJldmlld1wiXHJcbiAgICAgICAgICAgIGNvdXJzZT17Y291cnNlfVxyXG4gICAgICAgICAgICBleGFtPXtleGFtfVxyXG4gICAgICAgICAgICBhbnN3ZXJzPXthbnN3ZXJzfVxyXG4gICAgICAgICAgICBvbkJhY2tUb0V4YW09eygpID0+IHNldFN0YWdlKCdhY3RpdmUnKX1cclxuICAgICAgICAgICAgb25Db21taXQ9eygpID0+IHNldFN0YWdlKCdwcm9jZXNzaW5nJyl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge3N0YWdlID09PSAncHJvY2Vzc2luZycgJiYgKFxyXG4gICAgICAgICAgPEV4YW1Qcm9jZXNzaW5nXHJcbiAgICAgICAgICAgIGtleT1cInByb2Nlc3NpbmdcIlxyXG4gICAgICAgICAgICBvbkRvbmU9eygpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCBzY29yZSA9IGV4YW0ucXVlc3Rpb25zLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICh0b3RhbCwgcSkgPT4gKGFuc3dlcnNbcS5pZF0gPT09IHEuY29ycmVjdE9wdGlvbklkID8gdG90YWwgKyAxIDogdG90YWwpLFxyXG4gICAgICAgICAgICAgICAgMCxcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgY29uc3QgcGN0ID0gTWF0aC5yb3VuZCgoc2NvcmUgLyBleGFtLnF1ZXN0aW9ucy5sZW5ndGgpICogMTAwKVxyXG4gICAgICAgICAgICAgIHJlY29yZEZpbmFsRXhhbUF0dGVtcHQoY291cnNlLmlkLCB7IHNjb3JlLCB0b3RhbDogZXhhbS5xdWVzdGlvbnMubGVuZ3RoIH0pLmNhdGNoKCgpID0+IHt9KVxyXG4gICAgICAgICAgICAgIHBsYXlFeGFtUmVzdWx0Q3VlKHBjdCwgUEFTU0lOR19QQ1QpXHJcbiAgICAgICAgICAgICAgc2V0U3RhZ2UoJ3Jlc3VsdCcpXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAge3N0YWdlID09PSAncmVzdWx0JyAmJiAoXHJcbiAgICAgICAgICA8RXhhbVJlc3VsdFxyXG4gICAgICAgICAgICBrZXk9XCJyZXN1bHRcIlxyXG4gICAgICAgICAgICBjb3Vyc2U9e2NvdXJzZX1cclxuICAgICAgICAgICAgZXhhbT17ZXhhbX1cclxuICAgICAgICAgICAgYW5zd2Vycz17YW5zd2Vyc31cclxuICAgICAgICAgICAgb25SZXRyeT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFuc3dlcnMoe30pXHJcbiAgICAgICAgICAgICAgc2V0QWN0aXZlSW5kZXgoMClcclxuICAgICAgICAgICAgICBzZXRTZWNvbmRzTGVmdChleGFtLmR1cmF0aW9uTWludXRlcyAqIDYwKVxyXG4gICAgICAgICAgICAgIHNldFN0YWdlKCdpbnRybycpXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG4vLyBQZXJzaXN0ZW50IGRhcmsvbGlnaHQgdG9nZ2xlLCByZW5kZXJlZCBvbmNlIGF0IHRoZSB0b3Agb2YgLmV4YW0tc2hlbGwgc29cclxuLy8gaXQncyByZWFjaGFibGUgZnJvbSBldmVyeSBzdGFnZSAoaW50cm8sIGFjdGl2ZSwgcmV2aWV3LCBwcm9jZXNzaW5nLFxyXG4vLyByZXN1bHQpIGluc3RlYWQgb2Ygb25seSB0aGUgZmluYWwgcmVzdWx0IHNjcmVlbi5cclxuZnVuY3Rpb24gRXhhbVRoZW1lVG9nZ2xlKCkge1xyXG4gIGNvbnN0IHsgdGhlbWUsIHRvZ2dsZVRoZW1lIH0gPSB1c2VUaGVtZSgpXHJcbiAgY29uc3QgaXNEYXJrID1cclxuICAgIHRoZW1lID09PSAnZGFyaycgfHxcclxuICAgICh0aGVtZSA9PT0gJ3N5c3RlbScgJiZcclxuICAgICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgd2luZG93Lm1hdGNoTWVkaWE/LignKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKScpLm1hdGNoZXMpXHJcbiAgcmV0dXJuIChcclxuICAgIDxidXR0b25cclxuICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgIGNsYXNzTmFtZT1cInJlYWRlci10aGVtZS10b2dnbGUgZXhhbS10aGVtZS10b2dnbGVcIlxyXG4gICAgICBhcmlhLWxhYmVsPXtpc0RhcmsgPyAnU3dpdGNoIHRvIGxpZ2h0IG1vZGUnIDogJ1N3aXRjaCB0byBkYXJrIG1vZGUnfVxyXG4gICAgICBvbkNsaWNrPXt0b2dnbGVUaGVtZX1cclxuICAgID5cclxuICAgICAge2lzRGFyayA/IDxTdW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTd9IC8+IDogPE1vb24gYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTd9IC8+fVxyXG4gICAgPC9idXR0b24+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBFeGFtSW50cm8oeyBjb3Vyc2UsIGV4YW0sIG9uU3RhcnQgfSkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIHJldHVybiAoXHJcbiAgICA8bW90aW9uLmRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJleGFtLXBhbmVsIGV4YW0taW50cm9cIlxyXG4gICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cclxuICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XHJcbiAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCB9fVxyXG4gICAgPlxyXG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJleGFtLWNsb3NlXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9jb3Vyc2VzLyR7Y291cnNlLnNsdWd9L2xlYXJuYCl9PlxyXG4gICAgICAgIDxYIHNpemU9ezIwfSAvPlxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAgPFNoaWVsZEFsZXJ0IHNpemU9ezQwfSBjbGFzc05hbWU9XCJleGFtLWludHJvLWljb25cIiAvPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJleGFtLWludHJvLWV5ZWJyb3dcIj5GaW5hbCBleGFtIMK3IGNlcnRpZmljYXRpb24gYXR0ZW1wdDwvc3Bhbj5cclxuICAgICAgPGgxPntjb3Vyc2UudGl0bGV9PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwiZXhhbS1pbnRyby10YWdsaW5lXCI+XHJcbiAgICAgICAgVGhpcyBpcyB0aGUgcHJvY3RvcmVkIGFzc2Vzc21lbnQgZm9yIHRoaXMgY291cnNlIOKAlCBzZXBhcmF0ZSBmcm9tIHRoZSBtb2R1bGUgUUNNcy4gT25lXHJcbiAgICAgICAgdGltZWQsIHNpbmdsZSBhdHRlbXB0OiByZWFkIGNhcmVmdWxseSwgYW5zd2VyIGRlbGliZXJhdGVseS5cclxuICAgICAgPC9wPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLWludHJvLXN0YXRzXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxUaW1lciBzaXplPXsxNn0gLz4ge2V4YW0uZHVyYXRpb25NaW51dGVzfSBtaW5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPEdpdENvbW1pdEhvcml6b250YWwgc2l6ZT17MTZ9IC8+IHtleGFtLnF1ZXN0aW9ucy5sZW5ndGh9IHF1ZXN0aW9uc1xyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8Q2lyY2xlQ2hlY2sgc2l6ZT17MTZ9IC8+IHBhc3MgYXQge1BBU1NJTkdfUENUfSUrXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cImV4YW0taW50cm8tcnVsZXNcIj5cclxuICAgICAgICA8bGk+VGhlIHRpbWVyIHN0YXJ0cyB0aGUgbW9tZW50IHlvdSBiZWdpbiDigJQgaXQgY2Fubm90IGJlIHBhdXNlZC48L2xpPlxyXG4gICAgICAgIDxsaT5Zb3UgY2FuIG1vdmUgYmV0d2VlbiBxdWVzdGlvbnMgZnJlZWx5IGJlZm9yZSBzdWJtaXR0aW5nLjwvbGk+XHJcbiAgICAgICAgPGxpPk9uY2Ugc3VibWl0dGVkLCB5b3VyIGFuc3dlcnMgYXJlIGZpbmFsIGFuZCBpbW1lZGlhdGVseSBncmFkZWQuPC9saT5cclxuICAgICAgICA8bGk+U3dpdGNoaW5nIHRhYnMgb3IgbGVhdmluZyB0aGUgd2luZG93IGR1cmluZyB0aGUgZXhhbSB3aWxsIGJlIGZsYWdnZWQuPC9saT5cclxuICAgICAgPC91bD5cclxuXHJcbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImV4YW0tc3RhcnQtYnV0dG9uXCIgb25DbGljaz17b25TdGFydH0+XHJcbiAgICAgICAgPFNoaWVsZEFsZXJ0IHNpemU9ezE2fSAvPiBCZWdpbiBmaW5hbCBleGFtXHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9tb3Rpb24uZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gRXhhbUFjdGl2ZSh7XHJcbiAgY291cnNlLFxyXG4gIGV4YW0sXHJcbiAgYW5zd2VycyxcclxuICBzZXRBbnN3ZXJzLFxyXG4gIGFjdGl2ZUluZGV4LFxyXG4gIHNldEFjdGl2ZUluZGV4LFxyXG4gIHNlY29uZHNMZWZ0LFxyXG4gIHNldFNlY29uZHNMZWZ0LFxyXG4gIHRhYlN3aXRjaENvdW50LFxyXG4gIG9uRmluaXNoLFxyXG59KSB7XHJcbiAgY29uc3QgaW50ZXJ2YWxSZWYgPSB1c2VSZWYobnVsbClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGludGVydmFsUmVmLmN1cnJlbnQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIHNldFNlY29uZHNMZWZ0KChwcmV2KSA9PiB7XHJcbiAgICAgICAgaWYgKHByZXYgPD0gMSkge1xyXG4gICAgICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbFJlZi5jdXJyZW50KVxyXG4gICAgICAgICAgb25GaW5pc2goKVxyXG4gICAgICAgICAgcmV0dXJuIDBcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHByZXYgLSAxXHJcbiAgICAgIH0pXHJcbiAgICB9LCAxMDAwKVxyXG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxSZWYuY3VycmVudClcclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgcXVlc3Rpb24gPSBleGFtLnF1ZXN0aW9uc1thY3RpdmVJbmRleF1cclxuICBjb25zdCBhbnN3ZXJlZENvdW50ID0gT2JqZWN0LmtleXMoYW5zd2VycykubGVuZ3RoXHJcbiAgY29uc3QgbWludXRlcyA9IFN0cmluZyhNYXRoLmZsb29yKHNlY29uZHNMZWZ0IC8gNjApKS5wYWRTdGFydCgyLCAnMCcpXHJcbiAgY29uc3Qgc2Vjb25kcyA9IFN0cmluZyhzZWNvbmRzTGVmdCAlIDYwKS5wYWRTdGFydCgyLCAnMCcpXHJcbiAgY29uc3QgbG93ID0gc2Vjb25kc0xlZnQgPD0gMzBcclxuICBjb25zdCB0b3RhbFNlY29uZHMgPSBleGFtLmR1cmF0aW9uTWludXRlcyAqIDYwXHJcbiAgY29uc3QgdGltZUxlZnRQY3QgPSB0b3RhbFNlY29uZHMgPiAwID8gKHNlY29uZHNMZWZ0IC8gdG90YWxTZWNvbmRzKSAqIDEwMCA6IDBcclxuXHJcbiAgZnVuY3Rpb24gc2VsZWN0KG9wdGlvbklkKSB7XHJcbiAgICBzZXRBbnN3ZXJzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbcXVlc3Rpb24uaWRdOiBvcHRpb25JZCB9KSlcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bW90aW9uLmRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJleGFtLXBhbmVsIGV4YW0tYWN0aXZlXCJcclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXRvcGJhclwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4YW0tdG9wYmFyLXRpdGxlXCI+e2NvdXJzZS50aXRsZX0g4oCUIEZpbmFsIEV4YW08L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZXhhbS10aW1lciAke2xvdyA/ICdleGFtLXRpbWVyLWxvdycgOiAnJ31gfT5cclxuICAgICAgICAgIDxUaW1lciBzaXplPXsxNn0gLz4ge21pbnV0ZXN9OntzZWNvbmRzfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhhbS10aW1lci10cmFja1wiPlxyXG4gICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BleGFtLXRpbWVyLWZpbGwgJHtsb3cgPyAnZXhhbS10aW1lci1maWxsLWxvdycgOiAnJ31gfVxyXG4gICAgICAgICAgYW5pbWF0ZT17eyB3aWR0aDogYCR7dGltZUxlZnRQY3R9JWAgfX1cclxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDEsIGVhc2U6ICdsaW5lYXInIH19XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7dGFiU3dpdGNoQ291bnQgPiAwICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4YW0tdGFiLXdhcm5pbmdcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIDxFeWUgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICBUYWItc3dpdGNoIGRldGVjdGVkICh7dGFiU3dpdGNoQ291bnR9KS4gU3RheSBvbiB0aGlzIHdpbmRvdyB1bnRpbCB5b3Ugc3VibWl0LlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXByb2dyZXNzLWRvdHNcIj5cclxuICAgICAgICB7ZXhhbS5xdWVzdGlvbnMubWFwKChxLCBpKSA9PiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17cS5pZH1cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17W1xyXG4gICAgICAgICAgICAgICdleGFtLWRvdCcsXHJcbiAgICAgICAgICAgICAgaSA9PT0gYWN0aXZlSW5kZXggPyAnZXhhbS1kb3QtYWN0aXZlJyA6ICcnLFxyXG4gICAgICAgICAgICAgIGFuc3dlcnNbcS5pZF0gPyAnZXhhbS1kb3QtYW5zd2VyZWQnIDogJycsXHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgICAgICAgLmpvaW4oJyAnKX1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlSW5kZXgoaSl9XHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BRdWVzdGlvbiAke2kgKyAxfSR7YW5zd2Vyc1txLmlkXSA/ICcgKGFuc3dlcmVkKScgOiAnJ31gfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4YW0tcXVlc3Rpb24tY2FyZFwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImV4YW0tcXVlc3Rpb24taW5kZXhcIj5cclxuICAgICAgICAgIFF1ZXN0aW9uIHthY3RpdmVJbmRleCArIDF9IG9mIHtleGFtLnF1ZXN0aW9ucy5sZW5ndGh9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxoMj57cXVlc3Rpb24ucHJvbXB0fTwvaDI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLW9wdGlvbnNcIj5cclxuICAgICAgICAgIHtxdWVzdGlvbi5vcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgIGtleT17b3B0aW9uLmlkfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGV4YW0tb3B0aW9uICR7YW5zd2Vyc1txdWVzdGlvbi5pZF0gPT09IG9wdGlvbi5pZCA/ICdleGFtLW9wdGlvbi1zZWxlY3RlZCcgOiAnJ31gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgICAgbmFtZT17cXVlc3Rpb24uaWR9XHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXthbnN3ZXJzW3F1ZXN0aW9uLmlkXSA9PT0gb3B0aW9uLmlkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNlbGVjdChvcHRpb24uaWQpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e29wdGlvbi50ZXh0fTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhhbS1uYXZcIj5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGRpc2FibGVkPXthY3RpdmVJbmRleCA9PT0gMH1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUluZGV4KChpKSA9PiBNYXRoLm1heCgwLCBpIC0gMSkpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTZ9IC8+IFByZXZpb3VzXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhhbS1hbnN3ZXJlZC1jb3VudFwiPlxyXG4gICAgICAgICAge2Fuc3dlcmVkQ291bnR9L3tleGFtLnF1ZXN0aW9ucy5sZW5ndGh9IGFuc3dlcmVkXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIHthY3RpdmVJbmRleCA8IGV4YW0ucXVlc3Rpb25zLmxlbmd0aCAtIDEgPyAoXHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVJbmRleCgoaSkgPT4gaSArIDEpfT5cclxuICAgICAgICAgICAgTmV4dCA8QXJyb3dSaWdodCBzaXplPXsxNn0gLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJleGFtLXJldmlldy1idXR0b25cIiBvbkNsaWNrPXtvbkZpbmlzaH0+XHJcbiAgICAgICAgICAgIFJldmlldyAmYW1wOyBjb21taXRcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tb3Rpb24uZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gRXhhbVJldmlldyh7IGNvdXJzZSwgZXhhbSwgYW5zd2Vycywgb25CYWNrVG9FeGFtLCBvbkNvbW1pdCB9KSB7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoYENvbXBsZXRlIGZpbmFsIGV4YW0gZm9yICR7Y291cnNlLnRpdGxlfWApXHJcbiAgY29uc3QgdW5hbnN3ZXJlZCA9IGV4YW0ucXVlc3Rpb25zLmZpbHRlcigocSkgPT4gIWFuc3dlcnNbcS5pZF0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bW90aW9uLmRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJleGFtLXBhbmVsIGV4YW0tcmV2aWV3XCJcclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cclxuICAgID5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhhbS1pbnRyby1leWVicm93XCI+RmluYWwgcmV2aWV3IOKAlCBiZWZvcmUgeW91IHN1Ym1pdDwvc3Bhbj5cclxuICAgICAgPGgxPlJldmlldyB5b3VyIGFuc3dlcnM8L2gxPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXRlcm1pbmFsXCI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXhhbS10ZXJtaW5hbC1saW5lIGV4YW0tdGVybWluYWwtbXV0ZWRcIj5BbnN3ZXIgc3VtbWFyeTwvcD5cclxuICAgICAgICB7ZXhhbS5xdWVzdGlvbnMubWFwKChxLCBpKSA9PiAoXHJcbiAgICAgICAgICA8cCBrZXk9e3EuaWR9IGNsYXNzTmFtZT1cImV4YW0tdGVybWluYWwtbGluZVwiPlxyXG4gICAgICAgICAgICB7YW5zd2Vyc1txLmlkXSA/IChcclxuICAgICAgICAgICAgICA8Q2lyY2xlQ2hlY2sgc2l6ZT17MTR9IGNsYXNzTmFtZT1cImV4YW0tdGVybWluYWwtY2hlY2tcIiAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjbGVEYXNoZWQgc2l6ZT17MTR9IGNsYXNzTmFtZT1cImV4YW0tdGVybWluYWwtZGFzaFwiIC8+XHJcbiAgICAgICAgICAgICl9eycgJ31cclxuICAgICAgICAgICAgUXVlc3Rpb24ge2kgKyAxfXsnICd9XHJcbiAgICAgICAgICAgIHthbnN3ZXJzW3EuaWRdID8gJyhhbnN3ZXJlZCknIDogPGVtPih1bmFuc3dlcmVkIOKAlCB3aWxsIGNvdW50IGFzIHdyb25nKTwvZW0+fVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHt1bmFuc3dlcmVkLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImV4YW0tcmV2aWV3LXdhcm5pbmdcIj5cclxuICAgICAgICAgIHt1bmFuc3dlcmVkLmxlbmd0aH0gcXVlc3Rpb257dW5hbnN3ZXJlZC5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30gc3RpbGwgdW5hbnN3ZXJlZC4gWW91IGNhblxyXG4gICAgICAgICAgZ28gYmFjaywgb3Igc3VibWl0IGFueXdheS5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZXhhbS1jb21taXQtbGFiZWxcIiBodG1sRm9yPVwiY29tbWl0LW1lc3NhZ2VcIj5cclxuICAgICAgICBGaW5hbCBub3RlIChvcHRpb25hbClcclxuICAgICAgPC9sYWJlbD5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgaWQ9XCJjb21taXQtbWVzc2FnZVwiXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiZXhhbS1jb21taXQtaW5wdXRcIlxyXG4gICAgICAgIHZhbHVlPXttZXNzYWdlfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVzc2FnZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4YW0tcmV2aWV3LWFjdGlvbnNcIj5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJleGFtLWJhY2stYnV0dG9uXCIgb25DbGljaz17b25CYWNrVG9FeGFtfT5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTZ9IC8+IEJhY2sgdG8gZXhhbVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImV4YW0tY29tbWl0LWJ1dHRvblwiIG9uQ2xpY2s9e29uQ29tbWl0fT5cclxuICAgICAgICAgIDxHaXRDb21taXRIb3Jpem9udGFsIHNpemU9ezE2fSAvPiBTdWJtaXQgZmluYWwgYW5zd2Vyc1xyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbW90aW9uLmRpdj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEV4YW1Qcm9jZXNzaW5nKHsgb25Eb25lIH0pIHtcclxuICBjb25zdCBbc3RlcEluZGV4LCBzZXRTdGVwSW5kZXhdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCB0b3RhbE1zID0gdXNlTWVtbygoKSA9PiBQUk9DRVNTSU5HX1NURVBTLnJlZHVjZSgoc3VtLCBzKSA9PiBzdW0gKyBzLm1zLCAwKSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0aW1lb3V0cyA9IFtdXHJcbiAgICBsZXQgZWxhcHNlZCA9IDBcclxuICAgIFBST0NFU1NJTkdfU1RFUFMuZm9yRWFjaCgoc3RlcCwgaSkgPT4ge1xyXG4gICAgICBlbGFwc2VkICs9IHN0ZXAubXNcclxuICAgICAgdGltZW91dHMucHVzaChcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgIHBsYXlFeGFtR3JhZGluZ1RpY2soKVxyXG4gICAgICAgICAgaWYgKGkgPT09IFBST0NFU1NJTkdfU1RFUFMubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KG9uRG9uZSwgNDAwKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2V0U3RlcEluZGV4KGkgKyAxKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVsYXBzZWQpLFxyXG4gICAgICApXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuICgpID0+IHRpbWVvdXRzLmZvckVhY2goY2xlYXJUaW1lb3V0KVxyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFtdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG1vdGlvbi5kaXZcclxuICAgICAgY2xhc3NOYW1lPVwiZXhhbS1wYW5lbCBleGFtLXByb2Nlc3NpbmdcIlxyXG4gICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cclxuICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XHJcbiAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCB9fVxyXG4gICAgPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJleGFtLWludHJvLWV5ZWJyb3dcIj5IYW5nIHRpZ2h0PC9zcGFuPlxyXG4gICAgICA8aDE+R3JhZGluZyBpbiBwcm9ncmVzc+KApjwvaDE+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cImV4YW0tcHJvY2Vzc2luZy1jYXB0aW9uXCI+WW91ciBzdWJtaXNzaW9uIGlzIGJlaW5nIHNjb3JlZCBhdXRvbWF0aWNhbGx5LjwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhhbS1yb2FkXCI+XHJcbiAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImV4YW0tdHJ1Y2tcIlxyXG4gICAgICAgICAgYW5pbWF0ZT17eyBsZWZ0OiBgJHsoc3RlcEluZGV4IC8gKFBST0NFU1NJTkdfU1RFUFMubGVuZ3RoIC0gMSkpICogMTAwfSVgIH19XHJcbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiB0b3RhbE1zID09PSAwID8gMCA6IFBST0NFU1NJTkdfU1RFUFNbc3RlcEluZGV4XT8ubXMgLyAxMDAwLCBlYXNlOiAnbGluZWFyJyB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUcnVjayBzaXplPXsyOH0gLz5cclxuICAgICAgICA8L21vdGlvbi5kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJleGFtLXJvYWQtdHJhY2tcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDx1bCBjbGFzc05hbWU9XCJleGFtLXByb2Nlc3Npbmctc3RlcHNcIj5cclxuICAgICAgICB7UFJPQ0VTU0lOR19TVEVQUy5tYXAoKHN0ZXAsIGkpID0+IChcclxuICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICBrZXk9e3N0ZXAubGFiZWx9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17W1xyXG4gICAgICAgICAgICAgICdleGFtLXByb2Nlc3Npbmctc3RlcCcsXHJcbiAgICAgICAgICAgICAgaSA8IHN0ZXBJbmRleCA/ICdleGFtLXByb2Nlc3Npbmctc3RlcC1kb25lJyA6ICcnLFxyXG4gICAgICAgICAgICAgIGkgPT09IHN0ZXBJbmRleCA/ICdleGFtLXByb2Nlc3Npbmctc3RlcC1hY3RpdmUnIDogJycsXHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXHJcbiAgICAgICAgICAgICAgLmpvaW4oJyAnKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2kgPCBzdGVwSW5kZXggPyA8Q2lyY2xlQ2hlY2sgc2l6ZT17MTZ9IC8+IDogPENpcmNsZURhc2hlZCBzaXplPXsxNn0gLz59XHJcbiAgICAgICAgICAgIHtzdGVwLmxhYmVsfVxyXG4gICAgICAgICAgPC9saT5cclxuICAgICAgICApKX1cclxuICAgICAgPC91bD5cclxuICAgIDwvbW90aW9uLmRpdj5cclxuICApXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEV4YW1SZXN1bHQoeyBjb3Vyc2UsIGV4YW0sIGFuc3dlcnMsIG9uUmV0cnkgfSkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG5cclxuICBjb25zdCBzY29yZSA9IGV4YW0ucXVlc3Rpb25zLnJlZHVjZShcclxuICAgICh0b3RhbCwgcSkgPT4gKGFuc3dlcnNbcS5pZF0gPT09IHEuY29ycmVjdE9wdGlvbklkID8gdG90YWwgKyAxIDogdG90YWwpLFxyXG4gICAgMCxcclxuICApXHJcbiAgY29uc3QgdG90YWwgPSBleGFtLnF1ZXN0aW9ucy5sZW5ndGhcclxuICBjb25zdCBwY3QgPSBNYXRoLnJvdW5kKChzY29yZSAvIHRvdGFsKSAqIDEwMClcclxuICBjb25zdCBwYXNzZWQgPSBwY3QgPj0gUEFTU0lOR19QQ1RcclxuICBjb25zdCBwZXJmZWN0ID0gcGN0ID09PSAxMDBcclxuICBjb25zdCBncmVhdCA9IHBhc3NlZCAmJiAhcGVyZmVjdCAmJiBwY3QgPj0gOTBcclxuXHJcbiAgLy8gT25lIHNob3J0LCByZXN0cmFpbmVkIGNvbmZldHRpIGJ1cnN0IG9uIGEgcGFzcyDigJQgc2FtZSBpZGVhIGFzIHRoZVxyXG4gIC8vIG1vZHVsZS1xdWl6IGNvbmdyYXRzIChmZWF0dXJlcy9jb3Vyc2VzL1F1aXouanN4KSwgbm90IHRoZSBvbGRcclxuICAvLyBtdWx0aS1hbmdsZSBmaXJld29ya3M6IGEgc2luZ2xlIHF1aWNrIGJ1cnN0IGluIHRoZSBleGFtJ3Mgb3duIGFtYmVyLFxyXG4gIC8vIHNpemVkIGEgbGl0dGxlIGJpZ2dlciBmb3IgYSBwZXJmZWN0L2dyZWF0IHNjb3JlLlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIXBhc3NlZCkgcmV0dXJuXHJcbiAgICBjb25mZXR0aSh7XHJcbiAgICAgIGNvbG9yczogW2N1cnJlbnRFeGFtQWNjZW50KCldLFxyXG4gICAgICBvcmlnaW46IHsgeTogMC4zIH0sXHJcbiAgICAgIHBhcnRpY2xlQ291bnQ6IHBlcmZlY3QgPyA5MCA6IGdyZWF0ID8gNzAgOiA1NSxcclxuICAgICAgc3ByZWFkOiA3MCxcclxuICAgICAgc3RhcnRWZWxvY2l0eTogMzAsXHJcbiAgICAgIHRpY2tzOiAxNTAsXHJcbiAgICAgIGdyYXZpdHk6IDEsXHJcbiAgICAgIHNjYWxhcjogMC45LFxyXG4gICAgfSlcclxuICB9LCBbcGFzc2VkLCBwZXJmZWN0LCBncmVhdF0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8bW90aW9uLmRpdlxyXG4gICAgICBjbGFzc05hbWU9XCJleGFtLXBhbmVsIGV4YW0tcmVzdWx0XCJcclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICBleGl0PXt7IG9wYWNpdHk6IDAgfX1cclxuICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC41IH19XHJcbiAgICA+XHJcbiAgICAgIHtwYXNzZWQgJiYgPENhbG1NYXNjb3QgLz59XHJcblxyXG4gICAgICA8bW90aW9uLmRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGV4YW0tcmVzdWx0LWJhZGdlICR7cGFzc2VkID8gJ2V4YW0tcmVzdWx0LWJhZGdlLXBhc3MnIDogJ2V4YW0tcmVzdWx0LWJhZGdlLWZhaWwnfWB9XHJcbiAgICAgICAgaW5pdGlhbD17eyBzY2FsZTogMC42LCBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgYW5pbWF0ZT17eyBzY2FsZTogMSwgb3BhY2l0eTogMSB9fVxyXG4gICAgICAgIHRyYW5zaXRpb249e3sgdHlwZTogJ3NwcmluZycsIHN0aWZmbmVzczogMjQwLCBkYW1waW5nOiAyMCB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge3Bhc3NlZCA/IDxQYXJ0eVBvcHBlciBzaXplPXszMn0gLz4gOiA8U2hpZWxkQWxlcnQgc2l6ZT17MzJ9IC8+fVxyXG4gICAgICA8L21vdGlvbi5kaXY+XHJcblxyXG4gICAgICA8aDE+e3BlcmZlY3QgPyAnUGVyZmVjdCBzY29yZSEnIDogZ3JlYXQgPyAnR3JlYXQgc2NvcmUhJyA6IHBhc3NlZCA/ICdFeGFtIHBhc3NlZCcgOiAnTm90IGEgcGFzc2luZyBzY29yZSd9PC9oMT5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtY2FwdGlvblwiPlxyXG4gICAgICAgIHtwYXNzZWRcclxuICAgICAgICAgID8gYFlvdSBwYXNzZWQgdGhlICR7Y291cnNlLnRpdGxlfSBmaW5hbCBleGFtLmBcclxuICAgICAgICAgIDogYFlvdSBkaWRuJ3QgcmVhY2ggdGhlIHBhc3Npbmcgc2NvcmUgZm9yICR7Y291cnNlLnRpdGxlfSB0aGlzIHRpbWUuIFJldmlldyB0aGUgbWF0ZXJpYWwgYW5kIHRyeSBhZ2FpbiB3aGVuIHlvdSdyZSByZWFkeS5gfVxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImV4YW0tcmVzdWx0LXNjb3JlXCI+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtc2NvcmUtdmFsdWVcIj5cclxuICAgICAgICAgIDxDb3VudFVwTnVtYmVyIHZhbHVlPXtzY29yZX0gLz5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtc2NvcmUtdG90YWxcIj4vIHt0b3RhbH08L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtc2NvcmUtcGN0XCI+XHJcbiAgICAgICAgICAoPENvdW50VXBOdW1iZXIgdmFsdWU9e3BjdH0gLz4lKVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtcGN0LXRyYWNrXCI+XHJcbiAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT17YGV4YW0tcmVzdWx0LXBjdC1maWxsICR7cGFzc2VkID8gJycgOiAnZXhhbS1yZXN1bHQtcGN0LWZpbGwtZmFpbCd9YH1cclxuICAgICAgICAgIGluaXRpYWw9e3sgd2lkdGg6IDAgfX1cclxuICAgICAgICAgIGFuaW1hdGU9e3sgd2lkdGg6IGAke3BjdH0lYCB9fVxyXG4gICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMS42LCBlYXNlOiAnZWFzZUluT3V0JyB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJoaW50XCI+XHJcbiAgICAgICAgUGFzc2luZyBzY29yZToge1BBU1NJTkdfUENUfSUrXHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXhhbS1yZXN1bHQtYWN0aW9uc1wiPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImV4YW0tYmFjay1idXR0b25cIiBvbkNsaWNrPXtvblJldHJ5fT5cclxuICAgICAgICAgIDxSb3RhdGVDY3cgc2l6ZT17MTZ9IC8+IFJldHJ5IGV4YW1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL2NvdXJzZXMvJHtjb3Vyc2Uuc2x1Z30vbGVhcm5gKX0+XHJcbiAgICAgICAgICBCYWNrIHRvIGNvdXJzZVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvbW90aW9uLmRpdj5cclxuICApXHJcbn1cclxuIl19