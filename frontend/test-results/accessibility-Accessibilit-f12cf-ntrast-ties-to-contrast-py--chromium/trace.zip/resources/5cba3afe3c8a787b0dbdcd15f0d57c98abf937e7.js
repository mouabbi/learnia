import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { ApiError } from "/src/api/client.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/LoginPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
export function LoginPage() {
	_s();
	const { login } = useAuth();
	const navigate = useNavigate();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState(null);
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError(null);
		setIsSubmitting(true);
		try {
			const result = await login(email, password);
			if (result.mfaRequired) {
				// Password was correct; still needs a TOTP/recovery code (see
				// MfaChallengePage). The ticket travels in route state, not the URL,
				// so it never ends up in browser history or a shared link.
				navigate("/mfa-challenge", { state: { mfaTicket: result.mfaTicket } });
			} else {
				navigate("/");
			}
		} catch (err) {
			// ApiError.message comes straight from the backend's {"error":
			// {message}} shape (see api/client.js) — already the deliberately
			// generic "Invalid email or password" text, safe to show as-is.
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "page",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: "Log in" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "email",
						children: "Email"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "email",
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "password",
						children: "Password"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "password",
						type: "password",
						value: password,
						onChange: (e) => setPassword(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 9
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "error",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						disabled: isSubmitting,
						children: isSubmitting ? "Logging in..." : "Log in"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: ["No account? ", /* @__PURE__ */ _jsxDEV(Link, {
				to: "/register",
				children: "Register"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 21
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/forgot-password",
				children: "Forgot password?"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
}
_s(LoginPage, "THbevMHT3CIJQWKkhCx0gJkGeoA=", false, function() {
	return [useAuth, useNavigate];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LoginPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/LoginPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/LoginPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/LoginPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsT0FBTyxTQUFTLFlBQVk7O0NBQzFCLE1BQU0sRUFBRSxVQUFVLFFBQVE7Q0FDMUIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxlQUFlLGFBQWEsT0FBTztFQUNqQyxNQUFNLGVBQWU7RUFDckIsU0FBUyxJQUFJO0VBQ2IsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sU0FBUyxNQUFNLE1BQU0sT0FBTyxRQUFRO0dBQzFDLElBQUksT0FBTyxhQUFhOzs7O0lBSXRCLFNBQVMsa0JBQWtCLEVBQUUsT0FBTyxFQUFFLFdBQVcsT0FBTyxVQUFVLEVBQUUsQ0FBQztHQUN2RSxPQUFPO0lBQ0wsU0FBUyxHQUFHO0dBQ2Q7RUFDRixTQUFTLEtBQUs7Ozs7R0FJWixTQUFTLGVBQWUsV0FBVyxJQUFJLFVBQVUsc0JBQXNCO0VBQ3pFLFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE1BQUQsWUFBSSxTQUFVOzs7OztHQUNkLHdCQUFDLFFBQUQ7SUFBTSxVQUFVO2NBQWhCO0tBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUFRO0tBQVk7Ozs7ZUFDbkMsd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO01BQ3hDO0tBQ0Q7Ozs7YUFDRTs7Ozs7S0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQVc7S0FBZTs7OztlQUN6Qyx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxPQUFPO01BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7TUFDM0M7S0FDRDs7OzthQUNFOzs7OztLQUNKLFNBQ0Msd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBUSxXQUFVO2dCQUN2QjtLQUNBOzs7OztLQUVMLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVTtnQkFDN0IsZUFBZSxrQkFBa0I7S0FDNUI7Ozs7O0lBQ0o7Ozs7OztHQUNOLHdCQUFDLEtBQUQsYUFBRyxnQkFDVyx3QkFBQyxNQUFEO0lBQU0sSUFBRztjQUFZO0dBQWM7Ozs7V0FDOUM7Ozs7O0dBQ0gsd0JBQUMsS0FBRCxZQUNFLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO2NBQW1CO0dBQXNCOzs7O1lBQ2pEOzs7OztFQUNJOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMb2dpblBhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IEFwaUVycm9yIH0gZnJvbSAnLi4vYXBpL2NsaWVudCdcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XHJcbiAgY29uc3QgeyBsb2dpbiB9ID0gdXNlQXV0aCgpXHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbG9naW4oZW1haWwsIHBhc3N3b3JkKVxyXG4gICAgICBpZiAocmVzdWx0Lm1mYVJlcXVpcmVkKSB7XHJcbiAgICAgICAgLy8gUGFzc3dvcmQgd2FzIGNvcnJlY3Q7IHN0aWxsIG5lZWRzIGEgVE9UUC9yZWNvdmVyeSBjb2RlIChzZWVcclxuICAgICAgICAvLyBNZmFDaGFsbGVuZ2VQYWdlKS4gVGhlIHRpY2tldCB0cmF2ZWxzIGluIHJvdXRlIHN0YXRlLCBub3QgdGhlIFVSTCxcclxuICAgICAgICAvLyBzbyBpdCBuZXZlciBlbmRzIHVwIGluIGJyb3dzZXIgaGlzdG9yeSBvciBhIHNoYXJlZCBsaW5rLlxyXG4gICAgICAgIG5hdmlnYXRlKCcvbWZhLWNoYWxsZW5nZScsIHsgc3RhdGU6IHsgbWZhVGlja2V0OiByZXN1bHQubWZhVGlja2V0IH0gfSlcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBuYXZpZ2F0ZSgnLycpXHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAvLyBBcGlFcnJvci5tZXNzYWdlIGNvbWVzIHN0cmFpZ2h0IGZyb20gdGhlIGJhY2tlbmQncyB7XCJlcnJvclwiOlxyXG4gICAgICAvLyB7bWVzc2FnZX19IHNoYXBlIChzZWUgYXBpL2NsaWVudC5qcykg4oCUIGFscmVhZHkgdGhlIGRlbGliZXJhdGVseVxyXG4gICAgICAvLyBnZW5lcmljIFwiSW52YWxpZCBlbWFpbCBvciBwYXNzd29yZFwiIHRleHQsIHNhZmUgdG8gc2hvdyBhcy1pcy5cclxuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICA8aDE+TG9nIGluPC9oMT5cclxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIj5FbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZXJyb3JcIj5cclxuICAgICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XHJcbiAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gJ0xvZ2dpbmcgaW4uLi4nIDogJ0xvZyBpbid9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgICAgPHA+XHJcbiAgICAgICAgTm8gYWNjb3VudD8gPExpbmsgdG89XCIvcmVnaXN0ZXJcIj5SZWdpc3RlcjwvTGluaz5cclxuICAgICAgPC9wPlxyXG4gICAgICA8cD5cclxuICAgICAgICA8TGluayB0bz1cIi9mb3Jnb3QtcGFzc3dvcmRcIj5Gb3Jnb3QgcGFzc3dvcmQ/PC9MaW5rPlxyXG4gICAgICA8L3A+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==