import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/settings/SettingsNav.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/settings/SettingsNav.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Left-hand menu for the settings page: groups (e.g. "Security") each
// listing their individual settings as sub-items (e.g. "Password",
// "Two-factor authentication"). Purely controlled — AccountPage owns which
// item is active and swaps the detail pane on the right accordingly.
export function SettingsNav({ groups, activeItemId, onSelect }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		className: "settings-nav",
		"aria-label": "Settings",
		children: groups.map((group) => /* @__PURE__ */ _jsxDEV("div", {
			className: "settings-nav-group",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "settings-nav-group-label",
				children: [/* @__PURE__ */ _jsxDEV(group.icon, {
					className: "settings-nav-icon",
					"aria-hidden": "true",
					size: 14
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 13
				}, this), group.label]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("ul", {
				className: "settings-nav-list",
				children: group.items.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "settings-nav-item",
					"aria-current": item.id === activeItemId ? "page" : undefined,
					onClick: () => onSelect(item.id),
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "settings-nav-item-label",
							children: item.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 19
						}, this),
						item.badgeLoading && /* @__PURE__ */ _jsxDEV(Skeleton, {
							width: "2rem",
							height: "1.1em",
							className: "settings-nav-badge-skeleton"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 41
						}, this),
						!item.badgeLoading && item.badge && /* @__PURE__ */ _jsxDEV("span", {
							className: `settings-nav-badge settings-nav-badge-${item.badge.toLowerCase()}`,
							children: item.badge
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 21
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 17
				}, this) }, item.id, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 11
			}, this)]
		}, group.id, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = SettingsNav;
var _c;
$RefreshReg$(_c, "SettingsNav");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/settings/SettingsNav.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/settings/SettingsNav.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/settings/SettingsNav.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/settings/SettingsNav.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7Ozs7QUFNekIsT0FBTyxTQUFTLFlBQVksRUFBRSxRQUFRLGNBQWMsWUFBWTtDQUM5RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO0VBQWUsY0FBVztZQUN0QyxPQUFPLEtBQUssVUFDWCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYixDQUNFLHdCQUFDLE1BQU0sTUFBUDtLQUFZLFdBQVU7S0FBb0IsZUFBWTtLQUFPLE1BQU07SUFBSzs7OztjQUN2RSxNQUFNLEtBQ047Ozs7O2FBRUgsd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FDWCxNQUFNLE1BQU0sS0FBSyxTQUNoQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsZ0JBQWMsS0FBSyxPQUFPLGVBQWUsU0FBUztLQUNsRCxlQUFlLFNBQVMsS0FBSyxFQUFFO2VBSmpDO01BTUUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTJCLEtBQUs7TUFBWTs7Ozs7TUFDM0QsS0FBSyxnQkFBZ0Isd0JBQUMsVUFBRDtPQUFVLE9BQU07T0FBTyxRQUFPO09BQVEsV0FBVTtNQUErQjs7Ozs7TUFDcEcsQ0FBQyxLQUFLLGdCQUFnQixLQUFLLFNBQzFCLHdCQUFDLFFBQUQ7T0FBTSxXQUFXLHlDQUF5QyxLQUFLLE1BQU0sWUFBWTtpQkFDOUUsS0FBSztNQUNGOzs7OztLQUVGOzs7OzthQUNOLEdBZkssS0FBSzs7OztXQWVWLENBQ0w7R0FDQzs7OztXQUNEO0tBMUJvQyxNQUFNOzs7O1NBMEIxQyxDQUNOO0NBQ0U7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2V0dGluZ3NOYXYuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnLi4vU2tlbGV0b24nXHJcblxyXG4vLyBMZWZ0LWhhbmQgbWVudSBmb3IgdGhlIHNldHRpbmdzIHBhZ2U6IGdyb3VwcyAoZS5nLiBcIlNlY3VyaXR5XCIpIGVhY2hcclxuLy8gbGlzdGluZyB0aGVpciBpbmRpdmlkdWFsIHNldHRpbmdzIGFzIHN1Yi1pdGVtcyAoZS5nLiBcIlBhc3N3b3JkXCIsXHJcbi8vIFwiVHdvLWZhY3RvciBhdXRoZW50aWNhdGlvblwiKS4gUHVyZWx5IGNvbnRyb2xsZWQg4oCUIEFjY291bnRQYWdlIG93bnMgd2hpY2hcclxuLy8gaXRlbSBpcyBhY3RpdmUgYW5kIHN3YXBzIHRoZSBkZXRhaWwgcGFuZSBvbiB0aGUgcmlnaHQgYWNjb3JkaW5nbHkuXHJcbmV4cG9ydCBmdW5jdGlvbiBTZXR0aW5nc05hdih7IGdyb3VwcywgYWN0aXZlSXRlbUlkLCBvblNlbGVjdCB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxuYXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtbmF2XCIgYXJpYS1sYWJlbD1cIlNldHRpbmdzXCI+XHJcbiAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtbmF2LWdyb3VwXCIga2V5PXtncm91cC5pZH0+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzZXR0aW5ncy1uYXYtZ3JvdXAtbGFiZWxcIj5cclxuICAgICAgICAgICAgPGdyb3VwLmljb24gY2xhc3NOYW1lPVwic2V0dGluZ3MtbmF2LWljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAge2dyb3VwLmxhYmVsfVxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzZXR0aW5ncy1uYXYtbGlzdFwiPlxyXG4gICAgICAgICAgICB7Z3JvdXAuaXRlbXMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGxpIGtleT17aXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZXR0aW5ncy1uYXYtaXRlbVwiXHJcbiAgICAgICAgICAgICAgICAgIGFyaWEtY3VycmVudD17aXRlbS5pZCA9PT0gYWN0aXZlSXRlbUlkID8gJ3BhZ2UnIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdChpdGVtLmlkKX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2V0dGluZ3MtbmF2LWl0ZW0tbGFiZWxcIj57aXRlbS5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtpdGVtLmJhZGdlTG9hZGluZyAmJiA8U2tlbGV0b24gd2lkdGg9XCIycmVtXCIgaGVpZ2h0PVwiMS4xZW1cIiBjbGFzc05hbWU9XCJzZXR0aW5ncy1uYXYtYmFkZ2Utc2tlbGV0b25cIiAvPn1cclxuICAgICAgICAgICAgICAgICAgeyFpdGVtLmJhZGdlTG9hZGluZyAmJiBpdGVtLmJhZGdlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BzZXR0aW5ncy1uYXYtYmFkZ2Ugc2V0dGluZ3MtbmF2LWJhZGdlLSR7aXRlbS5iYWRnZS50b0xvd2VyQ2FzZSgpfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uYmFkZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L3VsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApKX1cclxuICAgIDwvbmF2PlxyXG4gIClcclxufVxyXG4iXX0=