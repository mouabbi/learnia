import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ForgotPasswordPage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { authApi } from "/src/features/auth/authApi.js";
import { ApiError } from "/src/api/client.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/ForgotPasswordPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Public page: enter an email, get a reset link by email. The backend
// answers identically whether or not the email is registered (see
// account_service.request_password_reset), so this page never says
// "no such account" either.
export function ForgotPasswordPage() {
	_s();
	const [email, setEmail] = useState("");
	const [message, setMessage] = useState(null);
	const [error, setError] = useState(null);
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError(null);
		setIsSubmitting(true);
		try {
			await authApi.forgotPassword(email);
			setMessage("If that email is registered, a reset link has been sent.");
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "page",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: "Forgot password" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			message ? /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "email",
						children: "Email"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "email",
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "error",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						disabled: isSubmitting,
						children: isSubmitting ? "Sending..." : "Send reset link"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/login",
				children: "Back to log in"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
_s(ForgotPasswordPage, "lGJ2ULUNWOVxq8+MVi0/rJ25rEg=");
_c = ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ForgotPasswordPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/ForgotPasswordPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/ForgotPasswordPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/ForgotPasswordPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7Ozs7Ozs7QUFNekIsT0FBTyxTQUFTLHFCQUFxQjs7Q0FDbkMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxlQUFlLGFBQWEsT0FBTztFQUNqQyxNQUFNLGVBQWU7RUFDckIsU0FBUyxJQUFJO0VBQ2IsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sUUFBUSxlQUFlLEtBQUs7R0FDbEMsV0FBVywwREFBMEQ7RUFDdkUsU0FBUyxLQUFLO0dBQ1osU0FBUyxlQUFlLFdBQVcsSUFBSSxVQUFVLHNCQUFzQjtFQUN6RSxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFELFlBQUksa0JBQW1COzs7OztHQUN0QixVQUNDLHdCQUFDLEtBQUQsWUFBSSxRQUFXOzs7O2NBRWYsd0JBQUMsUUFBRDtJQUFNLFVBQVU7Y0FBaEI7S0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQVE7S0FBWTs7OztlQUNuQyx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxPQUFPO01BQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7TUFDeEM7S0FDRDs7OzthQUNFOzs7OztLQUNKLFNBQ0Msd0JBQUMsS0FBRDtNQUFHLE1BQUs7TUFBUSxXQUFVO2dCQUN2QjtLQUNBOzs7OztLQUVMLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVTtnQkFDN0IsZUFBZSxlQUFlO0tBQ3pCOzs7OztJQUNKOzs7Ozs7R0FFUix3QkFBQyxLQUFELFlBQ0Usd0JBQUMsTUFBRDtJQUFNLElBQUc7Y0FBUztHQUFvQjs7OztZQUNyQzs7Ozs7RUFDSTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRm9yZ290UGFzc3dvcmRQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvYXV0aEFwaSdcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi9hcGkvY2xpZW50J1xyXG5cclxuLy8gUHVibGljIHBhZ2U6IGVudGVyIGFuIGVtYWlsLCBnZXQgYSByZXNldCBsaW5rIGJ5IGVtYWlsLiBUaGUgYmFja2VuZFxyXG4vLyBhbnN3ZXJzIGlkZW50aWNhbGx5IHdoZXRoZXIgb3Igbm90IHRoZSBlbWFpbCBpcyByZWdpc3RlcmVkIChzZWVcclxuLy8gYWNjb3VudF9zZXJ2aWNlLnJlcXVlc3RfcGFzc3dvcmRfcmVzZXQpLCBzbyB0aGlzIHBhZ2UgbmV2ZXIgc2F5c1xyXG4vLyBcIm5vIHN1Y2ggYWNjb3VudFwiIGVpdGhlci5cclxuZXhwb3J0IGZ1bmN0aW9uIEZvcmdvdFBhc3N3b3JkUGFnZSgpIHtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGV2ZW50KSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBzZXRFcnJvcihudWxsKVxyXG4gICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpXHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhdXRoQXBpLmZvcmdvdFBhc3N3b3JkKGVtYWlsKVxyXG4gICAgICBzZXRNZXNzYWdlKCdJZiB0aGF0IGVtYWlsIGlzIHJlZ2lzdGVyZWQsIGEgcmVzZXQgbGluayBoYXMgYmVlbiBzZW50LicpXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICA8aDE+Rm9yZ290IHBhc3N3b3JkPC9oMT5cclxuICAgICAge21lc3NhZ2UgPyAoXHJcbiAgICAgICAgPHA+e21lc3NhZ2V9PC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZXJyb3JcIj5cclxuICAgICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfT5cclxuICAgICAgICAgICAge2lzU3VibWl0dGluZyA/ICdTZW5kaW5nLi4uJyA6ICdTZW5kIHJlc2V0IGxpbmsnfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICApfVxyXG4gICAgICA8cD5cclxuICAgICAgICA8TGluayB0bz1cIi9sb2dpblwiPkJhY2sgdG8gbG9nIGluPC9MaW5rPlxyXG4gICAgICA8L3A+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==