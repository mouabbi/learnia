import { PASSING_PCT } from "/src/features/courses/progress.js";
// Tiny WebAudio chime played right before a module QCM starts — no audio
// asset needed, just a soft ascending sine arpeggio (C-E-G major triad)
// with a gentle bell-like decay. Best-effort: browsers that block audio
// without a prior user gesture (rare here, always fires from a click)
// just stay silent.
let sharedCtx = null;
function getContext() {
	if (typeof window === "undefined") return null;
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return null;
	if (!sharedCtx) sharedCtx = new Ctx();
	return sharedCtx;
}
function chimeNote(ctx, when, freq, duration, peakGain) {
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = "sine";
	osc.frequency.value = freq;
	gain.gain.setValueAtTime(0, when);
	gain.gain.linearRampToValueAtTime(peakGain, when + .02);
	gain.gain.exponentialRampToValueAtTime(8e-4, when + duration);
	osc.connect(gain);
	gain.connect(ctx.destination);
	osc.start(when);
	osc.stop(when + duration + .05);
}
export function playQuizStartCue() {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		// C5, E5, G5, C6 — a bright, quick major arpeggio.
		chimeNote(ctx, now, 523.25, .5, .1);
		chimeNote(ctx, now + .09, 659.25, .5, .1);
		chimeNote(ctx, now + .18, 783.99, .55, .1);
		chimeNote(ctx, now + .3, 1046.5, .7, .11);
	} catch {}
}
// Soft, neutral "processing" tick — one per grading step, so the ~10s
// grading sequence feels alive instead of silent.
export function playQuizGradingTick() {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "triangle";
		osc.frequency.value = 720;
		gain.gain.setValueAtTime(0, now);
		gain.gain.linearRampToValueAtTime(.05, now + .01);
		gain.gain.exponentialRampToValueAtTime(8e-4, now + .12);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now);
		osc.stop(now + .14);
	} catch {}
}
// Result cue, shaped by how well the learner actually did — a perfect
// score gets a full triumphant fanfare, a plain pass gets a shorter happy
// riff, and a fail gets a gentle (not punishing) descending minor cue.
export function playQuizResultCue(pct) {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		if (pct === 100) {
			// C5 E5 G5 C6 E6 — full major run, bright and long.
			;
			[
				523.25,
				659.25,
				783.99,
				1046.5,
				1318.51
			].forEach((freq, i) => chimeNote(ctx, now + i * .1, freq, .6, .12));
		} else if (pct >= PASSING_PCT) {
			// E5 G5 C6 — short, happy confirmation.
			;
			[
				659.25,
				783.99,
				1046.5
			].forEach((freq, i) => chimeNote(ctx, now + i * .1, freq, .5, .11));
		} else {
			// A4 F4 D4 — soft descending minor, encouraging rather than harsh.
			;
			[
				440,
				349.23,
				293.66
			].forEach((freq, i) => chimeNote(ctx, now + i * .14, freq, .55, .08));
		}
	} catch {}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7Ozs7OztBQU81QixJQUFJLFlBQVk7QUFFaEIsU0FBUyxhQUFhO0NBQ3BCLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxNQUFNLE1BQU0sT0FBTyxnQkFBZ0IsT0FBTztDQUMxQyxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksQ0FBQyxXQUFXLFlBQVksSUFBSSxJQUFJO0NBQ3BDLE9BQU87QUFDVDtBQUVBLFNBQVMsVUFBVSxLQUFLLE1BQU0sTUFBTSxVQUFVLFVBQVU7Q0FDdEQsTUFBTSxNQUFNLElBQUksaUJBQWlCO0NBQ2pDLE1BQU0sT0FBTyxJQUFJLFdBQVc7Q0FDNUIsSUFBSSxPQUFPO0NBQ1gsSUFBSSxVQUFVLFFBQVE7Q0FDdEIsS0FBSyxLQUFLLGVBQWUsR0FBRyxJQUFJO0NBQ2hDLEtBQUssS0FBSyx3QkFBd0IsVUFBVSxPQUFPLEdBQUk7Q0FDdkQsS0FBSyxLQUFLLDZCQUE2QixNQUFRLE9BQU8sUUFBUTtDQUM5RCxJQUFJLFFBQVEsSUFBSTtDQUNoQixLQUFLLFFBQVEsSUFBSSxXQUFXO0NBQzVCLElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxLQUFLLE9BQU8sV0FBVyxHQUFJO0FBQ2pDO0FBRUEsT0FBTyxTQUFTLG1CQUFtQjtDQUNqQyxJQUFJO0VBQ0YsTUFBTSxNQUFNLFdBQVc7RUFDdkIsSUFBSSxDQUFDLEtBQUs7RUFDVixJQUFJLElBQUksVUFBVSxhQUFhLElBQUksT0FBTztFQUMxQyxNQUFNLE1BQU0sSUFBSTs7RUFFaEIsVUFBVSxLQUFLLEtBQUssUUFBUSxJQUFLLEVBQUc7RUFDcEMsVUFBVSxLQUFLLE1BQU0sS0FBTSxRQUFRLElBQUssRUFBRztFQUMzQyxVQUFVLEtBQUssTUFBTSxLQUFNLFFBQVEsS0FBTSxFQUFHO0VBQzVDLFVBQVUsS0FBSyxNQUFNLElBQUssUUFBUSxJQUFLLEdBQUk7Q0FDN0MsUUFBUSxDQUVSO0FBQ0Y7OztBQUlBLE9BQU8sU0FBUyxzQkFBc0I7Q0FDcEMsSUFBSTtFQUNGLE1BQU0sTUFBTSxXQUFXO0VBQ3ZCLElBQUksQ0FBQyxLQUFLO0VBQ1YsSUFBSSxJQUFJLFVBQVUsYUFBYSxJQUFJLE9BQU87RUFDMUMsTUFBTSxNQUFNLElBQUk7RUFDaEIsTUFBTSxNQUFNLElBQUksaUJBQWlCO0VBQ2pDLE1BQU0sT0FBTyxJQUFJLFdBQVc7RUFDNUIsSUFBSSxPQUFPO0VBQ1gsSUFBSSxVQUFVLFFBQVE7RUFDdEIsS0FBSyxLQUFLLGVBQWUsR0FBRyxHQUFHO0VBQy9CLEtBQUssS0FBSyx3QkFBd0IsS0FBTSxNQUFNLEdBQUk7RUFDbEQsS0FBSyxLQUFLLDZCQUE2QixNQUFRLE1BQU0sR0FBSTtFQUN6RCxJQUFJLFFBQVEsSUFBSTtFQUNoQixLQUFLLFFBQVEsSUFBSSxXQUFXO0VBQzVCLElBQUksTUFBTSxHQUFHO0VBQ2IsSUFBSSxLQUFLLE1BQU0sR0FBSTtDQUNyQixRQUFRLENBRVI7QUFDRjs7OztBQUtBLE9BQU8sU0FBUyxrQkFBa0IsS0FBSztDQUNyQyxJQUFJO0VBQ0YsTUFBTSxNQUFNLFdBQVc7RUFDdkIsSUFBSSxDQUFDLEtBQUs7RUFDVixJQUFJLElBQUksVUFBVSxhQUFhLElBQUksT0FBTztFQUMxQyxNQUFNLE1BQU0sSUFBSTtFQUVoQixJQUFJLFFBQVEsS0FBSzs7R0FFZjtHQUFDO0lBQUM7SUFBUTtJQUFRO0lBQVE7SUFBUTtHQUFPLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFDeEQsVUFBVSxLQUFLLE1BQU0sSUFBSSxJQUFLLE1BQU0sSUFBSyxHQUFJLENBQy9DO0VBQ0YsT0FBTyxJQUFJLE9BQU8sYUFBYTs7R0FFN0I7R0FBQztJQUFDO0lBQVE7SUFBUTtHQUFNLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTSxVQUFVLEtBQUssTUFBTSxJQUFJLElBQUssTUFBTSxJQUFLLEdBQUksQ0FBQztFQUMvRixPQUFPOztHQUVMO0dBQUM7SUFBQztJQUFLO0lBQVE7R0FBTSxDQUFDLENBQUMsU0FBUyxNQUFNLE1BQU0sVUFBVSxLQUFLLE1BQU0sSUFBSSxLQUFNLE1BQU0sS0FBTSxHQUFJLENBQUM7RUFDOUY7Q0FDRixRQUFRLENBRVI7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWl6U291bmQuanMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUEFTU0lOR19QQ1QgfSBmcm9tICcuL3Byb2dyZXNzJ1xyXG5cclxuLy8gVGlueSBXZWJBdWRpbyBjaGltZSBwbGF5ZWQgcmlnaHQgYmVmb3JlIGEgbW9kdWxlIFFDTSBzdGFydHMg4oCUIG5vIGF1ZGlvXHJcbi8vIGFzc2V0IG5lZWRlZCwganVzdCBhIHNvZnQgYXNjZW5kaW5nIHNpbmUgYXJwZWdnaW8gKEMtRS1HIG1ham9yIHRyaWFkKVxyXG4vLyB3aXRoIGEgZ2VudGxlIGJlbGwtbGlrZSBkZWNheS4gQmVzdC1lZmZvcnQ6IGJyb3dzZXJzIHRoYXQgYmxvY2sgYXVkaW9cclxuLy8gd2l0aG91dCBhIHByaW9yIHVzZXIgZ2VzdHVyZSAocmFyZSBoZXJlLCBhbHdheXMgZmlyZXMgZnJvbSBhIGNsaWNrKVxyXG4vLyBqdXN0IHN0YXkgc2lsZW50LlxyXG5sZXQgc2hhcmVkQ3R4ID0gbnVsbFxyXG5cclxuZnVuY3Rpb24gZ2V0Q29udGV4dCgpIHtcclxuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBudWxsXHJcbiAgY29uc3QgQ3R4ID0gd2luZG93LkF1ZGlvQ29udGV4dCB8fCB3aW5kb3cud2Via2l0QXVkaW9Db250ZXh0XHJcbiAgaWYgKCFDdHgpIHJldHVybiBudWxsXHJcbiAgaWYgKCFzaGFyZWRDdHgpIHNoYXJlZEN0eCA9IG5ldyBDdHgoKVxyXG4gIHJldHVybiBzaGFyZWRDdHhcclxufVxyXG5cclxuZnVuY3Rpb24gY2hpbWVOb3RlKGN0eCwgd2hlbiwgZnJlcSwgZHVyYXRpb24sIHBlYWtHYWluKSB7XHJcbiAgY29uc3Qgb3NjID0gY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKVxyXG4gIGNvbnN0IGdhaW4gPSBjdHguY3JlYXRlR2FpbigpXHJcbiAgb3NjLnR5cGUgPSAnc2luZSdcclxuICBvc2MuZnJlcXVlbmN5LnZhbHVlID0gZnJlcVxyXG4gIGdhaW4uZ2Fpbi5zZXRWYWx1ZUF0VGltZSgwLCB3aGVuKVxyXG4gIGdhaW4uZ2Fpbi5saW5lYXJSYW1wVG9WYWx1ZUF0VGltZShwZWFrR2Fpbiwgd2hlbiArIDAuMDIpXHJcbiAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDA4LCB3aGVuICsgZHVyYXRpb24pXHJcbiAgb3NjLmNvbm5lY3QoZ2FpbilcclxuICBnYWluLmNvbm5lY3QoY3R4LmRlc3RpbmF0aW9uKVxyXG4gIG9zYy5zdGFydCh3aGVuKVxyXG4gIG9zYy5zdG9wKHdoZW4gKyBkdXJhdGlvbiArIDAuMDUpXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5UXVpelN0YXJ0Q3VlKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjdHggPSBnZXRDb250ZXh0KClcclxuICAgIGlmICghY3R4KSByZXR1cm5cclxuICAgIGlmIChjdHguc3RhdGUgPT09ICdzdXNwZW5kZWQnKSBjdHgucmVzdW1lKClcclxuICAgIGNvbnN0IG5vdyA9IGN0eC5jdXJyZW50VGltZVxyXG4gICAgLy8gQzUsIEU1LCBHNSwgQzYg4oCUIGEgYnJpZ2h0LCBxdWljayBtYWpvciBhcnBlZ2dpby5cclxuICAgIGNoaW1lTm90ZShjdHgsIG5vdywgNTIzLjI1LCAwLjUsIDAuMSlcclxuICAgIGNoaW1lTm90ZShjdHgsIG5vdyArIDAuMDksIDY1OS4yNSwgMC41LCAwLjEpXHJcbiAgICBjaGltZU5vdGUoY3R4LCBub3cgKyAwLjE4LCA3ODMuOTksIDAuNTUsIDAuMSlcclxuICAgIGNoaW1lTm90ZShjdHgsIG5vdyArIDAuMywgMTA0Ni41LCAwLjcsIDAuMTEpXHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBpZ25vcmUg4oCUIGN1ZSBpcyBhIG5pY2UtdG8taGF2ZSwgbmV2ZXIgYmxvY2sgdGhlIHF1aXogb24gaXRcclxuICB9XHJcbn1cclxuXHJcbi8vIFNvZnQsIG5ldXRyYWwgXCJwcm9jZXNzaW5nXCIgdGljayDigJQgb25lIHBlciBncmFkaW5nIHN0ZXAsIHNvIHRoZSB+MTBzXHJcbi8vIGdyYWRpbmcgc2VxdWVuY2UgZmVlbHMgYWxpdmUgaW5zdGVhZCBvZiBzaWxlbnQuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5UXVpekdyYWRpbmdUaWNrKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjdHggPSBnZXRDb250ZXh0KClcclxuICAgIGlmICghY3R4KSByZXR1cm5cclxuICAgIGlmIChjdHguc3RhdGUgPT09ICdzdXNwZW5kZWQnKSBjdHgucmVzdW1lKClcclxuICAgIGNvbnN0IG5vdyA9IGN0eC5jdXJyZW50VGltZVxyXG4gICAgY29uc3Qgb3NjID0gY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKVxyXG4gICAgY29uc3QgZ2FpbiA9IGN0eC5jcmVhdGVHYWluKClcclxuICAgIG9zYy50eXBlID0gJ3RyaWFuZ2xlJ1xyXG4gICAgb3NjLmZyZXF1ZW5jeS52YWx1ZSA9IDcyMFxyXG4gICAgZ2Fpbi5nYWluLnNldFZhbHVlQXRUaW1lKDAsIG5vdylcclxuICAgIGdhaW4uZ2Fpbi5saW5lYXJSYW1wVG9WYWx1ZUF0VGltZSgwLjA1LCBub3cgKyAwLjAxKVxyXG4gICAgZ2Fpbi5nYWluLmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMC4wMDA4LCBub3cgKyAwLjEyKVxyXG4gICAgb3NjLmNvbm5lY3QoZ2FpbilcclxuICAgIGdhaW4uY29ubmVjdChjdHguZGVzdGluYXRpb24pXHJcbiAgICBvc2Muc3RhcnQobm93KVxyXG4gICAgb3NjLnN0b3Aobm93ICsgMC4xNClcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIGlnbm9yZVxyXG4gIH1cclxufVxyXG5cclxuLy8gUmVzdWx0IGN1ZSwgc2hhcGVkIGJ5IGhvdyB3ZWxsIHRoZSBsZWFybmVyIGFjdHVhbGx5IGRpZCDigJQgYSBwZXJmZWN0XHJcbi8vIHNjb3JlIGdldHMgYSBmdWxsIHRyaXVtcGhhbnQgZmFuZmFyZSwgYSBwbGFpbiBwYXNzIGdldHMgYSBzaG9ydGVyIGhhcHB5XHJcbi8vIHJpZmYsIGFuZCBhIGZhaWwgZ2V0cyBhIGdlbnRsZSAobm90IHB1bmlzaGluZykgZGVzY2VuZGluZyBtaW5vciBjdWUuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5UXVpelJlc3VsdEN1ZShwY3QpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY3R4ID0gZ2V0Q29udGV4dCgpXHJcbiAgICBpZiAoIWN0eCkgcmV0dXJuXHJcbiAgICBpZiAoY3R4LnN0YXRlID09PSAnc3VzcGVuZGVkJykgY3R4LnJlc3VtZSgpXHJcbiAgICBjb25zdCBub3cgPSBjdHguY3VycmVudFRpbWVcclxuXHJcbiAgICBpZiAocGN0ID09PSAxMDApIHtcclxuICAgICAgLy8gQzUgRTUgRzUgQzYgRTYg4oCUIGZ1bGwgbWFqb3IgcnVuLCBicmlnaHQgYW5kIGxvbmcuXHJcbiAgICAgIDtbNTIzLjI1LCA2NTkuMjUsIDc4My45OSwgMTA0Ni41LCAxMzE4LjUxXS5mb3JFYWNoKChmcmVxLCBpKSA9PlxyXG4gICAgICAgIGNoaW1lTm90ZShjdHgsIG5vdyArIGkgKiAwLjEsIGZyZXEsIDAuNiwgMC4xMiksXHJcbiAgICAgIClcclxuICAgIH0gZWxzZSBpZiAocGN0ID49IFBBU1NJTkdfUENUKSB7XHJcbiAgICAgIC8vIEU1IEc1IEM2IOKAlCBzaG9ydCwgaGFwcHkgY29uZmlybWF0aW9uLlxyXG4gICAgICA7WzY1OS4yNSwgNzgzLjk5LCAxMDQ2LjVdLmZvckVhY2goKGZyZXEsIGkpID0+IGNoaW1lTm90ZShjdHgsIG5vdyArIGkgKiAwLjEsIGZyZXEsIDAuNSwgMC4xMSkpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBBNCBGNCBENCDigJQgc29mdCBkZXNjZW5kaW5nIG1pbm9yLCBlbmNvdXJhZ2luZyByYXRoZXIgdGhhbiBoYXJzaC5cclxuICAgICAgO1s0NDAsIDM0OS4yMywgMjkzLjY2XS5mb3JFYWNoKChmcmVxLCBpKSA9PiBjaGltZU5vdGUoY3R4LCBub3cgKyBpICogMC4xNCwgZnJlcSwgMC41NSwgMC4wOCkpXHJcbiAgICB9XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBpZ25vcmVcclxuICB9XHJcbn1cclxuIl19