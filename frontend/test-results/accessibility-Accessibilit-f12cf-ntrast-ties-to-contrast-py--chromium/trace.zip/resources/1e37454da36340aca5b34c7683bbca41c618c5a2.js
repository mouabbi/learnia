import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/theming/ThemeEditor.jsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { AlertTriangle, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { themeApi } from "/src/features/theming/themeApi.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/theming/ThemeEditor.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
/**
* ThemeEditor — CMS color-picker UI for a course's per-course theme
* (16-theming). Never exposes raw JSON: every field is a native
* `<input type="color">` swatch, with a live preview panel and inline
* WCAG contrast warnings sourced from the backend (routers/theme.py's
* `warnings` array, computed by utils/contrast.py).
*
* Props:
*   - courseId (string|number, required): which course's theme to load
*     and save. Used as `/courses/{courseId}/theme`.
*   - onSave (function(theme), optional): called after a successful save
*     with the saved CourseTheme object — e.g. so a hosting CMS page can
*     refresh a course list's swatch. The component always saves via its
*     own themeApi call regardless of whether this is provided; it's a
*     notification hook, not a substitute for the API call.
*
* Self-contained: fetches the current theme on mount, edits are local
* until "Save theme" is clicked. Not yet wired into a route/page — the
* CMS workspace hosting it is being built separately.
*/
export function ThemeEditor({ courseId, onSave }) {
	_s();
	const [theme, setTheme] = useState(null);
	const [warnings, setWarnings] = useState([]);
	const [loading, setLoading] = useState(true);
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState(null);
	useEffect(() => {
		let cancelled = false;
		setLoading(true);
		themeApi.getTheme(courseId).then((res) => {
			if (cancelled) return;
			setTheme(res.theme);
			setWarnings(res.warnings ?? []);
		}).catch((err) => !cancelled && setError(err.message ?? "Failed to load theme")).finally(() => !cancelled && setLoading(false));
		return () => {
			cancelled = true;
		};
	}, [courseId]);
	const setField = useCallback((path, value) => {
		setTheme((prev) => {
			if (!prev) return prev;
			if (path.length === 1) return {
				...prev,
				[path[0]]: value
			};
			const [group, key] = path;
			return {
				...prev,
				[group]: {
					...prev[group],
					[key]: value
				}
			};
		});
	}, []);
	const setModulePaletteColor = useCallback((index, value) => {
		setTheme((prev) => {
			if (!prev) return prev;
			const next = [...prev.modulePalette];
			next[index] = value;
			return {
				...prev,
				modulePalette: next
			};
		});
	}, []);
	const handleSave = useCallback(async () => {
		if (!theme) return;
		setSaving(true);
		setError(null);
		try {
			const res = await themeApi.updateTheme(courseId, theme);
			setTheme(res.theme);
			setWarnings(res.warnings ?? []);
			onSave?.(res.theme);
		} catch (err) {
			setError(err.message ?? "Failed to save theme");
		} finally {
			setSaving(false);
		}
	}, [
		courseId,
		theme,
		onSave
	]);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "theme-editor theme-editor-loading",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, {
				size: 18,
				className: "theme-editor-spinner",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 9
			}, this), "Loading theme…"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this);
	}
	if (!theme) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "theme-editor theme-editor-error",
			children: error ?? "No theme data"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 94,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "theme-editor",
		children: [
			/* @__PURE__ */ _jsxDEV("section", {
				className: "theme-editor-section",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Brand colors" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Accent",
						value: theme.accent,
						onChange: (v) => setField(["accent"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Secondary",
						value: theme.secondary,
						onChange: (v) => setField(["secondary"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Heading color",
						value: theme.headingColor,
						onChange: (v) => setField(["headingColor"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "theme-editor-section",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Module palette" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "theme-editor-hint",
						children: "Cycles across modules in order; assign extra modules re-use these colors."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "theme-editor-swatch-row",
						children: theme.modulePalette.map((hex, i) => /* @__PURE__ */ _jsxDEV(ColorField, {
							label: `Module ${i + 1}`,
							value: hex,
							onChange: (v) => setModulePaletteColor(i, v),
							compact: true
						}, i, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "theme-editor-section",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Light mode palette" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Background",
						value: theme.light.background,
						onChange: (v) => setField(["light", "background"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Surface",
						value: theme.light.surface,
						onChange: (v) => setField(["light", "surface"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Text",
						value: theme.light.text,
						onChange: (v) => setField(["light", "text"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "theme-editor-section",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Dark mode palette" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Background",
						value: theme.dark.background,
						onChange: (v) => setField(["dark", "background"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Surface",
						value: theme.dark.surface,
						onChange: (v) => setField(["dark", "surface"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ColorField, {
						label: "Text",
						value: theme.dark.text,
						onChange: (v) => setField(["dark", "text"], v)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "theme-editor-section theme-editor-preview",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Live preview" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "theme-editor-preview-grid",
					children: [/* @__PURE__ */ _jsxDEV(PreviewCard, {
						title: "Light mode",
						palette: theme.light,
						theme
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(PreviewCard, {
						title: "Dark mode",
						palette: theme.dark,
						theme
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: warnings.length > 0 && /* @__PURE__ */ _jsxDEV(motion.ul, {
				className: "theme-editor-warnings",
				initial: {
					opacity: 0,
					height: 0
				},
				animate: {
					opacity: 1,
					height: "auto"
				},
				exit: {
					opacity: 0,
					height: 0
				},
				children: warnings.map((w) => /* @__PURE__ */ _jsxDEV("li", {
					className: "theme-editor-warning",
					children: [
						/* @__PURE__ */ _jsxDEV(AlertTriangle, {
							size: 14,
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 17
						}, this),
						" ",
						w
					]
				}, w, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 180,
				columnNumber: 11
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "theme-editor-error-text",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 195,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(motion.button, {
				type: "button",
				className: "theme-editor-save",
				onClick: handleSave,
				disabled: saving,
				whileTap: { scale: .97 },
				children: saving ? "Saving…" : "Save theme"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 98,
		columnNumber: 5
	}, this);
}
_s(ThemeEditor, "aVK1VakTjhn3yu9tWe3Lrpi70iQ=");
_c = ThemeEditor;
function ColorField({ label, value, onChange, compact = false }) {
	return /* @__PURE__ */ _jsxDEV("label", {
		className: `theme-editor-field ${compact ? "theme-editor-field-compact" : ""}`,
		children: [/* @__PURE__ */ _jsxDEV("input", {
			type: "color",
			value,
			onChange: (e) => onChange(e.target.value),
			"aria-label": label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 213,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 212,
		columnNumber: 5
	}, this);
}
_c2 = ColorField;
function PreviewCard({ title, palette, theme }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "theme-editor-preview-card",
		style: {
			background: palette.background,
			color: palette.text
		},
		children: [
			/* @__PURE__ */ _jsxDEV("p", {
				className: "theme-editor-preview-label",
				children: title
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 230,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("h4", {
				style: { color: theme.headingColor },
				children: "Sample heading"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "theme-editor-preview-surface",
				style: { background: palette.surface },
				children: "Sample body text on a surface block."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 232,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "theme-editor-preview-button",
				style: {
					background: theme.accent,
					color: "#fff"
				},
				children: "Sample button"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 235,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 226,
		columnNumber: 5
	}, this);
}
_c3 = PreviewCard;
var _c, _c2, _c3;
$RefreshReg$(_c, "ThemeEditor");
$RefreshReg$(_c2, "ColorField");
$RefreshReg$(_c3, "PreviewCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/theming/ThemeEditor.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/theming/ThemeEditor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/theming/ThemeEditor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/theming/ThemeEditor.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBQ2pELFNBQVMsaUJBQWlCLGNBQWM7QUFDeEMsU0FBUyxlQUFlLGVBQWU7QUFDdkMsU0FBUyxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNCekIsT0FBTyxTQUFTLFlBQVksRUFBRSxVQUFVLFVBQVU7O0NBQ2hELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FDM0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FFdkMsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZO0VBQ2hCLFdBQVcsSUFBSTtFQUNmLFNBQ0csU0FBUyxRQUFRLENBQUMsQ0FDbEIsTUFBTSxRQUFRO0dBQ2IsSUFBSSxXQUFXO0dBQ2YsU0FBUyxJQUFJLEtBQUs7R0FDbEIsWUFBWSxJQUFJLFlBQVksQ0FBQyxDQUFDO0VBQ2hDLENBQUMsQ0FBQyxDQUNELE9BQU8sUUFBUSxDQUFDLGFBQWEsU0FBUyxJQUFJLFdBQVcsc0JBQXNCLENBQUMsQ0FBQyxDQUM3RSxjQUFjLENBQUMsYUFBYSxXQUFXLEtBQUssQ0FBQztFQUNoRCxhQUFhO0dBQ1gsWUFBWTtFQUNkO0NBQ0YsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0sV0FBVyxhQUFhLE1BQU0sVUFBVTtFQUM1QyxVQUFVLFNBQVM7R0FDakIsSUFBSSxDQUFDLE1BQU0sT0FBTztHQUNsQixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU87SUFBRSxHQUFHO0tBQU8sS0FBSyxLQUFLO0dBQU07R0FDMUQsTUFBTSxDQUFDLE9BQU8sT0FBTztHQUNyQixPQUFPO0lBQUUsR0FBRztLQUFPLFFBQVE7S0FBRSxHQUFHLEtBQUs7TUFBUyxNQUFNO0lBQU07R0FBRTtFQUM5RCxDQUFDO0NBQ0gsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLHdCQUF3QixhQUFhLE9BQU8sVUFBVTtFQUMxRCxVQUFVLFNBQVM7R0FDakIsSUFBSSxDQUFDLE1BQU0sT0FBTztHQUNsQixNQUFNLE9BQU8sQ0FBQyxHQUFHLEtBQUssYUFBYTtHQUNuQyxLQUFLLFNBQVM7R0FDZCxPQUFPO0lBQUUsR0FBRztJQUFNLGVBQWU7R0FBSztFQUN4QyxDQUFDO0NBQ0gsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGFBQWEsWUFBWSxZQUFZO0VBQ3pDLElBQUksQ0FBQyxPQUFPO0VBQ1osVUFBVSxJQUFJO0VBQ2QsU0FBUyxJQUFJO0VBQ2IsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFNBQVMsWUFBWSxVQUFVLEtBQUs7R0FDdEQsU0FBUyxJQUFJLEtBQUs7R0FDbEIsWUFBWSxJQUFJLFlBQVksQ0FBQyxDQUFDO0dBQzlCLFNBQVMsSUFBSSxLQUFLO0VBQ3BCLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxXQUFXLHNCQUFzQjtFQUNoRCxVQUFVO0dBQ1IsVUFBVSxLQUFLO0VBQ2pCO0NBQ0YsR0FBRztFQUFDO0VBQVU7RUFBTztDQUFNLENBQUM7Q0FFNUIsSUFBSSxTQUFTO0VBQ1gsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsU0FBRDtJQUFTLE1BQU07SUFBSSxXQUFVO0lBQXVCLGVBQVk7R0FBUTs7OzthQUFDLGdCQUV0RTs7Ozs7O0NBRVQ7Q0FFQSxJQUFJLENBQUMsT0FBTztFQUNWLE9BQU8sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBbUMsU0FBUztFQUFxQjs7Ozs7Q0FDekY7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUNFLHdCQUFDLE1BQUQsWUFBSSxlQUFnQjs7Ozs7S0FDcEIsd0JBQUMsWUFBRDtNQUFZLE9BQU07TUFBUyxPQUFPLE1BQU07TUFBUSxXQUFXLE1BQU0sU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDO0tBQUk7Ozs7O0tBQzNGLHdCQUFDLFlBQUQ7TUFDRSxPQUFNO01BQ04sT0FBTyxNQUFNO01BQ2IsV0FBVyxNQUFNLFNBQVMsQ0FBQyxXQUFXLEdBQUcsQ0FBQztLQUMzQzs7Ozs7S0FDRCx3QkFBQyxZQUFEO01BQ0UsT0FBTTtNQUNOLE9BQU8sTUFBTTtNQUNiLFdBQVcsTUFBTSxTQUFTLENBQUMsY0FBYyxHQUFHLENBQUM7S0FDOUM7Ozs7O0lBQ007Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7S0FDdEIsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQW9CO0tBRTlCOzs7OztLQUNILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLE1BQU0sY0FBYyxLQUFLLEtBQUssTUFDN0Isd0JBQUMsWUFBRDtPQUVFLE9BQU8sVUFBVSxJQUFJO09BQ3JCLE9BQU87T0FDUCxXQUFXLE1BQU0sc0JBQXNCLEdBQUcsQ0FBQztPQUMzQztNQUNELEdBTE07Ozs7YUFLTixDQUNGO0tBQ0U7Ozs7O0lBQ0U7Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLHFCQUFzQjs7Ozs7S0FDMUIsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sTUFBTTtNQUNuQixXQUFXLE1BQU0sU0FBUyxDQUFDLFNBQVMsWUFBWSxHQUFHLENBQUM7S0FDckQ7Ozs7O0tBQ0Qsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sTUFBTTtNQUNuQixXQUFXLE1BQU0sU0FBUyxDQUFDLFNBQVMsU0FBUyxHQUFHLENBQUM7S0FDbEQ7Ozs7O0tBQ0Qsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sTUFBTTtNQUNuQixXQUFXLE1BQU0sU0FBUyxDQUFDLFNBQVMsTUFBTSxHQUFHLENBQUM7S0FDL0M7Ozs7O0lBQ007Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLG9CQUFxQjs7Ozs7S0FDekIsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sS0FBSztNQUNsQixXQUFXLE1BQU0sU0FBUyxDQUFDLFFBQVEsWUFBWSxHQUFHLENBQUM7S0FDcEQ7Ozs7O0tBQ0Qsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sS0FBSztNQUNsQixXQUFXLE1BQU0sU0FBUyxDQUFDLFFBQVEsU0FBUyxHQUFHLENBQUM7S0FDakQ7Ozs7O0tBQ0Qsd0JBQUMsWUFBRDtNQUNFLE9BQU07TUFDTixPQUFPLE1BQU0sS0FBSztNQUNsQixXQUFXLE1BQU0sU0FBUyxDQUFDLFFBQVEsTUFBTSxHQUFHLENBQUM7S0FDOUM7Ozs7O0lBQ007Ozs7OztHQUVULHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2NBQ3BCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxhQUFEO01BQWEsT0FBTTtNQUFhLFNBQVMsTUFBTTtNQUFjO0tBQVE7Ozs7ZUFDckUsd0JBQUMsYUFBRDtNQUFhLE9BQU07TUFBWSxTQUFTLE1BQU07TUFBYTtLQUFROzs7O2FBQ2hFOzs7OztZQUNFOzs7Ozs7R0FFVCx3QkFBQyxpQkFBRCxZQUNHLFNBQVMsU0FBUyxLQUNqQix3QkFBQyxPQUFPLElBQVI7SUFDRSxXQUFVO0lBQ1YsU0FBUztLQUFFLFNBQVM7S0FBRyxRQUFRO0lBQUU7SUFDakMsU0FBUztLQUFFLFNBQVM7S0FBRyxRQUFRO0lBQU87SUFDdEMsTUFBTTtLQUFFLFNBQVM7S0FBRyxRQUFRO0lBQUU7Y0FFN0IsU0FBUyxLQUFLLE1BQ2Isd0JBQUMsTUFBRDtLQUFZLFdBQVU7ZUFBdEI7TUFDRSx3QkFBQyxlQUFEO09BQWUsTUFBTTtPQUFJLGVBQVk7TUFBUTs7Ozs7TUFBQztNQUFFO0tBQzlDO09BRks7Ozs7V0FFTCxDQUNMO0dBQ1E7Ozs7WUFFRTs7Ozs7R0FFaEIsU0FBUyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUEyQjtHQUFTOzs7OztHQUUzRCx3QkFBQyxPQUFPLFFBQVI7SUFDRSxNQUFLO0lBQ0wsV0FBVTtJQUNWLFNBQVM7SUFDVCxVQUFVO0lBQ1YsVUFBVSxFQUFFLE9BQU8sSUFBSztjQUV2QixTQUFTLFlBQVk7R0FDVDs7Ozs7RUFDWjs7Ozs7O0FBRVQ7OztBQUVBLFNBQVMsV0FBVyxFQUFFLE9BQU8sT0FBTyxVQUFVLFVBQVUsU0FBUztDQUMvRCxPQUNFLHdCQUFDLFNBQUQ7RUFBTyxXQUFXLHNCQUFzQixVQUFVLCtCQUErQjtZQUFqRixDQUNFLHdCQUFDLFNBQUQ7R0FDRSxNQUFLO0dBQ0U7R0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztHQUN4QyxjQUFZO0VBQ2I7Ozs7WUFDRCx3QkFBQyxRQUFELFlBQU8sTUFBWTs7OztVQUNkOzs7Ozs7QUFFWDs7QUFFQSxTQUFTLFlBQVksRUFBRSxPQUFPLFNBQVMsU0FBUztDQUM5QyxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFVO0VBQ1YsT0FBTztHQUFFLFlBQVksUUFBUTtHQUFZLE9BQU8sUUFBUTtFQUFLO1lBRi9EO0dBSUUsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBOEI7R0FBUzs7Ozs7R0FDcEQsd0JBQUMsTUFBRDtJQUFJLE9BQU8sRUFBRSxPQUFPLE1BQU0sYUFBYTtjQUFHO0dBQWtCOzs7OztHQUM1RCx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUErQixPQUFPLEVBQUUsWUFBWSxRQUFRLFFBQVE7Y0FBRztHQUVqRjs7Ozs7R0FDTCx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7SUFDVixPQUFPO0tBQUUsWUFBWSxNQUFNO0tBQVEsT0FBTztJQUFPO2NBQ2xEO0dBRU87Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRoZW1lRWRpdG9yLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQW5pbWF0ZVByZXNlbmNlLCBtb3Rpb24gfSBmcm9tICdtb3Rpb24vcmVhY3QnXG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdGhlbWVBcGkgfSBmcm9tICcuL3RoZW1lQXBpJ1xuXG4vKipcbiAqIFRoZW1lRWRpdG9yIOKAlCBDTVMgY29sb3ItcGlja2VyIFVJIGZvciBhIGNvdXJzZSdzIHBlci1jb3Vyc2UgdGhlbWVcbiAqICgxNi10aGVtaW5nKS4gTmV2ZXIgZXhwb3NlcyByYXcgSlNPTjogZXZlcnkgZmllbGQgaXMgYSBuYXRpdmVcbiAqIGA8aW5wdXQgdHlwZT1cImNvbG9yXCI+YCBzd2F0Y2gsIHdpdGggYSBsaXZlIHByZXZpZXcgcGFuZWwgYW5kIGlubGluZVxuICogV0NBRyBjb250cmFzdCB3YXJuaW5ncyBzb3VyY2VkIGZyb20gdGhlIGJhY2tlbmQgKHJvdXRlcnMvdGhlbWUucHknc1xuICogYHdhcm5pbmdzYCBhcnJheSwgY29tcHV0ZWQgYnkgdXRpbHMvY29udHJhc3QucHkpLlxuICpcbiAqIFByb3BzOlxuICogICAtIGNvdXJzZUlkIChzdHJpbmd8bnVtYmVyLCByZXF1aXJlZCk6IHdoaWNoIGNvdXJzZSdzIHRoZW1lIHRvIGxvYWRcbiAqICAgICBhbmQgc2F2ZS4gVXNlZCBhcyBgL2NvdXJzZXMve2NvdXJzZUlkfS90aGVtZWAuXG4gKiAgIC0gb25TYXZlIChmdW5jdGlvbih0aGVtZSksIG9wdGlvbmFsKTogY2FsbGVkIGFmdGVyIGEgc3VjY2Vzc2Z1bCBzYXZlXG4gKiAgICAgd2l0aCB0aGUgc2F2ZWQgQ291cnNlVGhlbWUgb2JqZWN0IOKAlCBlLmcuIHNvIGEgaG9zdGluZyBDTVMgcGFnZSBjYW5cbiAqICAgICByZWZyZXNoIGEgY291cnNlIGxpc3QncyBzd2F0Y2guIFRoZSBjb21wb25lbnQgYWx3YXlzIHNhdmVzIHZpYSBpdHNcbiAqICAgICBvd24gdGhlbWVBcGkgY2FsbCByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhpcyBpcyBwcm92aWRlZDsgaXQncyBhXG4gKiAgICAgbm90aWZpY2F0aW9uIGhvb2ssIG5vdCBhIHN1YnN0aXR1dGUgZm9yIHRoZSBBUEkgY2FsbC5cbiAqXG4gKiBTZWxmLWNvbnRhaW5lZDogZmV0Y2hlcyB0aGUgY3VycmVudCB0aGVtZSBvbiBtb3VudCwgZWRpdHMgYXJlIGxvY2FsXG4gKiB1bnRpbCBcIlNhdmUgdGhlbWVcIiBpcyBjbGlja2VkLiBOb3QgeWV0IHdpcmVkIGludG8gYSByb3V0ZS9wYWdlIOKAlCB0aGVcbiAqIENNUyB3b3Jrc3BhY2UgaG9zdGluZyBpdCBpcyBiZWluZyBidWlsdCBzZXBhcmF0ZWx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gVGhlbWVFZGl0b3IoeyBjb3Vyc2VJZCwgb25TYXZlIH0pIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZShudWxsKVxuICBjb25zdCBbd2FybmluZ3MsIHNldFdhcm5pbmdzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxuICAgIHNldExvYWRpbmcodHJ1ZSlcbiAgICB0aGVtZUFwaVxuICAgICAgLmdldFRoZW1lKGNvdXJzZUlkKVxuICAgICAgLnRoZW4oKHJlcykgPT4ge1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm5cbiAgICAgICAgc2V0VGhlbWUocmVzLnRoZW1lKVxuICAgICAgICBzZXRXYXJuaW5ncyhyZXMud2FybmluZ3MgPz8gW10pXG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnIpID0+ICFjYW5jZWxsZWQgJiYgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgPz8gJ0ZhaWxlZCB0byBsb2FkIHRoZW1lJykpXG4gICAgICAuZmluYWxseSgoKSA9PiAhY2FuY2VsbGVkICYmIHNldExvYWRpbmcoZmFsc2UpKVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlXG4gICAgfVxuICB9LCBbY291cnNlSWRdKVxuXG4gIGNvbnN0IHNldEZpZWxkID0gdXNlQ2FsbGJhY2soKHBhdGgsIHZhbHVlKSA9PiB7XG4gICAgc2V0VGhlbWUoKHByZXYpID0+IHtcbiAgICAgIGlmICghcHJldikgcmV0dXJuIHByZXZcbiAgICAgIGlmIChwYXRoLmxlbmd0aCA9PT0gMSkgcmV0dXJuIHsgLi4ucHJldiwgW3BhdGhbMF1dOiB2YWx1ZSB9XG4gICAgICBjb25zdCBbZ3JvdXAsIGtleV0gPSBwYXRoXG4gICAgICByZXR1cm4geyAuLi5wcmV2LCBbZ3JvdXBdOiB7IC4uLnByZXZbZ3JvdXBdLCBba2V5XTogdmFsdWUgfSB9XG4gICAgfSlcbiAgfSwgW10pXG5cbiAgY29uc3Qgc2V0TW9kdWxlUGFsZXR0ZUNvbG9yID0gdXNlQ2FsbGJhY2soKGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgIHNldFRoZW1lKChwcmV2KSA9PiB7XG4gICAgICBpZiAoIXByZXYpIHJldHVybiBwcmV2XG4gICAgICBjb25zdCBuZXh0ID0gWy4uLnByZXYubW9kdWxlUGFsZXR0ZV1cbiAgICAgIG5leHRbaW5kZXhdID0gdmFsdWVcbiAgICAgIHJldHVybiB7IC4uLnByZXYsIG1vZHVsZVBhbGV0dGU6IG5leHQgfVxuICAgIH0pXG4gIH0sIFtdKVxuXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCF0aGVtZSkgcmV0dXJuXG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgc2V0RXJyb3IobnVsbClcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhlbWVBcGkudXBkYXRlVGhlbWUoY291cnNlSWQsIHRoZW1lKVxuICAgICAgc2V0VGhlbWUocmVzLnRoZW1lKVxuICAgICAgc2V0V2FybmluZ3MocmVzLndhcm5pbmdzID8/IFtdKVxuICAgICAgb25TYXZlPy4ocmVzLnRoZW1lKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgPz8gJ0ZhaWxlZCB0byBzYXZlIHRoZW1lJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfSwgW2NvdXJzZUlkLCB0aGVtZSwgb25TYXZlXSlcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvciB0aGVtZS1lZGl0b3ItbG9hZGluZ1wiPlxuICAgICAgICA8TG9hZGVyMiBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXNwaW5uZXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICBMb2FkaW5nIHRoZW1l4oCmXG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICBpZiAoIXRoZW1lKSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yIHRoZW1lLWVkaXRvci1lcnJvclwiPntlcnJvciA/PyAnTm8gdGhlbWUgZGF0YSd9PC9kaXY+XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yXCI+XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJ0aGVtZS1lZGl0b3Itc2VjdGlvblwiPlxuICAgICAgICA8aDM+QnJhbmQgY29sb3JzPC9oMz5cbiAgICAgICAgPENvbG9yRmllbGQgbGFiZWw9XCJBY2NlbnRcIiB2YWx1ZT17dGhlbWUuYWNjZW50fSBvbkNoYW5nZT17KHYpID0+IHNldEZpZWxkKFsnYWNjZW50J10sIHYpfSAvPlxuICAgICAgICA8Q29sb3JGaWVsZFxuICAgICAgICAgIGxhYmVsPVwiU2Vjb25kYXJ5XCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUuc2Vjb25kYXJ5fVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydzZWNvbmRhcnknXSwgdil9XG4gICAgICAgIC8+XG4gICAgICAgIDxDb2xvckZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJIZWFkaW5nIGNvbG9yXCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUuaGVhZGluZ0NvbG9yfVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydoZWFkaW5nQ29sb3InXSwgdil9XG4gICAgICAgIC8+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1zZWN0aW9uXCI+XG4gICAgICAgIDxoMz5Nb2R1bGUgcGFsZXR0ZTwvaDM+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1oaW50XCI+XG4gICAgICAgICAgQ3ljbGVzIGFjcm9zcyBtb2R1bGVzIGluIG9yZGVyOyBhc3NpZ24gZXh0cmEgbW9kdWxlcyByZS11c2UgdGhlc2UgY29sb3JzLlxuICAgICAgICA8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXN3YXRjaC1yb3dcIj5cbiAgICAgICAgICB7dGhlbWUubW9kdWxlUGFsZXR0ZS5tYXAoKGhleCwgaSkgPT4gKFxuICAgICAgICAgICAgPENvbG9yRmllbGRcbiAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICBsYWJlbD17YE1vZHVsZSAke2kgKyAxfWB9XG4gICAgICAgICAgICAgIHZhbHVlPXtoZXh9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0TW9kdWxlUGFsZXR0ZUNvbG9yKGksIHYpfVxuICAgICAgICAgICAgICBjb21wYWN0XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXNlY3Rpb25cIj5cbiAgICAgICAgPGgzPkxpZ2h0IG1vZGUgcGFsZXR0ZTwvaDM+XG4gICAgICAgIDxDb2xvckZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJCYWNrZ3JvdW5kXCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUubGlnaHQuYmFja2dyb3VuZH1cbiAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldEZpZWxkKFsnbGlnaHQnLCAnYmFja2dyb3VuZCddLCB2KX1cbiAgICAgICAgLz5cbiAgICAgICAgPENvbG9yRmllbGRcbiAgICAgICAgICBsYWJlbD1cIlN1cmZhY2VcIlxuICAgICAgICAgIHZhbHVlPXt0aGVtZS5saWdodC5zdXJmYWNlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydsaWdodCcsICdzdXJmYWNlJ10sIHYpfVxuICAgICAgICAvPlxuICAgICAgICA8Q29sb3JGaWVsZFxuICAgICAgICAgIGxhYmVsPVwiVGV4dFwiXG4gICAgICAgICAgdmFsdWU9e3RoZW1lLmxpZ2h0LnRleHR9XG4gICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXRGaWVsZChbJ2xpZ2h0JywgJ3RleHQnXSwgdil9XG4gICAgICAgIC8+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1zZWN0aW9uXCI+XG4gICAgICAgIDxoMz5EYXJrIG1vZGUgcGFsZXR0ZTwvaDM+XG4gICAgICAgIDxDb2xvckZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJCYWNrZ3JvdW5kXCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUuZGFyay5iYWNrZ3JvdW5kfVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydkYXJrJywgJ2JhY2tncm91bmQnXSwgdil9XG4gICAgICAgIC8+XG4gICAgICAgIDxDb2xvckZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJTdXJmYWNlXCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUuZGFyay5zdXJmYWNlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydkYXJrJywgJ3N1cmZhY2UnXSwgdil9XG4gICAgICAgIC8+XG4gICAgICAgIDxDb2xvckZpZWxkXG4gICAgICAgICAgbGFiZWw9XCJUZXh0XCJcbiAgICAgICAgICB2YWx1ZT17dGhlbWUuZGFyay50ZXh0fVxuICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0RmllbGQoWydkYXJrJywgJ3RleHQnXSwgdil9XG4gICAgICAgIC8+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1zZWN0aW9uIHRoZW1lLWVkaXRvci1wcmV2aWV3XCI+XG4gICAgICAgIDxoMz5MaXZlIHByZXZpZXc8L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1wcmV2aWV3LWdyaWRcIj5cbiAgICAgICAgICA8UHJldmlld0NhcmQgdGl0bGU9XCJMaWdodCBtb2RlXCIgcGFsZXR0ZT17dGhlbWUubGlnaHR9IHRoZW1lPXt0aGVtZX0gLz5cbiAgICAgICAgICA8UHJldmlld0NhcmQgdGl0bGU9XCJEYXJrIG1vZGVcIiBwYWxldHRlPXt0aGVtZS5kYXJrfSB0aGVtZT17dGhlbWV9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7d2FybmluZ3MubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPG1vdGlvbi51bFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXdhcm5pbmdzXCJcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgaGVpZ2h0OiAwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIGhlaWdodDogJ2F1dG8nIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIGhlaWdodDogMCB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt3YXJuaW5ncy5tYXAoKHcpID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17d30gY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXdhcm5pbmdcIj5cbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4ge3d9XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L21vdGlvbi51bD5cbiAgICAgICAgKX1cbiAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLWVycm9yLXRleHRcIj57ZXJyb3J9PC9wPn1cblxuICAgICAgPG1vdGlvbi5idXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1zYXZlXCJcbiAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZX1cbiAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ31cbiAgICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOTcgfX1cbiAgICAgID5cbiAgICAgICAge3NhdmluZyA/ICdTYXZpbmfigKYnIDogJ1NhdmUgdGhlbWUnfVxuICAgICAgPC9tb3Rpb24uYnV0dG9uPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIENvbG9yRmllbGQoeyBsYWJlbCwgdmFsdWUsIG9uQ2hhbmdlLCBjb21wYWN0ID0gZmFsc2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxsYWJlbCBjbGFzc05hbWU9e2B0aGVtZS1lZGl0b3ItZmllbGQgJHtjb21wYWN0ID8gJ3RoZW1lLWVkaXRvci1maWVsZC1jb21wYWN0JyA6ICcnfWB9PlxuICAgICAgPGlucHV0XG4gICAgICAgIHR5cGU9XCJjb2xvclwiXG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIGFyaWEtbGFiZWw9e2xhYmVsfVxuICAgICAgLz5cbiAgICAgIDxzcGFuPntsYWJlbH08L3NwYW4+XG4gICAgPC9sYWJlbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBQcmV2aWV3Q2FyZCh7IHRpdGxlLCBwYWxldHRlLCB0aGVtZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwidGhlbWUtZWRpdG9yLXByZXZpZXctY2FyZFwiXG4gICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiBwYWxldHRlLmJhY2tncm91bmQsIGNvbG9yOiBwYWxldHRlLnRleHQgfX1cbiAgICA+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0aGVtZS1lZGl0b3ItcHJldmlldy1sYWJlbFwiPnt0aXRsZX08L3A+XG4gICAgICA8aDQgc3R5bGU9e3sgY29sb3I6IHRoZW1lLmhlYWRpbmdDb2xvciB9fT5TYW1wbGUgaGVhZGluZzwvaDQ+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRoZW1lLWVkaXRvci1wcmV2aWV3LXN1cmZhY2VcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiBwYWxldHRlLnN1cmZhY2UgfX0+XG4gICAgICAgIFNhbXBsZSBib2R5IHRleHQgb24gYSBzdXJmYWNlIGJsb2NrLlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9XCJ0aGVtZS1lZGl0b3ItcHJldmlldy1idXR0b25cIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kOiB0aGVtZS5hY2NlbnQsIGNvbG9yOiAnI2ZmZicgfX1cbiAgICAgID5cbiAgICAgICAgU2FtcGxlIGJ1dHRvblxuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==