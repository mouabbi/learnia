import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/health/BackendGate.jsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { fetchHealth } from "/src/features/health/healthApi.js";
import { createLogger } from "/src/utils/logger.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/health/BackendGate.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const log = createLogger("health");
/**
* Wraps the whole app: nothing (login, routes, auth check) renders until
* GET /health succeeds. Without this, a down backend shows up as a
* confusing "invalid credentials"-style failure on the login page instead
* of the real problem.
*/
export function BackendGate({ children }) {
	_s();
	const [status, setStatus] = useState("checking");
	const check = useCallback(() => {
		fetchHealth().then(() => {
			log.info("backend reachable");
			setStatus("ok");
		}).catch(() => {
			log.error("backend unreachable");
			setStatus("down");
		});
	}, []);
	// Initial state is already 'checking', so the first run needn't reset it
	// (setting state synchronously inside an effect is flagged by the linter).
	useEffect(() => {
		check();
	}, [check]);
	function retry() {
		setStatus("checking");
		check();
	}
	if (status === "checking") {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "page",
			children: /* @__PURE__ */ _jsxDEV("p", { children: "Connecting to server..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this);
	}
	if (status === "down") {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "page",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", { children: "Server unreachable" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: "Could not reach the backend. Make sure it is running, then retry." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: retry,
					children: "Retry"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this);
	}
	return children;
}
_s(BackendGate, "jQHuPbiL1dSHHPwE734xqsycRq4=");
_c = BackendGate;
var _c;
$RefreshReg$(_c, "BackendGate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/health/BackendGate.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/health/BackendGate.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/health/BackendGate.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/health/BackendGate.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBQ2pELFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsb0JBQW9COzs7O0FBRTdCLE1BQU0sTUFBTSxhQUFhLFFBQVE7Ozs7Ozs7QUFRakMsT0FBTyxTQUFTLFlBQVksRUFBRSxZQUFZOztDQUN4QyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsVUFBVTtDQUUvQyxNQUFNLFFBQVEsa0JBQWtCO0VBQzlCLFlBQVksQ0FBQyxDQUNWLFdBQVc7R0FDVixJQUFJLEtBQUssbUJBQW1CO0dBQzVCLFVBQVUsSUFBSTtFQUNoQixDQUFDLENBQUMsQ0FDRCxZQUFZO0dBQ1gsSUFBSSxNQUFNLHFCQUFxQjtHQUMvQixVQUFVLE1BQU07RUFDbEIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxDQUFDOzs7Q0FJTCxnQkFBZ0I7RUFDZCxNQUFNO0NBQ1IsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLFNBQVMsUUFBUTtFQUNmLFVBQVUsVUFBVTtFQUNwQixNQUFNO0NBQ1I7Q0FFQSxJQUFJLFdBQVcsWUFBWTtFQUN6QixPQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQ2pCLHdCQUFDLEtBQUQsWUFBRywwQkFBMEI7Ozs7O0VBQ3RCOzs7OztDQUViO0NBRUEsSUFBSSxXQUFXLFFBQVE7RUFDckIsT0FDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNFLHdCQUFDLE1BQUQsWUFBSSxxQkFBc0I7Ozs7O0lBQzFCLHdCQUFDLEtBQUQsWUFBRyxvRUFBb0U7Ozs7O0lBQ3ZFLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsU0FBUztlQUFPO0lBRTlCOzs7OztHQUNEOzs7Ozs7Q0FFYjtDQUVBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCYWNrZW5kR2F0ZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgZmV0Y2hIZWFsdGggfSBmcm9tICcuL2hlYWx0aEFwaSdcclxuaW1wb3J0IHsgY3JlYXRlTG9nZ2VyIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2VyJ1xyXG5cclxuY29uc3QgbG9nID0gY3JlYXRlTG9nZ2VyKCdoZWFsdGgnKVxyXG5cclxuLyoqXHJcbiAqIFdyYXBzIHRoZSB3aG9sZSBhcHA6IG5vdGhpbmcgKGxvZ2luLCByb3V0ZXMsIGF1dGggY2hlY2spIHJlbmRlcnMgdW50aWxcclxuICogR0VUIC9oZWFsdGggc3VjY2VlZHMuIFdpdGhvdXQgdGhpcywgYSBkb3duIGJhY2tlbmQgc2hvd3MgdXAgYXMgYVxyXG4gKiBjb25mdXNpbmcgXCJpbnZhbGlkIGNyZWRlbnRpYWxzXCItc3R5bGUgZmFpbHVyZSBvbiB0aGUgbG9naW4gcGFnZSBpbnN0ZWFkXHJcbiAqIG9mIHRoZSByZWFsIHByb2JsZW0uXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gQmFja2VuZEdhdGUoeyBjaGlsZHJlbiB9KSB7XHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKCdjaGVja2luZycpIC8vIGNoZWNraW5nIHwgb2sgfCBkb3duXHJcblxyXG4gIGNvbnN0IGNoZWNrID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgZmV0Y2hIZWFsdGgoKVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgbG9nLmluZm8oJ2JhY2tlbmQgcmVhY2hhYmxlJylcclxuICAgICAgICBzZXRTdGF0dXMoJ29rJylcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICBsb2cuZXJyb3IoJ2JhY2tlbmQgdW5yZWFjaGFibGUnKVxyXG4gICAgICAgIHNldFN0YXR1cygnZG93bicpXHJcbiAgICAgIH0pXHJcbiAgfSwgW10pXHJcblxyXG4gIC8vIEluaXRpYWwgc3RhdGUgaXMgYWxyZWFkeSAnY2hlY2tpbmcnLCBzbyB0aGUgZmlyc3QgcnVuIG5lZWRuJ3QgcmVzZXQgaXRcclxuICAvLyAoc2V0dGluZyBzdGF0ZSBzeW5jaHJvbm91c2x5IGluc2lkZSBhbiBlZmZlY3QgaXMgZmxhZ2dlZCBieSB0aGUgbGludGVyKS5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY2hlY2soKVxyXG4gIH0sIFtjaGVja10pXHJcblxyXG4gIGZ1bmN0aW9uIHJldHJ5KCkge1xyXG4gICAgc2V0U3RhdHVzKCdjaGVja2luZycpXHJcbiAgICBjaGVjaygpXHJcbiAgfVxyXG5cclxuICBpZiAoc3RhdHVzID09PSAnY2hlY2tpbmcnKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwYWdlXCI+XHJcbiAgICAgICAgPHA+Q29ubmVjdGluZyB0byBzZXJ2ZXIuLi48L3A+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIGlmIChzdGF0dXMgPT09ICdkb3duJykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICAgIDxoMT5TZXJ2ZXIgdW5yZWFjaGFibGU8L2gxPlxyXG4gICAgICAgIDxwPkNvdWxkIG5vdCByZWFjaCB0aGUgYmFja2VuZC4gTWFrZSBzdXJlIGl0IGlzIHJ1bm5pbmcsIHRoZW4gcmV0cnkuPC9wPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e3JldHJ5fT5cclxuICAgICAgICAgIFJldHJ5XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIHJldHVybiBjaGlsZHJlblxyXG59XHJcbiJdfQ==