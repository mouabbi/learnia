import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ButtonSpinner.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/ButtonSpinner.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Small spinning ring for inside a button's pending state (e.g. "Enrolling…").
// Uses currentColor so it matches whatever text color the button has.
export function ButtonSpinner() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "btn-spinner",
		"aria-hidden": "true"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = ButtonSpinner;
var _c;
$RefreshReg$(_c, "ButtonSpinner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ButtonSpinner.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/ButtonSpinner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/ButtonSpinner.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/ButtonSpinner.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUVBLE9BQU8sU0FBUyxnQkFBZ0I7Q0FDOUIsT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLGVBQVk7Q0FBUTs7Ozs7QUFDM0QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQnV0dG9uU3Bpbm5lci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLy8gU21hbGwgc3Bpbm5pbmcgcmluZyBmb3IgaW5zaWRlIGEgYnV0dG9uJ3MgcGVuZGluZyBzdGF0ZSAoZS5nLiBcIkVucm9sbGluZ+KAplwiKS5cclxuLy8gVXNlcyBjdXJyZW50Q29sb3Igc28gaXQgbWF0Y2hlcyB3aGF0ZXZlciB0ZXh0IGNvbG9yIHRoZSBidXR0b24gaGFzLlxyXG5leHBvcnQgZnVuY3Rpb24gQnV0dG9uU3Bpbm5lcigpIHtcclxuICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiYnRuLXNwaW5uZXJcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxyXG59XHJcbiJdfQ==