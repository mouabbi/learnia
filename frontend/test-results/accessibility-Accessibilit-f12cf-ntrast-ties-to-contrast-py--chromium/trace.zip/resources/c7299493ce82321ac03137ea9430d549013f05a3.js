// WebAudio cues for the final exam — deliberately more serious/tense than
// the module-quiz cues in features/courses/quizSound.js (lower, sparser
// tones; no playful major arpeggios) to match the "proctored assessment"
// framing. No audio assets needed. Best-effort: silently no-ops if
// WebAudio is unavailable or blocked.
let sharedCtx = null;
function getContext() {
	if (typeof window === "undefined") return null;
	const Ctx = window.AudioContext || window.webkitAudioContext;
	if (!Ctx) return null;
	if (!sharedCtx) sharedCtx = new Ctx();
	return sharedCtx;
}
function tone(ctx, when, freq, duration, peakGain, type = "sine") {
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = type;
	osc.frequency.value = freq;
	gain.gain.setValueAtTime(0, when);
	gain.gain.linearRampToValueAtTime(peakGain, when + .03);
	gain.gain.exponentialRampToValueAtTime(6e-4, when + duration);
	osc.connect(gain);
	gain.connect(ctx.destination);
	osc.start(when);
	osc.stop(when + duration + .05);
}
// Low two-note "attention" cue when the timed exam actually begins.
export function playExamStartCue() {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		tone(ctx, now, 220, .4, .09, "triangle");
		tone(ctx, now + .18, 164.81, .55, .1, "triangle");
	} catch {}
}
// Sharp, short alert blip — tab-switch detected.
export function playExamAlertCue() {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		tone(ctx, now, 880, .18, .08, "square");
		tone(ctx, now + .12, 660, .18, .07, "square");
	} catch {}
}
// Neutral, clinical tick — one per grading step during processing.
export function playExamGradingTick() {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		tone(ctx, now, 340, .12, .045, "triangle");
	} catch {}
}
// Result cue shaped by score — a strong but composed fanfare for a pass
// (not the bright bouncy quiz chime), a grave, quiet cue for a fail.
export function playExamResultCue(pct, passingPct) {
	try {
		const ctx = getContext();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		if (pct === 100) {
			;
			[
				261.63,
				329.63,
				392,
				523.25
			].forEach((freq, i) => tone(ctx, now + i * .12, freq, .7, .1, "triangle"));
		} else if (pct >= passingPct) {
			;
			[
				220,
				277.18,
				329.63
			].forEach((freq, i) => tone(ctx, now + i * .13, freq, .65, .1, "triangle"));
		} else {
			;
			[
				196,
				174.61,
				146.83
			].forEach((freq, i) => tone(ctx, now + i * .22, freq, .8, .07, "sine"));
		}
	} catch {}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxJQUFJLFlBQVk7QUFFaEIsU0FBUyxhQUFhO0NBQ3BCLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxNQUFNLE1BQU0sT0FBTyxnQkFBZ0IsT0FBTztDQUMxQyxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksQ0FBQyxXQUFXLFlBQVksSUFBSSxJQUFJO0NBQ3BDLE9BQU87QUFDVDtBQUVBLFNBQVMsS0FBSyxLQUFLLE1BQU0sTUFBTSxVQUFVLFVBQVUsT0FBTyxRQUFRO0NBQ2hFLE1BQU0sTUFBTSxJQUFJLGlCQUFpQjtDQUNqQyxNQUFNLE9BQU8sSUFBSSxXQUFXO0NBQzVCLElBQUksT0FBTztDQUNYLElBQUksVUFBVSxRQUFRO0NBQ3RCLEtBQUssS0FBSyxlQUFlLEdBQUcsSUFBSTtDQUNoQyxLQUFLLEtBQUssd0JBQXdCLFVBQVUsT0FBTyxHQUFJO0NBQ3ZELEtBQUssS0FBSyw2QkFBNkIsTUFBUSxPQUFPLFFBQVE7Q0FDOUQsSUFBSSxRQUFRLElBQUk7Q0FDaEIsS0FBSyxRQUFRLElBQUksV0FBVztDQUM1QixJQUFJLE1BQU0sSUFBSTtDQUNkLElBQUksS0FBSyxPQUFPLFdBQVcsR0FBSTtBQUNqQzs7QUFHQSxPQUFPLFNBQVMsbUJBQW1CO0NBQ2pDLElBQUk7RUFDRixNQUFNLE1BQU0sV0FBVztFQUN2QixJQUFJLENBQUMsS0FBSztFQUNWLElBQUksSUFBSSxVQUFVLGFBQWEsSUFBSSxPQUFPO0VBQzFDLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSyxLQUFNLFVBQVU7RUFDekMsS0FBSyxLQUFLLE1BQU0sS0FBTSxRQUFRLEtBQU0sSUFBSyxVQUFVO0NBQ3JELFFBQVEsQ0FFUjtBQUNGOztBQUdBLE9BQU8sU0FBUyxtQkFBbUI7Q0FDakMsSUFBSTtFQUNGLE1BQU0sTUFBTSxXQUFXO0VBQ3ZCLElBQUksQ0FBQyxLQUFLO0VBQ1YsSUFBSSxJQUFJLFVBQVUsYUFBYSxJQUFJLE9BQU87RUFDMUMsTUFBTSxNQUFNLElBQUk7RUFDaEIsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFNLEtBQU0sUUFBUTtFQUN4QyxLQUFLLEtBQUssTUFBTSxLQUFNLEtBQUssS0FBTSxLQUFNLFFBQVE7Q0FDakQsUUFBUSxDQUVSO0FBQ0Y7O0FBR0EsT0FBTyxTQUFTLHNCQUFzQjtDQUNwQyxJQUFJO0VBQ0YsTUFBTSxNQUFNLFdBQVc7RUFDdkIsSUFBSSxDQUFDLEtBQUs7RUFDVixJQUFJLElBQUksVUFBVSxhQUFhLElBQUksT0FBTztFQUMxQyxNQUFNLE1BQU0sSUFBSTtFQUNoQixLQUFLLEtBQUssS0FBSyxLQUFLLEtBQU0sTUFBTyxVQUFVO0NBQzdDLFFBQVEsQ0FFUjtBQUNGOzs7QUFJQSxPQUFPLFNBQVMsa0JBQWtCLEtBQUssWUFBWTtDQUNqRCxJQUFJO0VBQ0YsTUFBTSxNQUFNLFdBQVc7RUFDdkIsSUFBSSxDQUFDLEtBQUs7RUFDVixJQUFJLElBQUksVUFBVSxhQUFhLElBQUksT0FBTztFQUMxQyxNQUFNLE1BQU0sSUFBSTtFQUVoQixJQUFJLFFBQVEsS0FBSztHQUNmO0dBQUM7SUFBQztJQUFRO0lBQVE7SUFBTztHQUFNLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFDOUMsS0FBSyxLQUFLLE1BQU0sSUFBSSxLQUFNLE1BQU0sSUFBSyxJQUFLLFVBQVUsQ0FDdEQ7RUFDRixPQUFPLElBQUksT0FBTyxZQUFZO0dBQzVCO0dBQUM7SUFBQztJQUFLO0lBQVE7R0FBTSxDQUFDLENBQUMsU0FBUyxNQUFNLE1BQU0sS0FBSyxLQUFLLE1BQU0sSUFBSSxLQUFNLE1BQU0sS0FBTSxJQUFLLFVBQVUsQ0FBQztFQUNwRyxPQUFPO0dBQ0w7R0FBQztJQUFDO0lBQUs7SUFBUTtHQUFNLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQU0sTUFBTSxJQUFLLEtBQU0sTUFBTSxDQUFDO0VBQ2hHO0NBQ0YsUUFBUSxDQUVSO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZXhhbVNvdW5kLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkF1ZGlvIGN1ZXMgZm9yIHRoZSBmaW5hbCBleGFtIOKAlCBkZWxpYmVyYXRlbHkgbW9yZSBzZXJpb3VzL3RlbnNlIHRoYW5cclxuLy8gdGhlIG1vZHVsZS1xdWl6IGN1ZXMgaW4gZmVhdHVyZXMvY291cnNlcy9xdWl6U291bmQuanMgKGxvd2VyLCBzcGFyc2VyXHJcbi8vIHRvbmVzOyBubyBwbGF5ZnVsIG1ham9yIGFycGVnZ2lvcykgdG8gbWF0Y2ggdGhlIFwicHJvY3RvcmVkIGFzc2Vzc21lbnRcIlxyXG4vLyBmcmFtaW5nLiBObyBhdWRpbyBhc3NldHMgbmVlZGVkLiBCZXN0LWVmZm9ydDogc2lsZW50bHkgbm8tb3BzIGlmXHJcbi8vIFdlYkF1ZGlvIGlzIHVuYXZhaWxhYmxlIG9yIGJsb2NrZWQuXHJcbmxldCBzaGFyZWRDdHggPSBudWxsXHJcblxyXG5mdW5jdGlvbiBnZXRDb250ZXh0KCkge1xyXG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuIG51bGxcclxuICBjb25zdCBDdHggPSB3aW5kb3cuQXVkaW9Db250ZXh0IHx8IHdpbmRvdy53ZWJraXRBdWRpb0NvbnRleHRcclxuICBpZiAoIUN0eCkgcmV0dXJuIG51bGxcclxuICBpZiAoIXNoYXJlZEN0eCkgc2hhcmVkQ3R4ID0gbmV3IEN0eCgpXHJcbiAgcmV0dXJuIHNoYXJlZEN0eFxyXG59XHJcblxyXG5mdW5jdGlvbiB0b25lKGN0eCwgd2hlbiwgZnJlcSwgZHVyYXRpb24sIHBlYWtHYWluLCB0eXBlID0gJ3NpbmUnKSB7XHJcbiAgY29uc3Qgb3NjID0gY3R4LmNyZWF0ZU9zY2lsbGF0b3IoKVxyXG4gIGNvbnN0IGdhaW4gPSBjdHguY3JlYXRlR2FpbigpXHJcbiAgb3NjLnR5cGUgPSB0eXBlXHJcbiAgb3NjLmZyZXF1ZW5jeS52YWx1ZSA9IGZyZXFcclxuICBnYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMCwgd2hlbilcclxuICBnYWluLmdhaW4ubGluZWFyUmFtcFRvVmFsdWVBdFRpbWUocGVha0dhaW4sIHdoZW4gKyAwLjAzKVxyXG4gIGdhaW4uZ2Fpbi5leHBvbmVudGlhbFJhbXBUb1ZhbHVlQXRUaW1lKDAuMDAwNiwgd2hlbiArIGR1cmF0aW9uKVxyXG4gIG9zYy5jb25uZWN0KGdhaW4pXHJcbiAgZ2Fpbi5jb25uZWN0KGN0eC5kZXN0aW5hdGlvbilcclxuICBvc2Muc3RhcnQod2hlbilcclxuICBvc2Muc3RvcCh3aGVuICsgZHVyYXRpb24gKyAwLjA1KVxyXG59XHJcblxyXG4vLyBMb3cgdHdvLW5vdGUgXCJhdHRlbnRpb25cIiBjdWUgd2hlbiB0aGUgdGltZWQgZXhhbSBhY3R1YWxseSBiZWdpbnMuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5RXhhbVN0YXJ0Q3VlKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjdHggPSBnZXRDb250ZXh0KClcclxuICAgIGlmICghY3R4KSByZXR1cm5cclxuICAgIGlmIChjdHguc3RhdGUgPT09ICdzdXNwZW5kZWQnKSBjdHgucmVzdW1lKClcclxuICAgIGNvbnN0IG5vdyA9IGN0eC5jdXJyZW50VGltZVxyXG4gICAgdG9uZShjdHgsIG5vdywgMjIwLCAwLjQsIDAuMDksICd0cmlhbmdsZScpXHJcbiAgICB0b25lKGN0eCwgbm93ICsgMC4xOCwgMTY0LjgxLCAwLjU1LCAwLjEsICd0cmlhbmdsZScpXHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBpZ25vcmVcclxuICB9XHJcbn1cclxuXHJcbi8vIFNoYXJwLCBzaG9ydCBhbGVydCBibGlwIOKAlCB0YWItc3dpdGNoIGRldGVjdGVkLlxyXG5leHBvcnQgZnVuY3Rpb24gcGxheUV4YW1BbGVydEN1ZSgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY3R4ID0gZ2V0Q29udGV4dCgpXHJcbiAgICBpZiAoIWN0eCkgcmV0dXJuXHJcbiAgICBpZiAoY3R4LnN0YXRlID09PSAnc3VzcGVuZGVkJykgY3R4LnJlc3VtZSgpXHJcbiAgICBjb25zdCBub3cgPSBjdHguY3VycmVudFRpbWVcclxuICAgIHRvbmUoY3R4LCBub3csIDg4MCwgMC4xOCwgMC4wOCwgJ3NxdWFyZScpXHJcbiAgICB0b25lKGN0eCwgbm93ICsgMC4xMiwgNjYwLCAwLjE4LCAwLjA3LCAnc3F1YXJlJylcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIGlnbm9yZVxyXG4gIH1cclxufVxyXG5cclxuLy8gTmV1dHJhbCwgY2xpbmljYWwgdGljayDigJQgb25lIHBlciBncmFkaW5nIHN0ZXAgZHVyaW5nIHByb2Nlc3NpbmcuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5RXhhbUdyYWRpbmdUaWNrKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjdHggPSBnZXRDb250ZXh0KClcclxuICAgIGlmICghY3R4KSByZXR1cm5cclxuICAgIGlmIChjdHguc3RhdGUgPT09ICdzdXNwZW5kZWQnKSBjdHgucmVzdW1lKClcclxuICAgIGNvbnN0IG5vdyA9IGN0eC5jdXJyZW50VGltZVxyXG4gICAgdG9uZShjdHgsIG5vdywgMzQwLCAwLjEyLCAwLjA0NSwgJ3RyaWFuZ2xlJylcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIGlnbm9yZVxyXG4gIH1cclxufVxyXG5cclxuLy8gUmVzdWx0IGN1ZSBzaGFwZWQgYnkgc2NvcmUg4oCUIGEgc3Ryb25nIGJ1dCBjb21wb3NlZCBmYW5mYXJlIGZvciBhIHBhc3NcclxuLy8gKG5vdCB0aGUgYnJpZ2h0IGJvdW5jeSBxdWl6IGNoaW1lKSwgYSBncmF2ZSwgcXVpZXQgY3VlIGZvciBhIGZhaWwuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbGF5RXhhbVJlc3VsdEN1ZShwY3QsIHBhc3NpbmdQY3QpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY3R4ID0gZ2V0Q29udGV4dCgpXHJcbiAgICBpZiAoIWN0eCkgcmV0dXJuXHJcbiAgICBpZiAoY3R4LnN0YXRlID09PSAnc3VzcGVuZGVkJykgY3R4LnJlc3VtZSgpXHJcbiAgICBjb25zdCBub3cgPSBjdHguY3VycmVudFRpbWVcclxuXHJcbiAgICBpZiAocGN0ID09PSAxMDApIHtcclxuICAgICAgO1syNjEuNjMsIDMyOS42MywgMzkyLjAsIDUyMy4yNV0uZm9yRWFjaCgoZnJlcSwgaSkgPT5cclxuICAgICAgICB0b25lKGN0eCwgbm93ICsgaSAqIDAuMTIsIGZyZXEsIDAuNywgMC4xLCAndHJpYW5nbGUnKSxcclxuICAgICAgKVxyXG4gICAgfSBlbHNlIGlmIChwY3QgPj0gcGFzc2luZ1BjdCkge1xyXG4gICAgICA7WzIyMCwgMjc3LjE4LCAzMjkuNjNdLmZvckVhY2goKGZyZXEsIGkpID0+IHRvbmUoY3R4LCBub3cgKyBpICogMC4xMywgZnJlcSwgMC42NSwgMC4xLCAndHJpYW5nbGUnKSlcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIDtbMTk2LCAxNzQuNjEsIDE0Ni44M10uZm9yRWFjaCgoZnJlcSwgaSkgPT4gdG9uZShjdHgsIG5vdyArIGkgKiAwLjIyLCBmcmVxLCAwLjgsIDAuMDcsICdzaW5lJykpXHJcbiAgICB9XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBpZ25vcmVcclxuICB9XHJcbn1cclxuIl19