import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/BlockRenderer.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockRenderer.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Read-only renderer for a PageContent's `blocks` array (see backend
// schemas/content.py for the exact shape). Used both by the CMS Content
// tab's Preview toggle and by the AI-import modal's page-content preview
// step. Deliberately reusable: CourseReaderPage.jsx currently renders
// plain text (`content.split('\n\n')`) and is NOT block-aware yet — it
// should eventually be upgraded to use this same renderer, but that's a
// live-learner-view behavior change left out of this CMS/import work.
function Heading({ block }) {
	const Tag = `h${Math.min(Math.max(block.level || 2, 1), 6)}`;
	return /* @__PURE__ */ _jsxDEV(Tag, {
		className: "cms-block-heading",
		children: block.text
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 10
	}, this);
}
_c = Heading;
function Paragraph({ block }) {
	return /* @__PURE__ */ _jsxDEV("p", {
		className: "cms-block-paragraph",
		children: block.text
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_c2 = Paragraph;
function Code({ block }) {
	return /* @__PURE__ */ _jsxDEV("pre", {
		className: "cms-block-code",
		children: /* @__PURE__ */ _jsxDEV("code", { children: block.code }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
}
_c3 = Code;
function Terminal({ block }) {
	return /* @__PURE__ */ _jsxDEV("pre", {
		className: "cms-block-terminal",
		children: block.text
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 10
	}, this);
}
_c4 = Terminal;
function Image({ block }) {
	return /* @__PURE__ */ _jsxDEV("figure", {
		className: "cms-block-figure",
		children: [/* @__PURE__ */ _jsxDEV("img", {
			src: block.src,
			alt: block.alt || "",
			loading: "lazy"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), block.caption && /* @__PURE__ */ _jsxDEV("figcaption", { children: block.caption }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 25
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_c5 = Image;
function Video({ block }) {
	return /* @__PURE__ */ _jsxDEV("figure", {
		className: "cms-block-figure",
		children: [/* @__PURE__ */ _jsxDEV("video", {
			src: block.src,
			controls: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this), block.caption && /* @__PURE__ */ _jsxDEV("figcaption", { children: block.caption }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 25
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_c6 = Video;
function Youtube({ block }) {
	return /* @__PURE__ */ _jsxDEV("figure", {
		className: "cms-block-figure",
		children: [/* @__PURE__ */ _jsxDEV("iframe", {
			title: block.caption || "YouTube video",
			src: `https://www.youtube.com/embed/${block.videoId}`,
			allowFullScreen: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this), block.caption && /* @__PURE__ */ _jsxDEV("figcaption", { children: block.caption }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 25
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 5
	}, this);
}
_c7 = Youtube;
function Link({ block }) {
	return /* @__PURE__ */ _jsxDEV("p", { children: /* @__PURE__ */ _jsxDEV("a", {
		href: block.href,
		target: "_blank",
		rel: "noreferrer",
		children: block.text
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
}
_c8 = Link;
function Quote({ block }) {
	return /* @__PURE__ */ _jsxDEV("blockquote", {
		className: "cms-block-quote",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: block.text }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this), block.attribution && /* @__PURE__ */ _jsxDEV("cite", { children: block.attribution }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 29
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_c9 = Quote;
function Callout({ block }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `cms-block-callout cms-callout-${block.variant}`,
		children: block.text
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 10
	}, this);
}
_c10 = Callout;
function List({ block }) {
	const Tag = block.ordered ? "ol" : "ul";
	return /* @__PURE__ */ _jsxDEV(Tag, {
		className: "cms-block-list",
		children: block.items.map((item, i) => /* @__PURE__ */ _jsxDEV("li", { children: item }, i, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
}
_c11 = List;
function Table({ block }) {
	return /* @__PURE__ */ _jsxDEV("table", {
		className: "cms-block-table",
		children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: block.headers.map((h, i) => /* @__PURE__ */ _jsxDEV("th", { children: h }, i, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 13
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 9
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: block.rows.map((row, ri) => /* @__PURE__ */ _jsxDEV("tr", { children: row.map((cell, ci) => /* @__PURE__ */ _jsxDEV("td", { children: cell }, ci, false, {
			fileName: _jsxFileName,
			lineNumber: 109,
			columnNumber: 15
		}, this)) }, ri, false, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 11
		}, this)) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 97,
		columnNumber: 5
	}, this);
}
_c12 = Table;
const RENDERERS = {
	heading: Heading,
	paragraph: Paragraph,
	code: Code,
	terminal: Terminal,
	image: Image,
	video: Video,
	youtube: Youtube,
	link: Link,
	quote: Quote,
	callout: Callout,
	list: List,
	table: Table
};
export function BlockRenderer({ blocks }) {
	if (!blocks || blocks.length === 0) {
		return /* @__PURE__ */ _jsxDEV("p", {
			className: "cms-empty-hint",
			children: "No content yet."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-block-renderer",
		children: blocks.map((block, i) => {
			const Renderer = RENDERERS[block.type];
			if (!Renderer) return null;
			return /* @__PURE__ */ _jsxDEV(Renderer, { block }, i, false, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 16
			}, this);
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 138,
		columnNumber: 5
	}, this);
}
_c13 = BlockRenderer;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13;
$RefreshReg$(_c, "Heading");
$RefreshReg$(_c2, "Paragraph");
$RefreshReg$(_c3, "Code");
$RefreshReg$(_c4, "Terminal");
$RefreshReg$(_c5, "Image");
$RefreshReg$(_c6, "Video");
$RefreshReg$(_c7, "Youtube");
$RefreshReg$(_c8, "Link");
$RefreshReg$(_c9, "Quote");
$RefreshReg$(_c10, "Callout");
$RefreshReg$(_c11, "List");
$RefreshReg$(_c12, "Table");
$RefreshReg$(_c13, "BlockRenderer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/BlockRenderer.jsx?t=1790183660675";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockRenderer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockRenderer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockRenderer.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBUUEsU0FBUyxRQUFRLEVBQUUsU0FBUztDQUMxQixNQUFNLE1BQU0sSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDO0NBQ3pELE9BQU8sd0JBQUMsS0FBRDtFQUFLLFdBQVU7WUFBcUIsTUFBTTtDQUFVOzs7OztBQUM3RDs7QUFFQSxTQUFTLFVBQVUsRUFBRSxTQUFTO0NBQzVCLE9BQU8sd0JBQUMsS0FBRDtFQUFHLFdBQVU7WUFBdUIsTUFBTTtDQUFROzs7OztBQUMzRDs7QUFFQSxTQUFTLEtBQUssRUFBRSxTQUFTO0NBQ3ZCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxRQUFELFlBQU8sTUFBTSxLQUFXOzs7OztDQUNyQjs7Ozs7QUFFVDs7QUFFQSxTQUFTLFNBQVMsRUFBRSxTQUFTO0NBQzNCLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBc0IsTUFBTTtDQUFVOzs7OztBQUM5RDs7QUFFQSxTQUFTLE1BQU0sRUFBRSxTQUFTO0NBQ3hCLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEIsQ0FDRSx3QkFBQyxPQUFEO0dBQUssS0FBSyxNQUFNO0dBQUssS0FBSyxNQUFNLE9BQU87R0FBSSxTQUFRO0VBQVE7Ozs7WUFDMUQsTUFBTSxXQUFXLHdCQUFDLGNBQUQsWUFBYSxNQUFNLFFBQW9COzs7O1VBQ25EOzs7Ozs7QUFFWjs7QUFFQSxTQUFTLE1BQU0sRUFBRSxTQUFTO0NBQ3hCLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEIsQ0FDRSx3QkFBQyxTQUFEO0dBQU8sS0FBSyxNQUFNO0dBQUs7RUFBVTs7OztZQUNoQyxNQUFNLFdBQVcsd0JBQUMsY0FBRCxZQUFhLE1BQU0sUUFBb0I7Ozs7VUFDbkQ7Ozs7OztBQUVaOztBQUVBLFNBQVMsUUFBUSxFQUFFLFNBQVM7Q0FDMUIsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFsQixDQUNFLHdCQUFDLFVBQUQ7R0FDRSxPQUFPLE1BQU0sV0FBVztHQUN4QixLQUFLLGlDQUFpQyxNQUFNO0dBQzVDO0VBQ0Q7Ozs7WUFDQSxNQUFNLFdBQVcsd0JBQUMsY0FBRCxZQUFhLE1BQU0sUUFBb0I7Ozs7VUFDbkQ7Ozs7OztBQUVaOztBQUVBLFNBQVMsS0FBSyxFQUFFLFNBQVM7Q0FDdkIsT0FDRSx3QkFBQyxLQUFELFlBQ0Usd0JBQUMsS0FBRDtFQUFHLE1BQU0sTUFBTTtFQUFNLFFBQU87RUFBUyxLQUFJO1lBQ3RDLE1BQU07Q0FDTjs7OztVQUNGOzs7OztBQUVQOztBQUVBLFNBQVMsTUFBTSxFQUFFLFNBQVM7Q0FDeEIsT0FDRSx3QkFBQyxjQUFEO0VBQVksV0FBVTtZQUF0QixDQUNFLHdCQUFDLEtBQUQsWUFBSSxNQUFNLEtBQVE7Ozs7WUFDakIsTUFBTSxlQUFlLHdCQUFDLFFBQUQsWUFBTyxNQUFNLFlBQWtCOzs7O1VBQzNDOzs7Ozs7QUFFaEI7O0FBRUEsU0FBUyxRQUFRLEVBQUUsU0FBUztDQUMxQixPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLGlDQUFpQyxNQUFNO1lBQVksTUFBTTtDQUFVOzs7OztBQUM1Rjs7QUFFQSxTQUFTLEtBQUssRUFBRSxTQUFTO0NBQ3ZCLE1BQU0sTUFBTSxNQUFNLFVBQVUsT0FBTztDQUNuQyxPQUNFLHdCQUFDLEtBQUQ7RUFBSyxXQUFVO1lBQ1osTUFBTSxNQUFNLEtBQUssTUFBTSxNQUN0Qix3QkFBQyxNQUFELFlBQWEsS0FBUyxHQUFiOzs7O1NBQWEsQ0FDdkI7Q0FDRTs7Ozs7QUFFVDs7QUFFQSxTQUFTLE1BQU0sRUFBRSxTQUFTO0NBQ3hCLE9BQ0Usd0JBQUMsU0FBRDtFQUFPLFdBQVU7WUFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRCxZQUNHLE1BQU0sUUFBUSxLQUFLLEdBQUcsTUFDckIsd0JBQUMsTUFBRCxZQUFhLEVBQU0sR0FBVjs7OztTQUFVLENBQ3BCLEVBQ0M7Ozs7V0FDQzs7OztZQUNQLHdCQUFDLFNBQUQsWUFDRyxNQUFNLEtBQUssS0FBSyxLQUFLLE9BQ3BCLHdCQUFDLE1BQUQsWUFDRyxJQUFJLEtBQUssTUFBTSxPQUNkLHdCQUFDLE1BQUQsWUFBYyxLQUFTLEdBQWQ7Ozs7U0FBYyxDQUN4QixFQUNDLEdBSks7Ozs7U0FJTCxDQUNMLEVBQ0k7Ozs7VUFDRjs7Ozs7O0FBRVg7O0FBRUEsTUFBTSxZQUFZO0NBQ2hCLFNBQVM7Q0FDVCxXQUFXO0NBQ1gsTUFBTTtDQUNOLFVBQVU7Q0FDVixPQUFPO0NBQ1AsT0FBTztDQUNQLFNBQVM7Q0FDVCxNQUFNO0NBQ04sT0FBTztDQUNQLFNBQVM7Q0FDVCxNQUFNO0NBQ04sT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLGNBQWMsRUFBRSxVQUFVO0NBQ3hDLElBQUksQ0FBQyxVQUFVLE9BQU8sV0FBVyxHQUFHO0VBQ2xDLE9BQU8sd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBaUI7RUFBa0I7Ozs7O0NBQ3pEO0NBQ0EsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNaLE9BQU8sS0FBSyxPQUFPLE1BQU07R0FDeEIsTUFBTSxXQUFXLFVBQVUsTUFBTTtHQUNqQyxJQUFJLENBQUMsVUFBVSxPQUFPO0dBQ3RCLE9BQU8sd0JBQUMsVUFBRCxFQUF5QixNQUFRLEdBQWxCOzs7O1VBQWtCO0VBQzFDLENBQUM7Q0FDRTs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCbG9ja1JlbmRlcmVyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSZWFkLW9ubHkgcmVuZGVyZXIgZm9yIGEgUGFnZUNvbnRlbnQncyBgYmxvY2tzYCBhcnJheSAoc2VlIGJhY2tlbmRcbi8vIHNjaGVtYXMvY29udGVudC5weSBmb3IgdGhlIGV4YWN0IHNoYXBlKS4gVXNlZCBib3RoIGJ5IHRoZSBDTVMgQ29udGVudFxuLy8gdGFiJ3MgUHJldmlldyB0b2dnbGUgYW5kIGJ5IHRoZSBBSS1pbXBvcnQgbW9kYWwncyBwYWdlLWNvbnRlbnQgcHJldmlld1xuLy8gc3RlcC4gRGVsaWJlcmF0ZWx5IHJldXNhYmxlOiBDb3Vyc2VSZWFkZXJQYWdlLmpzeCBjdXJyZW50bHkgcmVuZGVyc1xuLy8gcGxhaW4gdGV4dCAoYGNvbnRlbnQuc3BsaXQoJ1xcblxcbicpYCkgYW5kIGlzIE5PVCBibG9jay1hd2FyZSB5ZXQg4oCUIGl0XG4vLyBzaG91bGQgZXZlbnR1YWxseSBiZSB1cGdyYWRlZCB0byB1c2UgdGhpcyBzYW1lIHJlbmRlcmVyLCBidXQgdGhhdCdzIGFcbi8vIGxpdmUtbGVhcm5lci12aWV3IGJlaGF2aW9yIGNoYW5nZSBsZWZ0IG91dCBvZiB0aGlzIENNUy9pbXBvcnQgd29yay5cblxuZnVuY3Rpb24gSGVhZGluZyh7IGJsb2NrIH0pIHtcbiAgY29uc3QgVGFnID0gYGgke01hdGgubWluKE1hdGgubWF4KGJsb2NrLmxldmVsIHx8IDIsIDEpLCA2KX1gXG4gIHJldHVybiA8VGFnIGNsYXNzTmFtZT1cImNtcy1ibG9jay1oZWFkaW5nXCI+e2Jsb2NrLnRleHR9PC9UYWc+XG59XG5cbmZ1bmN0aW9uIFBhcmFncmFwaCh7IGJsb2NrIH0pIHtcbiAgcmV0dXJuIDxwIGNsYXNzTmFtZT1cImNtcy1ibG9jay1wYXJhZ3JhcGhcIj57YmxvY2sudGV4dH08L3A+XG59XG5cbmZ1bmN0aW9uIENvZGUoeyBibG9jayB9KSB7XG4gIHJldHVybiAoXG4gICAgPHByZSBjbGFzc05hbWU9XCJjbXMtYmxvY2stY29kZVwiPlxuICAgICAgPGNvZGU+e2Jsb2NrLmNvZGV9PC9jb2RlPlxuICAgIDwvcHJlPlxuICApXG59XG5cbmZ1bmN0aW9uIFRlcm1pbmFsKHsgYmxvY2sgfSkge1xuICByZXR1cm4gPHByZSBjbGFzc05hbWU9XCJjbXMtYmxvY2stdGVybWluYWxcIj57YmxvY2sudGV4dH08L3ByZT5cbn1cblxuZnVuY3Rpb24gSW1hZ2UoeyBibG9jayB9KSB7XG4gIHJldHVybiAoXG4gICAgPGZpZ3VyZSBjbGFzc05hbWU9XCJjbXMtYmxvY2stZmlndXJlXCI+XG4gICAgICA8aW1nIHNyYz17YmxvY2suc3JjfSBhbHQ9e2Jsb2NrLmFsdCB8fCAnJ30gbG9hZGluZz1cImxhenlcIiAvPlxuICAgICAge2Jsb2NrLmNhcHRpb24gJiYgPGZpZ2NhcHRpb24+e2Jsb2NrLmNhcHRpb259PC9maWdjYXB0aW9uPn1cbiAgICA8L2ZpZ3VyZT5cbiAgKVxufVxuXG5mdW5jdGlvbiBWaWRlbyh7IGJsb2NrIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZmlndXJlIGNsYXNzTmFtZT1cImNtcy1ibG9jay1maWd1cmVcIj5cbiAgICAgIDx2aWRlbyBzcmM9e2Jsb2NrLnNyY30gY29udHJvbHMgLz5cbiAgICAgIHtibG9jay5jYXB0aW9uICYmIDxmaWdjYXB0aW9uPntibG9jay5jYXB0aW9ufTwvZmlnY2FwdGlvbj59XG4gICAgPC9maWd1cmU+XG4gIClcbn1cblxuZnVuY3Rpb24gWW91dHViZSh7IGJsb2NrIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZmlndXJlIGNsYXNzTmFtZT1cImNtcy1ibG9jay1maWd1cmVcIj5cbiAgICAgIDxpZnJhbWVcbiAgICAgICAgdGl0bGU9e2Jsb2NrLmNhcHRpb24gfHwgJ1lvdVR1YmUgdmlkZW8nfVxuICAgICAgICBzcmM9e2BodHRwczovL3d3dy55b3V0dWJlLmNvbS9lbWJlZC8ke2Jsb2NrLnZpZGVvSWR9YH1cbiAgICAgICAgYWxsb3dGdWxsU2NyZWVuXG4gICAgICAvPlxuICAgICAge2Jsb2NrLmNhcHRpb24gJiYgPGZpZ2NhcHRpb24+e2Jsb2NrLmNhcHRpb259PC9maWdjYXB0aW9uPn1cbiAgICA8L2ZpZ3VyZT5cbiAgKVxufVxuXG5mdW5jdGlvbiBMaW5rKHsgYmxvY2sgfSkge1xuICByZXR1cm4gKFxuICAgIDxwPlxuICAgICAgPGEgaHJlZj17YmxvY2suaHJlZn0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiPlxuICAgICAgICB7YmxvY2sudGV4dH1cbiAgICAgIDwvYT5cbiAgICA8L3A+XG4gIClcbn1cblxuZnVuY3Rpb24gUXVvdGUoeyBibG9jayB9KSB7XG4gIHJldHVybiAoXG4gICAgPGJsb2NrcXVvdGUgY2xhc3NOYW1lPVwiY21zLWJsb2NrLXF1b3RlXCI+XG4gICAgICA8cD57YmxvY2sudGV4dH08L3A+XG4gICAgICB7YmxvY2suYXR0cmlidXRpb24gJiYgPGNpdGU+e2Jsb2NrLmF0dHJpYnV0aW9ufTwvY2l0ZT59XG4gICAgPC9ibG9ja3F1b3RlPlxuICApXG59XG5cbmZ1bmN0aW9uIENhbGxvdXQoeyBibG9jayB9KSB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17YGNtcy1ibG9jay1jYWxsb3V0IGNtcy1jYWxsb3V0LSR7YmxvY2sudmFyaWFudH1gfT57YmxvY2sudGV4dH08L2Rpdj5cbn1cblxuZnVuY3Rpb24gTGlzdCh7IGJsb2NrIH0pIHtcbiAgY29uc3QgVGFnID0gYmxvY2sub3JkZXJlZCA/ICdvbCcgOiAndWwnXG4gIHJldHVybiAoXG4gICAgPFRhZyBjbGFzc05hbWU9XCJjbXMtYmxvY2stbGlzdFwiPlxuICAgICAge2Jsb2NrLml0ZW1zLm1hcCgoaXRlbSwgaSkgPT4gKFxuICAgICAgICA8bGkga2V5PXtpfT57aXRlbX08L2xpPlxuICAgICAgKSl9XG4gICAgPC9UYWc+XG4gIClcbn1cblxuZnVuY3Rpb24gVGFibGUoeyBibG9jayB9KSB7XG4gIHJldHVybiAoXG4gICAgPHRhYmxlIGNsYXNzTmFtZT1cImNtcy1ibG9jay10YWJsZVwiPlxuICAgICAgPHRoZWFkPlxuICAgICAgICA8dHI+XG4gICAgICAgICAge2Jsb2NrLmhlYWRlcnMubWFwKChoLCBpKSA9PiAoXG4gICAgICAgICAgICA8dGgga2V5PXtpfT57aH08L3RoPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3RyPlxuICAgICAgPC90aGVhZD5cbiAgICAgIDx0Ym9keT5cbiAgICAgICAge2Jsb2NrLnJvd3MubWFwKChyb3csIHJpKSA9PiAoXG4gICAgICAgICAgPHRyIGtleT17cml9PlxuICAgICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNpKSA9PiAoXG4gICAgICAgICAgICAgIDx0ZCBrZXk9e2NpfT57Y2VsbH08L3RkPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgKSl9XG4gICAgICA8L3Rib2R5PlxuICAgIDwvdGFibGU+XG4gIClcbn1cblxuY29uc3QgUkVOREVSRVJTID0ge1xuICBoZWFkaW5nOiBIZWFkaW5nLFxuICBwYXJhZ3JhcGg6IFBhcmFncmFwaCxcbiAgY29kZTogQ29kZSxcbiAgdGVybWluYWw6IFRlcm1pbmFsLFxuICBpbWFnZTogSW1hZ2UsXG4gIHZpZGVvOiBWaWRlbyxcbiAgeW91dHViZTogWW91dHViZSxcbiAgbGluazogTGluayxcbiAgcXVvdGU6IFF1b3RlLFxuICBjYWxsb3V0OiBDYWxsb3V0LFxuICBsaXN0OiBMaXN0LFxuICB0YWJsZTogVGFibGUsXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBCbG9ja1JlbmRlcmVyKHsgYmxvY2tzIH0pIHtcbiAgaWYgKCFibG9ja3MgfHwgYmxvY2tzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiA8cCBjbGFzc05hbWU9XCJjbXMtZW1wdHktaGludFwiPk5vIGNvbnRlbnQgeWV0LjwvcD5cbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLWJsb2NrLXJlbmRlcmVyXCI+XG4gICAgICB7YmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAgICAgY29uc3QgUmVuZGVyZXIgPSBSRU5ERVJFUlNbYmxvY2sudHlwZV1cbiAgICAgICAgaWYgKCFSZW5kZXJlcikgcmV0dXJuIG51bGxcbiAgICAgICAgcmV0dXJuIDxSZW5kZXJlciBrZXk9e2l9IGJsb2NrPXtibG9ja30gLz5cbiAgICAgIH0pfVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=