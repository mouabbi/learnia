import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HomePage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { GitBranch, Code2, Globe, FlaskConical, ArrowRight, Flame, Trophy, Target, BookOpen, Sparkles, CheckCircle2, AlertTriangle, MailWarning } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { authApi } from "/src/features/auth/authApi.js";
import { coursesApi } from "/src/features/courses/coursesApi.js";
import { CourseCard, CourseCardSkeleton } from "/src/features/courses/CourseCard.jsx?t=1790187136361";
import { learningProgress, scoreProgress, isQuizPassed, isModuleComplete, PASSING_PCT } from "/src/features/courses/progress.js";
import { useLearnerXp } from "/src/features/courses/useLearnerXp.js";
import { ApiError } from "/src/api/client.js";
import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/HomePage.jsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const ICONS = {
	GitBranch,
	Code2,
	Globe,
	FlaskConical
};
// "Continue learning" only has room for a handful of cards before it
// crowds out the recommendations below it.
const MAX_CONTINUE_CARDS = 3;
// Rendered inside AppLayout (see App.jsx) — only reachable once /auth/me
// has confirmed a logged-in user. The main landing spot: a "continue where
// you left off" card, a couple of stats, then recommendations.
export function HomePage() {
	_s();
	const { user } = useAuth();
	const displayName = user.email.split("@")[0];
	const [courses, setCourses] = useState(null);
	const [inProgress, setInProgress] = useState(null);
	const learnerXp = useLearnerXp();
	useEffect(() => {
		let cancelled = false;
		coursesApi.listCourses().then(async (list) => {
			if (cancelled) return;
			setCourses(list);
			// Find up to MAX_CONTINUE_CARDS courses with recorded progress to
			// feature as "Continue learning". In a real app this would come
			// from the learner's own attempt history, not a client-side scan.
			const found = [];
			for (const course of list) {
				if (found.length >= MAX_CONTINUE_CARDS) break;
				const progress = await coursesApi.getProgress(course.id);
				if (cancelled) return;
				if (progress.completedPageIds.length > 0) {
					// listCourses() returns lightweight summaries without `modules`
					// (ContinueLearningCard needs the full module tree to resolve
					// the resume target), so fetch the full course here.
					const fullCourse = await coursesApi.getCourse(course.slug);
					if (cancelled) return;
					found.push({
						course: fullCourse,
						progress
					});
				}
			}
			setInProgress(found);
		}).catch((error) => {
			if (cancelled) return;
			// Backend unreachable/erroring (e.g. no courses seeded yet) — fall
			// back to empty states rather than leaving the page stuck loading
			// and throwing an unhandled rejection into the console.
			console.error("Failed to load courses", error);
			setCourses([]);
			setInProgress([]);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const inProgressIds = new Set(inProgress ? inProgress.map(({ course }) => course.id) : []);
	const recommended = courses?.filter((c) => !inProgressIds.has(c.id)) ?? [];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home",
		children: [
			/* @__PURE__ */ _jsxDEV("section", {
				className: "content-card home-hello",
				children: [/* @__PURE__ */ _jsxDEV("h1", { children: ["Hello, ", displayName] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Welcome back to Learnia." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 7
			}, this),
			!user.email_verified && /* @__PURE__ */ _jsxDEV(VerifyEmailBanner, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 32
			}, this),
			courses && /* @__PURE__ */ _jsxDEV(StatsStrip, {
				courses,
				inProgress,
				learnerXp
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 19
			}, this),
			inProgress === null && /* @__PURE__ */ _jsxDEV(ContinueCardSkeleton, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 31
			}, this),
			inProgress && inProgress.map(({ course, progress }) => /* @__PURE__ */ _jsxDEV(ContinueLearningCard, {
				course,
				progress
			}, course.id, false, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 11
			}, this)),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "home-section",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "home-section-header",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Recommended for you" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/courses",
						className: "home-see-all",
						children: ["See all ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "course-grid",
					children: [courses === null && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this), courses !== null && recommended.map((course, index) => /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 8
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: index * .05 },
						children: /* @__PURE__ */ _jsxDEV(CourseCard, { course }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 17
						}, this)
					}, course.id, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 15
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 92,
		columnNumber: 5
	}, this);
}
_s(HomePage, "/8c1f3TJYF5T9ARNKJR2vGEbkSc=", false, function() {
	return [useAuth, useLearnerXp];
});
_c = HomePage;
function ContinueLearningCard({ course, progress }) {
	const Icon = ICONS[course.icon] ?? BookOpen;
	const completed = progress.completedPageIds;
	// Resume at the page the learner left off on, falling back to the first
	// not-yet-completed page, then the very first page.
	const allPages = course.modules.flatMap((m) => m.chapters.flatMap((c) => c.pages));
	const resumePage = allPages.find((p) => p.id === progress.lastPageId) ?? allPages.find((p) => !completed.includes(p.id)) ?? allPages[0];
	const learning = learningProgress(course, completed);
	const score = scoreProgress(course, progress.moduleQuizzes, progress.finalExam);
	const passed = score.pct >= PASSING_PCT;
	const complete = learning.pct >= 100;
	const resumeHref = resumePage ? `/courses/${course.slug}/learn?page=${resumePage.id}` : `/courses/${course.slug}/learn`;
	return /* @__PURE__ */ _jsxDEV(motion.section, {
		className: `continue-card continue-card-hero${complete ? " continue-card-complete" : ""}`,
		initial: {
			opacity: 0,
			y: 8
		},
		animate: {
			opacity: 1,
			y: 0
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "continue-card-hero-top",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: `continue-card-icon${course.image ? " continue-card-icon-image" : ""}`,
					children: course.image ? /* @__PURE__ */ _jsxDEV("img", {
						src: course.image,
						alt: "",
						className: "continue-card-icon-img"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 13
					}, this) : complete ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 26 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(Icon, { size: 26 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 168,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "continue-card-body",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "continue-card-eyebrow",
							children: complete ? "Course complete" : "Continue learning"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", { children: course.title }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 11
						}, this),
						complete ? /* @__PURE__ */ _jsxDEV("p", { children: "Every module and QCM done." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 23
						}, this) : resumePage && /* @__PURE__ */ _jsxDEV("p", { children: ["Next up: ", resumePage.title] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 73
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "continue-card-hero-actions",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: `score-chip ${passed ? "score-chip-passed" : ""}`,
						children: [
							passed ? /* @__PURE__ */ _jsxDEV(Trophy, {
								size: 14,
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 23
							}, this) : /* @__PURE__ */ _jsxDEV(Target, {
								size: 14,
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 65
							}, this),
							score.pct,
							"/100"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: resumeHref,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "continue-card-cta",
						children: [
							complete ? "Review" : "Resume",
							" ",
							/* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 46
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 167,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(ModuleTrack, {
			course,
			progress,
			learning
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 195,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 162,
		columnNumber: 5
	}, this);
}
_c2 = ContinueLearningCard;
// A DataCamp-style skill-track bar: one segment per module (done / current
// / upcoming/locked) instead of a single filled bar, so the shape of the
// course — not just a percentage — is visible at a glance.
function ModuleTrack({ course, progress, learning }) {
	const completed = new Set(progress.completedPageIds);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "chapter-track",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "chapter-track-header",
			children: [/* @__PURE__ */ _jsxDEV("span", { children: [
				learning.earned,
				"/",
				learning.total,
				" pts"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: [learning.pct, "% complete"] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "chapter-track-bar",
			children: course.modules.map((courseModule) => {
				const done = isModuleComplete(courseModule, [...completed], progress.moduleQuizzes);
				const pages = courseModule.chapters.flatMap((c) => c.pages);
				const started = pages.some((p) => completed.has(p.id));
				const state = done ? "done" : started ? "current" : "upcoming";
				return /* @__PURE__ */ _jsxDEV("span", {
					className: `chapter-segment chapter-segment-${state}`,
					title: courseModule.title
				}, courseModule.id, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 213,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 206,
		columnNumber: 5
	}, this);
}
_c3 = ModuleTrack;
function ContinueCardSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "continue-card continue-card-skeleton",
		children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
			circle: true,
			width: "3rem",
			height: "3rem"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 235,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "continue-card-body",
			children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "30%",
				height: "0.75rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 237,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "55%",
				height: "1.2rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 236,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 234,
		columnNumber: 5
	}, this);
}
_c4 = ContinueCardSkeleton;
function StatsStrip({ courses, inProgress, learnerXp }) {
	const totalCourses = courses.length;
	const completedPages = inProgress ? inProgress.reduce((sum, { progress }) => sum + progress.completedPageIds.length, 0) : 0;
	const examsPassed = inProgress ? inProgress.filter(({ progress }) => isQuizPassed(progress.finalExam)).length : 0;
	const stats = [
		{
			icon: BookOpen,
			label: "Courses available",
			value: totalCourses
		},
		{
			icon: Flame,
			label: "Pages completed",
			value: completedPages
		},
		{
			icon: Trophy,
			label: "Exams passed",
			value: examsPassed
		},
		{
			icon: Sparkles,
			label: "XP earned",
			value: learnerXp ? learnerXp.xp : "—"
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "stats-strip",
		children: stats.map(({ icon: Icon, label, value }) => /* @__PURE__ */ _jsxDEV("div", {
			className: "stat-tile",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "stat-tile-icon",
				children: /* @__PURE__ */ _jsxDEV(Icon, { size: 18 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 263,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 262,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "stat-tile-value",
				children: value
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 266,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "stat-tile-label",
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 267,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 265,
				columnNumber: 11
			}, this)]
		}, label, true, {
			fileName: _jsxFileName,
			lineNumber: 261,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 259,
		columnNumber: 5
	}, this);
}
_c5 = StatsStrip;
// Shown only while the account's email is unverified (see users.email_verified_at).
function VerifyEmailBanner() {
	_s2();
	const [status, setStatus] = useState("idle");
	async function handleResend() {
		setStatus("sending");
		try {
			await authApi.sendVerificationEmail();
			setStatus("sent");
		} catch (err) {
			setStatus(err instanceof ApiError ? err.message : "Something went wrong");
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		className: "banner banner-warning",
		children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
			size: 20,
			className: "banner-icon",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 291,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "banner-body",
			children: [
				/* @__PURE__ */ _jsxDEV("p", {
					className: "banner-title",
					children: "Your email isn't verified yet"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 293,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "banner-caption",
					children: "Verify it to make sure you can recover your account and receive important updates."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 294,
					columnNumber: 9
				}, this),
				status === "sent" ? /* @__PURE__ */ _jsxDEV("p", {
					className: "banner-status banner-status-ok",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 13
					}, this), " Sent — check your inbox."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 298,
					columnNumber: 11
				}, this) : status !== "idle" && status !== "sending" ? /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "banner-status banner-status-error",
					children: [
						/* @__PURE__ */ _jsxDEV(MailWarning, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 303,
							columnNumber: 13
						}, this),
						" ",
						status
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 302,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "banner-action",
					disabled: status === "sending",
					onClick: handleResend,
					children: status === "sending" ? "Sending…" : "Resend verification email"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 306,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 292,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 290,
		columnNumber: 5
	}, this);
}
_s2(VerifyEmailBanner, "pMVgpsUAJOHrZfHrrx/6nNCpzkc=");
_c6 = VerifyEmailBanner;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "HomePage");
$RefreshReg$(_c2, "ContinueLearningCard");
$RefreshReg$(_c3, "ModuleTrack");
$RefreshReg$(_c4, "ContinueCardSkeleton");
$RefreshReg$(_c5, "StatsStrip");
$RefreshReg$(_c6, "VerifyEmailBanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/HomePage.jsx?t=1790187136361";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/HomePage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/HomePage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/HomePage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLFlBQVk7QUFDckIsU0FBUyxjQUFjO0FBQ3ZCLFNBQ0UsV0FDQSxPQUNBLE9BQ0EsY0FDQSxZQUNBLE9BQ0EsUUFDQSxRQUNBLFVBQ0EsVUFDQSxjQUNBLGVBQ0EsbUJBQ0s7QUFDUCxTQUFTLGVBQWU7QUFDeEIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsWUFBWSwwQkFBMEI7QUFDL0MsU0FDRSxrQkFDQSxlQUNBLGNBQ0Esa0JBQ0EsbUJBQ0s7QUFDUCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGdCQUFnQjs7OztBQUV6QixNQUFNLFFBQVE7Q0FBRTtDQUFXO0NBQU87Q0FBTztBQUFhOzs7QUFJdEQsTUFBTSxxQkFBcUI7Ozs7QUFLM0IsT0FBTyxTQUFTLFdBQVc7O0NBQ3pCLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxjQUFjLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0NBQzFDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLElBQUk7Q0FDakQsTUFBTSxZQUFZLGFBQWE7Q0FFL0IsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZO0VBQ2hCLFdBQVcsWUFBWSxDQUFDLENBQUMsS0FBSyxPQUFPLFNBQVM7R0FDNUMsSUFBSSxXQUFXO0dBQ2YsV0FBVyxJQUFJOzs7O0dBS2YsTUFBTSxRQUFRLENBQUM7R0FDZixLQUFLLE1BQU0sVUFBVSxNQUFNO0lBQ3pCLElBQUksTUFBTSxVQUFVLG9CQUFvQjtJQUN4QyxNQUFNLFdBQVcsTUFBTSxXQUFXLFlBQVksT0FBTyxFQUFFO0lBQ3ZELElBQUksV0FBVztJQUNmLElBQUksU0FBUyxpQkFBaUIsU0FBUyxHQUFHOzs7O0tBSXhDLE1BQU0sYUFBYSxNQUFNLFdBQVcsVUFBVSxPQUFPLElBQUk7S0FDekQsSUFBSSxXQUFXO0tBQ2YsTUFBTSxLQUFLO01BQUUsUUFBUTtNQUFZO0tBQVMsQ0FBQztJQUM3QztHQUNGO0dBQ0EsY0FBYyxLQUFLO0VBQ3JCLENBQUMsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUNsQixJQUFJLFdBQVc7Ozs7R0FJZixRQUFRLE1BQU0sMEJBQTBCLEtBQUs7R0FDN0MsV0FBVyxDQUFDLENBQUM7R0FDYixjQUFjLENBQUMsQ0FBQztFQUNsQixDQUFDO0VBQ0QsYUFBYTtHQUNYLFlBQVk7RUFDZDtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJLGFBQWEsV0FBVyxLQUFLLEVBQUUsYUFBYSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Q0FDekYsTUFBTSxjQUFjLFNBQVMsUUFBUSxNQUFNLENBQUMsY0FBYyxJQUFJLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQztDQUV6RSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE1BQUQsYUFBSSxXQUFRLFdBQWdCOzs7O2NBQzVCLHdCQUFDLEtBQUQsWUFBRywyQkFBMkI7Ozs7WUFDdkI7Ozs7OztHQUVSLENBQUMsS0FBSyxrQkFBa0Isd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0dBRTVDLFdBQVcsd0JBQUMsWUFBRDtJQUFxQjtJQUFxQjtJQUF1QjtHQUFZOzs7OztHQUV4RixlQUFlLFFBQVEsd0JBQUMsc0JBQUQsQ0FBdUI7Ozs7O0dBQzlDLGNBQ0MsV0FBVyxLQUFLLEVBQUUsUUFBUSxlQUN4Qix3QkFBQyxzQkFBRDtJQUE4QztJQUFrQjtHQUFXLEdBQWhELE9BQU87Ozs7VUFBeUMsQ0FDNUU7R0FFSCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksc0JBQXVCOzs7O2VBQzNCLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQVcsV0FBVTtnQkFBOUIsQ0FBNkMsWUFDbkMsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7OztjQUMzQjs7Ozs7YUFDSDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0csWUFBWSxRQUNYLGdEQUNFLHdCQUFDLG9CQUFELENBQXFCOzs7O2VBQ3JCLHdCQUFDLG9CQUFELENBQXFCOzs7O2FBQ3JCOzs7O2VBRUgsWUFBWSxRQUNYLFlBQVksS0FBSyxRQUFRLFVBQ3ZCLHdCQUFDLE9BQU8sS0FBUjtNQUVFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLFlBQVksRUFBRSxPQUFPLFFBQVEsSUFBSztnQkFFbEMsd0JBQUMsWUFBRCxFQUFvQixPQUFTOzs7OztLQUNuQixHQU5MLE9BQU87Ozs7WUFNRixDQUNiLENBQ0E7Ozs7O1lBQ0U7Ozs7OztFQUNOOzs7Ozs7QUFFVDs7Ozs7QUFFQSxTQUFTLHFCQUFxQixFQUFFLFFBQVEsWUFBWTtDQUNsRCxNQUFNLE9BQU8sTUFBTSxPQUFPLFNBQVM7Q0FDbkMsTUFBTSxZQUFZLFNBQVM7OztDQUkzQixNQUFNLFdBQVcsT0FBTyxRQUFRLFNBQVMsTUFBTSxFQUFFLFNBQVMsU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDO0NBQ2pGLE1BQU0sYUFDSixTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sU0FBUyxVQUFVLEtBQ2pELFNBQVMsTUFBTSxNQUFNLENBQUMsVUFBVSxTQUFTLEVBQUUsRUFBRSxDQUFDLEtBQzlDLFNBQVM7Q0FFWCxNQUFNLFdBQVcsaUJBQWlCLFFBQVEsU0FBUztDQUNuRCxNQUFNLFFBQVEsY0FBYyxRQUFRLFNBQVMsZUFBZSxTQUFTLFNBQVM7Q0FFOUUsTUFBTSxTQUFTLE1BQU0sT0FBTztDQUM1QixNQUFNLFdBQVcsU0FBUyxPQUFPO0NBQ2pDLE1BQU0sYUFBYSxhQUNmLFlBQVksT0FBTyxLQUFLLGNBQWMsV0FBVyxPQUNqRCxZQUFZLE9BQU8sS0FBSztDQUU1QixPQUNFLHdCQUFDLE9BQU8sU0FBUjtFQUNFLFdBQVcsbUNBQW1DLFdBQVcsNEJBQTRCO0VBQ3JGLFNBQVM7R0FBRSxTQUFTO0dBQUcsR0FBRztFQUFFO0VBQzVCLFNBQVM7R0FBRSxTQUFTO0dBQUcsR0FBRztFQUFFO1lBSDlCLENBS0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLHFCQUFxQixPQUFPLFFBQVEsOEJBQThCO2VBQy9FLE9BQU8sUUFDTix3QkFBQyxPQUFEO01BQUssS0FBSyxPQUFPO01BQU8sS0FBSTtNQUFHLFdBQVU7S0FBMEI7Ozs7Z0JBQ2pFLFdBQ0Ysd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztnQkFFekIsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7SUFFaEI7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF5QixXQUFXLG9CQUFvQjtNQUEwQjs7Ozs7TUFDbEcsd0JBQUMsTUFBRCxZQUFLLE9BQU8sTUFBVTs7Ozs7TUFDckIsV0FBVyx3QkFBQyxLQUFELFlBQUcsNkJBQTZCOzs7O2lCQUFJLGNBQWMsd0JBQUMsS0FBRCxhQUFHLGFBQVUsV0FBVyxLQUFTOzs7OztLQUM1Rjs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFXLGNBQWMsU0FBUyxzQkFBc0I7Z0JBQTlEO09BQ0csU0FBUyx3QkFBQyxRQUFEO1FBQVEsTUFBTTtRQUFJLGVBQVk7T0FBUTs7OztrQkFBSSx3QkFBQyxRQUFEO1FBQVEsTUFBTTtRQUFJLGVBQVk7T0FBUTs7Ozs7T0FDekYsTUFBTTtPQUFJO01BQ1A7Ozs7O2VBR04sd0JBQUMsS0FBRDtNQUFHLE1BQU07TUFBWSxRQUFPO01BQVMsS0FBSTtNQUFzQixXQUFVO2dCQUF6RTtPQUNHLFdBQVcsV0FBVztPQUFTO09BQUMsd0JBQUMsWUFBRCxFQUFZLE1BQU0sR0FBSzs7Ozs7TUFDdkQ7Ozs7O2FBQ0E7Ozs7OztHQUNGOzs7OztZQUVMLHdCQUFDLGFBQUQ7R0FBcUI7R0FBa0I7R0FBb0I7RUFBVzs7OztVQUN4RDs7Ozs7O0FBRXBCOzs7OztBQUtBLFNBQVMsWUFBWSxFQUFFLFFBQVEsVUFBVSxZQUFZO0NBQ25ELE1BQU0sWUFBWSxJQUFJLElBQUksU0FBUyxnQkFBZ0I7Q0FDbkQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFFBQUQ7SUFDRyxTQUFTO0lBQU87SUFBRSxTQUFTO0lBQU07R0FDOUI7Ozs7YUFDTix3QkFBQyxRQUFELGFBQU8sU0FBUyxLQUFJLFlBQWdCOzs7O1dBQ2pDOzs7OztZQUNMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osT0FBTyxRQUFRLEtBQUssaUJBQWlCO0lBQ3BDLE1BQU0sT0FBTyxpQkFBaUIsY0FBYyxDQUFDLEdBQUcsU0FBUyxHQUFHLFNBQVMsYUFBYTtJQUNsRixNQUFNLFFBQVEsYUFBYSxTQUFTLFNBQVMsTUFBTSxFQUFFLEtBQUs7SUFDMUQsTUFBTSxVQUFVLE1BQU0sTUFBTSxNQUFNLFVBQVUsSUFBSSxFQUFFLEVBQUUsQ0FBQztJQUNyRCxNQUFNLFFBQVEsT0FBTyxTQUFTLFVBQVUsWUFBWTtJQUNwRCxPQUNFLHdCQUFDLFFBQUQ7S0FFRSxXQUFXLG1DQUFtQztLQUM5QyxPQUFPLGFBQWE7SUFDckIsR0FITSxhQUFhOzs7O1dBR25CO0dBRUwsQ0FBQztFQUNFOzs7O1VBQ0Y7Ozs7OztBQUVUOztBQUVBLFNBQVMsdUJBQXVCO0NBQzlCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFVBQUQ7R0FBVTtHQUFPLE9BQU07R0FBTyxRQUFPO0VBQVE7Ozs7WUFDN0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLFVBQUQ7SUFBVSxPQUFNO0lBQU0sUUFBTztHQUFXOzs7O2FBQ3hDLHdCQUFDLFVBQUQ7SUFBVSxPQUFNO0lBQU0sUUFBTztHQUFVOzs7O1dBQ3BDOzs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxTQUFTLFdBQVcsRUFBRSxTQUFTLFlBQVksYUFBYTtDQUN0RCxNQUFNLGVBQWUsUUFBUTtDQUM3QixNQUFNLGlCQUFpQixhQUNuQixXQUFXLFFBQVEsS0FBSyxFQUFFLGVBQWUsTUFBTSxTQUFTLGlCQUFpQixRQUFRLENBQUMsSUFDbEY7Q0FDSixNQUFNLGNBQWMsYUFDaEIsV0FBVyxRQUFRLEVBQUUsZUFBZSxhQUFhLFNBQVMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUN0RTtDQUNKLE1BQU0sUUFBUTtFQUNaO0dBQUUsTUFBTTtHQUFVLE9BQU87R0FBcUIsT0FBTztFQUFhO0VBQ2xFO0dBQUUsTUFBTTtHQUFPLE9BQU87R0FBbUIsT0FBTztFQUFlO0VBQy9EO0dBQUUsTUFBTTtHQUFRLE9BQU87R0FBZ0IsT0FBTztFQUFZO0VBQzFEO0dBQUUsTUFBTTtHQUFVLE9BQU87R0FBYSxPQUFPLFlBQVksVUFBVSxLQUFLO0VBQUk7Q0FDOUU7Q0FDQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQ2hCLE1BQU0sS0FBSyxFQUFFLE1BQU0sTUFBTSxPQUFPLFlBQy9CLHdCQUFDLE9BQUQ7R0FBaUIsV0FBVTthQUEzQixDQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2Qsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7R0FDYjs7OzthQUNOLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFtQjtHQUFXOzs7O2FBQzdDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQW1CO0dBQVc7Ozs7V0FDMUM7Ozs7V0FDRjtLQVJLOzs7O1NBUUwsQ0FDTjtDQUNNOzs7OztBQUViOzs7QUFHQSxTQUFTLG9CQUFvQjs7Q0FDM0IsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLE1BQU07Q0FFM0MsZUFBZSxlQUFlO0VBQzVCLFVBQVUsU0FBUztFQUNuQixJQUFJO0dBQ0YsTUFBTSxRQUFRLHNCQUFzQjtHQUNwQyxVQUFVLE1BQU07RUFDbEIsU0FBUyxLQUFLO0dBQ1osVUFBVSxlQUFlLFdBQVcsSUFBSSxVQUFVLHNCQUFzQjtFQUMxRTtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssTUFBSztFQUFTLFdBQVU7WUFBN0IsQ0FDRSx3QkFBQyxlQUFEO0dBQWUsTUFBTTtHQUFJLFdBQVU7R0FBYyxlQUFZO0VBQVE7Ozs7WUFDckUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWU7SUFBZ0M7Ozs7O0lBQzVELHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWlCO0lBRTNCOzs7OztJQUNGLFdBQVcsU0FDVix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiLENBQ0Usd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztlQUFDLDJCQUN6Qjs7Ozs7ZUFDRCxXQUFXLFVBQVUsV0FBVyxZQUNsQyx3QkFBQyxLQUFEO0tBQUcsTUFBSztLQUFRLFdBQVU7ZUFBMUI7TUFDRSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7OztNQUFDO01BQUU7S0FDMUI7Ozs7O2VBRUgsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQWdCLFVBQVUsV0FBVztLQUFXLFNBQVM7ZUFDdEYsV0FBVyxZQUFZLGFBQWE7SUFDL0I7Ozs7O0dBRVA7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhvbWVQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdtb3Rpb24vcmVhY3QnXHJcbmltcG9ydCB7XHJcbiAgR2l0QnJhbmNoLFxyXG4gIENvZGUyLFxyXG4gIEdsb2JlLFxyXG4gIEZsYXNrQ29uaWNhbCxcclxuICBBcnJvd1JpZ2h0LFxyXG4gIEZsYW1lLFxyXG4gIFRyb3BoeSxcclxuICBUYXJnZXQsXHJcbiAgQm9va09wZW4sXHJcbiAgU3BhcmtsZXMsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIEFsZXJ0VHJpYW5nbGUsXHJcbiAgTWFpbFdhcm5pbmcsXHJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXV0aC9BdXRoQ29udGV4dCdcclxuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvYXV0aEFwaSdcclxuaW1wb3J0IHsgY291cnNlc0FwaSB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvY291cnNlc0FwaSdcclxuaW1wb3J0IHsgQ291cnNlQ2FyZCwgQ291cnNlQ2FyZFNrZWxldG9uIH0gZnJvbSAnLi4vZmVhdHVyZXMvY291cnNlcy9Db3Vyc2VDYXJkJ1xyXG5pbXBvcnQge1xyXG4gIGxlYXJuaW5nUHJvZ3Jlc3MsXHJcbiAgc2NvcmVQcm9ncmVzcyxcclxuICBpc1F1aXpQYXNzZWQsXHJcbiAgaXNNb2R1bGVDb21wbGV0ZSxcclxuICBQQVNTSU5HX1BDVCxcclxufSBmcm9tICcuLi9mZWF0dXJlcy9jb3Vyc2VzL3Byb2dyZXNzJ1xyXG5pbXBvcnQgeyB1c2VMZWFybmVyWHAgfSBmcm9tICcuLi9mZWF0dXJlcy9jb3Vyc2VzL3VzZUxlYXJuZXJYcCdcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi9hcGkvY2xpZW50J1xyXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4uL2NvbXBvbmVudHMvU2tlbGV0b24nXHJcblxyXG5jb25zdCBJQ09OUyA9IHsgR2l0QnJhbmNoLCBDb2RlMiwgR2xvYmUsIEZsYXNrQ29uaWNhbCB9XHJcblxyXG4vLyBcIkNvbnRpbnVlIGxlYXJuaW5nXCIgb25seSBoYXMgcm9vbSBmb3IgYSBoYW5kZnVsIG9mIGNhcmRzIGJlZm9yZSBpdFxyXG4vLyBjcm93ZHMgb3V0IHRoZSByZWNvbW1lbmRhdGlvbnMgYmVsb3cgaXQuXHJcbmNvbnN0IE1BWF9DT05USU5VRV9DQVJEUyA9IDNcclxuXHJcbi8vIFJlbmRlcmVkIGluc2lkZSBBcHBMYXlvdXQgKHNlZSBBcHAuanN4KSDigJQgb25seSByZWFjaGFibGUgb25jZSAvYXV0aC9tZVxyXG4vLyBoYXMgY29uZmlybWVkIGEgbG9nZ2VkLWluIHVzZXIuIFRoZSBtYWluIGxhbmRpbmcgc3BvdDogYSBcImNvbnRpbnVlIHdoZXJlXHJcbi8vIHlvdSBsZWZ0IG9mZlwiIGNhcmQsIGEgY291cGxlIG9mIHN0YXRzLCB0aGVuIHJlY29tbWVuZGF0aW9ucy5cclxuZXhwb3J0IGZ1bmN0aW9uIEhvbWVQYWdlKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpXHJcbiAgY29uc3QgZGlzcGxheU5hbWUgPSB1c2VyLmVtYWlsLnNwbGl0KCdAJylbMF1cclxuICBjb25zdCBbY291cnNlcywgc2V0Q291cnNlc10gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtpblByb2dyZXNzLCBzZXRJblByb2dyZXNzXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgbGVhcm5lclhwID0gdXNlTGVhcm5lclhwKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxyXG4gICAgY291cnNlc0FwaS5saXN0Q291cnNlcygpLnRoZW4oYXN5bmMgKGxpc3QpID0+IHtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgIHNldENvdXJzZXMobGlzdClcclxuXHJcbiAgICAgIC8vIEZpbmQgdXAgdG8gTUFYX0NPTlRJTlVFX0NBUkRTIGNvdXJzZXMgd2l0aCByZWNvcmRlZCBwcm9ncmVzcyB0b1xyXG4gICAgICAvLyBmZWF0dXJlIGFzIFwiQ29udGludWUgbGVhcm5pbmdcIi4gSW4gYSByZWFsIGFwcCB0aGlzIHdvdWxkIGNvbWVcclxuICAgICAgLy8gZnJvbSB0aGUgbGVhcm5lcidzIG93biBhdHRlbXB0IGhpc3RvcnksIG5vdCBhIGNsaWVudC1zaWRlIHNjYW4uXHJcbiAgICAgIGNvbnN0IGZvdW5kID0gW11cclxuICAgICAgZm9yIChjb25zdCBjb3Vyc2Ugb2YgbGlzdCkge1xyXG4gICAgICAgIGlmIChmb3VuZC5sZW5ndGggPj0gTUFYX0NPTlRJTlVFX0NBUkRTKSBicmVha1xyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gYXdhaXQgY291cnNlc0FwaS5nZXRQcm9ncmVzcyhjb3Vyc2UuaWQpXHJcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgICAgaWYgKHByb2dyZXNzLmNvbXBsZXRlZFBhZ2VJZHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgLy8gbGlzdENvdXJzZXMoKSByZXR1cm5zIGxpZ2h0d2VpZ2h0IHN1bW1hcmllcyB3aXRob3V0IGBtb2R1bGVzYFxyXG4gICAgICAgICAgLy8gKENvbnRpbnVlTGVhcm5pbmdDYXJkIG5lZWRzIHRoZSBmdWxsIG1vZHVsZSB0cmVlIHRvIHJlc29sdmVcclxuICAgICAgICAgIC8vIHRoZSByZXN1bWUgdGFyZ2V0KSwgc28gZmV0Y2ggdGhlIGZ1bGwgY291cnNlIGhlcmUuXHJcbiAgICAgICAgICBjb25zdCBmdWxsQ291cnNlID0gYXdhaXQgY291cnNlc0FwaS5nZXRDb3Vyc2UoY291cnNlLnNsdWcpXHJcbiAgICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm5cclxuICAgICAgICAgIGZvdW5kLnB1c2goeyBjb3Vyc2U6IGZ1bGxDb3Vyc2UsIHByb2dyZXNzIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHNldEluUHJvZ3Jlc3MoZm91bmQpXHJcbiAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgIC8vIEJhY2tlbmQgdW5yZWFjaGFibGUvZXJyb3JpbmcgKGUuZy4gbm8gY291cnNlcyBzZWVkZWQgeWV0KSDigJQgZmFsbFxyXG4gICAgICAvLyBiYWNrIHRvIGVtcHR5IHN0YXRlcyByYXRoZXIgdGhhbiBsZWF2aW5nIHRoZSBwYWdlIHN0dWNrIGxvYWRpbmdcclxuICAgICAgLy8gYW5kIHRocm93aW5nIGFuIHVuaGFuZGxlZCByZWplY3Rpb24gaW50byB0aGUgY29uc29sZS5cclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGxvYWQgY291cnNlcycsIGVycm9yKVxyXG4gICAgICBzZXRDb3Vyc2VzKFtdKVxyXG4gICAgICBzZXRJblByb2dyZXNzKFtdKVxyXG4gICAgfSlcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNhbmNlbGxlZCA9IHRydWVcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgaW5Qcm9ncmVzc0lkcyA9IG5ldyBTZXQoaW5Qcm9ncmVzcyA/IGluUHJvZ3Jlc3MubWFwKCh7IGNvdXJzZSB9KSA9PiBjb3Vyc2UuaWQpIDogW10pXHJcbiAgY29uc3QgcmVjb21tZW5kZWQgPSBjb3Vyc2VzPy5maWx0ZXIoKGMpID0+ICFpblByb2dyZXNzSWRzLmhhcyhjLmlkKSkgPz8gW11cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaG9tZVwiPlxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjb250ZW50LWNhcmQgaG9tZS1oZWxsb1wiPlxyXG4gICAgICAgIDxoMT5IZWxsbywge2Rpc3BsYXlOYW1lfTwvaDE+XHJcbiAgICAgICAgPHA+V2VsY29tZSBiYWNrIHRvIExlYXJuaWEuPC9wPlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICB7IXVzZXIuZW1haWxfdmVyaWZpZWQgJiYgPFZlcmlmeUVtYWlsQmFubmVyIC8+fVxyXG5cclxuICAgICAge2NvdXJzZXMgJiYgPFN0YXRzU3RyaXAgY291cnNlcz17Y291cnNlc30gaW5Qcm9ncmVzcz17aW5Qcm9ncmVzc30gbGVhcm5lclhwPXtsZWFybmVyWHB9IC8+fVxyXG5cclxuICAgICAge2luUHJvZ3Jlc3MgPT09IG51bGwgJiYgPENvbnRpbnVlQ2FyZFNrZWxldG9uIC8+fVxyXG4gICAgICB7aW5Qcm9ncmVzcyAmJlxyXG4gICAgICAgIGluUHJvZ3Jlc3MubWFwKCh7IGNvdXJzZSwgcHJvZ3Jlc3MgfSkgPT4gKFxyXG4gICAgICAgICAgPENvbnRpbnVlTGVhcm5pbmdDYXJkIGtleT17Y291cnNlLmlkfSBjb3Vyc2U9e2NvdXJzZX0gcHJvZ3Jlc3M9e3Byb2dyZXNzfSAvPlxyXG4gICAgICAgICkpfVxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiaG9tZS1zZWN0aW9uXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob21lLXNlY3Rpb24taGVhZGVyXCI+XHJcbiAgICAgICAgICA8aDI+UmVjb21tZW5kZWQgZm9yIHlvdTwvaDI+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9jb3Vyc2VzXCIgY2xhc3NOYW1lPVwiaG9tZS1zZWUtYWxsXCI+XHJcbiAgICAgICAgICAgIFNlZSBhbGwgPEFycm93UmlnaHQgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291cnNlLWdyaWRcIj5cclxuICAgICAgICAgIHtjb3Vyc2VzID09PSBudWxsICYmIChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8Q291cnNlQ2FyZFNrZWxldG9uIC8+XHJcbiAgICAgICAgICAgICAgPENvdXJzZUNhcmRTa2VsZXRvbiAvPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7Y291cnNlcyAhPT0gbnVsbCAmJlxyXG4gICAgICAgICAgICByZWNvbW1lbmRlZC5tYXAoKGNvdXJzZSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtjb3Vyc2UuaWR9XHJcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDggfX1cclxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxyXG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogaW5kZXggKiAwLjA1IH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPENvdXJzZUNhcmQgY291cnNlPXtjb3Vyc2V9IC8+XHJcbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBDb250aW51ZUxlYXJuaW5nQ2FyZCh7IGNvdXJzZSwgcHJvZ3Jlc3MgfSkge1xyXG4gIGNvbnN0IEljb24gPSBJQ09OU1tjb3Vyc2UuaWNvbl0gPz8gQm9va09wZW5cclxuICBjb25zdCBjb21wbGV0ZWQgPSBwcm9ncmVzcy5jb21wbGV0ZWRQYWdlSWRzXHJcblxyXG4gIC8vIFJlc3VtZSBhdCB0aGUgcGFnZSB0aGUgbGVhcm5lciBsZWZ0IG9mZiBvbiwgZmFsbGluZyBiYWNrIHRvIHRoZSBmaXJzdFxyXG4gIC8vIG5vdC15ZXQtY29tcGxldGVkIHBhZ2UsIHRoZW4gdGhlIHZlcnkgZmlyc3QgcGFnZS5cclxuICBjb25zdCBhbGxQYWdlcyA9IGNvdXJzZS5tb2R1bGVzLmZsYXRNYXAoKG0pID0+IG0uY2hhcHRlcnMuZmxhdE1hcCgoYykgPT4gYy5wYWdlcykpXHJcbiAgY29uc3QgcmVzdW1lUGFnZSA9XHJcbiAgICBhbGxQYWdlcy5maW5kKChwKSA9PiBwLmlkID09PSBwcm9ncmVzcy5sYXN0UGFnZUlkKSA/P1xyXG4gICAgYWxsUGFnZXMuZmluZCgocCkgPT4gIWNvbXBsZXRlZC5pbmNsdWRlcyhwLmlkKSkgPz9cclxuICAgIGFsbFBhZ2VzWzBdXHJcblxyXG4gIGNvbnN0IGxlYXJuaW5nID0gbGVhcm5pbmdQcm9ncmVzcyhjb3Vyc2UsIGNvbXBsZXRlZClcclxuICBjb25zdCBzY29yZSA9IHNjb3JlUHJvZ3Jlc3MoY291cnNlLCBwcm9ncmVzcy5tb2R1bGVRdWl6emVzLCBwcm9ncmVzcy5maW5hbEV4YW0pXHJcblxyXG4gIGNvbnN0IHBhc3NlZCA9IHNjb3JlLnBjdCA+PSBQQVNTSU5HX1BDVFxyXG4gIGNvbnN0IGNvbXBsZXRlID0gbGVhcm5pbmcucGN0ID49IDEwMFxyXG4gIGNvbnN0IHJlc3VtZUhyZWYgPSByZXN1bWVQYWdlXHJcbiAgICA/IGAvY291cnNlcy8ke2NvdXJzZS5zbHVnfS9sZWFybj9wYWdlPSR7cmVzdW1lUGFnZS5pZH1gXHJcbiAgICA6IGAvY291cnNlcy8ke2NvdXJzZS5zbHVnfS9sZWFybmBcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxtb3Rpb24uc2VjdGlvblxyXG4gICAgICBjbGFzc05hbWU9e2Bjb250aW51ZS1jYXJkIGNvbnRpbnVlLWNhcmQtaGVybyR7Y29tcGxldGUgPyAnIGNvbnRpbnVlLWNhcmQtY29tcGxldGUnIDogJyd9YH1cclxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA4IH19XHJcbiAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxyXG4gICAgPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRpbnVlLWNhcmQtaGVyby10b3BcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGNvbnRpbnVlLWNhcmQtaWNvbiR7Y291cnNlLmltYWdlID8gJyBjb250aW51ZS1jYXJkLWljb24taW1hZ2UnIDogJyd9YH0+XHJcbiAgICAgICAgICB7Y291cnNlLmltYWdlID8gKFxyXG4gICAgICAgICAgICA8aW1nIHNyYz17Y291cnNlLmltYWdlfSBhbHQ9XCJcIiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWljb24taW1nXCIgLz5cclxuICAgICAgICAgICkgOiBjb21wbGV0ZSA/IChcclxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsyNn0gLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxJY29uIHNpemU9ezI2fSAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRpbnVlLWNhcmQtYm9keVwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY29udGludWUtY2FyZC1leWVicm93XCI+e2NvbXBsZXRlID8gJ0NvdXJzZSBjb21wbGV0ZScgOiAnQ29udGludWUgbGVhcm5pbmcnfTwvc3Bhbj5cclxuICAgICAgICAgIDxoMj57Y291cnNlLnRpdGxlfTwvaDI+XHJcbiAgICAgICAgICB7Y29tcGxldGUgPyA8cD5FdmVyeSBtb2R1bGUgYW5kIFFDTSBkb25lLjwvcD4gOiByZXN1bWVQYWdlICYmIDxwPk5leHQgdXA6IHtyZXN1bWVQYWdlLnRpdGxlfTwvcD59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWhlcm8tYWN0aW9uc1wiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgc2NvcmUtY2hpcCAke3Bhc3NlZCA/ICdzY29yZS1jaGlwLXBhc3NlZCcgOiAnJ31gfT5cclxuICAgICAgICAgICAge3Bhc3NlZCA/IDxUcm9waHkgc2l6ZT17MTR9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+IDogPFRhcmdldCBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XHJcbiAgICAgICAgICAgIHtzY29yZS5wY3R9LzEwMFxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgey8qIE9wZW5zIHRoZSByZWFkZXIgaW4gaXRzIG93biB0YWIsIG5vdCBjbGllbnQtc2lkZSBTUEEgbmF2IOKAlFxyXG4gICAgICAgICAgICAgIHNlZSBDb3Vyc2VDYXJkLmpzeCBmb3Igd2h5IGEgcGxhaW4gPGE+IGlzIHVzZWQgaGVyZS4gKi99XHJcbiAgICAgICAgICA8YSBocmVmPXtyZXN1bWVIcmVmfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiY29udGludWUtY2FyZC1jdGFcIj5cclxuICAgICAgICAgICAge2NvbXBsZXRlID8gJ1JldmlldycgOiAnUmVzdW1lJ30gPEFycm93UmlnaHQgc2l6ZT17MTZ9IC8+XHJcbiAgICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPE1vZHVsZVRyYWNrIGNvdXJzZT17Y291cnNlfSBwcm9ncmVzcz17cHJvZ3Jlc3N9IGxlYXJuaW5nPXtsZWFybmluZ30gLz5cclxuICAgIDwvbW90aW9uLnNlY3Rpb24+XHJcbiAgKVxyXG59XHJcblxyXG4vLyBBIERhdGFDYW1wLXN0eWxlIHNraWxsLXRyYWNrIGJhcjogb25lIHNlZ21lbnQgcGVyIG1vZHVsZSAoZG9uZSAvIGN1cnJlbnRcclxuLy8gLyB1cGNvbWluZy9sb2NrZWQpIGluc3RlYWQgb2YgYSBzaW5nbGUgZmlsbGVkIGJhciwgc28gdGhlIHNoYXBlIG9mIHRoZVxyXG4vLyBjb3Vyc2Ug4oCUIG5vdCBqdXN0IGEgcGVyY2VudGFnZSDigJQgaXMgdmlzaWJsZSBhdCBhIGdsYW5jZS5cclxuZnVuY3Rpb24gTW9kdWxlVHJhY2soeyBjb3Vyc2UsIHByb2dyZXNzLCBsZWFybmluZyB9KSB7XHJcbiAgY29uc3QgY29tcGxldGVkID0gbmV3IFNldChwcm9ncmVzcy5jb21wbGV0ZWRQYWdlSWRzKVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNoYXB0ZXItdHJhY2tcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGFwdGVyLXRyYWNrLWhlYWRlclwiPlxyXG4gICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAge2xlYXJuaW5nLmVhcm5lZH0ve2xlYXJuaW5nLnRvdGFsfSBwdHNcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4+e2xlYXJuaW5nLnBjdH0lIGNvbXBsZXRlPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjaGFwdGVyLXRyYWNrLWJhclwiPlxyXG4gICAgICAgIHtjb3Vyc2UubW9kdWxlcy5tYXAoKGNvdXJzZU1vZHVsZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZG9uZSA9IGlzTW9kdWxlQ29tcGxldGUoY291cnNlTW9kdWxlLCBbLi4uY29tcGxldGVkXSwgcHJvZ3Jlc3MubW9kdWxlUXVpenplcylcclxuICAgICAgICAgIGNvbnN0IHBhZ2VzID0gY291cnNlTW9kdWxlLmNoYXB0ZXJzLmZsYXRNYXAoKGMpID0+IGMucGFnZXMpXHJcbiAgICAgICAgICBjb25zdCBzdGFydGVkID0gcGFnZXMuc29tZSgocCkgPT4gY29tcGxldGVkLmhhcyhwLmlkKSlcclxuICAgICAgICAgIGNvbnN0IHN0YXRlID0gZG9uZSA/ICdkb25lJyA6IHN0YXJ0ZWQgPyAnY3VycmVudCcgOiAndXBjb21pbmcnXHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgIGtleT17Y291cnNlTW9kdWxlLmlkfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGNoYXB0ZXItc2VnbWVudCBjaGFwdGVyLXNlZ21lbnQtJHtzdGF0ZX1gfVxyXG4gICAgICAgICAgICAgIHRpdGxlPXtjb3Vyc2VNb2R1bGUudGl0bGV9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5mdW5jdGlvbiBDb250aW51ZUNhcmRTa2VsZXRvbigpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkIGNvbnRpbnVlLWNhcmQtc2tlbGV0b25cIj5cclxuICAgICAgPFNrZWxldG9uIGNpcmNsZSB3aWR0aD1cIjNyZW1cIiBoZWlnaHQ9XCIzcmVtXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250aW51ZS1jYXJkLWJvZHlcIj5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCIzMCVcIiBoZWlnaHQ9XCIwLjc1cmVtXCIgLz5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCI1NSVcIiBoZWlnaHQ9XCIxLjJyZW1cIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZnVuY3Rpb24gU3RhdHNTdHJpcCh7IGNvdXJzZXMsIGluUHJvZ3Jlc3MsIGxlYXJuZXJYcCB9KSB7XHJcbiAgY29uc3QgdG90YWxDb3Vyc2VzID0gY291cnNlcy5sZW5ndGhcclxuICBjb25zdCBjb21wbGV0ZWRQYWdlcyA9IGluUHJvZ3Jlc3NcclxuICAgID8gaW5Qcm9ncmVzcy5yZWR1Y2UoKHN1bSwgeyBwcm9ncmVzcyB9KSA9PiBzdW0gKyBwcm9ncmVzcy5jb21wbGV0ZWRQYWdlSWRzLmxlbmd0aCwgMClcclxuICAgIDogMFxyXG4gIGNvbnN0IGV4YW1zUGFzc2VkID0gaW5Qcm9ncmVzc1xyXG4gICAgPyBpblByb2dyZXNzLmZpbHRlcigoeyBwcm9ncmVzcyB9KSA9PiBpc1F1aXpQYXNzZWQocHJvZ3Jlc3MuZmluYWxFeGFtKSkubGVuZ3RoXHJcbiAgICA6IDBcclxuICBjb25zdCBzdGF0cyA9IFtcclxuICAgIHsgaWNvbjogQm9va09wZW4sIGxhYmVsOiAnQ291cnNlcyBhdmFpbGFibGUnLCB2YWx1ZTogdG90YWxDb3Vyc2VzIH0sXHJcbiAgICB7IGljb246IEZsYW1lLCBsYWJlbDogJ1BhZ2VzIGNvbXBsZXRlZCcsIHZhbHVlOiBjb21wbGV0ZWRQYWdlcyB9LFxyXG4gICAgeyBpY29uOiBUcm9waHksIGxhYmVsOiAnRXhhbXMgcGFzc2VkJywgdmFsdWU6IGV4YW1zUGFzc2VkIH0sXHJcbiAgICB7IGljb246IFNwYXJrbGVzLCBsYWJlbDogJ1hQIGVhcm5lZCcsIHZhbHVlOiBsZWFybmVyWHAgPyBsZWFybmVyWHAueHAgOiAn4oCUJyB9LFxyXG4gIF1cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3RhdHMtc3RyaXBcIj5cclxuICAgICAge3N0YXRzLm1hcCgoeyBpY29uOiBJY29uLCBsYWJlbCwgdmFsdWUgfSkgPT4gKFxyXG4gICAgICAgIDxkaXYga2V5PXtsYWJlbH0gY2xhc3NOYW1lPVwic3RhdC10aWxlXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0LXRpbGUtaWNvblwiPlxyXG4gICAgICAgICAgICA8SWNvbiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdC10aWxlLXZhbHVlXCI+e3ZhbHVlfTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXQtdGlsZS1sYWJlbFwiPntsYWJlbH08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuXHJcbi8vIFNob3duIG9ubHkgd2hpbGUgdGhlIGFjY291bnQncyBlbWFpbCBpcyB1bnZlcmlmaWVkIChzZWUgdXNlcnMuZW1haWxfdmVyaWZpZWRfYXQpLlxyXG5mdW5jdGlvbiBWZXJpZnlFbWFpbEJhbm5lcigpIHtcclxuICBjb25zdCBbc3RhdHVzLCBzZXRTdGF0dXNdID0gdXNlU3RhdGUoJ2lkbGUnKSAvLyBpZGxlIHwgc2VuZGluZyB8IHNlbnQgfCBlcnJvclxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVSZXNlbmQoKSB7XHJcbiAgICBzZXRTdGF0dXMoJ3NlbmRpbmcnKVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXV0aEFwaS5zZW5kVmVyaWZpY2F0aW9uRW1haWwoKVxyXG4gICAgICBzZXRTdGF0dXMoJ3NlbnQnKVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldFN0YXR1cyhlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogJ1NvbWV0aGluZyB3ZW50IHdyb25nJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJiYW5uZXIgYmFubmVyLXdhcm5pbmdcIj5cclxuICAgICAgPEFsZXJ0VHJpYW5nbGUgc2l6ZT17MjB9IGNsYXNzTmFtZT1cImJhbm5lci1pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiYW5uZXItYm9keVwiPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImJhbm5lci10aXRsZVwiPllvdXIgZW1haWwgaXNuJ3QgdmVyaWZpZWQgeWV0PC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImJhbm5lci1jYXB0aW9uXCI+XHJcbiAgICAgICAgICBWZXJpZnkgaXQgdG8gbWFrZSBzdXJlIHlvdSBjYW4gcmVjb3ZlciB5b3VyIGFjY291bnQgYW5kIHJlY2VpdmUgaW1wb3J0YW50IHVwZGF0ZXMuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIHtzdGF0dXMgPT09ICdzZW50JyA/IChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJhbm5lci1zdGF0dXMgYmFubmVyLXN0YXR1cy1va1wiPlxyXG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezE0fSAvPiBTZW50IOKAlCBjaGVjayB5b3VyIGluYm94LlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICkgOiBzdGF0dXMgIT09ICdpZGxlJyAmJiBzdGF0dXMgIT09ICdzZW5kaW5nJyA/IChcclxuICAgICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImJhbm5lci1zdGF0dXMgYmFubmVyLXN0YXR1cy1lcnJvclwiPlxyXG4gICAgICAgICAgICA8TWFpbFdhcm5pbmcgc2l6ZT17MTR9IC8+IHtzdGF0dXN9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJhbm5lci1hY3Rpb25cIiBkaXNhYmxlZD17c3RhdHVzID09PSAnc2VuZGluZyd9IG9uQ2xpY2s9e2hhbmRsZVJlc2VuZH0+XHJcbiAgICAgICAgICAgIHtzdGF0dXMgPT09ICdzZW5kaW5nJyA/ICdTZW5kaW5n4oCmJyA6ICdSZXNlbmQgdmVyaWZpY2F0aW9uIGVtYWlsJ31cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==