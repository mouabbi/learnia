import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "/api/v1", "VITE_LOG_LEVEL": "debug"};/**
* Tiny console logger with levels and a scope tag, so you can see exactly what
* the app does (API calls, auth actions, redirects) in the browser console.
*
*   const log = createLogger('auth')
*   log.info('login ok', { userId: 3 })
*   // 14:02:11.532 INFO  [auth] login ok { userId: 3 }
*
* Level comes from VITE_LOG_LEVEL (debug | info | warn | error | silent).
* If unset: 'debug' while developing (npm run dev), 'warn' in a production build.
*
* Never pass passwords, tokens, or request bodies to the logger: anything logged
* is visible to whoever opens the console.
*/
const LEVELS = {
	debug: 10,
	info: 20,
	warn: 30,
	error: 40,
	silent: 100
};
const configured = import.meta.env.VITE_LOG_LEVEL ?? (import.meta.env.DEV ? "debug" : "warn");
const threshold = LEVELS[configured] ?? LEVELS.info;
function write(level, scope, message, data) {
	if (LEVELS[level] < threshold) return;
	const time = new Date().toISOString().slice(11, 23);
	const line = `${time} ${level.toUpperCase().padEnd(5)} [${scope}] ${message}`;
	// console.debug/info/warn/error exist with the same names as our levels.
	if (data === undefined) console[level](line);
	else console[level](line, data);
}
export function createLogger(scope) {
	return {
		debug: (message, data) => write("debug", scope, message, data),
		info: (message, data) => write("info", scope, message, data),
		warn: (message, data) => write("warn", scope, message, data),
		error: (message, data) => write("error", scope, message, data)
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFlQSxNQUFNLFNBQVM7Q0FBRSxPQUFPO0NBQUksTUFBTTtDQUFJLE1BQU07Q0FBSSxPQUFPO0NBQUksUUFBUTtBQUFJO0FBRXZFLE1BQU0sYUFBYSxZQUFZLElBQUksbUJBQW1CLFlBQVksSUFBSSxNQUFNLFVBQVU7QUFDdEYsTUFBTSxZQUFZLE9BQU8sZUFBZSxPQUFPO0FBRS9DLFNBQVMsTUFBTSxPQUFPLE9BQU8sU0FBUyxNQUFNO0NBQzFDLElBQUksT0FBTyxTQUFTLFdBQVc7Q0FFL0IsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxJQUFJLEVBQUU7Q0FDbEQsTUFBTSxPQUFPLEdBQUcsS0FBSyxHQUFHLE1BQU0sWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxNQUFNLElBQUk7O0NBR3BFLElBQUksU0FBUyxXQUFXLFFBQVEsTUFBTSxDQUFDLElBQUk7TUFDdEMsUUFBUSxNQUFNLENBQUMsTUFBTSxJQUFJO0FBQ2hDO0FBRUEsT0FBTyxTQUFTLGFBQWEsT0FBTztDQUNsQyxPQUFPO0VBQ0wsUUFBUSxTQUFTLFNBQVMsTUFBTSxTQUFTLE9BQU8sU0FBUyxJQUFJO0VBQzdELE9BQU8sU0FBUyxTQUFTLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSTtFQUMzRCxPQUFPLFNBQVMsU0FBUyxNQUFNLFFBQVEsT0FBTyxTQUFTLElBQUk7RUFDM0QsUUFBUSxTQUFTLFNBQVMsTUFBTSxTQUFTLE9BQU8sU0FBUyxJQUFJO0NBQy9EO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibG9nZ2VyLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBUaW55IGNvbnNvbGUgbG9nZ2VyIHdpdGggbGV2ZWxzIGFuZCBhIHNjb3BlIHRhZywgc28geW91IGNhbiBzZWUgZXhhY3RseSB3aGF0XHJcbiAqIHRoZSBhcHAgZG9lcyAoQVBJIGNhbGxzLCBhdXRoIGFjdGlvbnMsIHJlZGlyZWN0cykgaW4gdGhlIGJyb3dzZXIgY29uc29sZS5cclxuICpcclxuICogICBjb25zdCBsb2cgPSBjcmVhdGVMb2dnZXIoJ2F1dGgnKVxyXG4gKiAgIGxvZy5pbmZvKCdsb2dpbiBvaycsIHsgdXNlcklkOiAzIH0pXHJcbiAqICAgLy8gMTQ6MDI6MTEuNTMyIElORk8gIFthdXRoXSBsb2dpbiBvayB7IHVzZXJJZDogMyB9XHJcbiAqXHJcbiAqIExldmVsIGNvbWVzIGZyb20gVklURV9MT0dfTEVWRUwgKGRlYnVnIHwgaW5mbyB8IHdhcm4gfCBlcnJvciB8IHNpbGVudCkuXHJcbiAqIElmIHVuc2V0OiAnZGVidWcnIHdoaWxlIGRldmVsb3BpbmcgKG5wbSBydW4gZGV2KSwgJ3dhcm4nIGluIGEgcHJvZHVjdGlvbiBidWlsZC5cclxuICpcclxuICogTmV2ZXIgcGFzcyBwYXNzd29yZHMsIHRva2Vucywgb3IgcmVxdWVzdCBib2RpZXMgdG8gdGhlIGxvZ2dlcjogYW55dGhpbmcgbG9nZ2VkXHJcbiAqIGlzIHZpc2libGUgdG8gd2hvZXZlciBvcGVucyB0aGUgY29uc29sZS5cclxuICovXHJcblxyXG5jb25zdCBMRVZFTFMgPSB7IGRlYnVnOiAxMCwgaW5mbzogMjAsIHdhcm46IDMwLCBlcnJvcjogNDAsIHNpbGVudDogMTAwIH1cclxuXHJcbmNvbnN0IGNvbmZpZ3VyZWQgPSBpbXBvcnQubWV0YS5lbnYuVklURV9MT0dfTEVWRUwgPz8gKGltcG9ydC5tZXRhLmVudi5ERVYgPyAnZGVidWcnIDogJ3dhcm4nKVxyXG5jb25zdCB0aHJlc2hvbGQgPSBMRVZFTFNbY29uZmlndXJlZF0gPz8gTEVWRUxTLmluZm9cclxuXHJcbmZ1bmN0aW9uIHdyaXRlKGxldmVsLCBzY29wZSwgbWVzc2FnZSwgZGF0YSkge1xyXG4gIGlmIChMRVZFTFNbbGV2ZWxdIDwgdGhyZXNob2xkKSByZXR1cm5cclxuXHJcbiAgY29uc3QgdGltZSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgxMSwgMjMpIC8vIEhIOk1NOlNTLm1tbVxyXG4gIGNvbnN0IGxpbmUgPSBgJHt0aW1lfSAke2xldmVsLnRvVXBwZXJDYXNlKCkucGFkRW5kKDUpfSBbJHtzY29wZX1dICR7bWVzc2FnZX1gXHJcblxyXG4gIC8vIGNvbnNvbGUuZGVidWcvaW5mby93YXJuL2Vycm9yIGV4aXN0IHdpdGggdGhlIHNhbWUgbmFtZXMgYXMgb3VyIGxldmVscy5cclxuICBpZiAoZGF0YSA9PT0gdW5kZWZpbmVkKSBjb25zb2xlW2xldmVsXShsaW5lKVxyXG4gIGVsc2UgY29uc29sZVtsZXZlbF0obGluZSwgZGF0YSlcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUxvZ2dlcihzY29wZSkge1xyXG4gIHJldHVybiB7XHJcbiAgICBkZWJ1ZzogKG1lc3NhZ2UsIGRhdGEpID0+IHdyaXRlKCdkZWJ1ZycsIHNjb3BlLCBtZXNzYWdlLCBkYXRhKSxcclxuICAgIGluZm86IChtZXNzYWdlLCBkYXRhKSA9PiB3cml0ZSgnaW5mbycsIHNjb3BlLCBtZXNzYWdlLCBkYXRhKSxcclxuICAgIHdhcm46IChtZXNzYWdlLCBkYXRhKSA9PiB3cml0ZSgnd2FybicsIHNjb3BlLCBtZXNzYWdlLCBkYXRhKSxcclxuICAgIGVycm9yOiAobWVzc2FnZSwgZGF0YSkgPT4gd3JpdGUoJ2Vycm9yJywgc2NvcGUsIG1lc3NhZ2UsIGRhdGEpLFxyXG4gIH1cclxufVxyXG4iXX0=