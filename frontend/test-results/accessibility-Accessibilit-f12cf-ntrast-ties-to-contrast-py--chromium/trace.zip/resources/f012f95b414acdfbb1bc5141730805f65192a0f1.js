// Small color-math helpers for the accent-color picker (see
// hooks/useAccentColor.js) — no color library needed for this.
export function hexToRgb(hex) {
	const value = hex.replace("#", "");
	const bigint = parseInt(value, 16);
	return {
		r: bigint >> 16 & 255,
		g: bigint >> 8 & 255,
		b: bigint & 255
	};
}
function toHexByte(value) {
	return Math.max(0, Math.min(255, Math.round(value))).toString(16).padStart(2, "0");
}
// Lighten (positive percent) or darken (negative) a hex color — used to
// derive --accent-hover from the user's chosen --accent.
export function shade(hex, percent) {
	const { r, g, b } = hexToRgb(hex);
	const amount = percent / 100 * 255;
	return `#${toHexByte(r + amount)}${toHexByte(g + amount)}${toHexByte(b + amount)}`;
}
// Picks black or white text over a given background so any accent color
// the user chooses stays readable (used for --accent-text).
export function contrastText(hex) {
	const { r, g, b } = hexToRgb(hex);
	const luminance = (.299 * r + .587 * g + .114 * b) / 255;
	return luminance > .6 ? "#111827" : "#ffffff";
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFHQSxPQUFPLFNBQVMsU0FBUyxLQUFLO0NBQzVCLE1BQU0sUUFBUSxJQUFJLFFBQVEsS0FBSyxFQUFFO0NBQ2pDLE1BQU0sU0FBUyxTQUFTLE9BQU8sRUFBRTtDQUNqQyxPQUFPO0VBQUUsR0FBSSxVQUFVLEtBQU07RUFBSyxHQUFJLFVBQVUsSUFBSztFQUFLLEdBQUcsU0FBUztDQUFJO0FBQzVFO0FBRUEsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxLQUFLLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7QUFDbkY7OztBQUlBLE9BQU8sU0FBUyxNQUFNLEtBQUssU0FBUztDQUNsQyxNQUFNLEVBQUUsR0FBRyxHQUFHLE1BQU0sU0FBUyxHQUFHO0NBQ2hDLE1BQU0sU0FBVSxVQUFVLE1BQU87Q0FDakMsT0FBTyxJQUFJLFVBQVUsSUFBSSxNQUFNLElBQUksVUFBVSxJQUFJLE1BQU0sSUFBSSxVQUFVLElBQUksTUFBTTtBQUNqRjs7O0FBSUEsT0FBTyxTQUFTLGFBQWEsS0FBSztDQUNoQyxNQUFNLEVBQUUsR0FBRyxHQUFHLE1BQU0sU0FBUyxHQUFHO0NBQ2hDLE1BQU0sYUFBYSxPQUFRLElBQUksT0FBUSxJQUFJLE9BQVEsS0FBSztDQUN4RCxPQUFPLFlBQVksS0FBTSxZQUFZO0FBQ3ZDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImNvbG9yLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8vIFNtYWxsIGNvbG9yLW1hdGggaGVscGVycyBmb3IgdGhlIGFjY2VudC1jb2xvciBwaWNrZXIgKHNlZVxyXG4vLyBob29rcy91c2VBY2NlbnRDb2xvci5qcykg4oCUIG5vIGNvbG9yIGxpYnJhcnkgbmVlZGVkIGZvciB0aGlzLlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGhleFRvUmdiKGhleCkge1xyXG4gIGNvbnN0IHZhbHVlID0gaGV4LnJlcGxhY2UoJyMnLCAnJylcclxuICBjb25zdCBiaWdpbnQgPSBwYXJzZUludCh2YWx1ZSwgMTYpXHJcbiAgcmV0dXJuIHsgcjogKGJpZ2ludCA+PiAxNikgJiAyNTUsIGc6IChiaWdpbnQgPj4gOCkgJiAyNTUsIGI6IGJpZ2ludCAmIDI1NSB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRvSGV4Qnl0ZSh2YWx1ZSkge1xyXG4gIHJldHVybiBNYXRoLm1heCgwLCBNYXRoLm1pbigyNTUsIE1hdGgucm91bmQodmFsdWUpKSkudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJylcclxufVxyXG5cclxuLy8gTGlnaHRlbiAocG9zaXRpdmUgcGVyY2VudCkgb3IgZGFya2VuIChuZWdhdGl2ZSkgYSBoZXggY29sb3Ig4oCUIHVzZWQgdG9cclxuLy8gZGVyaXZlIC0tYWNjZW50LWhvdmVyIGZyb20gdGhlIHVzZXIncyBjaG9zZW4gLS1hY2NlbnQuXHJcbmV4cG9ydCBmdW5jdGlvbiBzaGFkZShoZXgsIHBlcmNlbnQpIHtcclxuICBjb25zdCB7IHIsIGcsIGIgfSA9IGhleFRvUmdiKGhleClcclxuICBjb25zdCBhbW91bnQgPSAocGVyY2VudCAvIDEwMCkgKiAyNTVcclxuICByZXR1cm4gYCMke3RvSGV4Qnl0ZShyICsgYW1vdW50KX0ke3RvSGV4Qnl0ZShnICsgYW1vdW50KX0ke3RvSGV4Qnl0ZShiICsgYW1vdW50KX1gXHJcbn1cclxuXHJcbi8vIFBpY2tzIGJsYWNrIG9yIHdoaXRlIHRleHQgb3ZlciBhIGdpdmVuIGJhY2tncm91bmQgc28gYW55IGFjY2VudCBjb2xvclxyXG4vLyB0aGUgdXNlciBjaG9vc2VzIHN0YXlzIHJlYWRhYmxlICh1c2VkIGZvciAtLWFjY2VudC10ZXh0KS5cclxuZXhwb3J0IGZ1bmN0aW9uIGNvbnRyYXN0VGV4dChoZXgpIHtcclxuICBjb25zdCB7IHIsIGcsIGIgfSA9IGhleFRvUmdiKGhleClcclxuICBjb25zdCBsdW1pbmFuY2UgPSAoMC4yOTkgKiByICsgMC41ODcgKiBnICsgMC4xMTQgKiBiKSAvIDI1NVxyXG4gIHJldHVybiBsdW1pbmFuY2UgPiAwLjYgPyAnIzExMTgyNycgOiAnI2ZmZmZmZidcclxufVxyXG4iXX0=