import { apiClient } from "/src/api/client.js";
// Real backend — see backend/src/learnia_backend/routers/theme.py.
// Same thin-wrapper pattern as features/courses/coursesApi.js: plain
// async functions returning whatever the backend gives back, no caching
// or state here — that's ThemeEditor's job.
export const themeApi = {
	// -> { theme: CourseTheme, warnings: string[] }
	getTheme: (courseId) => apiClient.get(`/courses/${courseId}/theme`),
	// -> { theme: CourseTheme, warnings: string[] }
	updateTheme: (courseId, theme) => apiClient.patch(`/courses/${courseId}/theme`, theme)
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7Ozs7O0FBTTFCLE9BQU8sTUFBTSxXQUFXOztDQUV0QixXQUFXLGFBQWEsVUFBVSxJQUFJLFlBQVksU0FBUyxPQUFPOztDQUVsRSxjQUFjLFVBQVUsVUFBVSxVQUFVLE1BQU0sWUFBWSxTQUFTLFNBQVMsS0FBSztBQUN2RiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ0aGVtZUFwaS5qcyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhcGlDbGllbnQgfSBmcm9tICcuLi8uLi9hcGkvY2xpZW50J1xuXG4vLyBSZWFsIGJhY2tlbmQg4oCUIHNlZSBiYWNrZW5kL3NyYy9sZWFybmlhX2JhY2tlbmQvcm91dGVycy90aGVtZS5weS5cbi8vIFNhbWUgdGhpbi13cmFwcGVyIHBhdHRlcm4gYXMgZmVhdHVyZXMvY291cnNlcy9jb3Vyc2VzQXBpLmpzOiBwbGFpblxuLy8gYXN5bmMgZnVuY3Rpb25zIHJldHVybmluZyB3aGF0ZXZlciB0aGUgYmFja2VuZCBnaXZlcyBiYWNrLCBubyBjYWNoaW5nXG4vLyBvciBzdGF0ZSBoZXJlIOKAlCB0aGF0J3MgVGhlbWVFZGl0b3IncyBqb2IuXG5leHBvcnQgY29uc3QgdGhlbWVBcGkgPSB7XG4gIC8vIC0+IHsgdGhlbWU6IENvdXJzZVRoZW1lLCB3YXJuaW5nczogc3RyaW5nW10gfVxuICBnZXRUaGVtZTogKGNvdXJzZUlkKSA9PiBhcGlDbGllbnQuZ2V0KGAvY291cnNlcy8ke2NvdXJzZUlkfS90aGVtZWApLFxuICAvLyAtPiB7IHRoZW1lOiBDb3Vyc2VUaGVtZSwgd2FybmluZ3M6IHN0cmluZ1tdIH1cbiAgdXBkYXRlVGhlbWU6IChjb3Vyc2VJZCwgdGhlbWUpID0+IGFwaUNsaWVudC5wYXRjaChgL2NvdXJzZXMvJHtjb3Vyc2VJZH0vdGhlbWVgLCB0aGVtZSksXG59XG4iXX0=