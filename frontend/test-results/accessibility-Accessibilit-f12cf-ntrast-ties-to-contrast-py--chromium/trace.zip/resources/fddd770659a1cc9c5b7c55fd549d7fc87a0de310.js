import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ResetPasswordPage.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { authApi } from "/src/features/auth/authApi.js";
import { ApiError } from "/src/api/client.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/ResetPasswordPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Reached via the link emailed by ForgotPasswordPage: /reset-password?token=...
export function ResetPasswordPage() {
	_s();
	const [searchParams] = useSearchParams();
	const token = searchParams.get("token");
	const navigate = useNavigate();
	const [password, setPassword] = useState("");
	const [error, setError] = useState(null);
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError(null);
		setIsSubmitting(true);
		try {
			await authApi.resetPassword(token, password);
			navigate("/login");
		} catch (err) {
			// Covers both a bad request and an invalid/expired/already-used token
			// (backend returns the same 422 shape for both — see account_service.py).
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsSubmitting(false);
		}
	}
	if (!token) {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "page",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", { children: "Reset password" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "error",
					children: "This link is missing its token."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", { children: /* @__PURE__ */ _jsxDEV(Link, {
					to: "/forgot-password",
					children: "Request a new link"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "page",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Reset password" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "password",
						children: "New password"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "password",
						type: "password",
						minLength: 8,
						value: password,
						onChange: (e) => setPassword(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hint",
						children: "At least 8 characters."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "error",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					children: isSubmitting ? "Saving..." : "Set new password"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
}
_s(ResetPasswordPage, "k0sbDvj+k8eihAuAI3wRKfvKU48=", false, function() {
	return [useSearchParams, useNavigate];
});
_c = ResetPasswordPage;
var _c;
$RefreshReg$(_c, "ResetPasswordPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ResetPasswordPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/ResetPasswordPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/ResetPasswordPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/ResetPasswordPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLGFBQWEsdUJBQXVCO0FBQ25ELFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7Ozs7QUFHekIsT0FBTyxTQUFTLG9CQUFvQjs7Q0FDbEMsTUFBTSxDQUFDLGdCQUFnQixnQkFBZ0I7Q0FDdkMsTUFBTSxRQUFRLGFBQWEsSUFBSSxPQUFPO0NBQ3RDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FFdEQsZUFBZSxhQUFhLE9BQU87RUFDakMsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsSUFBSTtFQUNiLGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDRixNQUFNLFFBQVEsY0FBYyxPQUFPLFFBQVE7R0FDM0MsU0FBUyxRQUFRO0VBQ25CLFNBQVMsS0FBSzs7O0dBR1osU0FBUyxlQUFlLFdBQVcsSUFBSSxVQUFVLHNCQUFzQjtFQUN6RSxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLElBQUksQ0FBQyxPQUFPO0VBQ1YsT0FDRSx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQjtJQUNFLHdCQUFDLE1BQUQsWUFBSSxpQkFBa0I7Ozs7O0lBQ3RCLHdCQUFDLEtBQUQ7S0FBRyxNQUFLO0tBQVEsV0FBVTtlQUFRO0lBRS9COzs7OztJQUNILHdCQUFDLEtBQUQsWUFDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztlQUFtQjtJQUF3Qjs7OzthQUNuRDs7Ozs7R0FDSTs7Ozs7O0NBRWI7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7OztZQUN0Qix3QkFBQyxRQUFEO0dBQU0sVUFBVTthQUFoQjtJQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBVztLQUFtQjs7Ozs7S0FDN0Msd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsV0FBVztNQUNYLE9BQU87TUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztNQUMzQztLQUNEOzs7OztLQUNELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFPO0tBQXlCOzs7OztJQUMxQzs7Ozs7SUFDSixTQUNDLHdCQUFDLEtBQUQ7S0FBRyxNQUFLO0tBQVEsV0FBVTtlQUN2QjtJQUNBOzs7OztJQUVMLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVTtlQUM3QixlQUFlLGNBQWM7SUFDeEI7Ozs7O0dBQ0o7Ozs7O1VBQ0M7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlc2V0UGFzc3dvcmRQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlU2VhcmNoUGFyYW1zIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvYXV0aEFwaSdcclxuaW1wb3J0IHsgQXBpRXJyb3IgfSBmcm9tICcuLi9hcGkvY2xpZW50J1xyXG5cclxuLy8gUmVhY2hlZCB2aWEgdGhlIGxpbmsgZW1haWxlZCBieSBGb3Jnb3RQYXNzd29yZFBhZ2U6IC9yZXNldC1wYXNzd29yZD90b2tlbj0uLi5cclxuZXhwb3J0IGZ1bmN0aW9uIFJlc2V0UGFzc3dvcmRQYWdlKCkge1xyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXNdID0gdXNlU2VhcmNoUGFyYW1zKClcclxuICBjb25zdCB0b2tlbiA9IHNlYXJjaFBhcmFtcy5nZXQoJ3Rva2VuJylcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKClcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXV0aEFwaS5yZXNldFBhc3N3b3JkKHRva2VuLCBwYXNzd29yZClcclxuICAgICAgbmF2aWdhdGUoJy9sb2dpbicpXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgLy8gQ292ZXJzIGJvdGggYSBiYWQgcmVxdWVzdCBhbmQgYW4gaW52YWxpZC9leHBpcmVkL2FscmVhZHktdXNlZCB0b2tlblxyXG4gICAgICAvLyAoYmFja2VuZCByZXR1cm5zIHRoZSBzYW1lIDQyMiBzaGFwZSBmb3IgYm90aCDigJQgc2VlIGFjY291bnRfc2VydmljZS5weSkuXHJcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEFwaUVycm9yID8gZXJyLm1lc3NhZ2UgOiAnU29tZXRoaW5nIHdlbnQgd3JvbmcnKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaWYgKCF0b2tlbikge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICAgIDxoMT5SZXNldCBwYXNzd29yZDwvaDE+XHJcbiAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZXJyb3JcIj5cclxuICAgICAgICAgIFRoaXMgbGluayBpcyBtaXNzaW5nIGl0cyB0b2tlbi5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPHA+XHJcbiAgICAgICAgICA8TGluayB0bz1cIi9mb3Jnb3QtcGFzc3dvcmRcIj5SZXF1ZXN0IGEgbmV3IGxpbms8L0xpbms+XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZVwiPlxyXG4gICAgICA8aDE+UmVzZXQgcGFzc3dvcmQ8L2gxPlxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiPk5ldyBwYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cclxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJoaW50XCI+QXQgbGVhc3QgOCBjaGFyYWN0ZXJzLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZXJyb3JcIj5cclxuICAgICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ30+XHJcbiAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gJ1NhdmluZy4uLicgOiAnU2V0IG5ldyBwYXNzd29yZCd9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuIl19