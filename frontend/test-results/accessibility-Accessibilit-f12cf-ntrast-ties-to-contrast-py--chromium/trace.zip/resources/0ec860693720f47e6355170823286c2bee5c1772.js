import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/search/GlobalSearch.jsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];/**
* Global command-palette search (14-global-search). Self-contained: it
* manages its own open/closed state internally, listening for Ctrl+K /
* Cmd+K on `window`, so the only integration another file needs is
* rendering `<GlobalSearch />` once near the app root (e.g. in App.jsx or
* AppLayout) — no props required. Not wired into App.jsx yet, per this
* task's scope (avoiding a concurrent edit to that file); whoever wires it
* in just needs to add that one render.
*
* Navigation limitation: the reader (features/courses' course reader) does
* not support deep-linking to a specific page via URL today, so clicking a
* page/chapter/module result just navigates to `/courses/{slug}/learn`
* (the course's reader entry point), not to that exact page. Clicking a
* course result navigates to the same route. A future reader change to
* support `?page=` (or similar) could make this precise.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { Search, BookOpen, Layers, Bookmark, FileText, X } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { searchApi } from "/src/features/search/searchApi.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/search/GlobalSearch.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const DEBOUNCE_MS = 250;
const TYPE_ICON = {
	course: BookOpen,
	module: Layers,
	chapter: Bookmark,
	page: FileText
};
const TYPE_LABEL = {
	course: "Course",
	module: "Module",
	chapter: "Chapter",
	page: "Page"
};
export function GlobalSearch() {
	_s();
	const [isOpen, setIsOpen] = useState(false);
	const [query, setQuery] = useState("");
	const [results, setResults] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const inputRef = useRef(null);
	const debounceRef = useRef(null);
	const navigate = useNavigate();
	const close = useCallback(() => {
		setIsOpen(false);
		setQuery("");
		setResults([]);
	}, []);
	// Ctrl+K / Cmd+K opens the palette from anywhere; Escape closes it.
	useEffect(() => {
		function onKeyDown(e) {
			if ((e.metaKey || e.ctrlKey) && e.key === "k") {
				e.preventDefault();
				setIsOpen((open) => !open);
			} else if (e.key === "Escape") {
				setIsOpen(false);
			}
		}
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, []);
	// Focus the input as soon as the palette opens.
	useEffect(() => {
		if (isOpen) inputRef.current?.focus();
	}, [isOpen]);
	// Debounced query-as-you-type.
	useEffect(() => {
		if (debounceRef.current) clearTimeout(debounceRef.current);
		if (!query.trim()) {
			setResults([]);
			setIsLoading(false);
			return;
		}
		setIsLoading(true);
		debounceRef.current = setTimeout(async () => {
			try {
				const data = await searchApi.search(query.trim());
				setResults(data?.results ?? []);
			} catch {
				setResults([]);
			} finally {
				setIsLoading(false);
			}
		}, DEBOUNCE_MS);
		return () => clearTimeout(debounceRef.current);
	}, [query]);
	function handleSelect(result) {
		// See file-top docstring: no deep-linking into a specific page/chapter
		// yet, so every result type lands on the course's reader entry point.
		navigate(`/courses/${result.courseSlug}/learn`);
		close();
	}
	return /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isOpen && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(motion.div, {
		className: "global-search-overlay",
		onClick: close,
		"aria-hidden": "true",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		transition: { duration: .15 }
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 110,
		columnNumber: 11
	}, this), /* @__PURE__ */ _jsxDEV(motion.div, {
		className: "global-search-panel",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Global search",
		initial: {
			opacity: 0,
			scale: .97,
			y: -8
		},
		animate: {
			opacity: 1,
			scale: 1,
			y: 0
		},
		exit: {
			opacity: 0,
			scale: .97,
			y: -8
		},
		transition: {
			type: "tween",
			duration: .18,
			ease: "easeOut"
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "global-search-input-row",
			children: [
				/* @__PURE__ */ _jsxDEV(Search, {
					"aria-hidden": "true",
					size: 18
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					ref: inputRef,
					type: "text",
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Search courses, chapters, pages...",
					"aria-label": "Search"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "global-search-close",
					onClick: close,
					"aria-label": "Close search",
					title: "Close",
					children: /* @__PURE__ */ _jsxDEV(X, {
						"aria-hidden": "true",
						size: 16
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 15
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "global-search-results",
			children: [
				isLoading && /* @__PURE__ */ _jsxDEV("p", {
					className: "global-search-status",
					children: "Searching…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 29
				}, this),
				!isLoading && query.trim() && results.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
					className: "global-search-status",
					children: [
						"No results for \"",
						query.trim(),
						"\""
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 17
				}, this),
				!isLoading && results.length > 0 && /* @__PURE__ */ _jsxDEV("ul", { children: results.map((result) => {
					const Icon = TYPE_ICON[result.type] ?? FileText;
					return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "global-search-result",
						onClick: () => handleSelect(result),
						children: [
							/* @__PURE__ */ _jsxDEV(Icon, {
								"aria-hidden": "true",
								size: 16
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 27
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "global-search-result-body",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "global-search-result-title",
									children: result.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 29
								}, this), result.snippet && /* @__PURE__ */ _jsxDEV("span", {
									className: "global-search-result-snippet",
									// snippet HTML comes from our own backend's
									// FTS5 snippet() output (just <b> tags around
									// the match), never user-authored markup.
									dangerouslySetInnerHTML: { __html: result.snippet }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 31
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 27
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "global-search-result-type",
								children: TYPE_LABEL[result.type] ?? result.type
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 27
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 164,
						columnNumber: 25
					}, this) }, `${result.type}-${result.id}`, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 23
					}, this);
				}) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 17
				}, this),
				!isLoading && !query.trim() && /* @__PURE__ */ _jsxDEV("p", {
					className: "global-search-status",
					children: [
						"Type to search, or press ",
						/* @__PURE__ */ _jsxDEV("kbd", { children: "Esc" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 44
						}, this),
						" to close."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 120,
		columnNumber: 11
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 109,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 107,
		columnNumber: 5
	}, this);
}
_s(GlobalSearch, "/SMZz16QeDsFaeoLYSANLMLdf2I=", false, function() {
	return [useNavigate];
});
_c = GlobalSearch;
var _c;
$RefreshReg$(_c, "GlobalSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/search/GlobalSearch.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/search/GlobalSearch.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/search/GlobalSearch.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/search/GlobalSearch.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLGFBQWEsV0FBVyxRQUFRLGdCQUFnQjtBQUN6RCxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGlCQUFpQixjQUFjO0FBQ3hDLFNBQVMsUUFBUSxVQUFVLFFBQVEsVUFBVSxVQUFVLFNBQVM7QUFDaEUsU0FBUyxpQkFBaUI7Ozs7QUFFMUIsTUFBTSxjQUFjO0FBRXBCLE1BQU0sWUFBWTtDQUNoQixRQUFRO0NBQ1IsUUFBUTtDQUNSLFNBQVM7Q0FDVCxNQUFNO0FBQ1I7QUFFQSxNQUFNLGFBQWE7Q0FDakIsUUFBUTtDQUNSLFFBQVE7Q0FDUixTQUFTO0NBQ1QsTUFBTTtBQUNSO0FBRUEsT0FBTyxTQUFTLGVBQWU7O0NBQzdCLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDLENBQUM7Q0FDekMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLFdBQVcsT0FBTyxJQUFJO0NBQzVCLE1BQU0sY0FBYyxPQUFPLElBQUk7Q0FDL0IsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxRQUFRLGtCQUFrQjtFQUM5QixVQUFVLEtBQUs7RUFDZixTQUFTLEVBQUU7RUFDWCxXQUFXLENBQUMsQ0FBQztDQUNmLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLFNBQVMsVUFBVSxHQUFHO0dBQ3BCLEtBQUssRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFFBQVEsS0FBSztJQUM3QyxFQUFFLGVBQWU7SUFDakIsV0FBVyxTQUFTLENBQUMsSUFBSTtHQUMzQixPQUFPLElBQUksRUFBRSxRQUFRLFVBQVU7SUFDN0IsVUFBVSxLQUFLO0dBQ2pCO0VBQ0Y7RUFDQSxPQUFPLGlCQUFpQixXQUFXLFNBQVM7RUFDNUMsYUFBYSxPQUFPLG9CQUFvQixXQUFXLFNBQVM7Q0FDOUQsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxRQUFRLFNBQVMsU0FBUyxNQUFNO0NBQ3RDLEdBQUcsQ0FBQyxNQUFNLENBQUM7O0NBR1gsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU87RUFFekQsSUFBSSxDQUFDLE1BQU0sS0FBSyxHQUFHO0dBQ2pCLFdBQVcsQ0FBQyxDQUFDO0dBQ2IsYUFBYSxLQUFLO0dBQ2xCO0VBQ0Y7RUFFQSxhQUFhLElBQUk7RUFDakIsWUFBWSxVQUFVLFdBQVcsWUFBWTtHQUMzQyxJQUFJO0lBQ0YsTUFBTSxPQUFPLE1BQU0sVUFBVSxPQUFPLE1BQU0sS0FBSyxDQUFDO0lBQ2hELFdBQVcsTUFBTSxXQUFXLENBQUMsQ0FBQztHQUNoQyxRQUFRO0lBQ04sV0FBVyxDQUFDLENBQUM7R0FDZixVQUFVO0lBQ1IsYUFBYSxLQUFLO0dBQ3BCO0VBQ0YsR0FBRyxXQUFXO0VBRWQsYUFBYSxhQUFhLFlBQVksT0FBTztDQUMvQyxHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsU0FBUyxhQUFhLFFBQVE7OztFQUc1QixTQUFTLFlBQVksT0FBTyxXQUFXLE9BQU87RUFDOUMsTUFBTTtDQUNSO0NBRUEsT0FDRSx3QkFBQyxpQkFBRCxZQUNHLFVBQ0MsZ0RBQ0Usd0JBQUMsT0FBTyxLQUFSO0VBQ0UsV0FBVTtFQUNWLFNBQVM7RUFDVCxlQUFZO0VBQ1osU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7RUFDbkIsWUFBWSxFQUFFLFVBQVUsSUFBSztDQUM5Qjs7OztXQUVELHdCQUFDLE9BQU8sS0FBUjtFQUNFLFdBQVU7RUFDVixNQUFLO0VBQ0wsY0FBVztFQUNYLGNBQVc7RUFDWCxTQUFTO0dBQUUsU0FBUztHQUFHLE9BQU87R0FBTSxHQUFHLENBQUM7RUFBRTtFQUMxQyxTQUFTO0dBQUUsU0FBUztHQUFHLE9BQU87R0FBRyxHQUFHO0VBQUU7RUFDdEMsTUFBTTtHQUFFLFNBQVM7R0FBRyxPQUFPO0dBQU0sR0FBRyxDQUFDO0VBQUU7RUFDdkMsWUFBWTtHQUFFLE1BQU07R0FBUyxVQUFVO0dBQU0sTUFBTTtFQUFVO1lBUi9ELENBVUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFFBQUQ7S0FBUSxlQUFZO0tBQU8sTUFBTTtJQUFLOzs7OztJQUN0Qyx3QkFBQyxTQUFEO0tBQ0UsS0FBSztLQUNMLE1BQUs7S0FDTCxPQUFPO0tBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7S0FDeEMsYUFBWTtLQUNaLGNBQVc7SUFDWjs7Ozs7SUFDRCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixTQUFTO0tBQ1QsY0FBVztLQUNYLE9BQU07ZUFFTix3QkFBQyxHQUFEO01BQUcsZUFBWTtNQUFPLE1BQU07S0FBSzs7Ozs7SUFDM0I7Ozs7O0dBQ0w7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNHLGFBQWEsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBdUI7SUFBYTs7Ozs7SUFFOUQsQ0FBQyxhQUFhLE1BQU0sS0FBSyxLQUFLLFFBQVEsV0FBVyxLQUNoRCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQW9DO01BQWlCLE1BQU0sS0FBSztNQUFFO0tBQUk7Ozs7OztJQUd2RSxDQUFDLGFBQWEsUUFBUSxTQUFTLEtBQzlCLHdCQUFDLE1BQUQsWUFDRyxRQUFRLEtBQUssV0FBVztLQUN2QixNQUFNLE9BQU8sVUFBVSxPQUFPLFNBQVM7S0FDdkMsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFBZSxhQUFhLE1BQU07Z0JBSHBDO09BS0Usd0JBQUMsTUFBRDtRQUFNLGVBQVk7UUFBTyxNQUFNO09BQUs7Ozs7O09BQ3BDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE4QixPQUFPO1FBQVk7Ozs7a0JBQ2hFLE9BQU8sV0FDTix3QkFBQyxRQUFEO1NBQ0UsV0FBVTs7OztTQUlWLHlCQUF5QixFQUFFLFFBQVEsT0FBTyxRQUFRO1FBQ25EOzs7O2dCQUVDOzs7Ozs7T0FDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixXQUFXLE9BQU8sU0FBUyxPQUFPO09BQy9COzs7OztNQUNBOzs7OztjQUNOLEdBdkJLLEdBQUcsT0FBTyxLQUFLLEdBQUcsT0FBTzs7OztZQXVCOUI7SUFFUixDQUFDLEVBQ0M7Ozs7O0lBR0wsQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLEtBQ3pCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWI7TUFBb0M7TUFDVCx3QkFBQyxPQUFELFlBQUssTUFBUTs7Ozs7TUFBQztLQUN0Qzs7Ozs7O0dBRUY7Ozs7O1VBQ0s7Ozs7O1NBQ1o7Ozs7VUFFVzs7Ozs7QUFFckIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2xvYmFsU2VhcmNoLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEdsb2JhbCBjb21tYW5kLXBhbGV0dGUgc2VhcmNoICgxNC1nbG9iYWwtc2VhcmNoKS4gU2VsZi1jb250YWluZWQ6IGl0XG4gKiBtYW5hZ2VzIGl0cyBvd24gb3Blbi9jbG9zZWQgc3RhdGUgaW50ZXJuYWxseSwgbGlzdGVuaW5nIGZvciBDdHJsK0sgL1xuICogQ21kK0sgb24gYHdpbmRvd2AsIHNvIHRoZSBvbmx5IGludGVncmF0aW9uIGFub3RoZXIgZmlsZSBuZWVkcyBpc1xuICogcmVuZGVyaW5nIGA8R2xvYmFsU2VhcmNoIC8+YCBvbmNlIG5lYXIgdGhlIGFwcCByb290IChlLmcuIGluIEFwcC5qc3ggb3JcbiAqIEFwcExheW91dCkg4oCUIG5vIHByb3BzIHJlcXVpcmVkLiBOb3Qgd2lyZWQgaW50byBBcHAuanN4IHlldCwgcGVyIHRoaXNcbiAqIHRhc2sncyBzY29wZSAoYXZvaWRpbmcgYSBjb25jdXJyZW50IGVkaXQgdG8gdGhhdCBmaWxlKTsgd2hvZXZlciB3aXJlcyBpdFxuICogaW4ganVzdCBuZWVkcyB0byBhZGQgdGhhdCBvbmUgcmVuZGVyLlxuICpcbiAqIE5hdmlnYXRpb24gbGltaXRhdGlvbjogdGhlIHJlYWRlciAoZmVhdHVyZXMvY291cnNlcycgY291cnNlIHJlYWRlcikgZG9lc1xuICogbm90IHN1cHBvcnQgZGVlcC1saW5raW5nIHRvIGEgc3BlY2lmaWMgcGFnZSB2aWEgVVJMIHRvZGF5LCBzbyBjbGlja2luZyBhXG4gKiBwYWdlL2NoYXB0ZXIvbW9kdWxlIHJlc3VsdCBqdXN0IG5hdmlnYXRlcyB0byBgL2NvdXJzZXMve3NsdWd9L2xlYXJuYFxuICogKHRoZSBjb3Vyc2UncyByZWFkZXIgZW50cnkgcG9pbnQpLCBub3QgdG8gdGhhdCBleGFjdCBwYWdlLiBDbGlja2luZyBhXG4gKiBjb3Vyc2UgcmVzdWx0IG5hdmlnYXRlcyB0byB0aGUgc2FtZSByb3V0ZS4gQSBmdXR1cmUgcmVhZGVyIGNoYW5nZSB0b1xuICogc3VwcG9ydCBgP3BhZ2U9YCAob3Igc2ltaWxhcikgY291bGQgbWFrZSB0aGlzIHByZWNpc2UuXG4gKi9cblxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgQW5pbWF0ZVByZXNlbmNlLCBtb3Rpb24gfSBmcm9tICdtb3Rpb24vcmVhY3QnXG5pbXBvcnQgeyBTZWFyY2gsIEJvb2tPcGVuLCBMYXllcnMsIEJvb2ttYXJrLCBGaWxlVGV4dCwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IHNlYXJjaEFwaSB9IGZyb20gJy4vc2VhcmNoQXBpJ1xuXG5jb25zdCBERUJPVU5DRV9NUyA9IDI1MFxuXG5jb25zdCBUWVBFX0lDT04gPSB7XG4gIGNvdXJzZTogQm9va09wZW4sXG4gIG1vZHVsZTogTGF5ZXJzLFxuICBjaGFwdGVyOiBCb29rbWFyayxcbiAgcGFnZTogRmlsZVRleHQsXG59XG5cbmNvbnN0IFRZUEVfTEFCRUwgPSB7XG4gIGNvdXJzZTogJ0NvdXJzZScsXG4gIG1vZHVsZTogJ01vZHVsZScsXG4gIGNoYXB0ZXI6ICdDaGFwdGVyJyxcbiAgcGFnZTogJ1BhZ2UnLFxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2xvYmFsU2VhcmNoKCkge1xuICBjb25zdCBbaXNPcGVuLCBzZXRJc09wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtyZXN1bHRzLCBzZXRSZXN1bHRzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmKG51bGwpXG4gIGNvbnN0IGRlYm91bmNlUmVmID0gdXNlUmVmKG51bGwpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuXG4gIGNvbnN0IGNsb3NlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldElzT3BlbihmYWxzZSlcbiAgICBzZXRRdWVyeSgnJylcbiAgICBzZXRSZXN1bHRzKFtdKVxuICB9LCBbXSlcblxuICAvLyBDdHJsK0sgLyBDbWQrSyBvcGVucyB0aGUgcGFsZXR0ZSBmcm9tIGFueXdoZXJlOyBFc2NhcGUgY2xvc2VzIGl0LlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGZ1bmN0aW9uIG9uS2V5RG93bihlKSB7XG4gICAgICBpZiAoKGUubWV0YUtleSB8fCBlLmN0cmxLZXkpICYmIGUua2V5ID09PSAnaycpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHNldElzT3Blbigob3BlbikgPT4gIW9wZW4pXG4gICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICBzZXRJc09wZW4oZmFsc2UpXG4gICAgICB9XG4gICAgfVxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duKVxuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93bilcbiAgfSwgW10pXG5cbiAgLy8gRm9jdXMgdGhlIGlucHV0IGFzIHNvb24gYXMgdGhlIHBhbGV0dGUgb3BlbnMuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzT3BlbikgaW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKVxuICB9LCBbaXNPcGVuXSlcblxuICAvLyBEZWJvdW5jZWQgcXVlcnktYXMteW91LXR5cGUuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRlYm91bmNlUmVmLmN1cnJlbnQpIGNsZWFyVGltZW91dChkZWJvdW5jZVJlZi5jdXJyZW50KVxuXG4gICAgaWYgKCFxdWVyeS50cmltKCkpIHtcbiAgICAgIHNldFJlc3VsdHMoW10pXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSlcbiAgICBkZWJvdW5jZVJlZi5jdXJyZW50ID0gc2V0VGltZW91dChhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgc2VhcmNoQXBpLnNlYXJjaChxdWVyeS50cmltKCkpXG4gICAgICAgIHNldFJlc3VsdHMoZGF0YT8ucmVzdWx0cyA/PyBbXSlcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBzZXRSZXN1bHRzKFtdKVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKVxuICAgICAgfVxuICAgIH0sIERFQk9VTkNFX01TKVxuXG4gICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dChkZWJvdW5jZVJlZi5jdXJyZW50KVxuICB9LCBbcXVlcnldKVxuXG4gIGZ1bmN0aW9uIGhhbmRsZVNlbGVjdChyZXN1bHQpIHtcbiAgICAvLyBTZWUgZmlsZS10b3AgZG9jc3RyaW5nOiBubyBkZWVwLWxpbmtpbmcgaW50byBhIHNwZWNpZmljIHBhZ2UvY2hhcHRlclxuICAgIC8vIHlldCwgc28gZXZlcnkgcmVzdWx0IHR5cGUgbGFuZHMgb24gdGhlIGNvdXJzZSdzIHJlYWRlciBlbnRyeSBwb2ludC5cbiAgICBuYXZpZ2F0ZShgL2NvdXJzZXMvJHtyZXN1bHQuY291cnNlU2x1Z30vbGVhcm5gKVxuICAgIGNsb3NlKClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPEFuaW1hdGVQcmVzZW5jZT5cbiAgICAgIHtpc09wZW4gJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnbG9iYWwtc2VhcmNoLW92ZXJsYXlcIlxuICAgICAgICAgICAgb25DbGljaz17Y2xvc2V9XG4gICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX1cbiAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4xNSB9fVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1wYW5lbFwiXG4gICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJHbG9iYWwgc2VhcmNoXCJcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOTcsIHk6IC04IH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxLCB5OiAwIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk3LCB5OiAtOCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAndHdlZW4nLCBkdXJhdGlvbjogMC4xOCwgZWFzZTogJ2Vhc2VPdXQnIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnbG9iYWwtc2VhcmNoLWlucHV0LXJvd1wiPlxuICAgICAgICAgICAgICA8U2VhcmNoIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2lucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cXVlcnl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggY291cnNlcywgY2hhcHRlcnMsIHBhZ2VzLi4uXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VhcmNoXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsb2JhbC1zZWFyY2gtY2xvc2VcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlfVxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZSBzZWFyY2hcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2xvc2VcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1yZXN1bHRzXCI+XG4gICAgICAgICAgICAgIHtpc0xvYWRpbmcgJiYgPHAgY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1zdGF0dXNcIj5TZWFyY2hpbmfigKY8L3A+fVxuXG4gICAgICAgICAgICAgIHshaXNMb2FkaW5nICYmIHF1ZXJ5LnRyaW0oKSAmJiByZXN1bHRzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1zdGF0dXNcIj5ObyByZXN1bHRzIGZvciBcIntxdWVyeS50cmltKCl9XCI8L3A+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiYgcmVzdWx0cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgICB7cmVzdWx0cy5tYXAoKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBJY29uID0gVFlQRV9JQ09OW3Jlc3VsdC50eXBlXSA/PyBGaWxlVGV4dFxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2Ake3Jlc3VsdC50eXBlfS0ke3Jlc3VsdC5pZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsb2JhbC1zZWFyY2gtcmVzdWx0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0KHJlc3VsdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnbG9iYWwtc2VhcmNoLXJlc3VsdC1ib2R5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1yZXN1bHQtdGl0bGVcIj57cmVzdWx0LnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0LnNuaXBwZXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xvYmFsLXNlYXJjaC1yZXN1bHQtc25pcHBldFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHNuaXBwZXQgSFRNTCBjb21lcyBmcm9tIG91ciBvd24gYmFja2VuZCdzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZUUzUgc25pcHBldCgpIG91dHB1dCAoanVzdCA8Yj4gdGFncyBhcm91bmRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIG1hdGNoKSwgbmV2ZXIgdXNlci1hdXRob3JlZCBtYXJrdXAuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogcmVzdWx0LnNuaXBwZXQgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnbG9iYWwtc2VhcmNoLXJlc3VsdC10eXBlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1RZUEVfTEFCRUxbcmVzdWx0LnR5cGVdID8/IHJlc3VsdC50eXBlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHshaXNMb2FkaW5nICYmICFxdWVyeS50cmltKCkgJiYgKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImdsb2JhbC1zZWFyY2gtc3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICBUeXBlIHRvIHNlYXJjaCwgb3IgcHJlc3MgPGtiZD5Fc2M8L2tiZD4gdG8gY2xvc2UuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gIClcbn1cbiJdfQ==