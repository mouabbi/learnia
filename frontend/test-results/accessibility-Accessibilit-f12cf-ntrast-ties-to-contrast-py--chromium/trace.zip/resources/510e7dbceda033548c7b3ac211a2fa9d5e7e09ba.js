import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/ContentTab.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Plus, Trash2, ArrowUp, ArrowDown, Sparkles, Eye, Pencil } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { cmsApi } from "/src/features/cms/cmsApi.js";
import { BLOCK_EDITORS, BLOCK_TYPES, defaultBlockFor } from "/src/features/cms/BlockEditors.jsx";
import { BlockRenderer } from "/src/features/cms/BlockRenderer.jsx?t=1790183660675";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/ContentTab.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
/**
* Content tab — block-by-block editor for the page selected in the
* Structure tab. Explicit "Save" only (11's resolved decision: no
* autosave). A Preview toggle renders the same blocks read-only via
* BlockRenderer (also reused by AiImportModal's page-content preview).
*/
export function ContentTab({ page, onGenerateWithAi }) {
	_s();
	const [blocks, setBlocks] = useState([]);
	const [loading, setLoading] = useState(false);
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState(null);
	const [saved, setSaved] = useState(false);
	const [preview, setPreview] = useState(false);
	useEffect(() => {
		if (!page) return;
		// eslint-disable-next-line react-hooks/set-state-in-effect
		setLoading(true);
		setError(null);
		setSaved(false);
		cmsApi.getPageContent(page.id).then((res) => setBlocks(res.blocks || [])).catch((err) => setError(err.message)).finally(() => setLoading(false));
	}, [page]);
	if (!page) {
		return /* @__PURE__ */ _jsxDEV("p", {
			className: "cms-empty-hint",
			children: "Select a page from the Structure tab to edit its content."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 12
		}, this);
	}
	const updateBlock = (index, next) => {
		setBlocks((prev) => prev.map((b, i) => i === index ? next : b));
	};
	const removeBlock = (index) => {
		setBlocks((prev) => prev.filter((_, i) => i !== index));
	};
	const moveBlock = (index, dir) => {
		setBlocks((prev) => {
			const next = [...prev];
			const target = index + dir;
			if (target < 0 || target >= next.length) return prev;
			[next[index], next[target]] = [next[target], next[index]];
			return next;
		});
	};
	const addBlock = (type) => {
		setBlocks((prev) => [...prev, defaultBlockFor(type)]);
	};
	const save = async () => {
		setSaving(true);
		setError(null);
		setSaved(false);
		try {
			await cmsApi.putPageContent(page.id, {
				schemaVersion: 1,
				blocks
			});
			setSaved(true);
			setTimeout(() => setSaved(false), 1800);
		} catch (err) {
			setError(err.message);
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-content-editor",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cms-content-header",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: page.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "cms-modal-actions",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "cms-btn-ai",
							onClick: () => onGenerateWithAi({
								scope: "page",
								chapterId: page.chapterId,
								pageId: page.id
							}),
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 13
							}, this), " Generate with AI"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "cms-btn-secondary",
							onClick: () => setPreview((p) => !p),
							children: [preview ? /* @__PURE__ */ _jsxDEV(Pencil, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 24
							}, this) : /* @__PURE__ */ _jsxDEV(Eye, { size: 16 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 47
							}, this), preview ? "Edit" : "Preview"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "cms-btn-primary",
							onClick: save,
							disabled: saving,
							children: saving ? "Saving…" : saved ? "Saved ✓" : "Save"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 77,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 97,
				columnNumber: 17
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", {
				className: "cms-loading",
				children: "Loading…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 19
			}, this),
			!loading && preview && /* @__PURE__ */ _jsxDEV(BlockRenderer, { blocks }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 31
			}, this),
			!loading && !preview && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				blocks.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
					className: "cms-empty-hint",
					children: "No blocks yet — add one below."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 35
				}, this),
				/* @__PURE__ */ _jsxDEV("ul", {
					className: "cms-block-list-editor",
					children: blocks.map((block, i) => {
						const Editor = BLOCK_EDITORS[block.type];
						return /* @__PURE__ */ _jsxDEV("li", {
							className: "cms-block-card",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "cms-block-card-header",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "cms-block-type-tag",
									children: block.type
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "cms-tree-actions",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => moveBlock(i, -1),
											title: "Move up",
											children: /* @__PURE__ */ _jsxDEV(ArrowUp, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 114,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 113,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => moveBlock(i, 1),
											title: "Move down",
											children: /* @__PURE__ */ _jsxDEV(ArrowDown, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 117,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 116,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => removeBlock(i),
											title: "Remove block",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 120,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 119,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 19
							}, this), Editor ? /* @__PURE__ */ _jsxDEV(Editor, {
								block,
								onChange: (next) => updateBlock(i, next)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 21
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "cms-error",
								children: ["Unknown block type: ", block.type]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 21
							}, this)]
						}, i, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "cms-add-block-row",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Add block:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 13
					}, this), BLOCK_TYPES.map((type) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "cms-btn-secondary",
						onClick: () => addBlock(type),
						children: [
							/* @__PURE__ */ _jsxDEV(Plus, { size: 12 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 17
							}, this),
							" ",
							type
						]
					}, type, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 15
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
}
_s(ContentTab, "zXRusKOlUXxYqshvSLmxUai/RSw=");
_c = ContentTab;
var _c;
$RefreshReg$(_c, "ContentTab");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/ContentTab.jsx?t=1790183660675";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/ContentTab.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/ContentTab.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/ContentTab.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLE1BQU0sUUFBUSxTQUFTLFdBQVcsVUFBVSxLQUFLLGNBQWM7QUFDeEUsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZSxhQUFhLHVCQUF1QjtBQUM1RCxTQUFTLHFCQUFxQjs7Ozs7Ozs7OztBQVE5QixPQUFPLFNBQVMsV0FBVyxFQUFFLE1BQU0sb0JBQW9COztDQUNyRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxLQUFLO0NBQ3hDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNOztFQUVYLFdBQVcsSUFBSTtFQUNmLFNBQVMsSUFBSTtFQUNiLFNBQVMsS0FBSztFQUNkLE9BQ0csZUFBZSxLQUFLLEVBQUUsQ0FBQyxDQUN2QixNQUFNLFFBQVEsVUFBVSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUMxQyxPQUFPLFFBQVEsU0FBUyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQ3JDLGNBQWMsV0FBVyxLQUFLLENBQUM7Q0FDcEMsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULElBQUksQ0FBQyxNQUFNO0VBQ1QsT0FBTyx3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFpQjtFQUE0RDs7Ozs7Q0FDbkc7Q0FFQSxNQUFNLGVBQWUsT0FBTyxTQUFTO0VBQ25DLFdBQVcsU0FBUyxLQUFLLEtBQUssR0FBRyxNQUFPLE1BQU0sUUFBUSxPQUFPLENBQUUsQ0FBQztDQUNsRTtDQUVBLE1BQU0sZUFBZSxVQUFVO0VBQzdCLFdBQVcsU0FBUyxLQUFLLFFBQVEsR0FBRyxNQUFNLE1BQU0sS0FBSyxDQUFDO0NBQ3hEO0NBRUEsTUFBTSxhQUFhLE9BQU8sUUFBUTtFQUNoQyxXQUFXLFNBQVM7R0FDbEIsTUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJO0dBQ3JCLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUksU0FBUyxLQUFLLFVBQVUsS0FBSyxRQUFRLE9BQU87R0FDL0MsQ0FBQyxLQUFLLFFBQVEsS0FBSyxXQUFXLENBQUMsS0FBSyxTQUFTLEtBQUssTUFBTTtHQUN6RCxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBRUEsTUFBTSxZQUFZLFNBQVM7RUFDekIsV0FBVyxTQUFTLENBQUMsR0FBRyxNQUFNLGdCQUFnQixJQUFJLENBQUMsQ0FBQztDQUN0RDtDQUVBLE1BQU0sT0FBTyxZQUFZO0VBQ3ZCLFVBQVUsSUFBSTtFQUNkLFNBQVMsSUFBSTtFQUNiLFNBQVMsS0FBSztFQUNkLElBQUk7R0FDRixNQUFNLE9BQU8sZUFBZSxLQUFLLElBQUk7SUFBRSxlQUFlO0lBQUc7R0FBTyxDQUFDO0dBQ2pFLFNBQVMsSUFBSTtHQUNiLGlCQUFpQixTQUFTLEtBQUssR0FBRyxJQUFJO0VBQ3hDLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxPQUFPO0VBQ3RCLFVBQVU7R0FDUixVQUFVLEtBQUs7RUFDakI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUssS0FBSyxNQUFVOzs7O2NBQ3BCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7T0FDVixlQUFlLGlCQUFpQjtRQUFFLE9BQU87UUFBUSxXQUFXLEtBQUs7UUFBVyxRQUFRLEtBQUs7T0FBRyxDQUFDO2lCQUgvRixDQUtFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7aUJBQUMsbUJBQ2hCOzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFdBQVU7T0FBb0IsZUFBZSxZQUFZLE1BQU0sQ0FBQyxDQUFDO2lCQUF2RixDQUNHLFVBQVUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztrQkFBSSx3QkFBQyxLQUFELEVBQUssTUFBTSxHQUFLOzs7O2lCQUNqRCxVQUFVLFNBQVMsU0FDZDs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUFRLE1BQUs7T0FBUyxXQUFVO09BQWtCLFNBQVM7T0FBTSxVQUFVO2lCQUN4RSxTQUFTLFlBQVksUUFBUSxZQUFZO01BQ3BDOzs7OztLQUNMOzs7OztZQUNGOzs7Ozs7R0FFSixTQUFTLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWE7R0FBUzs7Ozs7R0FDNUMsV0FBVyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFjO0dBQVc7Ozs7O0dBRWpELENBQUMsV0FBVyxXQUFXLHdCQUFDLGVBQUQsRUFBdUIsT0FBUzs7Ozs7R0FFdkQsQ0FBQyxXQUFXLENBQUMsV0FDWjtJQUNHLE9BQU8sV0FBVyxLQUFLLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWlCO0lBQWlDOzs7OztJQUN2Rix3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLE9BQU8sS0FBSyxPQUFPLE1BQU07TUFDeEIsTUFBTSxTQUFTLGNBQWMsTUFBTTtNQUNuQyxPQUNFLHdCQUFDLE1BQUQ7T0FBWSxXQUFVO2lCQUF0QixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNCLE1BQU07UUFBVzs7OztrQkFDdkQsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxVQUFEO1dBQVEsTUFBSztXQUFTLGVBQWUsVUFBVSxHQUFHLENBQUMsQ0FBQztXQUFHLE9BQU07cUJBQzNELHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7O1VBQ2Q7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLFVBQVUsR0FBRyxDQUFDO1dBQUcsT0FBTTtxQkFDMUQsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7Ozs7VUFDaEI7Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUFRLE1BQUs7V0FBUyxlQUFlLFlBQVksQ0FBQztXQUFHLE9BQU07cUJBQ3pELHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7O1VBQ2I7Ozs7O1NBQ0w7Ozs7O2dCQUNGOzs7OztpQkFDSixTQUNDLHdCQUFDLFFBQUQ7UUFBZTtRQUFPLFdBQVcsU0FBUyxZQUFZLEdBQUcsSUFBSTtPQUFJOzs7O2tCQUVqRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYixDQUF5Qix3QkFBcUIsTUFBTSxJQUFROzs7OztlQUU1RDtTQXBCSzs7OzthQW9CTDtLQUVSLENBQUM7SUFDQzs7Ozs7SUFFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2VBQ3JCLFlBQVksS0FBSyxTQUNoQix3QkFBQyxVQUFEO01BQW1CLE1BQUs7TUFBUyxXQUFVO01BQW9CLGVBQWUsU0FBUyxJQUFJO2dCQUEzRjtPQUNFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O09BQUM7T0FBRTtNQUNkO1FBRks7Ozs7WUFFTCxDQUNULENBQ0U7Ozs7OztHQUNMOzs7OztFQUVEOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb250ZW50VGFiLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBQbHVzLCBUcmFzaDIsIEFycm93VXAsIEFycm93RG93biwgU3BhcmtsZXMsIEV5ZSwgUGVuY2lsIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgY21zQXBpIH0gZnJvbSAnLi9jbXNBcGknXG5pbXBvcnQgeyBCTE9DS19FRElUT1JTLCBCTE9DS19UWVBFUywgZGVmYXVsdEJsb2NrRm9yIH0gZnJvbSAnLi9CbG9ja0VkaXRvcnMnXG5pbXBvcnQgeyBCbG9ja1JlbmRlcmVyIH0gZnJvbSAnLi9CbG9ja1JlbmRlcmVyJ1xuXG4vKipcbiAqIENvbnRlbnQgdGFiIOKAlCBibG9jay1ieS1ibG9jayBlZGl0b3IgZm9yIHRoZSBwYWdlIHNlbGVjdGVkIGluIHRoZVxuICogU3RydWN0dXJlIHRhYi4gRXhwbGljaXQgXCJTYXZlXCIgb25seSAoMTEncyByZXNvbHZlZCBkZWNpc2lvbjogbm9cbiAqIGF1dG9zYXZlKS4gQSBQcmV2aWV3IHRvZ2dsZSByZW5kZXJzIHRoZSBzYW1lIGJsb2NrcyByZWFkLW9ubHkgdmlhXG4gKiBCbG9ja1JlbmRlcmVyIChhbHNvIHJldXNlZCBieSBBaUltcG9ydE1vZGFsJ3MgcGFnZS1jb250ZW50IHByZXZpZXcpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gQ29udGVudFRhYih7IHBhZ2UsIG9uR2VuZXJhdGVXaXRoQWkgfSkge1xuICBjb25zdCBbYmxvY2tzLCBzZXRCbG9ja3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW3NhdmVkLCBzZXRTYXZlZF0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3ByZXZpZXcsIHNldFByZXZpZXddID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBhZ2UpIHJldHVyblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9zZXQtc3RhdGUtaW4tZWZmZWN0XG4gICAgc2V0TG9hZGluZyh0cnVlKVxuICAgIHNldEVycm9yKG51bGwpXG4gICAgc2V0U2F2ZWQoZmFsc2UpXG4gICAgY21zQXBpXG4gICAgICAuZ2V0UGFnZUNvbnRlbnQocGFnZS5pZClcbiAgICAgIC50aGVuKChyZXMpID0+IHNldEJsb2NrcyhyZXMuYmxvY2tzIHx8IFtdKSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBzZXRFcnJvcihlcnIubWVzc2FnZSkpXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSlcbiAgfSwgW3BhZ2VdKVxuXG4gIGlmICghcGFnZSkge1xuICAgIHJldHVybiA8cCBjbGFzc05hbWU9XCJjbXMtZW1wdHktaGludFwiPlNlbGVjdCBhIHBhZ2UgZnJvbSB0aGUgU3RydWN0dXJlIHRhYiB0byBlZGl0IGl0cyBjb250ZW50LjwvcD5cbiAgfVxuXG4gIGNvbnN0IHVwZGF0ZUJsb2NrID0gKGluZGV4LCBuZXh0KSA9PiB7XG4gICAgc2V0QmxvY2tzKChwcmV2KSA9PiBwcmV2Lm1hcCgoYiwgaSkgPT4gKGkgPT09IGluZGV4ID8gbmV4dCA6IGIpKSlcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZUJsb2NrID0gKGluZGV4KSA9PiB7XG4gICAgc2V0QmxvY2tzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKVxuICB9XG5cbiAgY29uc3QgbW92ZUJsb2NrID0gKGluZGV4LCBkaXIpID0+IHtcbiAgICBzZXRCbG9ja3MoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IG5leHQgPSBbLi4ucHJldl1cbiAgICAgIGNvbnN0IHRhcmdldCA9IGluZGV4ICsgZGlyXG4gICAgICBpZiAodGFyZ2V0IDwgMCB8fCB0YXJnZXQgPj0gbmV4dC5sZW5ndGgpIHJldHVybiBwcmV2XG4gICAgICA7W25leHRbaW5kZXhdLCBuZXh0W3RhcmdldF1dID0gW25leHRbdGFyZ2V0XSwgbmV4dFtpbmRleF1dXG4gICAgICByZXR1cm4gbmV4dFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBhZGRCbG9jayA9ICh0eXBlKSA9PiB7XG4gICAgc2V0QmxvY2tzKChwcmV2KSA9PiBbLi4ucHJldiwgZGVmYXVsdEJsb2NrRm9yKHR5cGUpXSlcbiAgfVxuXG4gIGNvbnN0IHNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgc2V0RXJyb3IobnVsbClcbiAgICBzZXRTYXZlZChmYWxzZSlcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY21zQXBpLnB1dFBhZ2VDb250ZW50KHBhZ2UuaWQsIHsgc2NoZW1hVmVyc2lvbjogMSwgYmxvY2tzIH0pXG4gICAgICBzZXRTYXZlZCh0cnVlKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTYXZlZChmYWxzZSksIDE4MDApXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtY29udGVudC1lZGl0b3JcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLWNvbnRlbnQtaGVhZGVyXCI+XG4gICAgICAgIDxoMz57cGFnZS50aXRsZX08L2gzPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy1tb2RhbC1hY3Rpb25zXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjbXMtYnRuLWFpXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uR2VuZXJhdGVXaXRoQWkoeyBzY29wZTogJ3BhZ2UnLCBjaGFwdGVySWQ6IHBhZ2UuY2hhcHRlcklkLCBwYWdlSWQ6IHBhZ2UuaWQgfSl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE2fSAvPiBHZW5lcmF0ZSB3aXRoIEFJXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRQcmV2aWV3KChwKSA9PiAhcCl9PlxuICAgICAgICAgICAge3ByZXZpZXcgPyA8UGVuY2lsIHNpemU9ezE2fSAvPiA6IDxFeWUgc2l6ZT17MTZ9IC8+fVxuICAgICAgICAgICAge3ByZXZpZXcgPyAnRWRpdCcgOiAnUHJldmlldyd9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1wcmltYXJ5XCIgb25DbGljaz17c2F2ZX0gZGlzYWJsZWQ9e3NhdmluZ30+XG4gICAgICAgICAgICB7c2F2aW5nID8gJ1NhdmluZ+KApicgOiBzYXZlZCA/ICdTYXZlZCDinJMnIDogJ1NhdmUnfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiY21zLWVycm9yXCI+e2Vycm9yfTwvcD59XG4gICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJjbXMtbG9hZGluZ1wiPkxvYWRpbmfigKY8L3A+fVxuXG4gICAgICB7IWxvYWRpbmcgJiYgcHJldmlldyAmJiA8QmxvY2tSZW5kZXJlciBibG9ja3M9e2Jsb2Nrc30gLz59XG5cbiAgICAgIHshbG9hZGluZyAmJiAhcHJldmlldyAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAge2Jsb2Nrcy5sZW5ndGggPT09IDAgJiYgPHAgY2xhc3NOYW1lPVwiY21zLWVtcHR5LWhpbnRcIj5ObyBibG9ja3MgeWV0IOKAlCBhZGQgb25lIGJlbG93LjwvcD59XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImNtcy1ibG9jay1saXN0LWVkaXRvclwiPlxuICAgICAgICAgICAge2Jsb2Nrcy5tYXAoKGJsb2NrLCBpKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IEVkaXRvciA9IEJMT0NLX0VESVRPUlNbYmxvY2sudHlwZV1cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtpfSBjbGFzc05hbWU9XCJjbXMtYmxvY2stY2FyZFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjbXMtYmxvY2stY2FyZC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY21zLWJsb2NrLXR5cGUtdGFnXCI+e2Jsb2NrLnR5cGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy10cmVlLWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBtb3ZlQmxvY2soaSwgLTEpfSB0aXRsZT1cIk1vdmUgdXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IG1vdmVCbG9jayhpLCAxKX0gdGl0bGU9XCJNb3ZlIGRvd25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0Rvd24gc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gcmVtb3ZlQmxvY2soaSl9IHRpdGxlPVwiUmVtb3ZlIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAge0VkaXRvciA/IChcbiAgICAgICAgICAgICAgICAgICAgPEVkaXRvciBibG9jaz17YmxvY2t9IG9uQ2hhbmdlPXsobmV4dCkgPT4gdXBkYXRlQmxvY2soaSwgbmV4dCl9IC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjbXMtZXJyb3JcIj5Vbmtub3duIGJsb2NrIHR5cGU6IHtibG9jay50eXBlfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC91bD5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLWFkZC1ibG9jay1yb3dcIj5cbiAgICAgICAgICAgIDxzcGFuPkFkZCBibG9jazo8L3NwYW4+XG4gICAgICAgICAgICB7QkxPQ0tfVFlQRVMubWFwKCh0eXBlKSA9PiAoXG4gICAgICAgICAgICAgIDxidXR0b24ga2V5PXt0eXBlfSB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY21zLWJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBhZGRCbG9jayh0eXBlKX0+XG4gICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTJ9IC8+IHt0eXBlfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==