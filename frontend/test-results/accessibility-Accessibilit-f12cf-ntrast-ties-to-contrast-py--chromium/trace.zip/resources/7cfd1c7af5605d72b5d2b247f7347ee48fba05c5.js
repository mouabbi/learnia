import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const _jsxDEV = __vite__cjsImport22_react_jsxDevRuntime["jsxDEV"];import { Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { AuthProvider } from "/src/features/auth/AuthContext.jsx";
import { RouteLogger } from "/src/components/RouteLogger.jsx";
import { AppLayout } from "/src/components/layout/AppLayout.jsx";
import { BackendGate } from "/src/features/health/BackendGate.jsx";
import { useAccentColor } from "/src/hooks/useAccentColor.js";
import { ProtectedRoute } from "/src/features/auth/ProtectedRoute.jsx";
import { PublicOnlyRoute } from "/src/features/auth/PublicOnlyRoute.jsx";
import { AccountPage } from "/src/pages/AccountPage.jsx?t=1790183762308";
import { HomePage } from "/src/pages/HomePage.jsx?t=1790187136361";
import { CoursesPage } from "/src/pages/CoursesPage.jsx?t=1790187136361";
import { CourseReaderPage } from "/src/pages/CourseReaderPage.jsx";
import { DashboardPage } from "/src/pages/DashboardPage.jsx?t=1790187136361";
import { WorkspacePage } from "/src/pages/WorkspacePage.jsx?t=1790183660675";
import { ExamPage } from "/src/features/exam/ExamPage.jsx";
import { GlobalSearch } from "/src/features/search/GlobalSearch.jsx";
import { LoginPage } from "/src/pages/LoginPage.jsx";
import { MfaChallengePage } from "/src/pages/MfaChallengePage.jsx";
import { RegisterPage } from "/src/pages/RegisterPage.jsx";
import { ForgotPasswordPage } from "/src/pages/ForgotPasswordPage.jsx";
import { ResetPasswordPage } from "/src/pages/ResetPasswordPage.jsx";
import { VerifyEmailPage } from "/src/pages/VerifyEmailPage.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/App.jsx";
import __vite__cjsImport22_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// App.jsx stays thin: routing + the AuthProvider wrapping everything so
// useAuth() works anywhere in the tree. Actual content lives in pages/ and features/.
function App() {
	_s();
	// Applies the user's persisted accent color (see hooks/useAccentColor.js)
	// on every page, not just Settings where it's actually changed.
	useAccentColor();
	return /* @__PURE__ */ _jsxDEV(BackendGate, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: [
		/* @__PURE__ */ _jsxDEV(RouteLogger, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(GlobalSearch, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Routes, { children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/login",
				element: /* @__PURE__ */ _jsxDEV(PublicOnlyRoute, { children: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/register",
				element: /* @__PURE__ */ _jsxDEV(PublicOnlyRoute, { children: /* @__PURE__ */ _jsxDEV(RegisterPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/mfa-challenge",
				element: /* @__PURE__ */ _jsxDEV(MfaChallengePage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 49
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 15
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/",
						element: /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 38
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/dashboard",
						element: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 47
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/courses",
						element: /* @__PURE__ */ _jsxDEV(CoursesPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 45
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/cms/:slug",
						element: /* @__PURE__ */ _jsxDEV(WorkspacePage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 47
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/account",
						element: /* @__PURE__ */ _jsxDEV(AccountPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 45
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/courses/:slug/learn",
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(CourseReaderPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/courses/:slug/exam",
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(ExamPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/forgot-password",
				element: /* @__PURE__ */ _jsxDEV(ForgotPasswordPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 51
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/reset-password",
				element: /* @__PURE__ */ _jsxDEV(ResetPasswordPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 50
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 11
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/verify-email",
				element: /* @__PURE__ */ _jsxDEV(VerifyEmailPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 48
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 11
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
}
_s(App, "OcQ0SSrr2co7wLJ+jHwpEf7YGNs=", false, function() {
	return [useAccentColor];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1790187136361";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxPQUFPLGNBQWM7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx1QkFBdUI7Ozs7OztBQUloQyxTQUFTLE1BQU07Ozs7Q0FHYixlQUFlO0NBRWYsT0FDRSx3QkFBQyxhQUFELFlBQ0Usd0JBQUMsY0FBRDtFQUNFLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7RUFJZCx3QkFBQyxjQUFELENBQWU7Ozs7O0VBQ2Ysd0JBQUMsUUFBRDtHQUNFLHdCQUFDLE9BQUQ7SUFDRSxNQUFLO0lBQ0wsU0FDRSx3QkFBQyxpQkFBRCxZQUNFLHdCQUFDLFdBQUQsQ0FBWTs7OzthQUNHOzs7OztHQUVwQjs7Ozs7R0FDRCx3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFNBQ0Usd0JBQUMsaUJBQUQsWUFDRSx3QkFBQyxjQUFELENBQWU7Ozs7YUFDQTs7Ozs7R0FFcEI7Ozs7O0dBSUQsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBaUIsU0FBUyx3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7R0FBSTs7Ozs7R0FJN0Qsd0JBQUMsT0FBRDtJQUNFLFNBQ0Usd0JBQUMsZ0JBQUQsWUFDRSx3QkFBQyxXQUFELENBQVk7Ozs7YUFDRTs7Ozs7Y0FKcEI7S0FPRSx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFJLFNBQVMsd0JBQUMsVUFBRCxDQUFXOzs7OztLQUFJOzs7OztLQUN4Qyx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFhLFNBQVMsd0JBQUMsZUFBRCxDQUFnQjs7Ozs7S0FBSTs7Ozs7S0FDdEQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVyxTQUFTLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7S0FBSTs7Ozs7S0FDbEQsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBYSxTQUFTLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7O0tBQUk7Ozs7O0tBQ3RELHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVcsU0FBUyx3QkFBQyxhQUFELENBQWM7Ozs7O0tBQUk7Ozs7O0lBQzdDOzs7Ozs7R0FNUCx3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFNBQ0Usd0JBQUMsZ0JBQUQsWUFDRSx3QkFBQyxrQkFBRCxDQUFtQjs7OzthQUNMOzs7OztHQUVuQjs7Ozs7R0FDRCx3QkFBQyxPQUFEO0lBQ0UsTUFBSztJQUNMLFNBQ0Usd0JBQUMsZ0JBQUQsWUFDRSx3QkFBQyxVQUFELENBQVc7Ozs7YUFDRzs7Ozs7R0FFbkI7Ozs7O0dBSUQsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBbUIsU0FBUyx3QkFBQyxvQkFBRCxDQUFxQjs7Ozs7R0FBSTs7Ozs7R0FDakUsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBa0IsU0FBUyx3QkFBQyxtQkFBRCxDQUFvQjs7Ozs7R0FBSTs7Ozs7R0FDL0Qsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBZ0IsU0FBUyx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7R0FBSTs7Ozs7RUFDckQ7Ozs7O0NBQ0k7Ozs7VUFDSDs7Ozs7QUFFakI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlLCBSb3V0ZXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tICcuL2ZlYXR1cmVzL2F1dGgvQXV0aENvbnRleHQnXHJcbmltcG9ydCB7IFJvdXRlTG9nZ2VyIH0gZnJvbSAnLi9jb21wb25lbnRzL1JvdXRlTG9nZ2VyJ1xyXG5pbXBvcnQgeyBBcHBMYXlvdXQgfSBmcm9tICcuL2NvbXBvbmVudHMvbGF5b3V0L0FwcExheW91dCdcclxuaW1wb3J0IHsgQmFja2VuZEdhdGUgfSBmcm9tICcuL2ZlYXR1cmVzL2hlYWx0aC9CYWNrZW5kR2F0ZSdcclxuaW1wb3J0IHsgdXNlQWNjZW50Q29sb3IgfSBmcm9tICcuL2hvb2tzL3VzZUFjY2VudENvbG9yJ1xyXG5pbXBvcnQgeyBQcm90ZWN0ZWRSb3V0ZSB9IGZyb20gJy4vZmVhdHVyZXMvYXV0aC9Qcm90ZWN0ZWRSb3V0ZSdcclxuaW1wb3J0IHsgUHVibGljT25seVJvdXRlIH0gZnJvbSAnLi9mZWF0dXJlcy9hdXRoL1B1YmxpY09ubHlSb3V0ZSdcclxuaW1wb3J0IHsgQWNjb3VudFBhZ2UgfSBmcm9tICcuL3BhZ2VzL0FjY291bnRQYWdlJ1xyXG5pbXBvcnQgeyBIb21lUGFnZSB9IGZyb20gJy4vcGFnZXMvSG9tZVBhZ2UnXHJcbmltcG9ydCB7IENvdXJzZXNQYWdlIH0gZnJvbSAnLi9wYWdlcy9Db3Vyc2VzUGFnZSdcclxuaW1wb3J0IHsgQ291cnNlUmVhZGVyUGFnZSB9IGZyb20gJy4vcGFnZXMvQ291cnNlUmVhZGVyUGFnZSdcclxuaW1wb3J0IHsgRGFzaGJvYXJkUGFnZSB9IGZyb20gJy4vcGFnZXMvRGFzaGJvYXJkUGFnZSdcclxuaW1wb3J0IHsgV29ya3NwYWNlUGFnZSB9IGZyb20gJy4vcGFnZXMvV29ya3NwYWNlUGFnZSdcclxuaW1wb3J0IHsgRXhhbVBhZ2UgfSBmcm9tICcuL2ZlYXR1cmVzL2V4YW0vRXhhbVBhZ2UnXHJcbmltcG9ydCB7IEdsb2JhbFNlYXJjaCB9IGZyb20gJy4vZmVhdHVyZXMvc2VhcmNoL0dsb2JhbFNlYXJjaCdcclxuaW1wb3J0IHsgTG9naW5QYWdlIH0gZnJvbSAnLi9wYWdlcy9Mb2dpblBhZ2UnXHJcbmltcG9ydCB7IE1mYUNoYWxsZW5nZVBhZ2UgfSBmcm9tICcuL3BhZ2VzL01mYUNoYWxsZW5nZVBhZ2UnXHJcbmltcG9ydCB7IFJlZ2lzdGVyUGFnZSB9IGZyb20gJy4vcGFnZXMvUmVnaXN0ZXJQYWdlJ1xyXG5pbXBvcnQgeyBGb3Jnb3RQYXNzd29yZFBhZ2UgfSBmcm9tICcuL3BhZ2VzL0ZvcmdvdFBhc3N3b3JkUGFnZSdcclxuaW1wb3J0IHsgUmVzZXRQYXNzd29yZFBhZ2UgfSBmcm9tICcuL3BhZ2VzL1Jlc2V0UGFzc3dvcmRQYWdlJ1xyXG5pbXBvcnQgeyBWZXJpZnlFbWFpbFBhZ2UgfSBmcm9tICcuL3BhZ2VzL1ZlcmlmeUVtYWlsUGFnZSdcclxuXHJcbi8vIEFwcC5qc3ggc3RheXMgdGhpbjogcm91dGluZyArIHRoZSBBdXRoUHJvdmlkZXIgd3JhcHBpbmcgZXZlcnl0aGluZyBzb1xyXG4vLyB1c2VBdXRoKCkgd29ya3MgYW55d2hlcmUgaW4gdGhlIHRyZWUuIEFjdHVhbCBjb250ZW50IGxpdmVzIGluIHBhZ2VzLyBhbmQgZmVhdHVyZXMvLlxyXG5mdW5jdGlvbiBBcHAoKSB7XHJcbiAgLy8gQXBwbGllcyB0aGUgdXNlcidzIHBlcnNpc3RlZCBhY2NlbnQgY29sb3IgKHNlZSBob29rcy91c2VBY2NlbnRDb2xvci5qcylcclxuICAvLyBvbiBldmVyeSBwYWdlLCBub3QganVzdCBTZXR0aW5ncyB3aGVyZSBpdCdzIGFjdHVhbGx5IGNoYW5nZWQuXHJcbiAgdXNlQWNjZW50Q29sb3IoKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEJhY2tlbmRHYXRlPlxyXG4gICAgICA8QXV0aFByb3ZpZGVyPlxyXG4gICAgICAgIDxSb3V0ZUxvZ2dlciAvPlxyXG4gICAgICAgIHsvKiBTZWxmLWNvbnRhaW5lZDogb3ducyBpdHMgb3duIEN0cmwrSy9DbWQrSyBvcGVuIHN0YXRlIChzZWVcclxuICAgICAgICAgICAgZmVhdHVyZXMvc2VhcmNoL0dsb2JhbFNlYXJjaC5qc3gpIOKAlCBtb3VudGVkIG9uY2UgaGVyZSBzbyBpdCdzXHJcbiAgICAgICAgICAgIHJlYWNoYWJsZSBmcm9tIGFueXdoZXJlIGluIHRoZSBhcHAuICovfVxyXG4gICAgICAgIDxHbG9iYWxTZWFyY2ggLz5cclxuICAgICAgICA8Um91dGVzPlxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvbG9naW5cIlxyXG4gICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICA8UHVibGljT25seVJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPExvZ2luUGFnZSAvPlxyXG4gICAgICAgICAgICAgIDwvUHVibGljT25seVJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvcmVnaXN0ZXJcIlxyXG4gICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICA8UHVibGljT25seVJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPFJlZ2lzdGVyUGFnZSAvPlxyXG4gICAgICAgICAgICAgIDwvUHVibGljT25seVJvdXRlPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgey8qIE5vdCB3cmFwcGVkIGluIFB1YmxpY09ubHlSb3V0ZTogbWlkLWxvZ2luLCB0aGUgdXNlciBoYXMgcHJvdmVuXHJcbiAgICAgICAgICAgICAgdGhlaXIgcGFzc3dvcmQgYnV0IHVzZUF1dGgoKSBpc24ndCBhdXRoZW50aWNhdGVkIHlldCAobm9cclxuICAgICAgICAgICAgICBzZXNzaW9uIGNvb2tpZSBleGlzdHMgdW50aWwgdGhlIE1GQSBzdGVwIHN1Y2NlZWRzKS4gKi99XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9tZmEtY2hhbGxlbmdlXCIgZWxlbWVudD17PE1mYUNoYWxsZW5nZVBhZ2UgLz59IC8+XHJcbiAgICAgICAgICB7LyogRXZlcnkgYXV0aGVudGljYXRlZCBwYWdlIHNoYXJlcyBvbmUgc2hlbGwgKHRvcGJhciArIHNsaWRlLWluXHJcbiAgICAgICAgICAgICAgc2lkZWJhcikg4oCUIHNlZSBjb21wb25lbnRzL2xheW91dC9BcHBMYXlvdXQuanN4LiBHYXRlZCBieSBhXHJcbiAgICAgICAgICAgICAgc2luZ2xlIFByb3RlY3RlZFJvdXRlIGhlcmUgaW5zdGVhZCBvZiBwZXItcGFnZS4gKi99XHJcbiAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgPEFwcExheW91dCAvPlxyXG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEhvbWVQYWdlIC8+fSAvPlxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9kYXNoYm9hcmRcIiBlbGVtZW50PXs8RGFzaGJvYXJkUGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY291cnNlc1wiIGVsZW1lbnQ9ezxDb3Vyc2VzUGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY21zLzpzbHVnXCIgZWxlbWVudD17PFdvcmtzcGFjZVBhZ2UgLz59IC8+XHJcbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2FjY291bnRcIiBlbGVtZW50PXs8QWNjb3VudFBhZ2UgLz59IC8+XHJcbiAgICAgICAgICA8L1JvdXRlPlxyXG4gICAgICAgICAgey8qIFRoZSBjb3Vyc2UgcmVhZGVyIGFuZCB0aGUgZmluYWwgZXhhbSBhcmUgZGVsaWJlcmF0ZWx5IG91dHNpZGVcclxuICAgICAgICAgICAgICBBcHBMYXlvdXQg4oCUIG5vIHRvcGJhci9zaWRlYmFyIGNocm9tZSwgZWFjaCB3aXRoIGl0cyBvd25cclxuICAgICAgICAgICAgICBkZWRpY2F0ZWQgc2hlbGwgKGRvY3Mtc3R5bGUgcmVhZGVyLCBmdWxsLXNjcmVlbiBleGFtIHJvb20pLlxyXG4gICAgICAgICAgICAgIENvdXJzZSBjYXJkcyBvcGVuIHRoZSByZWFkZXIgaW4gYSBuZXcgYnJvd3NlciB0YWIgKHNlZVxyXG4gICAgICAgICAgICAgIENvdXJzZUNhcmQuanN4KS4gU3RpbGwgZ2F0ZWQgYnkgUHJvdGVjdGVkUm91dGUuICovfVxyXG4gICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgIHBhdGg9XCIvY291cnNlcy86c2x1Zy9sZWFyblwiXHJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgIDxDb3Vyc2VSZWFkZXJQYWdlIC8+XHJcbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICBwYXRoPVwiL2NvdXJzZXMvOnNsdWcvZXhhbVwiXHJcbiAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgIDxFeGFtUGFnZSAvPlxyXG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7LyogUmVhY2hhYmxlIHdoZXRoZXIgbG9nZ2VkIGluIG9yIG91dDogYSBqdXN0LXJlZ2lzdGVyZWQgdXNlciBpc1xyXG4gICAgICAgICAgICAgIGxvZ2dlZCBpbiBidXQgc3RpbGwgbmVlZHMgL3ZlcmlmeS1lbWFpbDsgZm9yZ290L3Jlc2V0IHBhc3N3b3JkXHJcbiAgICAgICAgICAgICAgbXVzdCB3b3JrIGZvciBhIGxvZ2dlZC1vdXQgdXNlci4gKi99XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9mb3Jnb3QtcGFzc3dvcmRcIiBlbGVtZW50PXs8Rm9yZ290UGFzc3dvcmRQYWdlIC8+fSAvPlxyXG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVzZXQtcGFzc3dvcmRcIiBlbGVtZW50PXs8UmVzZXRQYXNzd29yZFBhZ2UgLz59IC8+XHJcbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi92ZXJpZnktZW1haWxcIiBlbGVtZW50PXs8VmVyaWZ5RW1haWxQYWdlIC8+fSAvPlxyXG4gICAgICAgIDwvUm91dGVzPlxyXG4gICAgICA8L0F1dGhQcm92aWRlcj5cclxuICAgIDwvQmFja2VuZEdhdGU+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHBcclxuIl19