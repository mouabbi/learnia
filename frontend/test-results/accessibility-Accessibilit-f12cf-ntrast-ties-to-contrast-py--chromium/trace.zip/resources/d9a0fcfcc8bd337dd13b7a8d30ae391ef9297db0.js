import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AppShellSkeleton.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppShellSkeleton.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Shown by ProtectedRoute/PublicOnlyRoute while the initial GET /auth/me is
// in flight — a rough outline of the real app shell (topbar + a couple of
// content blocks) instead of a blank flash before the real page mounts.
export function AppShellSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-shell",
		"aria-busy": "true",
		"aria-label": "Loading",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "topbar",
			children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "1.5rem",
				height: "1.5rem"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, {
				width: "6rem",
				height: "1.2em"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "app-content",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "content-card skeleton-block",
				children: [
					/* @__PURE__ */ _jsxDEV(Skeleton, {
						width: "40%",
						height: "1.3em"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, {
						width: "90%",
						height: "1em"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Skeleton, {
						width: "70%",
						height: "1em"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 18,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "content-card skeleton-block",
				children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "30%",
					height: "1.3em"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "85%",
					height: "1em"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 22,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_c = AppShellSkeleton;
var _c;
$RefreshReg$(_c, "AppShellSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/AppShellSkeleton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppShellSkeleton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppShellSkeleton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/AppShellSkeleton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7OztBQUt6QixPQUFPLFNBQVMsbUJBQW1CO0NBQ2pDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBWSxhQUFVO0VBQU8sY0FBVztZQUF2RCxDQUNFLHdCQUFDLFVBQUQ7R0FBUSxXQUFVO2FBQWxCLENBQ0Usd0JBQUMsVUFBRDtJQUFVLE9BQU07SUFBUyxRQUFPO0dBQVU7Ozs7YUFDMUMsd0JBQUMsVUFBRDtJQUFVLE9BQU07SUFBTyxRQUFPO0dBQVM7Ozs7V0FDakM7Ozs7O1lBRVIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEIsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsVUFBRDtNQUFVLE9BQU07TUFBTSxRQUFPO0tBQVM7Ozs7O0tBQ3RDLHdCQUFDLFVBQUQ7TUFBVSxPQUFNO01BQU0sUUFBTztLQUFPOzs7OztLQUNwQyx3QkFBQyxVQUFEO01BQVUsT0FBTTtNQUFNLFFBQU87S0FBTzs7Ozs7SUFDakM7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FBVSxPQUFNO0tBQU0sUUFBTztJQUFTOzs7O2NBQ3RDLHdCQUFDLFVBQUQ7S0FBVSxPQUFNO0tBQU0sUUFBTztJQUFPOzs7O1lBQ2pDOzs7OztXQUNEOzs7OztVQUNIOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHBTaGVsbFNrZWxldG9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4uL1NrZWxldG9uJ1xyXG5cclxuLy8gU2hvd24gYnkgUHJvdGVjdGVkUm91dGUvUHVibGljT25seVJvdXRlIHdoaWxlIHRoZSBpbml0aWFsIEdFVCAvYXV0aC9tZSBpc1xyXG4vLyBpbiBmbGlnaHQg4oCUIGEgcm91Z2ggb3V0bGluZSBvZiB0aGUgcmVhbCBhcHAgc2hlbGwgKHRvcGJhciArIGEgY291cGxlIG9mXHJcbi8vIGNvbnRlbnQgYmxvY2tzKSBpbnN0ZWFkIG9mIGEgYmxhbmsgZmxhc2ggYmVmb3JlIHRoZSByZWFsIHBhZ2UgbW91bnRzLlxyXG5leHBvcnQgZnVuY3Rpb24gQXBwU2hlbGxTa2VsZXRvbigpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtc2hlbGxcIiBhcmlhLWJ1c3k9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIkxvYWRpbmdcIj5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJ0b3BiYXJcIj5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCIxLjVyZW1cIiBoZWlnaHQ9XCIxLjVyZW1cIiAvPlxyXG4gICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjZyZW1cIiBoZWlnaHQ9XCIxLjJlbVwiIC8+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiYXBwLWNvbnRlbnRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRlbnQtY2FyZCBza2VsZXRvbi1ibG9ja1wiPlxyXG4gICAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNDAlXCIgaGVpZ2h0PVwiMS4zZW1cIiAvPlxyXG4gICAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiOTAlXCIgaGVpZ2h0PVwiMWVtXCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjcwJVwiIGhlaWdodD1cIjFlbVwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250ZW50LWNhcmQgc2tlbGV0b24tYmxvY2tcIj5cclxuICAgICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjMwJVwiIGhlaWdodD1cIjEuM2VtXCIgLz5cclxuICAgICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjg1JVwiIGhlaWdodD1cIjFlbVwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXX0=