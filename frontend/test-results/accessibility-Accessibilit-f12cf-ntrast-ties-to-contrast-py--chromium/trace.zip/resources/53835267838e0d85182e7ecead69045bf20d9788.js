import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Sidebar.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { Home, BookOpen, Settings, LogOut, PanelLeftClose, PanelLeftOpen } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/Sidebar.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Off-canvas nav drawer used by AppLayout. Pure presentational component —
// open/close state and the close callback are owned by the caller so this
// stays easy to test without touching routing. Slide/fade handled by
// motion (see AnimatePresence) instead of a CSS transform transition, so
// the drawer unmounts (not just hides) when closed.
//
// `pinned` renders the same nav as a static, always-visible column (no
// overlay, no slide animation, no close button) — used by AppLayout for
// the persistent desktop sidebar, hidden below the desktop breakpoint via
// CSS (see .sidebar-pinned in index.css).
export function Sidebar({ email, isOpen, onClose, onLogout, pinned = false, collapsed = false, onToggleCollapse }) {
	const displayName = email.split("@")[0];
	const links = /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		pinned && onToggleCollapse && /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "sidebar-collapse-toggle",
			onClick: onToggleCollapse,
			"aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
			title: collapsed ? "Expand sidebar" : "Collapse sidebar",
			children: collapsed ? /* @__PURE__ */ _jsxDEV(PanelLeftOpen, {
				"aria-hidden": "true",
				size: 18
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 13
			}, this) : /* @__PURE__ */ _jsxDEV(PanelLeftClose, {
				"aria-hidden": "true",
				size: 18
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "sidebar-user",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "sidebar-avatar",
				"aria-hidden": "true",
				children: displayName.charAt(0).toUpperCase()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 9
			}, this), !collapsed && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "sidebar-name",
				children: displayName
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "sidebar-email",
				children: email
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("ul", {
			className: "sidebar-links",
			children: [
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
					to: "/",
					end: true,
					onClick: onClose,
					title: "Home",
					children: [/* @__PURE__ */ _jsxDEV(Home, {
						"aria-hidden": "true",
						size: 18
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 13
					}, this), !collapsed && /* @__PURE__ */ _jsxDEV("span", { children: "Home" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 28
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
					to: "/courses",
					onClick: onClose,
					title: "Courses",
					children: [/* @__PURE__ */ _jsxDEV(BookOpen, {
						"aria-hidden": "true",
						size: 18
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 13
					}, this), !collapsed && /* @__PURE__ */ _jsxDEV("span", { children: "Courses" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 28
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(NavLink, {
					to: "/account",
					onClick: onClose,
					title: "Settings",
					children: [/* @__PURE__ */ _jsxDEV(Settings, {
						"aria-hidden": "true",
						size: 18
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this), !collapsed && /* @__PURE__ */ _jsxDEV("span", { children: "Settings" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 28
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "sidebar-logout",
			onClick: onLogout,
			title: "Log out",
			children: [/* @__PURE__ */ _jsxDEV(LogOut, {
				"aria-hidden": "true",
				size: 18
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this), !collapsed && /* @__PURE__ */ _jsxDEV("span", { children: "Log out" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 24
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
	if (pinned) {
		return /* @__PURE__ */ _jsxDEV("nav", {
			className: `sidebar sidebar-static${collapsed ? " sidebar-collapsed" : ""}`,
			"aria-label": "Main menu",
			children: links
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isOpen && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(motion.div, {
		className: "sidebar-overlay",
		onClick: onClose,
		"aria-hidden": "true",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		exit: { opacity: 0 },
		transition: { duration: .15 }
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 11
	}, this), /* @__PURE__ */ _jsxDEV(motion.nav, {
		className: "sidebar",
		"aria-label": "Main menu",
		initial: { x: "-100%" },
		animate: { x: 0 },
		exit: { x: "-100%" },
		transition: {
			type: "tween",
			duration: .2,
			ease: "easeOut"
		},
		children: links
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 109,
		columnNumber: 11
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 98,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 96,
		columnNumber: 5
	}, this);
}
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Sidebar.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/layout/Sidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/layout/Sidebar.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsY0FBYztBQUN4QyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxNQUFNLFVBQVUsVUFBVSxRQUFRLGdCQUFnQixxQkFBcUI7Ozs7Ozs7Ozs7Ozs7QUFZaEYsT0FBTyxTQUFTLFFBQVEsRUFDdEIsT0FDQSxRQUNBLFNBQ0EsVUFDQSxTQUFTLE9BQ1QsWUFBWSxPQUNaLG9CQUNDO0NBQ0QsTUFBTSxjQUFjLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQztDQUVyQyxNQUFNLFFBQ0o7RUFDRyxVQUFVLG9CQUNULHdCQUFDLFVBQUQ7R0FDRSxNQUFLO0dBQ0wsV0FBVTtHQUNWLFNBQVM7R0FDVCxjQUFZLFlBQVksbUJBQW1CO0dBQzNDLE9BQU8sWUFBWSxtQkFBbUI7YUFFckMsWUFDQyx3QkFBQyxlQUFEO0lBQWUsZUFBWTtJQUFPLE1BQU07R0FBSzs7OztjQUU3Qyx3QkFBQyxnQkFBRDtJQUFnQixlQUFZO0lBQU8sTUFBTTtHQUFLOzs7OztFQUUxQzs7Ozs7RUFHVix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7SUFBaUIsZUFBWTtjQUMxQyxZQUFZLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUMvQjs7OzthQUNMLENBQUMsYUFDQSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBZ0I7R0FBZTs7OzthQUM1Qyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFpQjtHQUFTOzs7O1dBQ3BDOzs7O1dBRUo7Ozs7OztFQUVMLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWQ7SUFDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsU0FBRDtLQUFTLElBQUc7S0FBSTtLQUFJLFNBQVM7S0FBUyxPQUFNO2VBQTVDLENBQ0Usd0JBQUMsTUFBRDtNQUFNLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7ZUFDbkMsQ0FBQyxhQUFhLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2FBQ3hCOzs7OzthQUNQOzs7OztJQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxTQUFEO0tBQVMsSUFBRztLQUFXLFNBQVM7S0FBUyxPQUFNO2VBQS9DLENBQ0Usd0JBQUMsVUFBRDtNQUFVLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7ZUFDdkMsQ0FBQyxhQUFhLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O2FBQzNCOzs7OzthQUNQOzs7OztJQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxTQUFEO0tBQVMsSUFBRztLQUFXLFNBQVM7S0FBUyxPQUFNO2VBQS9DLENBQ0Usd0JBQUMsVUFBRDtNQUFVLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7ZUFDdkMsQ0FBQyxhQUFhLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O2FBQzVCOzs7OzthQUNQOzs7OztHQUNGOzs7Ozs7RUFFSix3QkFBQyxVQUFEO0dBQVEsTUFBSztHQUFTLFdBQVU7R0FBaUIsU0FBUztHQUFVLE9BQU07YUFBMUUsQ0FDRSx3QkFBQyxRQUFEO0lBQVEsZUFBWTtJQUFPLE1BQU07R0FBSzs7OzthQUNyQyxDQUFDLGFBQWEsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7V0FDNUI7Ozs7OztDQUNSOzs7OztDQUdKLElBQUksUUFBUTtFQUNWLE9BQ0Usd0JBQUMsT0FBRDtHQUNFLFdBQVcseUJBQXlCLFlBQVksdUJBQXVCO0dBQ3ZFLGNBQVc7YUFFVjtFQUNFOzs7OztDQUVUO0NBRUEsT0FDRSx3QkFBQyxpQkFBRCxZQUNHLFVBQ0MsZ0RBQ0Usd0JBQUMsT0FBTyxLQUFSO0VBQ0UsV0FBVTtFQUNWLFNBQVM7RUFDVCxlQUFZO0VBQ1osU0FBUyxFQUFFLFNBQVMsRUFBRTtFQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO0VBQ3RCLE1BQU0sRUFBRSxTQUFTLEVBQUU7RUFDbkIsWUFBWSxFQUFFLFVBQVUsSUFBSztDQUM5Qjs7OztXQUVELHdCQUFDLE9BQU8sS0FBUjtFQUNFLFdBQVU7RUFDVixjQUFXO0VBQ1gsU0FBUyxFQUFFLEdBQUcsUUFBUTtFQUN0QixTQUFTLEVBQUUsR0FBRyxFQUFFO0VBQ2hCLE1BQU0sRUFBRSxHQUFHLFFBQVE7RUFDbkIsWUFBWTtHQUFFLE1BQU07R0FBUyxVQUFVO0dBQUssTUFBTTtFQUFVO1lBRTNEO0NBQ1M7Ozs7U0FDWjs7OztVQUVXOzs7OztBQUVyQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaWRlYmFyLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBbmltYXRlUHJlc2VuY2UsIG1vdGlvbiB9IGZyb20gJ21vdGlvbi9yZWFjdCdcclxuaW1wb3J0IHsgTmF2TGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXHJcbmltcG9ydCB7IEhvbWUsIEJvb2tPcGVuLCBTZXR0aW5ncywgTG9nT3V0LCBQYW5lbExlZnRDbG9zZSwgUGFuZWxMZWZ0T3BlbiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuXHJcbi8vIE9mZi1jYW52YXMgbmF2IGRyYXdlciB1c2VkIGJ5IEFwcExheW91dC4gUHVyZSBwcmVzZW50YXRpb25hbCBjb21wb25lbnQg4oCUXHJcbi8vIG9wZW4vY2xvc2Ugc3RhdGUgYW5kIHRoZSBjbG9zZSBjYWxsYmFjayBhcmUgb3duZWQgYnkgdGhlIGNhbGxlciBzbyB0aGlzXHJcbi8vIHN0YXlzIGVhc3kgdG8gdGVzdCB3aXRob3V0IHRvdWNoaW5nIHJvdXRpbmcuIFNsaWRlL2ZhZGUgaGFuZGxlZCBieVxyXG4vLyBtb3Rpb24gKHNlZSBBbmltYXRlUHJlc2VuY2UpIGluc3RlYWQgb2YgYSBDU1MgdHJhbnNmb3JtIHRyYW5zaXRpb24sIHNvXHJcbi8vIHRoZSBkcmF3ZXIgdW5tb3VudHMgKG5vdCBqdXN0IGhpZGVzKSB3aGVuIGNsb3NlZC5cclxuLy9cclxuLy8gYHBpbm5lZGAgcmVuZGVycyB0aGUgc2FtZSBuYXYgYXMgYSBzdGF0aWMsIGFsd2F5cy12aXNpYmxlIGNvbHVtbiAobm9cclxuLy8gb3ZlcmxheSwgbm8gc2xpZGUgYW5pbWF0aW9uLCBubyBjbG9zZSBidXR0b24pIOKAlCB1c2VkIGJ5IEFwcExheW91dCBmb3JcclxuLy8gdGhlIHBlcnNpc3RlbnQgZGVza3RvcCBzaWRlYmFyLCBoaWRkZW4gYmVsb3cgdGhlIGRlc2t0b3AgYnJlYWtwb2ludCB2aWFcclxuLy8gQ1NTIChzZWUgLnNpZGViYXItcGlubmVkIGluIGluZGV4LmNzcykuXHJcbmV4cG9ydCBmdW5jdGlvbiBTaWRlYmFyKHtcclxuICBlbWFpbCxcclxuICBpc09wZW4sXHJcbiAgb25DbG9zZSxcclxuICBvbkxvZ291dCxcclxuICBwaW5uZWQgPSBmYWxzZSxcclxuICBjb2xsYXBzZWQgPSBmYWxzZSxcclxuICBvblRvZ2dsZUNvbGxhcHNlLFxyXG59KSB7XHJcbiAgY29uc3QgZGlzcGxheU5hbWUgPSBlbWFpbC5zcGxpdCgnQCcpWzBdXHJcblxyXG4gIGNvbnN0IGxpbmtzID0gKFxyXG4gICAgPD5cclxuICAgICAge3Bpbm5lZCAmJiBvblRvZ2dsZUNvbGxhcHNlICYmIChcclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGViYXItY29sbGFwc2UtdG9nZ2xlXCJcclxuICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlQ29sbGFwc2V9XHJcbiAgICAgICAgICBhcmlhLWxhYmVsPXtjb2xsYXBzZWQgPyAnRXhwYW5kIHNpZGViYXInIDogJ0NvbGxhcHNlIHNpZGViYXInfVxyXG4gICAgICAgICAgdGl0bGU9e2NvbGxhcHNlZCA/ICdFeHBhbmQgc2lkZWJhcicgOiAnQ29sbGFwc2Ugc2lkZWJhcid9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2NvbGxhcHNlZCA/IChcclxuICAgICAgICAgICAgPFBhbmVsTGVmdE9wZW4gYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8UGFuZWxMZWZ0Q2xvc2UgYXJpYS1oaWRkZW49XCJ0cnVlXCIgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWRlYmFyLXVzZXJcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaWRlYmFyLWF2YXRhclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAge2Rpc3BsYXlOYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICB7IWNvbGxhcHNlZCAmJiAoXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaWRlYmFyLW5hbWVcIj57ZGlzcGxheU5hbWV9PC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJzaWRlYmFyLWVtYWlsXCI+e2VtYWlsfTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cInNpZGViYXItbGlua3NcIj5cclxuICAgICAgICA8bGk+XHJcbiAgICAgICAgICA8TmF2TGluayB0bz1cIi9cIiBlbmQgb25DbGljaz17b25DbG9zZX0gdGl0bGU9XCJIb21lXCI+XHJcbiAgICAgICAgICAgIDxIb21lIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICB7IWNvbGxhcHNlZCAmJiA8c3Bhbj5Ib21lPC9zcGFuPn1cclxuICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIDxsaT5cclxuICAgICAgICAgIDxOYXZMaW5rIHRvPVwiL2NvdXJzZXNcIiBvbkNsaWNrPXtvbkNsb3NlfSB0aXRsZT1cIkNvdXJzZXNcIj5cclxuICAgICAgICAgICAgPEJvb2tPcGVuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICB7IWNvbGxhcHNlZCAmJiA8c3Bhbj5Db3Vyc2VzPC9zcGFuPn1cclxuICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIDxsaT5cclxuICAgICAgICAgIDxOYXZMaW5rIHRvPVwiL2FjY291bnRcIiBvbkNsaWNrPXtvbkNsb3NlfSB0aXRsZT1cIlNldHRpbmdzXCI+XHJcbiAgICAgICAgICAgIDxTZXR0aW5ncyBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgeyFjb2xsYXBzZWQgJiYgPHNwYW4+U2V0dGluZ3M8L3NwYW4+fVxyXG4gICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgIDwvdWw+XHJcblxyXG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJzaWRlYmFyLWxvZ291dFwiIG9uQ2xpY2s9e29uTG9nb3V0fSB0aXRsZT1cIkxvZyBvdXRcIj5cclxuICAgICAgICA8TG9nT3V0IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIHNpemU9ezE4fSAvPlxyXG4gICAgICAgIHshY29sbGFwc2VkICYmIDxzcGFuPkxvZyBvdXQ8L3NwYW4+fVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgIDwvPlxyXG4gIClcclxuXHJcbiAgaWYgKHBpbm5lZCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPG5hdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YHNpZGViYXIgc2lkZWJhci1zdGF0aWMke2NvbGxhcHNlZCA/ICcgc2lkZWJhci1jb2xsYXBzZWQnIDogJyd9YH1cclxuICAgICAgICBhcmlhLWxhYmVsPVwiTWFpbiBtZW51XCJcclxuICAgICAgPlxyXG4gICAgICAgIHtsaW5rc31cclxuICAgICAgPC9uYXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEFuaW1hdGVQcmVzZW5jZT5cclxuICAgICAge2lzT3BlbiAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpZGViYXItb3ZlcmxheVwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxyXG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX1cclxuICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMTUgfX1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPG1vdGlvbi5uYXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2lkZWJhclwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNYWluIG1lbnVcIlxyXG4gICAgICAgICAgICBpbml0aWFsPXt7IHg6ICctMTAwJScgfX1cclxuICAgICAgICAgICAgYW5pbWF0ZT17eyB4OiAwIH19XHJcbiAgICAgICAgICAgIGV4aXQ9e3sgeDogJy0xMDAlJyB9fVxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IHR5cGU6ICd0d2VlbicsIGR1cmF0aW9uOiAwLjIsIGVhc2U6ICdlYXNlT3V0JyB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7bGlua3N9XHJcbiAgICAgICAgICA8L21vdGlvbi5uYXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L0FuaW1hdGVQcmVzZW5jZT5cclxuICApXHJcbn1cclxuIl19