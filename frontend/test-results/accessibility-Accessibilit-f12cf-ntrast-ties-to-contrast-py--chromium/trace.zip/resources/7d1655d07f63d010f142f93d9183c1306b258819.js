import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/VerifyEmailPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { authApi } from "/src/features/auth/authApi.js";
import { ApiError } from "/src/api/client.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/VerifyEmailPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Reached via the link emailed on register / resend: /verify-email?token=...
// Verifies automatically on load — no form, nothing for the user to type.
export function VerifyEmailPage() {
	_s();
	const [searchParams] = useSearchParams();
	const token = searchParams.get("token");
	// No token at all -> nothing to verify, no API call, no effect needed.
	const [status, setStatus] = useState(token ? "verifying" : "error");
	const [error, setError] = useState(token ? null : "This link is missing its token.");
	useEffect(() => {
		if (!token) return;
		authApi.verifyEmail(token).then(() => setStatus("success")).catch((err) => {
			setStatus("error");
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		});
	}, [token]);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "page",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: "Verify email" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			status === "verifying" && /* @__PURE__ */ _jsxDEV("p", { children: "Verifying..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 34
			}, this),
			status === "success" && /* @__PURE__ */ _jsxDEV("p", { children: "Your email is now verified." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 32
			}, this),
			status === "error" && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				children: "Go to Learnia"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 9
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_s(VerifyEmailPage, "T9M8EYDJ71ybTnbOoctR54iLf00=", false, function() {
	return [useSearchParams];
});
_c = VerifyEmailPage;
var _c;
$RefreshReg$(_c, "VerifyEmailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/VerifyEmailPage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/VerifyEmailPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/VerifyEmailPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/VerifyEmailPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLE1BQU0sdUJBQXVCO0FBQ3RDLFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7Ozs7O0FBSXpCLE9BQU8sU0FBUyxrQkFBa0I7O0NBQ2hDLE1BQU0sQ0FBQyxnQkFBZ0IsZ0JBQWdCO0NBQ3ZDLE1BQU0sUUFBUSxhQUFhLElBQUksT0FBTzs7Q0FFdEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLFFBQVEsY0FBYyxPQUFPO0NBQ2xFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxRQUFRLE9BQU8saUNBQWlDO0NBRW5GLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxPQUFPO0VBQ1osUUFDRyxZQUFZLEtBQUssQ0FBQyxDQUNsQixXQUFXLFVBQVUsU0FBUyxDQUFDLENBQUMsQ0FDaEMsT0FBTyxRQUFRO0dBQ2QsVUFBVSxPQUFPO0dBQ2pCLFNBQVMsZUFBZSxXQUFXLElBQUksVUFBVSxzQkFBc0I7RUFDekUsQ0FBQztDQUNMLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7OztHQUNuQixXQUFXLGVBQWUsd0JBQUMsS0FBRCxZQUFHLGVBQWU7Ozs7O0dBQzVDLFdBQVcsYUFBYSx3QkFBQyxLQUFELFlBQUcsOEJBQThCOzs7OztHQUN6RCxXQUFXLFdBQ1Ysd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUSxXQUFVO2NBQ3ZCO0dBQ0E7Ozs7O0dBRUwsd0JBQUMsS0FBRCxZQUNFLHdCQUFDLE1BQUQ7SUFBTSxJQUFHO2NBQUk7R0FBbUI7Ozs7WUFDL0I7Ozs7O0VBQ0k7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlZlcmlmeUVtYWlsUGFnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXV0aC9hdXRoQXBpJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uL2FwaS9jbGllbnQnXHJcblxyXG4vLyBSZWFjaGVkIHZpYSB0aGUgbGluayBlbWFpbGVkIG9uIHJlZ2lzdGVyIC8gcmVzZW5kOiAvdmVyaWZ5LWVtYWlsP3Rva2VuPS4uLlxyXG4vLyBWZXJpZmllcyBhdXRvbWF0aWNhbGx5IG9uIGxvYWQg4oCUIG5vIGZvcm0sIG5vdGhpbmcgZm9yIHRoZSB1c2VyIHRvIHR5cGUuXHJcbmV4cG9ydCBmdW5jdGlvbiBWZXJpZnlFbWFpbFBhZ2UoKSB7XHJcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKVxyXG4gIGNvbnN0IHRva2VuID0gc2VhcmNoUGFyYW1zLmdldCgndG9rZW4nKVxyXG4gIC8vIE5vIHRva2VuIGF0IGFsbCAtPiBub3RoaW5nIHRvIHZlcmlmeSwgbm8gQVBJIGNhbGwsIG5vIGVmZmVjdCBuZWVkZWQuXHJcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlKHRva2VuID8gJ3ZlcmlmeWluZycgOiAnZXJyb3InKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUodG9rZW4gPyBudWxsIDogJ1RoaXMgbGluayBpcyBtaXNzaW5nIGl0cyB0b2tlbi4nKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCF0b2tlbikgcmV0dXJuXHJcbiAgICBhdXRoQXBpXHJcbiAgICAgIC52ZXJpZnlFbWFpbCh0b2tlbilcclxuICAgICAgLnRoZW4oKCkgPT4gc2V0U3RhdHVzKCdzdWNjZXNzJykpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgICAgc2V0U3RhdHVzKCdlcnJvcicpXHJcbiAgICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgQXBpRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdTb21ldGhpbmcgd2VudCB3cm9uZycpXHJcbiAgICAgIH0pXHJcbiAgfSwgW3Rva2VuXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhZ2VcIj5cclxuICAgICAgPGgxPlZlcmlmeSBlbWFpbDwvaDE+XHJcbiAgICAgIHtzdGF0dXMgPT09ICd2ZXJpZnlpbmcnICYmIDxwPlZlcmlmeWluZy4uLjwvcD59XHJcbiAgICAgIHtzdGF0dXMgPT09ICdzdWNjZXNzJyAmJiA8cD5Zb3VyIGVtYWlsIGlzIG5vdyB2ZXJpZmllZC48L3A+fVxyXG4gICAgICB7c3RhdHVzID09PSAnZXJyb3InICYmIChcclxuICAgICAgICA8cCByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJlcnJvclwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuICAgICAgPHA+XHJcbiAgICAgICAgPExpbmsgdG89XCIvXCI+R28gdG8gTGVhcm5pYTwvTGluaz5cclxuICAgICAgPC9wPlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufVxyXG4iXX0=