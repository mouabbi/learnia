import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "/api/v1", "VITE_LOG_LEVEL": "debug"};/**
* Shared API client — every feature's API calls go through this, instead of
* calling `fetch` directly everywhere. Centralizes the base URL, JSON
* handling, and error handling so features don't each reinvent it.
*
* Base URL comes from VITE_API_BASE_URL (see .env.development /
* .env.production), not hardcoded — that's what lets dev (proxied through
* Vite to localhost:8000) and a later production build (real API domain)
* use different values without touching this code. `import.meta.env` is
* Vite's replacement for Node's `process.env` in browser code; only
* variables prefixed VITE_ are exposed to the client bundle.
*/
import { createLogger } from "/src/utils/logger.js";
const BASE_URL = import.meta.env.VITE_API_BASE_URL;
const log = createLogger("api");
/**
* Custom error class so callers can distinguish "the API returned an error
* response" from a network failure, and read the structured error code
* the backend sends (see backend/exceptions.py for the matching shape).
*/
export class ApiError extends Error {
	constructor(status, code, message) {
		super(message);
		this.status = status;
		this.code = code;
	}
}
async function request(path, options = {}) {
	const method = options.method ?? "GET";
	const started = performance.now();
	let response;
	try {
		response = await fetch(`${BASE_URL}${path}`, {
			headers: { "Content-Type": "application/json" },
			...options
		});
	} catch (networkError) {
		// fetch only throws when no response came back at all (server down, offline, CORS block).
		log.error(`${method} ${path} -> network error`, networkError);
		throw networkError;
	}
	const ms = Math.round(performance.now() - started);
	if (!response.ok) {
		const body = await response.json().catch(() => null);
		const error = body?.error;
		// Only method, path, status, timing and the error code are logged — never bodies.
		log.warn(`${method} ${path} -> ${response.status} (${ms} ms)`, { code: error?.code });
		throw new ApiError(response.status, error?.code ?? "UNKNOWN_ERROR", error?.message ?? "Something went wrong");
	}
	log.info(`${method} ${path} -> ${response.status} (${ms} ms)`);
	// No content (e.g. 204 on delete) — nothing to parse.
	if (response.status === 204) return null;
	return response.json();
}
async function requestForm(path, formData) {
	// Same error/logging behavior as request(), but skips the
	// `Content-Type: application/json` header and JSON.stringify — a
	// multipart body needs the browser to set its own
	// `Content-Type: multipart/form-data; boundary=...` header, which only
	// happens if we don't set Content-Type ourselves at all.
	const method = "POST";
	const started = performance.now();
	let response;
	try {
		response = await fetch(`${BASE_URL}${path}`, {
			method,
			body: formData
		});
	} catch (networkError) {
		log.error(`${method} ${path} -> network error`, networkError);
		throw networkError;
	}
	const ms = Math.round(performance.now() - started);
	if (!response.ok) {
		const body = await response.json().catch(() => null);
		const error = body?.error;
		log.warn(`${method} ${path} -> ${response.status} (${ms} ms)`, { code: error?.code });
		throw new ApiError(response.status, error?.code ?? "UNKNOWN_ERROR", error?.message ?? "Something went wrong");
	}
	log.info(`${method} ${path} -> ${response.status} (${ms} ms)`);
	if (response.status === 204) return null;
	return response.json();
}
export const apiClient = {
	get: (path) => request(path),
	post: (path, data) => request(path, {
		method: "POST",
		body: JSON.stringify(data)
	}),
	patch: (path, data) => request(path, {
		method: "PATCH",
		body: JSON.stringify(data)
	}),
	delete: (path) => request(path, { method: "DELETE" }),
	// For multipart/form-data uploads (e.g. features/assets/assetsApi.js) —
	// pass a `FormData` instance, not a plain object.
	postForm: (path, formData) => requestForm(path, formData)
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxvQkFBb0I7QUFFN0IsTUFBTSxXQUFXLFlBQVksSUFBSTtBQUNqQyxNQUFNLE1BQU0sYUFBYSxLQUFLOzs7Ozs7QUFPOUIsT0FBTyxNQUFNLGlCQUFpQixNQUFNO0NBQ2xDLFlBQVksUUFBUSxNQUFNLFNBQVM7RUFDakMsTUFBTSxPQUFPO0VBQ2IsS0FBSyxTQUFTO0VBQ2QsS0FBSyxPQUFPO0NBQ2Q7QUFDRjtBQUVBLGVBQWUsUUFBUSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0NBQ3pDLE1BQU0sU0FBUyxRQUFRLFVBQVU7Q0FDakMsTUFBTSxVQUFVLFlBQVksSUFBSTtDQUVoQyxJQUFJO0NBQ0osSUFBSTtFQUNGLFdBQVcsTUFBTSxNQUFNLEdBQUcsV0FBVyxRQUFRO0dBQzNDLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLEdBQUc7RUFDTCxDQUFDO0NBQ0gsU0FBUyxjQUFjOztFQUVyQixJQUFJLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxvQkFBb0IsWUFBWTtFQUM1RCxNQUFNO0NBQ1I7Q0FFQSxNQUFNLEtBQUssS0FBSyxNQUFNLFlBQVksSUFBSSxJQUFJLE9BQU87Q0FFakQsSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUNoQixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVksSUFBSTtFQUNuRCxNQUFNLFFBQVEsTUFBTTs7RUFFcEIsSUFBSSxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssTUFBTSxTQUFTLE9BQU8sSUFBSSxHQUFHLE9BQU8sRUFBRSxNQUFNLE9BQU8sS0FBSyxDQUFDO0VBQ3BGLE1BQU0sSUFBSSxTQUNSLFNBQVMsUUFDVCxPQUFPLFFBQVEsaUJBQ2YsT0FBTyxXQUFXLHNCQUNwQjtDQUNGO0NBRUEsSUFBSSxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssTUFBTSxTQUFTLE9BQU8sSUFBSSxHQUFHLEtBQUs7O0NBRzdELElBQUksU0FBUyxXQUFXLEtBQUssT0FBTztDQUVwQyxPQUFPLFNBQVMsS0FBSztBQUN2QjtBQUVBLGVBQWUsWUFBWSxNQUFNLFVBQVU7Ozs7OztDQU16QyxNQUFNLFNBQVM7Q0FDZixNQUFNLFVBQVUsWUFBWSxJQUFJO0NBRWhDLElBQUk7Q0FDSixJQUFJO0VBQ0YsV0FBVyxNQUFNLE1BQU0sR0FBRyxXQUFXLFFBQVE7R0FBRTtHQUFRLE1BQU07RUFBUyxDQUFDO0NBQ3pFLFNBQVMsY0FBYztFQUNyQixJQUFJLE1BQU0sR0FBRyxPQUFPLEdBQUcsS0FBSyxvQkFBb0IsWUFBWTtFQUM1RCxNQUFNO0NBQ1I7Q0FFQSxNQUFNLEtBQUssS0FBSyxNQUFNLFlBQVksSUFBSSxJQUFJLE9BQU87Q0FFakQsSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUNoQixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVksSUFBSTtFQUNuRCxNQUFNLFFBQVEsTUFBTTtFQUNwQixJQUFJLEtBQUssR0FBRyxPQUFPLEdBQUcsS0FBSyxNQUFNLFNBQVMsT0FBTyxJQUFJLEdBQUcsT0FBTyxFQUFFLE1BQU0sT0FBTyxLQUFLLENBQUM7RUFDcEYsTUFBTSxJQUFJLFNBQ1IsU0FBUyxRQUNULE9BQU8sUUFBUSxpQkFDZixPQUFPLFdBQVcsc0JBQ3BCO0NBQ0Y7Q0FFQSxJQUFJLEtBQUssR0FBRyxPQUFPLEdBQUcsS0FBSyxNQUFNLFNBQVMsT0FBTyxJQUFJLEdBQUcsS0FBSztDQUM3RCxJQUFJLFNBQVMsV0FBVyxLQUFLLE9BQU87Q0FDcEMsT0FBTyxTQUFTLEtBQUs7QUFDdkI7QUFFQSxPQUFPLE1BQU0sWUFBWTtDQUN2QixNQUFNLFNBQVMsUUFBUSxJQUFJO0NBQzNCLE9BQU8sTUFBTSxTQUFTLFFBQVEsTUFBTTtFQUFFLFFBQVE7RUFBUSxNQUFNLEtBQUssVUFBVSxJQUFJO0NBQUUsQ0FBQztDQUNsRixRQUFRLE1BQU0sU0FBUyxRQUFRLE1BQU07RUFBRSxRQUFRO0VBQVMsTUFBTSxLQUFLLFVBQVUsSUFBSTtDQUFFLENBQUM7Q0FDcEYsU0FBUyxTQUFTLFFBQVEsTUFBTSxFQUFFLFFBQVEsU0FBUyxDQUFDOzs7Q0FHcEQsV0FBVyxNQUFNLGFBQWEsWUFBWSxNQUFNLFFBQVE7QUFDMUQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiY2xpZW50LmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBTaGFyZWQgQVBJIGNsaWVudCDigJQgZXZlcnkgZmVhdHVyZSdzIEFQSSBjYWxscyBnbyB0aHJvdWdoIHRoaXMsIGluc3RlYWQgb2ZcclxuICogY2FsbGluZyBgZmV0Y2hgIGRpcmVjdGx5IGV2ZXJ5d2hlcmUuIENlbnRyYWxpemVzIHRoZSBiYXNlIFVSTCwgSlNPTlxyXG4gKiBoYW5kbGluZywgYW5kIGVycm9yIGhhbmRsaW5nIHNvIGZlYXR1cmVzIGRvbid0IGVhY2ggcmVpbnZlbnQgaXQuXHJcbiAqXHJcbiAqIEJhc2UgVVJMIGNvbWVzIGZyb20gVklURV9BUElfQkFTRV9VUkwgKHNlZSAuZW52LmRldmVsb3BtZW50IC9cclxuICogLmVudi5wcm9kdWN0aW9uKSwgbm90IGhhcmRjb2RlZCDigJQgdGhhdCdzIHdoYXQgbGV0cyBkZXYgKHByb3hpZWQgdGhyb3VnaFxyXG4gKiBWaXRlIHRvIGxvY2FsaG9zdDo4MDAwKSBhbmQgYSBsYXRlciBwcm9kdWN0aW9uIGJ1aWxkIChyZWFsIEFQSSBkb21haW4pXHJcbiAqIHVzZSBkaWZmZXJlbnQgdmFsdWVzIHdpdGhvdXQgdG91Y2hpbmcgdGhpcyBjb2RlLiBgaW1wb3J0Lm1ldGEuZW52YCBpc1xyXG4gKiBWaXRlJ3MgcmVwbGFjZW1lbnQgZm9yIE5vZGUncyBgcHJvY2Vzcy5lbnZgIGluIGJyb3dzZXIgY29kZTsgb25seVxyXG4gKiB2YXJpYWJsZXMgcHJlZml4ZWQgVklURV8gYXJlIGV4cG9zZWQgdG8gdGhlIGNsaWVudCBidW5kbGUuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlTG9nZ2VyIH0gZnJvbSAnLi4vdXRpbHMvbG9nZ2VyJ1xyXG5cclxuY29uc3QgQkFTRV9VUkwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfQkFTRV9VUkxcclxuY29uc3QgbG9nID0gY3JlYXRlTG9nZ2VyKCdhcGknKVxyXG5cclxuLyoqXHJcbiAqIEN1c3RvbSBlcnJvciBjbGFzcyBzbyBjYWxsZXJzIGNhbiBkaXN0aW5ndWlzaCBcInRoZSBBUEkgcmV0dXJuZWQgYW4gZXJyb3JcclxuICogcmVzcG9uc2VcIiBmcm9tIGEgbmV0d29yayBmYWlsdXJlLCBhbmQgcmVhZCB0aGUgc3RydWN0dXJlZCBlcnJvciBjb2RlXHJcbiAqIHRoZSBiYWNrZW5kIHNlbmRzIChzZWUgYmFja2VuZC9leGNlcHRpb25zLnB5IGZvciB0aGUgbWF0Y2hpbmcgc2hhcGUpLlxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIEFwaUVycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIGNvbnN0cnVjdG9yKHN0YXR1cywgY29kZSwgbWVzc2FnZSkge1xyXG4gICAgc3VwZXIobWVzc2FnZSlcclxuICAgIHRoaXMuc3RhdHVzID0gc3RhdHVzXHJcbiAgICB0aGlzLmNvZGUgPSBjb2RlXHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZXF1ZXN0KHBhdGgsIG9wdGlvbnMgPSB7fSkge1xyXG4gIGNvbnN0IG1ldGhvZCA9IG9wdGlvbnMubWV0aG9kID8/ICdHRVQnXHJcbiAgY29uc3Qgc3RhcnRlZCA9IHBlcmZvcm1hbmNlLm5vdygpXHJcblxyXG4gIGxldCByZXNwb25zZVxyXG4gIHRyeSB7XHJcbiAgICByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfSR7cGF0aH1gLCB7XHJcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICAuLi5vcHRpb25zLFxyXG4gICAgfSlcclxuICB9IGNhdGNoIChuZXR3b3JrRXJyb3IpIHtcclxuICAgIC8vIGZldGNoIG9ubHkgdGhyb3dzIHdoZW4gbm8gcmVzcG9uc2UgY2FtZSBiYWNrIGF0IGFsbCAoc2VydmVyIGRvd24sIG9mZmxpbmUsIENPUlMgYmxvY2spLlxyXG4gICAgbG9nLmVycm9yKGAke21ldGhvZH0gJHtwYXRofSAtPiBuZXR3b3JrIGVycm9yYCwgbmV0d29ya0Vycm9yKVxyXG4gICAgdGhyb3cgbmV0d29ya0Vycm9yXHJcbiAgfVxyXG5cclxuICBjb25zdCBtcyA9IE1hdGgucm91bmQocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydGVkKVxyXG5cclxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXHJcbiAgICBjb25zdCBlcnJvciA9IGJvZHk/LmVycm9yXHJcbiAgICAvLyBPbmx5IG1ldGhvZCwgcGF0aCwgc3RhdHVzLCB0aW1pbmcgYW5kIHRoZSBlcnJvciBjb2RlIGFyZSBsb2dnZWQg4oCUIG5ldmVyIGJvZGllcy5cclxuICAgIGxvZy53YXJuKGAke21ldGhvZH0gJHtwYXRofSAtPiAke3Jlc3BvbnNlLnN0YXR1c30gKCR7bXN9IG1zKWAsIHsgY29kZTogZXJyb3I/LmNvZGUgfSlcclxuICAgIHRocm93IG5ldyBBcGlFcnJvcihcclxuICAgICAgcmVzcG9uc2Uuc3RhdHVzLFxyXG4gICAgICBlcnJvcj8uY29kZSA/PyAnVU5LTk9XTl9FUlJPUicsXHJcbiAgICAgIGVycm9yPy5tZXNzYWdlID8/ICdTb21ldGhpbmcgd2VudCB3cm9uZycsXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBsb2cuaW5mbyhgJHttZXRob2R9ICR7cGF0aH0gLT4gJHtyZXNwb25zZS5zdGF0dXN9ICgke21zfSBtcylgKVxyXG5cclxuICAvLyBObyBjb250ZW50IChlLmcuIDIwNCBvbiBkZWxldGUpIOKAlCBub3RoaW5nIHRvIHBhcnNlLlxyXG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGxcclxuXHJcbiAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZXF1ZXN0Rm9ybShwYXRoLCBmb3JtRGF0YSkge1xyXG4gIC8vIFNhbWUgZXJyb3IvbG9nZ2luZyBiZWhhdmlvciBhcyByZXF1ZXN0KCksIGJ1dCBza2lwcyB0aGVcclxuICAvLyBgQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qc29uYCBoZWFkZXIgYW5kIEpTT04uc3RyaW5naWZ5IOKAlCBhXHJcbiAgLy8gbXVsdGlwYXJ0IGJvZHkgbmVlZHMgdGhlIGJyb3dzZXIgdG8gc2V0IGl0cyBvd25cclxuICAvLyBgQ29udGVudC1UeXBlOiBtdWx0aXBhcnQvZm9ybS1kYXRhOyBib3VuZGFyeT0uLi5gIGhlYWRlciwgd2hpY2ggb25seVxyXG4gIC8vIGhhcHBlbnMgaWYgd2UgZG9uJ3Qgc2V0IENvbnRlbnQtVHlwZSBvdXJzZWx2ZXMgYXQgYWxsLlxyXG4gIGNvbnN0IG1ldGhvZCA9ICdQT1NUJ1xyXG4gIGNvbnN0IHN0YXJ0ZWQgPSBwZXJmb3JtYW5jZS5ub3coKVxyXG5cclxuICBsZXQgcmVzcG9uc2VcclxuICB0cnkge1xyXG4gICAgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0ke3BhdGh9YCwgeyBtZXRob2QsIGJvZHk6IGZvcm1EYXRhIH0pXHJcbiAgfSBjYXRjaCAobmV0d29ya0Vycm9yKSB7XHJcbiAgICBsb2cuZXJyb3IoYCR7bWV0aG9kfSAke3BhdGh9IC0+IG5ldHdvcmsgZXJyb3JgLCBuZXR3b3JrRXJyb3IpXHJcbiAgICB0aHJvdyBuZXR3b3JrRXJyb3JcclxuICB9XHJcblxyXG4gIGNvbnN0IG1zID0gTWF0aC5yb3VuZChwZXJmb3JtYW5jZS5ub3coKSAtIHN0YXJ0ZWQpXHJcblxyXG4gIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcclxuICAgIGNvbnN0IGVycm9yID0gYm9keT8uZXJyb3JcclxuICAgIGxvZy53YXJuKGAke21ldGhvZH0gJHtwYXRofSAtPiAke3Jlc3BvbnNlLnN0YXR1c30gKCR7bXN9IG1zKWAsIHsgY29kZTogZXJyb3I/LmNvZGUgfSlcclxuICAgIHRocm93IG5ldyBBcGlFcnJvcihcclxuICAgICAgcmVzcG9uc2Uuc3RhdHVzLFxyXG4gICAgICBlcnJvcj8uY29kZSA/PyAnVU5LTk9XTl9FUlJPUicsXHJcbiAgICAgIGVycm9yPy5tZXNzYWdlID8/ICdTb21ldGhpbmcgd2VudCB3cm9uZycsXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBsb2cuaW5mbyhgJHttZXRob2R9ICR7cGF0aH0gLT4gJHtyZXNwb25zZS5zdGF0dXN9ICgke21zfSBtcylgKVxyXG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGxcclxuICByZXR1cm4gcmVzcG9uc2UuanNvbigpXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhcGlDbGllbnQgPSB7XHJcbiAgZ2V0OiAocGF0aCkgPT4gcmVxdWVzdChwYXRoKSxcclxuICBwb3N0OiAocGF0aCwgZGF0YSkgPT4gcmVxdWVzdChwYXRoLCB7IG1ldGhvZDogJ1BPU1QnLCBib2R5OiBKU09OLnN0cmluZ2lmeShkYXRhKSB9KSxcclxuICBwYXRjaDogKHBhdGgsIGRhdGEpID0+IHJlcXVlc3QocGF0aCwgeyBtZXRob2Q6ICdQQVRDSCcsIGJvZHk6IEpTT04uc3RyaW5naWZ5KGRhdGEpIH0pLFxyXG4gIGRlbGV0ZTogKHBhdGgpID0+IHJlcXVlc3QocGF0aCwgeyBtZXRob2Q6ICdERUxFVEUnIH0pLFxyXG4gIC8vIEZvciBtdWx0aXBhcnQvZm9ybS1kYXRhIHVwbG9hZHMgKGUuZy4gZmVhdHVyZXMvYXNzZXRzL2Fzc2V0c0FwaS5qcykg4oCUXHJcbiAgLy8gcGFzcyBhIGBGb3JtRGF0YWAgaW5zdGFuY2UsIG5vdCBhIHBsYWluIG9iamVjdC5cclxuICBwb3N0Rm9ybTogKHBhdGgsIGZvcm1EYXRhKSA9PiByZXF1ZXN0Rm9ybShwYXRoLCBmb3JtRGF0YSksXHJcbn1cclxuIl19