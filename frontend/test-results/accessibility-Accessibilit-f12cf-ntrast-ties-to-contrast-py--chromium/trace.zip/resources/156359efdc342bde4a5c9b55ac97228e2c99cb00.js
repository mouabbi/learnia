import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/reader/ReaderShell.jsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { ChevronLeft, ChevronDown, ChevronRight, Lock, CheckCircle2, Circle, HelpCircle, GraduationCap, Sun, Moon } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { useTheme } from "/src/hooks/useTheme.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/reader/ReaderShell.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Docs-style shell for the course reader (see pages/CourseReaderPage.jsx):
// a slim topbar, a left sidebar tree (Module > Chapter > Page, plus a
// module-QCM row per module), and a content pane for whatever's active.
// Purely presentational — all state (expanded modules, active
// page/quiz, lock/completion status) is owned by the caller.
export function ReaderShell({ course, learningPct, expandedModuleIds, onToggleModule, isModuleLocked, isPageComplete, isModulePagesComplete, isModuleQuizPassed, activeKind, activePageId, activeModuleId, onSelectPage, onSelectQuiz, allModulesDone, children }) {
	_s();
	const { theme, toggleTheme } = useTheme();
	const isDark = theme === "dark" || theme === "system" && typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches;
	// Per-course accent (16-theming) as a scoped CSS custom property — the
	// reader shell can lean on --course-accent wherever it wants a
	// course-branded touch, without a full CSS rewrite. `course.color`
	// already exists on CourseSummary (== theme.accent, see
	// repositories/course_repository.py); falls back to the app's own
	// --accent (see hooks/useAccentColor.js) if a course has no theme yet.
	const courseThemeStyle = course.color ? { "--course-accent": course.color } : undefined;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "reader-shell",
		style: courseThemeStyle,
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "reader-topbar",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/courses",
					className: "reader-back-link",
					children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this), " All courses"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "reader-topbar-title",
					children: course.title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "reader-topbar-progress",
					children: [learningPct, "% complete"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				allModulesDone && course.finalExam && /* @__PURE__ */ _jsxDEV(Link, {
					to: `/courses/${course.slug}/exam`,
					className: "reader-topbar-exam-cta",
					children: [/* @__PURE__ */ _jsxDEV(GraduationCap, {
						size: 15,
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this), " Final exam"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "reader-theme-toggle",
					"aria-label": isDark ? "Switch to light mode" : "Switch to dark mode",
					onClick: toggleTheme,
					children: isDark ? /* @__PURE__ */ _jsxDEV(Sun, {
						"aria-hidden": "true",
						size: 17
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 21
					}, this) : /* @__PURE__ */ _jsxDEV(Moon, {
						"aria-hidden": "true",
						size: 17
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 60
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "reader-body",
			children: [/* @__PURE__ */ _jsxDEV("nav", {
				className: "reader-sidebar",
				"aria-label": "Course contents",
				children: course.modules.map((courseModule, moduleIndex) => {
					const locked = isModuleLocked(moduleIndex);
					const expanded = expandedModuleIds.has(courseModule.id);
					const pagesComplete = isModulePagesComplete(courseModule);
					const quizPassed = courseModule.quiz ? isModuleQuizPassed(courseModule.id) : true;
					const moduleDone = pagesComplete && quizPassed;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "reader-module",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `reader-module-header ${locked ? "reader-module-header-locked" : ""}`,
							onClick: () => !locked && onToggleModule(courseModule.id),
							disabled: locked,
							children: [
								expanded && !locked ? /* @__PURE__ */ _jsxDEV(ChevronDown, {
									size: 14,
									className: "reader-module-chevron"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV(ChevronRight, {
									size: 14,
									className: "reader-module-chevron"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "reader-module-title",
									children: courseModule.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 19
								}, this),
								locked ? /* @__PURE__ */ _jsxDEV(Lock, {
									size: 14,
									className: "reader-module-status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 21
								}, this) : moduleDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, {
									size: 14,
									className: "reader-module-status reader-module-status-done"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 21
								}, this) : null
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 17
						}, this), expanded && !locked && /* @__PURE__ */ _jsxDEV("div", {
							className: "reader-module-body",
							children: [courseModule.chapters.map((chapter) => /* @__PURE__ */ _jsxDEV("div", {
								className: "reader-chapter",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "reader-chapter-title",
									children: chapter.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("ul", {
									className: "reader-page-list",
									children: chapter.pages.map((p) => {
										const done = isPageComplete(p.id);
										const active = activeKind === "page" && activePageId === p.id;
										return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											className: `reader-page-item ${active ? "reader-page-item-active" : ""}`,
											onClick: () => onSelectPage(p.id),
											children: [done ? /* @__PURE__ */ _jsxDEV(CheckCircle2, {
												size: 14,
												className: "reader-page-icon reader-page-icon-done"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 126,
												columnNumber: 37
											}, this) : /* @__PURE__ */ _jsxDEV(Circle, {
												size: 14,
												className: "reader-page-icon"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 37
											}, this), p.title]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 120,
											columnNumber: 33
										}, this) }, p.id, false, {
											fileName: _jsxFileName,
											lineNumber: 119,
											columnNumber: 31
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 25
								}, this)]
							}, chapter.id, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 23
							}, this)), courseModule.quiz && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: `reader-quiz-item ${activeKind === "quiz" && activeModuleId === courseModule.id ? "reader-page-item-active" : ""} ${!pagesComplete ? "reader-quiz-item-locked" : ""}`,
								disabled: !pagesComplete,
								onClick: () => onSelectQuiz(courseModule.id),
								title: !pagesComplete ? "Read every page in this module first" : undefined,
								children: [!pagesComplete ? /* @__PURE__ */ _jsxDEV(Lock, {
									size: 14,
									className: "reader-page-icon"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 27
								}, this) : quizPassed ? /* @__PURE__ */ _jsxDEV(CheckCircle2, {
									size: 14,
									className: "reader-page-icon reader-page-icon-done"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 27
								}, this) : /* @__PURE__ */ _jsxDEV(HelpCircle, {
									size: 14,
									className: "reader-page-icon"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 27
								}, this), "Module QCM"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 23
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 19
						}, this)]
					}, courseModule.id, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("main", {
				className: "reader-content",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
}
_s(ReaderShell, "Q4eAjrIZ0CuRuhycs6byifK2KBk=", false, function() {
	return [useTheme];
});
_c = ReaderShell;
var _c;
$RefreshReg$(_c, "ReaderShell");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/reader/ReaderShell.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/reader/ReaderShell.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/reader/ReaderShell.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/reader/ReaderShell.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBQ3JCLFNBQ0UsYUFDQSxhQUNBLGNBQ0EsTUFDQSxjQUNBLFFBQ0EsWUFDQSxlQUNBLEtBQ0EsWUFDSztBQUNQLFNBQVMsZ0JBQWdCOzs7Ozs7Ozs7QUFPekIsT0FBTyxTQUFTLFlBQVksRUFDMUIsUUFDQSxhQUNBLG1CQUNBLGdCQUNBLGdCQUNBLGdCQUNBLHVCQUNBLG9CQUNBLFlBQ0EsY0FDQSxnQkFDQSxjQUNBLGNBQ0EsZ0JBQ0EsWUFDQzs7Q0FDRCxNQUFNLEVBQUUsT0FBTyxnQkFBZ0IsU0FBUztDQUN4QyxNQUFNLFNBQ0osVUFBVSxVQUNULFVBQVUsWUFDVCxPQUFPLFdBQVcsZUFDbEIsT0FBTyxhQUFhLDhCQUE4QixDQUFDLENBQUM7Ozs7Ozs7Q0FReEQsTUFBTSxtQkFBbUIsT0FBTyxRQUFRLEVBQUUsbUJBQW1CLE9BQU8sTUFBTSxJQUFJO0NBRTlFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7RUFBZSxPQUFPO1lBQXJDLENBQ0Usd0JBQUMsVUFBRDtHQUFRLFdBQVU7YUFBbEI7SUFDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFXLFdBQVU7ZUFBOUIsQ0FDRSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2VBQUMsY0FDckI7Ozs7OztJQUNOLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXVCLE9BQU87SUFBWTs7Ozs7SUFDMUQsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBMEMsYUFBWSxZQUFnQjs7Ozs7O0lBQ3JFLGtCQUFrQixPQUFPLGFBQ3hCLHdCQUFDLE1BQUQ7S0FDRSxJQUFJLFlBQVksT0FBTyxLQUFLO0tBQzVCLFdBQVU7ZUFGWixDQUlFLHdCQUFDLGVBQUQ7TUFBZSxNQUFNO01BQUksZUFBWTtLQUFROzs7O2VBQUMsYUFDMUM7Ozs7OztJQUVSLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtLQUNWLGNBQVksU0FBUyx5QkFBeUI7S0FDOUMsU0FBUztlQUVSLFNBQVMsd0JBQUMsS0FBRDtNQUFLLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7Z0JBQUksd0JBQUMsTUFBRDtNQUFNLGVBQVk7TUFBTyxNQUFNO0tBQUs7Ozs7O0lBQy9FOzs7OztHQUNGOzs7OztZQUVSLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFpQixjQUFXO2NBQ3hDLE9BQU8sUUFBUSxLQUFLLGNBQWMsZ0JBQWdCO0tBQ2pELE1BQU0sU0FBUyxlQUFlLFdBQVc7S0FDekMsTUFBTSxXQUFXLGtCQUFrQixJQUFJLGFBQWEsRUFBRTtLQUN0RCxNQUFNLGdCQUFnQixzQkFBc0IsWUFBWTtLQUN4RCxNQUFNLGFBQWEsYUFBYSxPQUFPLG1CQUFtQixhQUFhLEVBQUUsSUFBSTtLQUM3RSxNQUFNLGFBQWEsaUJBQWlCO0tBRXBDLE9BQ0Usd0JBQUMsT0FBRDtNQUEyQixXQUFVO2dCQUFyQyxDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVyx3QkFBd0IsU0FBUyxnQ0FBZ0M7T0FDNUUsZUFBZSxDQUFDLFVBQVUsZUFBZSxhQUFhLEVBQUU7T0FDeEQsVUFBVTtpQkFKWjtRQU1HLFlBQVksQ0FBQyxTQUNaLHdCQUFDLGFBQUQ7U0FBYSxNQUFNO1NBQUksV0FBVTtRQUF5Qjs7OzttQkFFMUQsd0JBQUMsY0FBRDtTQUFjLE1BQU07U0FBSSxXQUFVO1FBQXlCOzs7OztRQUU3RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBdUIsYUFBYTtRQUFZOzs7OztRQUMvRCxTQUNDLHdCQUFDLE1BQUQ7U0FBTSxNQUFNO1NBQUksV0FBVTtRQUF3Qjs7OzttQkFDaEQsYUFDRix3QkFBQyxjQUFEO1NBQWMsTUFBTTtTQUFJLFdBQVU7UUFBa0Q7Ozs7bUJBQ2xGO09BQ0U7Ozs7O2dCQUVQLFlBQVksQ0FBQyxVQUNaLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0csYUFBYSxTQUFTLEtBQUssWUFDMUIsd0JBQUMsT0FBRDtRQUFzQixXQUFVO2tCQUFoQyxDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF3QixRQUFRO1FBQVk7Ozs7a0JBQzVELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLFFBQVEsTUFBTSxLQUFLLE1BQU07VUFDeEIsTUFBTSxPQUFPLGVBQWUsRUFBRSxFQUFFO1VBQ2hDLE1BQU0sU0FBUyxlQUFlLFVBQVUsaUJBQWlCLEVBQUU7VUFDM0QsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxXQUFXLG9CQUFvQixTQUFTLDRCQUE0QjtXQUNwRSxlQUFlLGFBQWEsRUFBRSxFQUFFO3FCQUhsQyxDQUtHLE9BQ0Msd0JBQUMsY0FBRDtZQUFjLE1BQU07WUFBSSxXQUFVO1dBQTBDOzs7O3NCQUU1RSx3QkFBQyxRQUFEO1lBQVEsTUFBTTtZQUFJLFdBQVU7V0FBb0I7Ozs7cUJBRWpELEVBQUUsS0FDRzs7Ozs7bUJBQ04sR0FiSyxFQUFFOzs7O2lCQWFQO1NBRVIsQ0FBQztRQUNDOzs7O2dCQUNEO1VBeEJLLFFBQVE7Ozs7Y0F3QmIsQ0FDTixHQUVBLGFBQWEsUUFDWix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVcsb0JBQ1QsZUFBZSxVQUFVLG1CQUFtQixhQUFhLEtBQ3JELDRCQUNBLEdBQ0wsR0FBRyxDQUFDLGdCQUFnQiw0QkFBNEI7UUFDakQsVUFBVSxDQUFDO1FBQ1gsZUFBZSxhQUFhLGFBQWEsRUFBRTtRQUMzQyxPQUFPLENBQUMsZ0JBQWdCLHlDQUF5QztrQkFUbkUsQ0FXRyxDQUFDLGdCQUNBLHdCQUFDLE1BQUQ7U0FBTSxNQUFNO1NBQUksV0FBVTtRQUFvQjs7OzttQkFDNUMsYUFDRix3QkFBQyxjQUFEO1NBQWMsTUFBTTtTQUFJLFdBQVU7UUFBMEM7Ozs7bUJBRTVFLHdCQUFDLFlBQUQ7U0FBWSxNQUFNO1NBQUksV0FBVTtRQUFvQjs7OztrQkFDcEQsWUFFSTs7Ozs7ZUFFUDs7Ozs7Y0FFSjtRQTFFSyxhQUFhOzs7O1lBMEVsQjtJQUVULENBQUM7R0FDRTs7OzthQUVMLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO0lBQWtCO0dBQWU7Ozs7V0FDOUM7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlYWRlclNoZWxsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSdcclxuaW1wb3J0IHtcclxuICBDaGV2cm9uTGVmdCxcclxuICBDaGV2cm9uRG93bixcclxuICBDaGV2cm9uUmlnaHQsXHJcbiAgTG9jayxcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgQ2lyY2xlLFxyXG4gIEhlbHBDaXJjbGUsXHJcbiAgR3JhZHVhdGlvbkNhcCxcclxuICBTdW4sXHJcbiAgTW9vbixcclxufSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi4vLi4vaG9va3MvdXNlVGhlbWUnXHJcblxyXG4vLyBEb2NzLXN0eWxlIHNoZWxsIGZvciB0aGUgY291cnNlIHJlYWRlciAoc2VlIHBhZ2VzL0NvdXJzZVJlYWRlclBhZ2UuanN4KTpcclxuLy8gYSBzbGltIHRvcGJhciwgYSBsZWZ0IHNpZGViYXIgdHJlZSAoTW9kdWxlID4gQ2hhcHRlciA+IFBhZ2UsIHBsdXMgYVxyXG4vLyBtb2R1bGUtUUNNIHJvdyBwZXIgbW9kdWxlKSwgYW5kIGEgY29udGVudCBwYW5lIGZvciB3aGF0ZXZlcidzIGFjdGl2ZS5cclxuLy8gUHVyZWx5IHByZXNlbnRhdGlvbmFsIOKAlCBhbGwgc3RhdGUgKGV4cGFuZGVkIG1vZHVsZXMsIGFjdGl2ZVxyXG4vLyBwYWdlL3F1aXosIGxvY2svY29tcGxldGlvbiBzdGF0dXMpIGlzIG93bmVkIGJ5IHRoZSBjYWxsZXIuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZWFkZXJTaGVsbCh7XHJcbiAgY291cnNlLFxyXG4gIGxlYXJuaW5nUGN0LFxyXG4gIGV4cGFuZGVkTW9kdWxlSWRzLFxyXG4gIG9uVG9nZ2xlTW9kdWxlLFxyXG4gIGlzTW9kdWxlTG9ja2VkLFxyXG4gIGlzUGFnZUNvbXBsZXRlLFxyXG4gIGlzTW9kdWxlUGFnZXNDb21wbGV0ZSxcclxuICBpc01vZHVsZVF1aXpQYXNzZWQsXHJcbiAgYWN0aXZlS2luZCwgLy8gJ3BhZ2UnIHwgJ3F1aXonXHJcbiAgYWN0aXZlUGFnZUlkLFxyXG4gIGFjdGl2ZU1vZHVsZUlkLFxyXG4gIG9uU2VsZWN0UGFnZSxcclxuICBvblNlbGVjdFF1aXosXHJcbiAgYWxsTW9kdWxlc0RvbmUsXHJcbiAgY2hpbGRyZW4sXHJcbn0pIHtcclxuICBjb25zdCB7IHRoZW1lLCB0b2dnbGVUaGVtZSB9ID0gdXNlVGhlbWUoKVxyXG4gIGNvbnN0IGlzRGFyayA9XHJcbiAgICB0aGVtZSA9PT0gJ2RhcmsnIHx8XHJcbiAgICAodGhlbWUgPT09ICdzeXN0ZW0nICYmXHJcbiAgICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgIHdpbmRvdy5tYXRjaE1lZGlhPy4oJyhwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyayknKS5tYXRjaGVzKVxyXG5cclxuICAvLyBQZXItY291cnNlIGFjY2VudCAoMTYtdGhlbWluZykgYXMgYSBzY29wZWQgQ1NTIGN1c3RvbSBwcm9wZXJ0eSDigJQgdGhlXHJcbiAgLy8gcmVhZGVyIHNoZWxsIGNhbiBsZWFuIG9uIC0tY291cnNlLWFjY2VudCB3aGVyZXZlciBpdCB3YW50cyBhXHJcbiAgLy8gY291cnNlLWJyYW5kZWQgdG91Y2gsIHdpdGhvdXQgYSBmdWxsIENTUyByZXdyaXRlLiBgY291cnNlLmNvbG9yYFxyXG4gIC8vIGFscmVhZHkgZXhpc3RzIG9uIENvdXJzZVN1bW1hcnkgKD09IHRoZW1lLmFjY2VudCwgc2VlXHJcbiAgLy8gcmVwb3NpdG9yaWVzL2NvdXJzZV9yZXBvc2l0b3J5LnB5KTsgZmFsbHMgYmFjayB0byB0aGUgYXBwJ3Mgb3duXHJcbiAgLy8gLS1hY2NlbnQgKHNlZSBob29rcy91c2VBY2NlbnRDb2xvci5qcykgaWYgYSBjb3Vyc2UgaGFzIG5vIHRoZW1lIHlldC5cclxuICBjb25zdCBjb3Vyc2VUaGVtZVN0eWxlID0gY291cnNlLmNvbG9yID8geyAnLS1jb3Vyc2UtYWNjZW50JzogY291cnNlLmNvbG9yIH0gOiB1bmRlZmluZWRcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVhZGVyLXNoZWxsXCIgc3R5bGU9e2NvdXJzZVRoZW1lU3R5bGV9PlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInJlYWRlci10b3BiYXJcIj5cclxuICAgICAgICA8TGluayB0bz1cIi9jb3Vyc2VzXCIgY2xhc3NOYW1lPVwicmVhZGVyLWJhY2stbGlua1wiPlxyXG4gICAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE2fSAvPiBBbGwgY291cnNlc1xyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWFkZXItdG9wYmFyLXRpdGxlXCI+e2NvdXJzZS50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVhZGVyLXRvcGJhci1wcm9ncmVzc1wiPntsZWFybmluZ1BjdH0lIGNvbXBsZXRlPC9zcGFuPlxyXG4gICAgICAgIHthbGxNb2R1bGVzRG9uZSAmJiBjb3Vyc2UuZmluYWxFeGFtICYmIChcclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtgL2NvdXJzZXMvJHtjb3Vyc2Uuc2x1Z30vZXhhbWB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlYWRlci10b3BiYXItZXhhbS1jdGFcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R3JhZHVhdGlvbkNhcCBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4gRmluYWwgZXhhbVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICl9XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWFkZXItdGhlbWUtdG9nZ2xlXCJcclxuICAgICAgICAgIGFyaWEtbGFiZWw9e2lzRGFyayA/ICdTd2l0Y2ggdG8gbGlnaHQgbW9kZScgOiAnU3dpdGNoIHRvIGRhcmsgbW9kZSd9XHJcbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVUaGVtZX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7aXNEYXJrID8gPFN1biBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxN30gLz4gOiA8TW9vbiBhcmlhLWhpZGRlbj1cInRydWVcIiBzaXplPXsxN30gLz59XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItYm9keVwiPlxyXG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwicmVhZGVyLXNpZGViYXJcIiBhcmlhLWxhYmVsPVwiQ291cnNlIGNvbnRlbnRzXCI+XHJcbiAgICAgICAgICB7Y291cnNlLm1vZHVsZXMubWFwKChjb3Vyc2VNb2R1bGUsIG1vZHVsZUluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGxvY2tlZCA9IGlzTW9kdWxlTG9ja2VkKG1vZHVsZUluZGV4KVxyXG4gICAgICAgICAgICBjb25zdCBleHBhbmRlZCA9IGV4cGFuZGVkTW9kdWxlSWRzLmhhcyhjb3Vyc2VNb2R1bGUuaWQpXHJcbiAgICAgICAgICAgIGNvbnN0IHBhZ2VzQ29tcGxldGUgPSBpc01vZHVsZVBhZ2VzQ29tcGxldGUoY291cnNlTW9kdWxlKVxyXG4gICAgICAgICAgICBjb25zdCBxdWl6UGFzc2VkID0gY291cnNlTW9kdWxlLnF1aXogPyBpc01vZHVsZVF1aXpQYXNzZWQoY291cnNlTW9kdWxlLmlkKSA6IHRydWVcclxuICAgICAgICAgICAgY29uc3QgbW9kdWxlRG9uZSA9IHBhZ2VzQ29tcGxldGUgJiYgcXVpelBhc3NlZFxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8ZGl2IGtleT17Y291cnNlTW9kdWxlLmlkfSBjbGFzc05hbWU9XCJyZWFkZXItbW9kdWxlXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWFkZXItbW9kdWxlLWhlYWRlciAke2xvY2tlZCA/ICdyZWFkZXItbW9kdWxlLWhlYWRlci1sb2NrZWQnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gIWxvY2tlZCAmJiBvblRvZ2dsZU1vZHVsZShjb3Vyc2VNb2R1bGUuaWQpfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9ja2VkfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZXhwYW5kZWQgJiYgIWxvY2tlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gc2l6ZT17MTR9IGNsYXNzTmFtZT1cInJlYWRlci1tb2R1bGUtY2hldnJvblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNH0gY2xhc3NOYW1lPVwicmVhZGVyLW1vZHVsZS1jaGV2cm9uXCIgLz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVhZGVyLW1vZHVsZS10aXRsZVwiPntjb3Vyc2VNb2R1bGUudGl0bGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7bG9ja2VkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxMb2NrIHNpemU9ezE0fSBjbGFzc05hbWU9XCJyZWFkZXItbW9kdWxlLXN0YXR1c1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiBtb2R1bGVEb25lID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInJlYWRlci1tb2R1bGUtc3RhdHVzIHJlYWRlci1tb2R1bGUtc3RhdHVzLWRvbmVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgIHtleHBhbmRlZCAmJiAhbG9ja2VkICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWFkZXItbW9kdWxlLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y291cnNlTW9kdWxlLmNoYXB0ZXJzLm1hcCgoY2hhcHRlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NoYXB0ZXIuaWR9IGNsYXNzTmFtZT1cInJlYWRlci1jaGFwdGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlYWRlci1jaGFwdGVyLXRpdGxlXCI+e2NoYXB0ZXIudGl0bGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGFwdGVyLnBhZ2VzLm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZG9uZSA9IGlzUGFnZUNvbXBsZXRlKHAuaWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhY3RpdmUgPSBhY3RpdmVLaW5kID09PSAncGFnZScgJiYgYWN0aXZlUGFnZUlkID09PSBwLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtwLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlYWRlci1wYWdlLWl0ZW0gJHthY3RpdmUgPyAncmVhZGVyLXBhZ2UtaXRlbS1hY3RpdmUnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0UGFnZShwLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9uZSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtaWNvbiByZWFkZXItcGFnZS1pY29uLWRvbmVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmNsZSBzaXplPXsxNH0gY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtaWNvblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3AudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2NvdXJzZU1vZHVsZS5xdWl6ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlYWRlci1xdWl6LWl0ZW0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVLaW5kID09PSAncXVpeicgJiYgYWN0aXZlTW9kdWxlSWQgPT09IGNvdXJzZU1vZHVsZS5pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAncmVhZGVyLXBhZ2UtaXRlbS1hY3RpdmUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gJHshcGFnZXNDb21wbGV0ZSA/ICdyZWFkZXItcXVpei1pdGVtLWxvY2tlZCcgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXBhZ2VzQ29tcGxldGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0UXVpeihjb3Vyc2VNb2R1bGUuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17IXBhZ2VzQ29tcGxldGUgPyAnUmVhZCBldmVyeSBwYWdlIGluIHRoaXMgbW9kdWxlIGZpcnN0JyA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyFwYWdlc0NvbXBsZXRlID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2NrIHNpemU9ezE0fSBjbGFzc05hbWU9XCJyZWFkZXItcGFnZS1pY29uXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IHF1aXpQYXNzZWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxNH0gY2xhc3NOYW1lPVwicmVhZGVyLXBhZ2UtaWNvbiByZWFkZXItcGFnZS1pY29uLWRvbmVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIHNpemU9ezE0fSBjbGFzc05hbWU9XCJyZWFkZXItcGFnZS1pY29uXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgTW9kdWxlIFFDTVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVhZGVyLWNvbnRlbnRcIj57Y2hpbGRyZW59PC9tYWluPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG4iXX0=