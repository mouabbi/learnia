import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/ChangePasswordForm.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { authApi } from "/src/features/auth/authApi.js";
import { ApiError } from "/src/api/client.js";
import { ButtonSpinner } from "/src/components/ButtonSpinner.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ChangePasswordForm.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Used on HomePage. Changing the password logs out every OTHER session
// (see backend account_service.change_password) — this tab stays logged in.
export function ChangePasswordForm() {
	_s();
	const [currentPassword, setCurrentPassword] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [message, setMessage] = useState(null);
	const [error, setError] = useState(null);
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError(null);
		setMessage(null);
		setIsSubmitting(true);
		try {
			await authApi.changePassword(currentPassword, newPassword);
			setMessage("Password changed. Other logged-in devices were signed out.");
			setCurrentPassword("");
			setNewPassword("");
		} catch (err) {
			setError(err instanceof ApiError ? err.message : "Something went wrong");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: "Change password" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "current-password",
				children: "Current password"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				id: "current-password",
				type: "password",
				value: currentPassword,
				onChange: (e) => setCurrentPassword(e.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "new-password",
				children: "New password"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("input", {
				id: "new-password",
				type: "password",
				minLength: 8,
				value: newPassword,
				onChange: (e) => setNewPassword(e.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 19
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting,
				children: [isSubmitting && /* @__PURE__ */ _jsxDEV(ButtonSpinner, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 26
				}, this), isSubmitting ? "Changing..." : "Change password"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 5
	}, this);
}
_s(ChangePasswordForm, "ZwQvinQvaYV3iiF4idQhYeeHQhQ=");
_c = ChangePasswordForm;
var _c;
$RefreshReg$(_c, "ChangePasswordForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/ChangePasswordForm.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ChangePasswordForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ChangePasswordForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/ChangePasswordForm.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMscUJBQXFCOzs7Ozs7QUFJOUIsT0FBTyxTQUFTLHFCQUFxQjs7Q0FDbkMsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFO0NBQ3pELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FDdkMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxlQUFlLGFBQWEsT0FBTztFQUNqQyxNQUFNLGVBQWU7RUFDckIsU0FBUyxJQUFJO0VBQ2IsV0FBVyxJQUFJO0VBQ2YsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sUUFBUSxlQUFlLGlCQUFpQixXQUFXO0dBQ3pELFdBQVcsNERBQTREO0dBQ3ZFLG1CQUFtQixFQUFFO0dBQ3JCLGVBQWUsRUFBRTtFQUNuQixTQUFTLEtBQUs7R0FDWixTQUFTLGVBQWUsV0FBVyxJQUFJLFVBQVUsc0JBQXNCO0VBQ3pFLFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sVUFBVTtZQUFoQjtHQUNFLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7O0dBQ3ZCLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFtQjtHQUF1Qjs7OzthQUN6RCx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxPQUFPO0lBQ1AsV0FBVyxNQUFNLG1CQUFtQixFQUFFLE9BQU8sS0FBSztJQUNsRDtHQUNEOzs7O1dBQ0U7Ozs7O0dBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQWU7R0FBbUI7Ozs7YUFDakQsd0JBQUMsU0FBRDtJQUNFLElBQUc7SUFDSCxNQUFLO0lBQ0wsV0FBVztJQUNYLE9BQU87SUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztJQUM5QztHQUNEOzs7O1dBQ0U7Ozs7O0dBQ0osV0FBVyx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFVO0dBQVc7Ozs7O0dBQ3hDLFNBQ0Msd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUSxXQUFVO2NBQ3ZCO0dBQ0E7Ozs7O0dBRUwsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVO2NBQWhDLENBQ0csZ0JBQWdCLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7Y0FDaEMsZUFBZSxnQkFBZ0IsaUJBQzFCOzs7Ozs7RUFDSjs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hhbmdlUGFzc3dvcmRGb3JtLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSAnLi9hdXRoQXBpJ1xyXG5pbXBvcnQgeyBBcGlFcnJvciB9IGZyb20gJy4uLy4uL2FwaS9jbGllbnQnXHJcbmltcG9ydCB7IEJ1dHRvblNwaW5uZXIgfSBmcm9tICcuLi8uLi9jb21wb25lbnRzL0J1dHRvblNwaW5uZXInXHJcblxyXG4vLyBVc2VkIG9uIEhvbWVQYWdlLiBDaGFuZ2luZyB0aGUgcGFzc3dvcmQgbG9ncyBvdXQgZXZlcnkgT1RIRVIgc2Vzc2lvblxyXG4vLyAoc2VlIGJhY2tlbmQgYWNjb3VudF9zZXJ2aWNlLmNoYW5nZV9wYXNzd29yZCkg4oCUIHRoaXMgdGFiIHN0YXlzIGxvZ2dlZCBpbi5cclxuZXhwb3J0IGZ1bmN0aW9uIENoYW5nZVBhc3N3b3JkRm9ybSgpIHtcclxuICBjb25zdCBbY3VycmVudFBhc3N3b3JkLCBzZXRDdXJyZW50UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW25ld1Bhc3N3b3JkLCBzZXROZXdQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudCkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3IobnVsbClcclxuICAgIHNldE1lc3NhZ2UobnVsbClcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKVxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXV0aEFwaS5jaGFuZ2VQYXNzd29yZChjdXJyZW50UGFzc3dvcmQsIG5ld1Bhc3N3b3JkKVxyXG4gICAgICBzZXRNZXNzYWdlKCdQYXNzd29yZCBjaGFuZ2VkLiBPdGhlciBsb2dnZWQtaW4gZGV2aWNlcyB3ZXJlIHNpZ25lZCBvdXQuJylcclxuICAgICAgc2V0Q3VycmVudFBhc3N3b3JkKCcnKVxyXG4gICAgICBzZXROZXdQYXNzd29yZCgnJylcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBBcGlFcnJvciA/IGVyci5tZXNzYWdlIDogJ1NvbWV0aGluZyB3ZW50IHdyb25nJylcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgPGgyPkNoYW5nZSBwYXNzd29yZDwvaDI+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjdXJyZW50LXBhc3N3b3JkXCI+Q3VycmVudCBwYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD1cImN1cnJlbnQtcGFzc3dvcmRcIlxyXG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgIHZhbHVlPXtjdXJyZW50UGFzc3dvcmR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1cnJlbnRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmV3LXBhc3N3b3JkXCI+TmV3IHBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwibmV3LXBhc3N3b3JkXCJcclxuICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICBtaW5MZW5ndGg9ezh9XHJcbiAgICAgICAgICB2YWx1ZT17bmV3UGFzc3dvcmR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHttZXNzYWdlICYmIDxwIHJvbGU9XCJzdGF0dXNcIj57bWVzc2FnZX08L3A+fVxyXG4gICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImVycm9yXCI+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfT5cclxuICAgICAgICB7aXNTdWJtaXR0aW5nICYmIDxCdXR0b25TcGlubmVyIC8+fVxyXG4gICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAnQ2hhbmdpbmcuLi4nIDogJ0NoYW5nZSBwYXNzd29yZCd9XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9mb3JtPlxyXG4gIClcclxufVxyXG4iXX0=