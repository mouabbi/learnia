import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/BlockEditors.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockEditors.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Per-block-type editor forms — registry-pattern mirroring the backend's
// discriminated union (schemas/content.py) and BlockRenderer.jsx's registry.
// Each editor is a small controlled form: `block` (current value),
// `onChange(nextBlock)`. Kept intentionally plain (native inputs) to match
// index.css's existing form styling rather than inventing new components.
function Field({ label, children }) {
	return /* @__PURE__ */ _jsxDEV("label", {
		className: "cms-field",
		children: [/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = Field;
function set(block, patch) {
	return {
		...block,
		...patch
	};
}
export const BLOCK_TYPES = [
	"heading",
	"paragraph",
	"code",
	"terminal",
	"image",
	"video",
	"youtube",
	"link",
	"quote",
	"callout",
	"list",
	"table"
];
export function defaultBlockFor(type) {
	switch (type) {
		case "heading": return {
			type,
			text: "",
			level: 2,
			numbered: false
		};
		case "paragraph": return {
			type,
			text: ""
		};
		case "code": return {
			type,
			code: "",
			language: ""
		};
		case "terminal": return {
			type,
			text: ""
		};
		case "image":
 // TODO: swap in AssetPicker once frontend/src/features/assets/AssetPicker.jsx lands
		return {
			type,
			src: "",
			alt: "",
			caption: ""
		};
		case "video":
 // TODO: swap in AssetPicker once frontend/src/features/assets/AssetPicker.jsx lands
		return {
			type,
			src: "",
			caption: ""
		};
		case "youtube": return {
			type,
			videoId: "",
			caption: ""
		};
		case "link": return {
			type,
			href: "",
			text: ""
		};
		case "quote": return {
			type,
			text: "",
			attribution: ""
		};
		case "callout": return {
			type,
			variant: "note",
			text: ""
		};
		case "list": return {
			type,
			ordered: false,
			items: [""]
		};
		case "table": return {
			type,
			headers: ["", ""],
			rows: [["", ""]]
		};
		default: return {
			type: "paragraph",
			text: ""
		};
	}
}
function HeadingEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(Field, {
			label: "Text",
			children: /* @__PURE__ */ _jsxDEV("input", {
				value: block.text,
				onChange: (e) => onChange(set(block, { text: e.target.value }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Field, {
			label: "Level",
			children: /* @__PURE__ */ _jsxDEV("select", {
				value: block.level,
				onChange: (e) => onChange(set(block, { level: Number(e.target.value) })),
				children: [
					1,
					2,
					3,
					4
				].map((l) => /* @__PURE__ */ _jsxDEV("option", {
					value: l,
					children: ["H", l]
				}, l, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("label", {
			className: "cms-checkbox",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				type: "checkbox",
				checked: !!block.numbered,
				onChange: (e) => onChange(set(block, { numbered: e.target.checked }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 9
			}, this), "Numbered"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 70,
		columnNumber: 5
	}, this);
}
_c2 = HeadingEditor;
function ParagraphEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(Field, {
		label: "Text",
		children: /* @__PURE__ */ _jsxDEV("textarea", {
			rows: 3,
			value: block.text,
			onChange: (e) => onChange(set(block, { text: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 100,
		columnNumber: 5
	}, this);
}
_c3 = ParagraphEditor;
function CodeEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "Language",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.language || "",
			onChange: (e) => onChange(set(block, { language: e.target.value })),
			placeholder: "e.g. python"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 113,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Code",
		children: /* @__PURE__ */ _jsxDEV("textarea", {
			rows: 6,
			className: "cms-mono",
			value: block.code,
			onChange: (e) => onChange(set(block, { code: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 120,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 112,
		columnNumber: 5
	}, this);
}
_c4 = CodeEditor;
function TerminalEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(Field, {
		label: "Terminal output",
		children: /* @__PURE__ */ _jsxDEV("textarea", {
			rows: 4,
			className: "cms-mono",
			value: block.text,
			onChange: (e) => onChange(set(block, { text: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 134,
		columnNumber: 5
	}, this);
}
_c5 = TerminalEditor;
function ImageEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV(Field, {
			label: "Image URL / asset id",
			children: /* @__PURE__ */ _jsxDEV("input", {
				value: block.src,
				onChange: (e) => onChange(set(block, { src: e.target.value }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 149,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Field, {
			label: "Alt text",
			children: /* @__PURE__ */ _jsxDEV("input", {
				value: block.alt || "",
				onChange: (e) => onChange(set(block, { alt: e.target.value }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 153,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 152,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Field, {
			label: "Caption",
			children: /* @__PURE__ */ _jsxDEV("input", {
				value: block.caption || "",
				onChange: (e) => onChange(set(block, { caption: e.target.value }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 147,
		columnNumber: 5
	}, this);
}
_c6 = ImageEditor;
function VideoEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "Video URL / asset id",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.src,
			onChange: (e) => onChange(set(block, { src: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 169,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Caption",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.caption || "",
			onChange: (e) => onChange(set(block, { caption: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 173,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 172,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 167,
		columnNumber: 5
	}, this);
}
_c7 = VideoEditor;
function YoutubeEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "YouTube video id",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.videoId || "",
			onChange: (e) => onChange(set(block, { videoId: e.target.value })),
			placeholder: "e.g. dQw4w9WgXcQ"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 185,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Caption",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.caption || "",
			onChange: (e) => onChange(set(block, { caption: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 192,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 184,
		columnNumber: 5
	}, this);
}
_c8 = YoutubeEditor;
function LinkEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "URL",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.href,
			onChange: (e) => onChange(set(block, { href: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 206,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 205,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Link text",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.text,
			onChange: (e) => onChange(set(block, { text: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 208,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 204,
		columnNumber: 5
	}, this);
}
_c9 = LinkEditor;
function QuoteEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "Quote",
		children: /* @__PURE__ */ _jsxDEV("textarea", {
			rows: 3,
			value: block.text,
			onChange: (e) => onChange(set(block, { text: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 218,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Attribution",
		children: /* @__PURE__ */ _jsxDEV("input", {
			value: block.attribution || "",
			onChange: (e) => onChange(set(block, { attribution: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 226,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 225,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 217,
		columnNumber: 5
	}, this);
}
_c10 = QuoteEditor;
function CalloutEditor({ block, onChange }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Field, {
		label: "Variant",
		children: /* @__PURE__ */ _jsxDEV("select", {
			value: block.variant,
			onChange: (e) => onChange(set(block, { variant: e.target.value })),
			children: [
				"tip",
				"warning",
				"important",
				"note"
			].map((v) => /* @__PURE__ */ _jsxDEV("option", {
				value: v,
				children: v
			}, v, false, {
				fileName: _jsxFileName,
				lineNumber: 244,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 239,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 238,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(Field, {
		label: "Text",
		children: /* @__PURE__ */ _jsxDEV("textarea", {
			rows: 3,
			value: block.text,
			onChange: (e) => onChange(set(block, { text: e.target.value }))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 251,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 250,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 237,
		columnNumber: 5
	}, this);
}
_c11 = CalloutEditor;
function ListEditor({ block, onChange }) {
	const items = block.items || [];
	const updateItem = (i, value) => {
		const next = [...items];
		next[i] = value;
		onChange(set(block, { items: next }));
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("label", {
			className: "cms-checkbox",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				type: "checkbox",
				checked: !!block.ordered,
				onChange: (e) => onChange(set(block, { ordered: e.target.checked }))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 9
			}, this), "Ordered"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 270,
			columnNumber: 7
		}, this),
		items.map((item, i) => /* @__PURE__ */ _jsxDEV("div", {
			className: "cms-row",
			children: [/* @__PURE__ */ _jsxDEV("input", {
				value: item,
				onChange: (e) => updateItem(i, e.target.value)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "cms-btn-icon",
				onClick: () => onChange(set(block, { items: items.filter((_, idx) => idx !== i) })),
				children: "Remove"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 281,
				columnNumber: 11
			}, this)]
		}, i, true, {
			fileName: _jsxFileName,
			lineNumber: 279,
			columnNumber: 9
		}, this)),
		/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "cms-btn-secondary",
			onClick: () => onChange(set(block, { items: [...items, ""] })),
			children: "+ Add item"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 290,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 269,
		columnNumber: 5
	}, this);
}
_c12 = ListEditor;
function TableEditor({ block, onChange }) {
	const headers = block.headers || [];
	const rows = block.rows || [];
	const updateHeader = (i, value) => {
		const next = [...headers];
		next[i] = value;
		onChange(set(block, { headers: next }));
	};
	const updateCell = (ri, ci, value) => {
		const next = rows.map((row) => [...row]);
		next[ri][ci] = value;
		onChange(set(block, { rows: next }));
	};
	const addColumn = () => {
		onChange(set(block, {
			headers: [...headers, ""],
			rows: rows.map((row) => [...row, ""])
		}));
	};
	const addRow = () => {
		onChange(set(block, { rows: [...rows, headers.map(() => "")] }));
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "cms-row",
			children: [headers.map((h, i) => /* @__PURE__ */ _jsxDEV("input", {
				value: h,
				onChange: (e) => updateHeader(i, e.target.value),
				placeholder: `Header ${i + 1}`
			}, i, false, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 11
			}, this)), /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "cms-btn-icon",
				onClick: addColumn,
				children: "+ Col"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 331,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 327,
			columnNumber: 7
		}, this),
		rows.map((row, ri) => /* @__PURE__ */ _jsxDEV("div", {
			className: "cms-row",
			children: row.map((cell, ci) => /* @__PURE__ */ _jsxDEV("input", {
				value: cell,
				onChange: (e) => updateCell(ri, ci, e.target.value)
			}, ci, false, {
				fileName: _jsxFileName,
				lineNumber: 338,
				columnNumber: 13
			}, this))
		}, ri, false, {
			fileName: _jsxFileName,
			lineNumber: 336,
			columnNumber: 9
		}, this)),
		/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "cms-btn-secondary",
			onClick: addRow,
			children: "+ Add row"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 342,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 326,
		columnNumber: 5
	}, this);
}
_c13 = TableEditor;
export const BLOCK_EDITORS = {
	heading: HeadingEditor,
	paragraph: ParagraphEditor,
	code: CodeEditor,
	terminal: TerminalEditor,
	image: ImageEditor,
	video: VideoEditor,
	youtube: YoutubeEditor,
	link: LinkEditor,
	quote: QuoteEditor,
	callout: CalloutEditor,
	list: ListEditor,
	table: TableEditor
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13;
$RefreshReg$(_c, "Field");
$RefreshReg$(_c2, "HeadingEditor");
$RefreshReg$(_c3, "ParagraphEditor");
$RefreshReg$(_c4, "CodeEditor");
$RefreshReg$(_c5, "TerminalEditor");
$RefreshReg$(_c6, "ImageEditor");
$RefreshReg$(_c7, "VideoEditor");
$RefreshReg$(_c8, "YoutubeEditor");
$RefreshReg$(_c9, "LinkEditor");
$RefreshReg$(_c10, "QuoteEditor");
$RefreshReg$(_c11, "CalloutEditor");
$RefreshReg$(_c12, "ListEditor");
$RefreshReg$(_c13, "TableEditor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/BlockEditors.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockEditors.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockEditors.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/BlockEditors.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7OztBQU1BLFNBQVMsTUFBTSxFQUFFLE9BQU8sWUFBWTtDQUNsQyxPQUNFLHdCQUFDLFNBQUQ7RUFBTyxXQUFVO1lBQWpCLENBQ0Usd0JBQUMsUUFBRCxZQUFPLE1BQVk7Ozs7WUFDbEIsUUFDSTs7Ozs7O0FBRVg7O0FBRUEsU0FBUyxJQUFJLE9BQU8sT0FBTztDQUN6QixPQUFPO0VBQUUsR0FBRztFQUFPLEdBQUc7Q0FBTTtBQUM5QjtBQUVBLE9BQU8sTUFBTSxjQUFjO0NBQ3pCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsT0FBTyxTQUFTLGdCQUFnQixNQUFNO0NBQ3BDLFFBQVEsTUFBUjtFQUNFLEtBQUssV0FDSCxPQUFPO0dBQUU7R0FBTSxNQUFNO0dBQUksT0FBTztHQUFHLFVBQVU7RUFBTTtFQUNyRCxLQUFLLGFBQ0gsT0FBTztHQUFFO0dBQU0sTUFBTTtFQUFHO0VBQzFCLEtBQUssUUFDSCxPQUFPO0dBQUU7R0FBTSxNQUFNO0dBQUksVUFBVTtFQUFHO0VBQ3hDLEtBQUssWUFDSCxPQUFPO0dBQUU7R0FBTSxNQUFNO0VBQUc7RUFDMUIsS0FBSzs7RUFFSCxPQUFPO0dBQUU7R0FBTSxLQUFLO0dBQUksS0FBSztHQUFJLFNBQVM7RUFBRztFQUMvQyxLQUFLOztFQUVILE9BQU87R0FBRTtHQUFNLEtBQUs7R0FBSSxTQUFTO0VBQUc7RUFDdEMsS0FBSyxXQUNILE9BQU87R0FBRTtHQUFNLFNBQVM7R0FBSSxTQUFTO0VBQUc7RUFDMUMsS0FBSyxRQUNILE9BQU87R0FBRTtHQUFNLE1BQU07R0FBSSxNQUFNO0VBQUc7RUFDcEMsS0FBSyxTQUNILE9BQU87R0FBRTtHQUFNLE1BQU07R0FBSSxhQUFhO0VBQUc7RUFDM0MsS0FBSyxXQUNILE9BQU87R0FBRTtHQUFNLFNBQVM7R0FBUSxNQUFNO0VBQUc7RUFDM0MsS0FBSyxRQUNILE9BQU87R0FBRTtHQUFNLFNBQVM7R0FBTyxPQUFPLENBQUMsRUFBRTtFQUFFO0VBQzdDLEtBQUssU0FDSCxPQUFPO0dBQUU7R0FBTSxTQUFTLENBQUMsSUFBSSxFQUFFO0dBQUcsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7RUFBRTtFQUNyRCxTQUNFLE9BQU87R0FBRSxNQUFNO0dBQWEsTUFBTTtFQUFHO0NBQ3pDO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsRUFBRSxPQUFPLFlBQVk7Q0FDMUMsT0FDRTtFQUNFLHdCQUFDLE9BQUQ7R0FBTyxPQUFNO2FBQ1gsd0JBQUMsU0FBRDtJQUFPLE9BQU8sTUFBTTtJQUFNLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQUk7Ozs7O0VBQ3ZGOzs7OztFQUNQLHdCQUFDLE9BQUQ7R0FBTyxPQUFNO2FBQ1gsd0JBQUMsVUFBRDtJQUNFLE9BQU8sTUFBTTtJQUNiLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQztjQUV0RTtLQUFDO0tBQUc7S0FBRztLQUFHO0lBQUMsQ0FBQyxDQUFDLEtBQUssTUFDakIsd0JBQUMsVUFBRDtLQUFnQixPQUFPO2VBQXZCLENBQTBCLEtBQ3RCLENBQ0k7T0FGSzs7OztXQUVMLENBQ1Q7R0FDSzs7Ozs7RUFDSDs7Ozs7RUFDUCx3QkFBQyxTQUFEO0dBQU8sV0FBVTthQUFqQixDQUNFLHdCQUFDLFNBQUQ7SUFDRSxNQUFLO0lBQ0wsU0FBUyxDQUFDLENBQUMsTUFBTTtJQUNqQixXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLENBQUMsQ0FBQztHQUNyRTs7OzthQUFDLFVBRUc7Ozs7OztDQUNQOzs7OztBQUVOOztBQUVBLFNBQVMsZ0JBQWdCLEVBQUUsT0FBTyxZQUFZO0NBQzVDLE9BQ0Usd0JBQUMsT0FBRDtFQUFPLE9BQU07WUFDWCx3QkFBQyxZQUFEO0dBQ0UsTUFBTTtHQUNOLE9BQU8sTUFBTTtHQUNiLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0VBQy9EOzs7OztDQUNJOzs7OztBQUVYOztBQUVBLFNBQVMsV0FBVyxFQUFFLE9BQU8sWUFBWTtDQUN2QyxPQUNFLGdEQUNFLHdCQUFDLE9BQUQ7RUFBTyxPQUFNO1lBQ1gsd0JBQUMsU0FBRDtHQUNFLE9BQU8sTUFBTSxZQUFZO0dBQ3pCLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLFVBQVUsRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQ2xFLGFBQVk7RUFDYjs7Ozs7Q0FDSTs7OztXQUNQLHdCQUFDLE9BQUQ7RUFBTyxPQUFNO1lBQ1gsd0JBQUMsWUFBRDtHQUNFLE1BQU07R0FDTixXQUFVO0dBQ1YsT0FBTyxNQUFNO0dBQ2IsV0FBVyxNQUFNLFNBQVMsSUFBSSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7RUFDL0Q7Ozs7O0NBQ0k7Ozs7U0FDUDs7Ozs7QUFFTjs7QUFFQSxTQUFTLGVBQWUsRUFBRSxPQUFPLFlBQVk7Q0FDM0MsT0FDRSx3QkFBQyxPQUFEO0VBQU8sT0FBTTtZQUNYLHdCQUFDLFlBQUQ7R0FDRSxNQUFNO0dBQ04sV0FBVTtHQUNWLE9BQU8sTUFBTTtHQUNiLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0VBQy9EOzs7OztDQUNJOzs7OztBQUVYOztBQUVBLFNBQVMsWUFBWSxFQUFFLE9BQU8sWUFBWTtDQUN4QyxPQUNFO0VBRUUsd0JBQUMsT0FBRDtHQUFPLE9BQU07YUFDWCx3QkFBQyxTQUFEO0lBQU8sT0FBTyxNQUFNO0lBQUssV0FBVyxNQUFNLFNBQVMsSUFBSSxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FBSTs7Ozs7RUFDckY7Ozs7O0VBQ1Asd0JBQUMsT0FBRDtHQUFPLE9BQU07YUFDWCx3QkFBQyxTQUFEO0lBQU8sT0FBTyxNQUFNLE9BQU87SUFBSSxXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztHQUFJOzs7OztFQUMzRjs7Ozs7RUFDUCx3QkFBQyxPQUFEO0dBQU8sT0FBTTthQUNYLHdCQUFDLFNBQUQ7SUFDRSxPQUFPLE1BQU0sV0FBVztJQUN4QixXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztHQUNsRTs7Ozs7RUFDSTs7Ozs7Q0FDUDs7Ozs7QUFFTjs7QUFFQSxTQUFTLFlBQVksRUFBRSxPQUFPLFlBQVk7Q0FDeEMsT0FDRSxnREFFRSx3QkFBQyxPQUFEO0VBQU8sT0FBTTtZQUNYLHdCQUFDLFNBQUQ7R0FBTyxPQUFPLE1BQU07R0FBSyxXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztFQUFJOzs7OztDQUNyRjs7OztXQUNQLHdCQUFDLE9BQUQ7RUFBTyxPQUFNO1lBQ1gsd0JBQUMsU0FBRDtHQUNFLE9BQU8sTUFBTSxXQUFXO0dBQ3hCLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0VBQ2xFOzs7OztDQUNJOzs7O1NBQ1A7Ozs7O0FBRU47O0FBRUEsU0FBUyxjQUFjLEVBQUUsT0FBTyxZQUFZO0NBQzFDLE9BQ0UsZ0RBQ0Usd0JBQUMsT0FBRDtFQUFPLE9BQU07WUFDWCx3QkFBQyxTQUFEO0dBQ0UsT0FBTyxNQUFNLFdBQVc7R0FDeEIsV0FBVyxNQUFNLFNBQVMsSUFBSSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDakUsYUFBWTtFQUNiOzs7OztDQUNJOzs7O1dBQ1Asd0JBQUMsT0FBRDtFQUFPLE9BQU07WUFDWCx3QkFBQyxTQUFEO0dBQ0UsT0FBTyxNQUFNLFdBQVc7R0FDeEIsV0FBVyxNQUFNLFNBQVMsSUFBSSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7RUFDbEU7Ozs7O0NBQ0k7Ozs7U0FDUDs7Ozs7QUFFTjs7QUFFQSxTQUFTLFdBQVcsRUFBRSxPQUFPLFlBQVk7Q0FDdkMsT0FDRSxnREFDRSx3QkFBQyxPQUFEO0VBQU8sT0FBTTtZQUNYLHdCQUFDLFNBQUQ7R0FBTyxPQUFPLE1BQU07R0FBTSxXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztFQUFJOzs7OztDQUN2Rjs7OztXQUNQLHdCQUFDLE9BQUQ7RUFBTyxPQUFNO1lBQ1gsd0JBQUMsU0FBRDtHQUFPLE9BQU8sTUFBTTtHQUFNLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0VBQUk7Ozs7O0NBQ3ZGOzs7O1NBQ1A7Ozs7O0FBRU47O0FBRUEsU0FBUyxZQUFZLEVBQUUsT0FBTyxZQUFZO0NBQ3hDLE9BQ0UsZ0RBQ0Usd0JBQUMsT0FBRDtFQUFPLE9BQU07WUFDWCx3QkFBQyxZQUFEO0dBQ0UsTUFBTTtHQUNOLE9BQU8sTUFBTTtHQUNiLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0VBQy9EOzs7OztDQUNJOzs7O1dBQ1Asd0JBQUMsT0FBRDtFQUFPLE9BQU07WUFDWCx3QkFBQyxTQUFEO0dBQ0UsT0FBTyxNQUFNLGVBQWU7R0FDNUIsV0FBVyxNQUFNLFNBQVMsSUFBSSxPQUFPLEVBQUUsYUFBYSxFQUFFLE9BQU8sTUFBTSxDQUFDLENBQUM7RUFDdEU7Ozs7O0NBQ0k7Ozs7U0FDUDs7Ozs7QUFFTjs7QUFFQSxTQUFTLGNBQWMsRUFBRSxPQUFPLFlBQVk7Q0FDMUMsT0FDRSxnREFDRSx3QkFBQyxPQUFEO0VBQU8sT0FBTTtZQUNYLHdCQUFDLFVBQUQ7R0FDRSxPQUFPLE1BQU07R0FDYixXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQzthQUVoRTtJQUFDO0lBQU87SUFBVztJQUFhO0dBQU0sQ0FBQyxDQUFDLEtBQUssTUFDNUMsd0JBQUMsVUFBRDtJQUFnQixPQUFPO2NBQ3BCO0dBQ0ssR0FGSzs7OztVQUVMLENBQ1Q7RUFDSzs7Ozs7Q0FDSDs7OztXQUNQLHdCQUFDLE9BQUQ7RUFBTyxPQUFNO1lBQ1gsd0JBQUMsWUFBRDtHQUNFLE1BQU07R0FDTixPQUFPLE1BQU07R0FDYixXQUFXLE1BQU0sU0FBUyxJQUFJLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNLENBQUMsQ0FBQztFQUMvRDs7Ozs7Q0FDSTs7OztTQUNQOzs7OztBQUVOOztBQUVBLFNBQVMsV0FBVyxFQUFFLE9BQU8sWUFBWTtDQUN2QyxNQUFNLFFBQVEsTUFBTSxTQUFTLENBQUM7Q0FDOUIsTUFBTSxjQUFjLEdBQUcsVUFBVTtFQUMvQixNQUFNLE9BQU8sQ0FBQyxHQUFHLEtBQUs7RUFDdEIsS0FBSyxLQUFLO0VBQ1YsU0FBUyxJQUFJLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQyxDQUFDO0NBQ3RDO0NBQ0EsT0FDRTtFQUNFLHdCQUFDLFNBQUQ7R0FBTyxXQUFVO2FBQWpCLENBQ0Usd0JBQUMsU0FBRDtJQUNFLE1BQUs7SUFDTCxTQUFTLENBQUMsQ0FBQyxNQUFNO0lBQ2pCLFdBQVcsTUFBTSxTQUFTLElBQUksT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDO0dBQ3BFOzs7O2FBQUMsU0FFRzs7Ozs7O0VBQ04sTUFBTSxLQUFLLE1BQU0sTUFDaEIsd0JBQUMsT0FBRDtHQUFhLFdBQVU7YUFBdkIsQ0FDRSx3QkFBQyxTQUFEO0lBQU8sT0FBTztJQUFNLFdBQVcsTUFBTSxXQUFXLEdBQUcsRUFBRSxPQUFPLEtBQUs7R0FBSTs7OzthQUNyRSx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7SUFDVixlQUFlLFNBQVMsSUFBSSxPQUFPLEVBQUUsT0FBTyxNQUFNLFFBQVEsR0FBRyxRQUFRLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztjQUNuRjtHQUVPOzs7O1dBQ0w7S0FUSzs7OztTQVNMLENBQ047RUFDRCx3QkFBQyxVQUFEO0dBQ0UsTUFBSztHQUNMLFdBQVU7R0FDVixlQUFlLFNBQVMsSUFBSSxPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQzlEO0VBRU87Ozs7O0NBQ1I7Ozs7O0FBRU47O0FBRUEsU0FBUyxZQUFZLEVBQUUsT0FBTyxZQUFZO0NBQ3hDLE1BQU0sVUFBVSxNQUFNLFdBQVcsQ0FBQztDQUNsQyxNQUFNLE9BQU8sTUFBTSxRQUFRLENBQUM7Q0FDNUIsTUFBTSxnQkFBZ0IsR0FBRyxVQUFVO0VBQ2pDLE1BQU0sT0FBTyxDQUFDLEdBQUcsT0FBTztFQUN4QixLQUFLLEtBQUs7RUFDVixTQUFTLElBQUksT0FBTyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7Q0FDeEM7Q0FDQSxNQUFNLGNBQWMsSUFBSSxJQUFJLFVBQVU7RUFDcEMsTUFBTSxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUM7RUFDdkMsS0FBSyxHQUFHLENBQUMsTUFBTTtFQUNmLFNBQVMsSUFBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQztDQUNyQztDQUNBLE1BQU0sa0JBQWtCO0VBQ3RCLFNBQ0UsSUFBSSxPQUFPO0dBQ1QsU0FBUyxDQUFDLEdBQUcsU0FBUyxFQUFFO0dBQ3hCLE1BQU0sS0FBSyxLQUFLLFFBQVEsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDO0VBQ3RDLENBQUMsQ0FDSDtDQUNGO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLFNBQVMsSUFBSSxPQUFPLEVBQUUsTUFBTSxDQUFDLEdBQUcsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ2pFO0NBQ0EsT0FDRTtFQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRyxRQUFRLEtBQUssR0FBRyxNQUNmLHdCQUFDLFNBQUQ7SUFBZSxPQUFPO0lBQUcsV0FBVyxNQUFNLGFBQWEsR0FBRyxFQUFFLE9BQU8sS0FBSztJQUFHLGFBQWEsVUFBVSxJQUFJO0dBQU0sR0FBaEc7Ozs7VUFBZ0csQ0FDN0csR0FDRCx3QkFBQyxVQUFEO0lBQVEsTUFBSztJQUFTLFdBQVU7SUFBZSxTQUFTO2NBQVc7R0FFM0Q7Ozs7V0FDTDs7Ozs7O0VBQ0osS0FBSyxLQUFLLEtBQUssT0FDZCx3QkFBQyxPQUFEO0dBQWMsV0FBVTthQUNyQixJQUFJLEtBQUssTUFBTSxPQUNkLHdCQUFDLFNBQUQ7SUFBZ0IsT0FBTztJQUFNLFdBQVcsTUFBTSxXQUFXLElBQUksSUFBSSxFQUFFLE9BQU8sS0FBSztHQUFJLEdBQXZFOzs7O1VBQXVFLENBQ3BGO0VBQ0UsR0FKSzs7OztTQUlMLENBQ047RUFDRCx3QkFBQyxVQUFEO0dBQVEsTUFBSztHQUFTLFdBQVU7R0FBb0IsU0FBUzthQUFRO0VBRTdEOzs7OztDQUNSOzs7OztBQUVOOztBQUVBLE9BQU8sTUFBTSxnQkFBZ0I7Q0FDM0IsU0FBUztDQUNULFdBQVc7Q0FDWCxNQUFNO0NBQ04sVUFBVTtDQUNWLE9BQU87Q0FDUCxPQUFPO0NBQ1AsU0FBUztDQUNULE1BQU07Q0FDTixPQUFPO0NBQ1AsU0FBUztDQUNULE1BQU07Q0FDTixPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQmxvY2tFZGl0b3JzLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQZXItYmxvY2stdHlwZSBlZGl0b3IgZm9ybXMg4oCUIHJlZ2lzdHJ5LXBhdHRlcm4gbWlycm9yaW5nIHRoZSBiYWNrZW5kJ3Ncbi8vIGRpc2NyaW1pbmF0ZWQgdW5pb24gKHNjaGVtYXMvY29udGVudC5weSkgYW5kIEJsb2NrUmVuZGVyZXIuanN4J3MgcmVnaXN0cnkuXG4vLyBFYWNoIGVkaXRvciBpcyBhIHNtYWxsIGNvbnRyb2xsZWQgZm9ybTogYGJsb2NrYCAoY3VycmVudCB2YWx1ZSksXG4vLyBgb25DaGFuZ2UobmV4dEJsb2NrKWAuIEtlcHQgaW50ZW50aW9uYWxseSBwbGFpbiAobmF0aXZlIGlucHV0cykgdG8gbWF0Y2hcbi8vIGluZGV4LmNzcydzIGV4aXN0aW5nIGZvcm0gc3R5bGluZyByYXRoZXIgdGhhbiBpbnZlbnRpbmcgbmV3IGNvbXBvbmVudHMuXG5cbmZ1bmN0aW9uIEZpZWxkKHsgbGFiZWwsIGNoaWxkcmVuIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY21zLWZpZWxkXCI+XG4gICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvbGFiZWw+XG4gIClcbn1cblxuZnVuY3Rpb24gc2V0KGJsb2NrLCBwYXRjaCkge1xuICByZXR1cm4geyAuLi5ibG9jaywgLi4ucGF0Y2ggfVxufVxuXG5leHBvcnQgY29uc3QgQkxPQ0tfVFlQRVMgPSBbXG4gICdoZWFkaW5nJyxcbiAgJ3BhcmFncmFwaCcsXG4gICdjb2RlJyxcbiAgJ3Rlcm1pbmFsJyxcbiAgJ2ltYWdlJyxcbiAgJ3ZpZGVvJyxcbiAgJ3lvdXR1YmUnLFxuICAnbGluaycsXG4gICdxdW90ZScsXG4gICdjYWxsb3V0JyxcbiAgJ2xpc3QnLFxuICAndGFibGUnLFxuXVxuXG5leHBvcnQgZnVuY3Rpb24gZGVmYXVsdEJsb2NrRm9yKHR5cGUpIHtcbiAgc3dpdGNoICh0eXBlKSB7XG4gICAgY2FzZSAnaGVhZGluZyc6XG4gICAgICByZXR1cm4geyB0eXBlLCB0ZXh0OiAnJywgbGV2ZWw6IDIsIG51bWJlcmVkOiBmYWxzZSB9XG4gICAgY2FzZSAncGFyYWdyYXBoJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIHRleHQ6ICcnIH1cbiAgICBjYXNlICdjb2RlJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIGNvZGU6ICcnLCBsYW5ndWFnZTogJycgfVxuICAgIGNhc2UgJ3Rlcm1pbmFsJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIHRleHQ6ICcnIH1cbiAgICBjYXNlICdpbWFnZSc6XG4gICAgICAvLyBUT0RPOiBzd2FwIGluIEFzc2V0UGlja2VyIG9uY2UgZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2Fzc2V0cy9Bc3NldFBpY2tlci5qc3ggbGFuZHNcbiAgICAgIHJldHVybiB7IHR5cGUsIHNyYzogJycsIGFsdDogJycsIGNhcHRpb246ICcnIH1cbiAgICBjYXNlICd2aWRlbyc6XG4gICAgICAvLyBUT0RPOiBzd2FwIGluIEFzc2V0UGlja2VyIG9uY2UgZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2Fzc2V0cy9Bc3NldFBpY2tlci5qc3ggbGFuZHNcbiAgICAgIHJldHVybiB7IHR5cGUsIHNyYzogJycsIGNhcHRpb246ICcnIH1cbiAgICBjYXNlICd5b3V0dWJlJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIHZpZGVvSWQ6ICcnLCBjYXB0aW9uOiAnJyB9XG4gICAgY2FzZSAnbGluayc6XG4gICAgICByZXR1cm4geyB0eXBlLCBocmVmOiAnJywgdGV4dDogJycgfVxuICAgIGNhc2UgJ3F1b3RlJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIHRleHQ6ICcnLCBhdHRyaWJ1dGlvbjogJycgfVxuICAgIGNhc2UgJ2NhbGxvdXQnOlxuICAgICAgcmV0dXJuIHsgdHlwZSwgdmFyaWFudDogJ25vdGUnLCB0ZXh0OiAnJyB9XG4gICAgY2FzZSAnbGlzdCc6XG4gICAgICByZXR1cm4geyB0eXBlLCBvcmRlcmVkOiBmYWxzZSwgaXRlbXM6IFsnJ10gfVxuICAgIGNhc2UgJ3RhYmxlJzpcbiAgICAgIHJldHVybiB7IHR5cGUsIGhlYWRlcnM6IFsnJywgJyddLCByb3dzOiBbWycnLCAnJ11dIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgdHlwZTogJ3BhcmFncmFwaCcsIHRleHQ6ICcnIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBIZWFkaW5nRWRpdG9yKHsgYmxvY2ssIG9uQ2hhbmdlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEZpZWxkIGxhYmVsPVwiVGV4dFwiPlxuICAgICAgICA8aW5wdXQgdmFsdWU9e2Jsb2NrLnRleHR9IG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pKX0gLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgICA8RmllbGQgbGFiZWw9XCJMZXZlbFwiPlxuICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgdmFsdWU9e2Jsb2NrLmxldmVsfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IGxldmVsOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpIH0pKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtbMSwgMiwgMywgNF0ubWFwKChsKSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17bH0gdmFsdWU9e2x9PlxuICAgICAgICAgICAgICBIe2x9XG4gICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICA8L0ZpZWxkPlxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNtcy1jaGVja2JveFwiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgIGNoZWNrZWQ9eyEhYmxvY2subnVtYmVyZWR9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgbnVtYmVyZWQ6IGUudGFyZ2V0LmNoZWNrZWQgfSkpfVxuICAgICAgICAvPlxuICAgICAgICBOdW1iZXJlZFxuICAgICAgPC9sYWJlbD5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBQYXJhZ3JhcGhFZGl0b3IoeyBibG9jaywgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxGaWVsZCBsYWJlbD1cIlRleHRcIj5cbiAgICAgIDx0ZXh0YXJlYVxuICAgICAgICByb3dzPXszfVxuICAgICAgICB2YWx1ZT17YmxvY2sudGV4dH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgdGV4dDogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgLz5cbiAgICA8L0ZpZWxkPlxuICApXG59XG5cbmZ1bmN0aW9uIENvZGVFZGl0b3IoeyBibG9jaywgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8RmllbGQgbGFiZWw9XCJMYW5ndWFnZVwiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB2YWx1ZT17YmxvY2subGFuZ3VhZ2UgfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgbGFuZ3VhZ2U6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gcHl0aG9uXCJcbiAgICAgICAgLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgICA8RmllbGQgbGFiZWw9XCJDb2RlXCI+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIHJvd3M9ezZ9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiY21zLW1vbm9cIlxuICAgICAgICAgIHZhbHVlPXtibG9jay5jb2RlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IGNvZGU6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gVGVybWluYWxFZGl0b3IoeyBibG9jaywgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDxGaWVsZCBsYWJlbD1cIlRlcm1pbmFsIG91dHB1dFwiPlxuICAgICAgPHRleHRhcmVhXG4gICAgICAgIHJvd3M9ezR9XG4gICAgICAgIGNsYXNzTmFtZT1cImNtcy1tb25vXCJcbiAgICAgICAgdmFsdWU9e2Jsb2NrLnRleHR9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgIC8+XG4gICAgPC9GaWVsZD5cbiAgKVxufVxuXG5mdW5jdGlvbiBJbWFnZUVkaXRvcih7IGJsb2NrLCBvbkNoYW5nZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiBUT0RPOiBzd2FwIGluIEFzc2V0UGlja2VyIG9uY2UgZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2Fzc2V0cy9Bc3NldFBpY2tlci5qc3ggbGFuZHMgKi99XG4gICAgICA8RmllbGQgbGFiZWw9XCJJbWFnZSBVUkwgLyBhc3NldCBpZFwiPlxuICAgICAgICA8aW5wdXQgdmFsdWU9e2Jsb2NrLnNyY30gb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgc3JjOiBlLnRhcmdldC52YWx1ZSB9KSl9IC8+XG4gICAgICA8L0ZpZWxkPlxuICAgICAgPEZpZWxkIGxhYmVsPVwiQWx0IHRleHRcIj5cbiAgICAgICAgPGlucHV0IHZhbHVlPXtibG9jay5hbHQgfHwgJyd9IG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IGFsdDogZS50YXJnZXQudmFsdWUgfSkpfSAvPlxuICAgICAgPC9GaWVsZD5cbiAgICAgIDxGaWVsZCBsYWJlbD1cIkNhcHRpb25cIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdmFsdWU9e2Jsb2NrLmNhcHRpb24gfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgY2FwdGlvbjogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAvPlxuICAgICAgPC9GaWVsZD5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBWaWRlb0VkaXRvcih7IGJsb2NrLCBvbkNoYW5nZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiBUT0RPOiBzd2FwIGluIEFzc2V0UGlja2VyIG9uY2UgZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2Fzc2V0cy9Bc3NldFBpY2tlci5qc3ggbGFuZHMgKi99XG4gICAgICA8RmllbGQgbGFiZWw9XCJWaWRlbyBVUkwgLyBhc3NldCBpZFwiPlxuICAgICAgICA8aW5wdXQgdmFsdWU9e2Jsb2NrLnNyY30gb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgc3JjOiBlLnRhcmdldC52YWx1ZSB9KSl9IC8+XG4gICAgICA8L0ZpZWxkPlxuICAgICAgPEZpZWxkIGxhYmVsPVwiQ2FwdGlvblwiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB2YWx1ZT17YmxvY2suY2FwdGlvbiB8fCAnJ31cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHNldChibG9jaywgeyBjYXB0aW9uOiBlLnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgIC8+XG4gICAgICA8L0ZpZWxkPlxuICAgIDwvPlxuICApXG59XG5cbmZ1bmN0aW9uIFlvdXR1YmVFZGl0b3IoeyBibG9jaywgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8RmllbGQgbGFiZWw9XCJZb3VUdWJlIHZpZGVvIGlkXCI+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHZhbHVlPXtibG9jay52aWRlb0lkIHx8ICcnfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHZpZGVvSWQ6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gZFF3NHc5V2dYY1FcIlxuICAgICAgICAvPlxuICAgICAgPC9GaWVsZD5cbiAgICAgIDxGaWVsZCBsYWJlbD1cIkNhcHRpb25cIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdmFsdWU9e2Jsb2NrLmNhcHRpb24gfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgY2FwdGlvbjogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAvPlxuICAgICAgPC9GaWVsZD5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBMaW5rRWRpdG9yKHsgYmxvY2ssIG9uQ2hhbmdlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEZpZWxkIGxhYmVsPVwiVVJMXCI+XG4gICAgICAgIDxpbnB1dCB2YWx1ZT17YmxvY2suaHJlZn0gb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgaHJlZjogZS50YXJnZXQudmFsdWUgfSkpfSAvPlxuICAgICAgPC9GaWVsZD5cbiAgICAgIDxGaWVsZCBsYWJlbD1cIkxpbmsgdGV4dFwiPlxuICAgICAgICA8aW5wdXQgdmFsdWU9e2Jsb2NrLnRleHR9IG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pKX0gLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gUXVvdGVFZGl0b3IoeyBibG9jaywgb25DaGFuZ2UgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8RmllbGQgbGFiZWw9XCJRdW90ZVwiPlxuICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgIHZhbHVlPXtibG9jay50ZXh0fVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgICA8RmllbGQgbGFiZWw9XCJBdHRyaWJ1dGlvblwiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB2YWx1ZT17YmxvY2suYXR0cmlidXRpb24gfHwgJyd9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgYXR0cmlidXRpb246IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgLz5cbiAgICAgIDwvRmllbGQ+XG4gICAgPC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2FsbG91dEVkaXRvcih7IGJsb2NrLCBvbkNoYW5nZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxGaWVsZCBsYWJlbD1cIlZhcmlhbnRcIj5cbiAgICAgICAgPHNlbGVjdFxuICAgICAgICAgIHZhbHVlPXtibG9jay52YXJpYW50fVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHZhcmlhbnQ6IGUudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtbJ3RpcCcsICd3YXJuaW5nJywgJ2ltcG9ydGFudCcsICdub3RlJ10ubWFwKCh2KSA9PiAoXG4gICAgICAgICAgICA8b3B0aW9uIGtleT17dn0gdmFsdWU9e3Z9PlxuICAgICAgICAgICAgICB7dn1cbiAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3NlbGVjdD5cbiAgICAgIDwvRmllbGQ+XG4gICAgICA8RmllbGQgbGFiZWw9XCJUZXh0XCI+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgdmFsdWU9e2Jsb2NrLnRleHR9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShzZXQoYmxvY2ssIHsgdGV4dDogZS50YXJnZXQudmFsdWUgfSkpfVxuICAgICAgICAvPlxuICAgICAgPC9GaWVsZD5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBMaXN0RWRpdG9yKHsgYmxvY2ssIG9uQ2hhbmdlIH0pIHtcbiAgY29uc3QgaXRlbXMgPSBibG9jay5pdGVtcyB8fCBbXVxuICBjb25zdCB1cGRhdGVJdGVtID0gKGksIHZhbHVlKSA9PiB7XG4gICAgY29uc3QgbmV4dCA9IFsuLi5pdGVtc11cbiAgICBuZXh0W2ldID0gdmFsdWVcbiAgICBvbkNoYW5nZShzZXQoYmxvY2ssIHsgaXRlbXM6IG5leHQgfSkpXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNtcy1jaGVja2JveFwiPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgIGNoZWNrZWQ9eyEhYmxvY2sub3JkZXJlZH1cbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uQ2hhbmdlKHNldChibG9jaywgeyBvcmRlcmVkOiBlLnRhcmdldC5jaGVja2VkIH0pKX1cbiAgICAgICAgLz5cbiAgICAgICAgT3JkZXJlZFxuICAgICAgPC9sYWJlbD5cbiAgICAgIHtpdGVtcy5tYXAoKGl0ZW0sIGkpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImNtcy1yb3dcIj5cbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e2l0ZW19IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlSXRlbShpLCBlLnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjbXMtYnRuLWljb25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IGl0ZW1zOiBpdGVtcy5maWx0ZXIoKF8sIGlkeCkgPT4gaWR4ICE9PSBpKSB9KSl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgUmVtb3ZlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSl9XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9XCJjbXMtYnRuLXNlY29uZGFyeVwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHNldChibG9jaywgeyBpdGVtczogWy4uLml0ZW1zLCAnJ10gfSkpfVxuICAgICAgPlxuICAgICAgICArIEFkZCBpdGVtXG4gICAgICA8L2J1dHRvbj5cbiAgICA8Lz5cbiAgKVxufVxuXG5mdW5jdGlvbiBUYWJsZUVkaXRvcih7IGJsb2NrLCBvbkNoYW5nZSB9KSB7XG4gIGNvbnN0IGhlYWRlcnMgPSBibG9jay5oZWFkZXJzIHx8IFtdXG4gIGNvbnN0IHJvd3MgPSBibG9jay5yb3dzIHx8IFtdXG4gIGNvbnN0IHVwZGF0ZUhlYWRlciA9IChpLCB2YWx1ZSkgPT4ge1xuICAgIGNvbnN0IG5leHQgPSBbLi4uaGVhZGVyc11cbiAgICBuZXh0W2ldID0gdmFsdWVcbiAgICBvbkNoYW5nZShzZXQoYmxvY2ssIHsgaGVhZGVyczogbmV4dCB9KSlcbiAgfVxuICBjb25zdCB1cGRhdGVDZWxsID0gKHJpLCBjaSwgdmFsdWUpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gcm93cy5tYXAoKHJvdykgPT4gWy4uLnJvd10pXG4gICAgbmV4dFtyaV1bY2ldID0gdmFsdWVcbiAgICBvbkNoYW5nZShzZXQoYmxvY2ssIHsgcm93czogbmV4dCB9KSlcbiAgfVxuICBjb25zdCBhZGRDb2x1bW4gPSAoKSA9PiB7XG4gICAgb25DaGFuZ2UoXG4gICAgICBzZXQoYmxvY2ssIHtcbiAgICAgICAgaGVhZGVyczogWy4uLmhlYWRlcnMsICcnXSxcbiAgICAgICAgcm93czogcm93cy5tYXAoKHJvdykgPT4gWy4uLnJvdywgJyddKSxcbiAgICAgIH0pLFxuICAgIClcbiAgfVxuICBjb25zdCBhZGRSb3cgPSAoKSA9PiB7XG4gICAgb25DaGFuZ2Uoc2V0KGJsb2NrLCB7IHJvd3M6IFsuLi5yb3dzLCBoZWFkZXJzLm1hcCgoKSA9PiAnJyldIH0pKVxuICB9XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXJvd1wiPlxuICAgICAgICB7aGVhZGVycy5tYXAoKGgsIGkpID0+IChcbiAgICAgICAgICA8aW5wdXQga2V5PXtpfSB2YWx1ZT17aH0gb25DaGFuZ2U9eyhlKSA9PiB1cGRhdGVIZWFkZXIoaSwgZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj17YEhlYWRlciAke2kgKyAxfWB9IC8+XG4gICAgICAgICkpfVxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjbXMtYnRuLWljb25cIiBvbkNsaWNrPXthZGRDb2x1bW59PlxuICAgICAgICAgICsgQ29sXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICB7cm93cy5tYXAoKHJvdywgcmkpID0+IChcbiAgICAgICAgPGRpdiBrZXk9e3JpfSBjbGFzc05hbWU9XCJjbXMtcm93XCI+XG4gICAgICAgICAge3Jvdy5tYXAoKGNlbGwsIGNpKSA9PiAoXG4gICAgICAgICAgICA8aW5wdXQga2V5PXtjaX0gdmFsdWU9e2NlbGx9IG9uQ2hhbmdlPXsoZSkgPT4gdXBkYXRlQ2VsbChyaSwgY2ksIGUudGFyZ2V0LnZhbHVlKX0gLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImNtcy1idG4tc2Vjb25kYXJ5XCIgb25DbGljaz17YWRkUm93fT5cbiAgICAgICAgKyBBZGQgcm93XG4gICAgICA8L2J1dHRvbj5cbiAgICA8Lz5cbiAgKVxufVxuXG5leHBvcnQgY29uc3QgQkxPQ0tfRURJVE9SUyA9IHtcbiAgaGVhZGluZzogSGVhZGluZ0VkaXRvcixcbiAgcGFyYWdyYXBoOiBQYXJhZ3JhcGhFZGl0b3IsXG4gIGNvZGU6IENvZGVFZGl0b3IsXG4gIHRlcm1pbmFsOiBUZXJtaW5hbEVkaXRvcixcbiAgaW1hZ2U6IEltYWdlRWRpdG9yLFxuICB2aWRlbzogVmlkZW9FZGl0b3IsXG4gIHlvdXR1YmU6IFlvdXR1YmVFZGl0b3IsXG4gIGxpbms6IExpbmtFZGl0b3IsXG4gIHF1b3RlOiBRdW90ZUVkaXRvcixcbiAgY2FsbG91dDogQ2FsbG91dEVkaXRvcixcbiAgbGlzdDogTGlzdEVkaXRvcixcbiAgdGFibGU6IFRhYmxlRWRpdG9yLFxufVxuIl19