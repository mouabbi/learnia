import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/courses/CourseCard.jsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import { GitBranch, Code2, Globe, FlaskConical, Clock, BookOpen, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/courses/CourseCard.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
const ICONS = {
	GitBranch,
	Code2,
	Globe,
	FlaskConical
};
// A gradient "thumbnail" per course icon, so the icon reads as a cover
// image rather than a small inline glyph. Cycled by a stable hash of the
// course id so the same course always gets the same color.
const THUMB_VARIANTS = [
	"thumb-indigo",
	"thumb-amber",
	"thumb-teal",
	"thumb-rose"
];
function thumbVariant(id) {
	const hash = [...String(id)].reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
	return THUMB_VARIANTS[hash % THUMB_VARIANTS.length];
}
// Shared course card used by both the catalog (CoursesPage) and the home
// page's "Recommended for you" section — one layout to keep in sync.
// `progressPct` is optional: when passed (parent has already fetched the
// learner's progress for this course), a slim progress bar renders on the
// card instead of leaving it flat for started courses.
export function CourseCard({ course, progressPct }) {
	const Icon = ICONS[course.icon] ?? BookOpen;
	const started = typeof progressPct === "number" && progressPct > 0;
	const completed = started && progressPct >= 100;
	return /* @__PURE__ */ _jsxDEV(
		"a",
		// Opens the docs-style reader in its own browser tab rather than
		// navigating the current one — a plain <a target="_blank"> gets real
		// new-tab semantics; React Router's <Link> doesn't apply here since
		// we want a genuinely separate tab, not client-side SPA navigation.
		{
			href: `/courses/${course.slug}/learn`,
			target: "_blank",
			rel: "noopener noreferrer",
			className: `course-card${completed ? " course-card-complete" : ""}`,
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: `course-card-thumb ${course.image ? "course-card-thumb-image" : thumbVariant(course.id)}`,
				children: [course.image ? /* @__PURE__ */ _jsxDEV("img", {
					src: course.image,
					alt: "",
					className: "course-card-thumb-img"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(Icon, {
					size: 40,
					strokeWidth: 1.6,
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 11
				}, this), completed ? /* @__PURE__ */ _jsxDEV("span", {
					className: "course-card-badge course-card-badge-done",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), " Completed"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this) : course.difficulty && /* @__PURE__ */ _jsxDEV("span", {
					className: "course-card-badge",
					children: course.difficulty
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 32
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "course-card-body",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: course.title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: course.description }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "course-card-meta",
						children: [
							/* @__PURE__ */ _jsxDEV(Clock, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 11
							}, this),
							" ",
							course.estimatedMinutes,
							" min"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 9
					}, this),
					started && /* @__PURE__ */ _jsxDEV("div", {
						className: "course-card-progress",
						"aria-label": `${progressPct}% complete`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "course-card-progress-track",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: `course-card-progress-fill${completed ? " course-card-progress-fill-done" : ""}`,
								style: { width: `${progressPct}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "course-card-progress-label",
							children: completed ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 13 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 19
							}, this), " Completed"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 17
							}, this) : `${progressPct}% complete`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this)]
		},
		void 0,
		true,
		{
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 5
		},
		this
	);
}
_c = CourseCard;
export function CourseCardSkeleton() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "course-card course-card-skeleton",
		children: [/* @__PURE__ */ _jsxDEV(Skeleton, {
			className: "course-card-thumb-skeleton",
			height: "6.5rem"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "course-card-body",
			children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "60%",
					height: "1.1rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "90%",
					height: "0.85rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "40%",
					height: "0.85rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 84,
		columnNumber: 5
	}, this);
}
_c2 = CourseCardSkeleton;
var _c, _c2;
$RefreshReg$(_c, "CourseCard");
$RefreshReg$(_c2, "CourseCardSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/courses/CourseCard.jsx?t=1790187136361";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/courses/CourseCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/courses/CourseCard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/courses/CourseCard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLE9BQU8sT0FBTyxjQUFjLE9BQU8sVUFBVSxvQkFBb0I7QUFDckYsU0FBUyxnQkFBZ0I7OztBQUV6QixNQUFNLFFBQVE7Q0FBRTtDQUFXO0NBQU87Q0FBTztBQUFhOzs7O0FBS3RELE1BQU0saUJBQWlCO0NBQUM7Q0FBZ0I7Q0FBZTtDQUFjO0FBQVk7QUFFakYsU0FBUyxhQUFhLElBQUk7Q0FDeEIsTUFBTSxPQUFPLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLE9BQU8sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUM7Q0FDMUUsT0FBTyxlQUFlLE9BQU8sZUFBZTtBQUM5Qzs7Ozs7O0FBT0EsT0FBTyxTQUFTLFdBQVcsRUFBRSxRQUFRLGVBQWU7Q0FDbEQsTUFBTSxPQUFPLE1BQU0sT0FBTyxTQUFTO0NBQ25DLE1BQU0sVUFBVSxPQUFPLGdCQUFnQixZQUFZLGNBQWM7Q0FDakUsTUFBTSxZQUFZLFdBQVcsZUFBZTtDQUM1QyxPQUtFO0VBQUM7Ozs7O0VBQUQ7R0FDRSxNQUFNLFlBQVksT0FBTyxLQUFLO0dBQzlCLFFBQU87R0FDUCxLQUFJO0dBQ0osV0FBVyxjQUFjLFlBQVksMEJBQTBCO2FBSmpFLENBTUUsd0JBQUMsT0FBRDtJQUNFLFdBQVcscUJBQXFCLE9BQU8sUUFBUSw0QkFBNEIsYUFBYSxPQUFPLEVBQUU7Y0FEbkcsQ0FHRyxPQUFPLFFBQ04sd0JBQUMsT0FBRDtLQUFLLEtBQUssT0FBTztLQUFPLEtBQUk7S0FBRyxXQUFVO0lBQXlCOzs7O2VBRWxFLHdCQUFDLE1BQUQ7S0FBTSxNQUFNO0tBQUksYUFBYTtLQUFLLGVBQVk7SUFBUTs7OztjQUV2RCxZQUNDLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQ0Usd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztlQUFDLFlBQ3RCOzs7OztlQUVOLE9BQU8sY0FBYyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFxQixPQUFPO0lBQWlCOzs7O1lBRWpGOzs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFELFlBQUssT0FBTyxNQUFVOzs7OztLQUN0Qix3QkFBQyxLQUFELFlBQUksT0FBTyxZQUFlOzs7OztLQUMxQix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FDRSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztPQUFDO09BQUUsT0FBTztPQUFpQjtNQUN6Qzs7Ozs7O0tBQ0wsV0FDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUF1QixjQUFZLEdBQUcsWUFBWTtnQkFBakUsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQ0UsV0FBVyw0QkFBNEIsWUFBWSxvQ0FBb0M7UUFDdkYsT0FBTyxFQUFFLE9BQU8sR0FBRyxZQUFZLEdBQUc7T0FDbkM7Ozs7O01BQ0U7Ozs7Z0JBQ0wsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsWUFDQyxnREFDRSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2lCQUFDLFlBQzFCOzs7O2tCQUVGLEdBQUcsWUFBWTtNQUViOzs7O2NBQ0g7Ozs7OztJQUVKOzs7OztXQUNKOzs7Ozs7Ozs7OztBQUVQOztBQUVBLE9BQU8sU0FBUyxxQkFBcUI7Q0FDbkMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsVUFBRDtHQUFVLFdBQVU7R0FBNkIsUUFBTztFQUFVOzs7O1lBQ2xFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxVQUFEO0tBQVUsT0FBTTtLQUFNLFFBQU87SUFBVTs7Ozs7SUFDdkMsd0JBQUMsVUFBRDtLQUFVLE9BQU07S0FBTSxRQUFPO0lBQVc7Ozs7O0lBQ3hDLHdCQUFDLFVBQUQ7S0FBVSxPQUFNO0tBQU0sUUFBTztJQUFXOzs7OztHQUNyQzs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ291cnNlQ2FyZC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR2l0QnJhbmNoLCBDb2RlMiwgR2xvYmUsIEZsYXNrQ29uaWNhbCwgQ2xvY2ssIEJvb2tPcGVuLCBDaGVja0NpcmNsZTIgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnLi4vLi4vY29tcG9uZW50cy9Ta2VsZXRvbidcclxuXHJcbmNvbnN0IElDT05TID0geyBHaXRCcmFuY2gsIENvZGUyLCBHbG9iZSwgRmxhc2tDb25pY2FsIH1cclxuXHJcbi8vIEEgZ3JhZGllbnQgXCJ0aHVtYm5haWxcIiBwZXIgY291cnNlIGljb24sIHNvIHRoZSBpY29uIHJlYWRzIGFzIGEgY292ZXJcclxuLy8gaW1hZ2UgcmF0aGVyIHRoYW4gYSBzbWFsbCBpbmxpbmUgZ2x5cGguIEN5Y2xlZCBieSBhIHN0YWJsZSBoYXNoIG9mIHRoZVxyXG4vLyBjb3Vyc2UgaWQgc28gdGhlIHNhbWUgY291cnNlIGFsd2F5cyBnZXRzIHRoZSBzYW1lIGNvbG9yLlxyXG5jb25zdCBUSFVNQl9WQVJJQU5UUyA9IFsndGh1bWItaW5kaWdvJywgJ3RodW1iLWFtYmVyJywgJ3RodW1iLXRlYWwnLCAndGh1bWItcm9zZSddXHJcblxyXG5mdW5jdGlvbiB0aHVtYlZhcmlhbnQoaWQpIHtcclxuICBjb25zdCBoYXNoID0gWy4uLlN0cmluZyhpZCldLnJlZHVjZSgoc3VtLCBjaCkgPT4gc3VtICsgY2guY2hhckNvZGVBdCgwKSwgMClcclxuICByZXR1cm4gVEhVTUJfVkFSSUFOVFNbaGFzaCAlIFRIVU1CX1ZBUklBTlRTLmxlbmd0aF1cclxufVxyXG5cclxuLy8gU2hhcmVkIGNvdXJzZSBjYXJkIHVzZWQgYnkgYm90aCB0aGUgY2F0YWxvZyAoQ291cnNlc1BhZ2UpIGFuZCB0aGUgaG9tZVxyXG4vLyBwYWdlJ3MgXCJSZWNvbW1lbmRlZCBmb3IgeW91XCIgc2VjdGlvbiDigJQgb25lIGxheW91dCB0byBrZWVwIGluIHN5bmMuXHJcbi8vIGBwcm9ncmVzc1BjdGAgaXMgb3B0aW9uYWw6IHdoZW4gcGFzc2VkIChwYXJlbnQgaGFzIGFscmVhZHkgZmV0Y2hlZCB0aGVcclxuLy8gbGVhcm5lcidzIHByb2dyZXNzIGZvciB0aGlzIGNvdXJzZSksIGEgc2xpbSBwcm9ncmVzcyBiYXIgcmVuZGVycyBvbiB0aGVcclxuLy8gY2FyZCBpbnN0ZWFkIG9mIGxlYXZpbmcgaXQgZmxhdCBmb3Igc3RhcnRlZCBjb3Vyc2VzLlxyXG5leHBvcnQgZnVuY3Rpb24gQ291cnNlQ2FyZCh7IGNvdXJzZSwgcHJvZ3Jlc3NQY3QgfSkge1xyXG4gIGNvbnN0IEljb24gPSBJQ09OU1tjb3Vyc2UuaWNvbl0gPz8gQm9va09wZW5cclxuICBjb25zdCBzdGFydGVkID0gdHlwZW9mIHByb2dyZXNzUGN0ID09PSAnbnVtYmVyJyAmJiBwcm9ncmVzc1BjdCA+IDBcclxuICBjb25zdCBjb21wbGV0ZWQgPSBzdGFydGVkICYmIHByb2dyZXNzUGN0ID49IDEwMFxyXG4gIHJldHVybiAoXHJcbiAgICAvLyBPcGVucyB0aGUgZG9jcy1zdHlsZSByZWFkZXIgaW4gaXRzIG93biBicm93c2VyIHRhYiByYXRoZXIgdGhhblxyXG4gICAgLy8gbmF2aWdhdGluZyB0aGUgY3VycmVudCBvbmUg4oCUIGEgcGxhaW4gPGEgdGFyZ2V0PVwiX2JsYW5rXCI+IGdldHMgcmVhbFxyXG4gICAgLy8gbmV3LXRhYiBzZW1hbnRpY3M7IFJlYWN0IFJvdXRlcidzIDxMaW5rPiBkb2Vzbid0IGFwcGx5IGhlcmUgc2luY2VcclxuICAgIC8vIHdlIHdhbnQgYSBnZW51aW5lbHkgc2VwYXJhdGUgdGFiLCBub3QgY2xpZW50LXNpZGUgU1BBIG5hdmlnYXRpb24uXHJcbiAgICA8YVxyXG4gICAgICBocmVmPXtgL2NvdXJzZXMvJHtjb3Vyc2Uuc2x1Z30vbGVhcm5gfVxyXG4gICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgY2xhc3NOYW1lPXtgY291cnNlLWNhcmQke2NvbXBsZXRlZCA/ICcgY291cnNlLWNhcmQtY29tcGxldGUnIDogJyd9YH1cclxuICAgID5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGNvdXJzZS1jYXJkLXRodW1iICR7Y291cnNlLmltYWdlID8gJ2NvdXJzZS1jYXJkLXRodW1iLWltYWdlJyA6IHRodW1iVmFyaWFudChjb3Vyc2UuaWQpfWB9XHJcbiAgICAgID5cclxuICAgICAgICB7Y291cnNlLmltYWdlID8gKFxyXG4gICAgICAgICAgPGltZyBzcmM9e2NvdXJzZS5pbWFnZX0gYWx0PVwiXCIgY2xhc3NOYW1lPVwiY291cnNlLWNhcmQtdGh1bWItaW1nXCIgLz5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPEljb24gc2l6ZT17NDB9IHN0cm9rZVdpZHRoPXsxLjZ9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgICB7Y29tcGxldGVkID8gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY291cnNlLWNhcmQtYmFkZ2UgY291cnNlLWNhcmQtYmFkZ2UtZG9uZVwiPlxyXG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezEzfSAvPiBDb21wbGV0ZWRcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgY291cnNlLmRpZmZpY3VsdHkgJiYgPHNwYW4gY2xhc3NOYW1lPVwiY291cnNlLWNhcmQtYmFkZ2VcIj57Y291cnNlLmRpZmZpY3VsdHl9PC9zcGFuPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvdXJzZS1jYXJkLWJvZHlcIj5cclxuICAgICAgICA8aDI+e2NvdXJzZS50aXRsZX08L2gyPlxyXG4gICAgICAgIDxwPntjb3Vyc2UuZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNvdXJzZS1jYXJkLW1ldGFcIj5cclxuICAgICAgICAgIDxDbG9jayBzaXplPXsxNH0gLz4ge2NvdXJzZS5lc3RpbWF0ZWRNaW51dGVzfSBtaW5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAge3N0YXJ0ZWQgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtY2FyZC1wcm9ncmVzc1wiIGFyaWEtbGFiZWw9e2Ake3Byb2dyZXNzUGN0fSUgY29tcGxldGVgfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtY2FyZC1wcm9ncmVzcy10cmFja1wiPlxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGNvdXJzZS1jYXJkLXByb2dyZXNzLWZpbGwke2NvbXBsZXRlZCA/ICcgY291cnNlLWNhcmQtcHJvZ3Jlc3MtZmlsbC1kb25lJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cHJvZ3Jlc3NQY3R9JWAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY291cnNlLWNhcmQtcHJvZ3Jlc3MtbGFiZWxcIj5cclxuICAgICAgICAgICAgICB7Y29tcGxldGVkID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBzaXplPXsxM30gLz4gQ29tcGxldGVkXHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgYCR7cHJvZ3Jlc3NQY3R9JSBjb21wbGV0ZWBcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvYT5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDb3Vyc2VDYXJkU2tlbGV0b24oKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY291cnNlLWNhcmQgY291cnNlLWNhcmQtc2tlbGV0b25cIj5cclxuICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImNvdXJzZS1jYXJkLXRodW1iLXNrZWxldG9uXCIgaGVpZ2h0PVwiNi41cmVtXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtY2FyZC1ib2R5XCI+XHJcbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiNjAlXCIgaGVpZ2h0PVwiMS4xcmVtXCIgLz5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCI5MCVcIiBoZWlnaHQ9XCIwLjg1cmVtXCIgLz5cclxuICAgICAgICA8U2tlbGV0b24gd2lkdGg9XCI0MCVcIiBoZWlnaHQ9XCIwLjg1cmVtXCIgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19