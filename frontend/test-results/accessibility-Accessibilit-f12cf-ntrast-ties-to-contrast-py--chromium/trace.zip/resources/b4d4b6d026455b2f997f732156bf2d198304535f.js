import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/PublicOnlyRoute.jsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3afdbed5";
import { useAuth } from "/src/features/auth/AuthContext.jsx";
import { createLogger } from "/src/utils/logger.js";
import { Skeleton } from "/src/components/Skeleton.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/PublicOnlyRoute.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const log = createLogger("route");
/**
* Opposite of ProtectedRoute: for pages that only make sense when logged OUT
* (login, register). A logged-in user who opens them is sent to the home page.
*   <Route path="/login" element={<PublicOnlyRoute><LoginPage /></PublicOnlyRoute>} />
*/
export function PublicOnlyRoute({ children }) {
	_s();
	const { isAuthenticated, isLoading } = useAuth();
	useEffect(() => {
		if (!isLoading && isAuthenticated) log.info("PublicOnlyRoute: already logged in -> /");
	}, [isLoading, isAuthenticated]);
	// Wait for the initial GET /auth/me before deciding (same reason as ProtectedRoute).
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("section", {
			className: "page skeleton-block",
			"aria-busy": "true",
			"aria-label": "Loading",
			children: [
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "50%",
					height: "1.75em"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "100%",
					height: "2.4rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "100%",
					height: "2.4rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Skeleton, {
					width: "8rem",
					height: "2.4rem"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this);
	}
	if (isAuthenticated) return /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 31
	}, this);
	return children;
}
_s(PublicOnlyRoute, "Welk9fbFNINSfytYxhp3k8pzvRM=", false, function() {
	return [useAuth];
});
_c = PublicOnlyRoute;
var _c;
$RefreshReg$(_c, "PublicOnlyRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/PublicOnlyRoute.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/PublicOnlyRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/auth/PublicOnlyRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/auth/PublicOnlyRoute.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsZ0JBQWdCOzs7O0FBRXpCLE1BQU0sTUFBTSxhQUFhLE9BQU87Ozs7OztBQU9oQyxPQUFPLFNBQVMsZ0JBQWdCLEVBQUUsWUFBWTs7Q0FDNUMsTUFBTSxFQUFFLGlCQUFpQixjQUFjLFFBQVE7Q0FFL0MsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLGFBQWEsaUJBQWlCLElBQUksS0FBSyx5Q0FBeUM7Q0FDdkYsR0FBRyxDQUFDLFdBQVcsZUFBZSxDQUFDOztDQUcvQixJQUFJLFdBQVc7RUFDYixPQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO0dBQXNCLGFBQVU7R0FBTyxjQUFXO2FBQXJFO0lBQ0Usd0JBQUMsVUFBRDtLQUFVLE9BQU07S0FBTSxRQUFPO0lBQVU7Ozs7O0lBQ3ZDLHdCQUFDLFVBQUQ7S0FBVSxPQUFNO0tBQU8sUUFBTztJQUFVOzs7OztJQUN4Qyx3QkFBQyxVQUFEO0tBQVUsT0FBTTtLQUFPLFFBQU87SUFBVTs7Ozs7SUFDeEMsd0JBQUMsVUFBRDtLQUFVLE9BQU07S0FBTyxRQUFPO0lBQVU7Ozs7O0dBQ2pDOzs7Ozs7Q0FFYjtDQUVBLElBQUksaUJBQWlCLE9BQU8sd0JBQUMsVUFBRDtFQUFVLElBQUc7RUFBSTtDQUFTOzs7OztDQUV0RCxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHVibGljT25seVJvdXRlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9BdXRoQ29udGV4dCdcclxuaW1wb3J0IHsgY3JlYXRlTG9nZ2VyIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2VyJ1xyXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJy4uLy4uL2NvbXBvbmVudHMvU2tlbGV0b24nXHJcblxyXG5jb25zdCBsb2cgPSBjcmVhdGVMb2dnZXIoJ3JvdXRlJylcclxuXHJcbi8qKlxyXG4gKiBPcHBvc2l0ZSBvZiBQcm90ZWN0ZWRSb3V0ZTogZm9yIHBhZ2VzIHRoYXQgb25seSBtYWtlIHNlbnNlIHdoZW4gbG9nZ2VkIE9VVFxyXG4gKiAobG9naW4sIHJlZ2lzdGVyKS4gQSBsb2dnZWQtaW4gdXNlciB3aG8gb3BlbnMgdGhlbSBpcyBzZW50IHRvIHRoZSBob21lIHBhZ2UuXHJcbiAqICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8UHVibGljT25seVJvdXRlPjxMb2dpblBhZ2UgLz48L1B1YmxpY09ubHlSb3V0ZT59IC8+XHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gUHVibGljT25seVJvdXRlKHsgY2hpbGRyZW4gfSkge1xyXG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCBpc0xvYWRpbmcgfSA9IHVzZUF1dGgoKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFpc0xvYWRpbmcgJiYgaXNBdXRoZW50aWNhdGVkKSBsb2cuaW5mbygnUHVibGljT25seVJvdXRlOiBhbHJlYWR5IGxvZ2dlZCBpbiAtPiAvJylcclxuICB9LCBbaXNMb2FkaW5nLCBpc0F1dGhlbnRpY2F0ZWRdKVxyXG5cclxuICAvLyBXYWl0IGZvciB0aGUgaW5pdGlhbCBHRVQgL2F1dGgvbWUgYmVmb3JlIGRlY2lkaW5nIChzYW1lIHJlYXNvbiBhcyBQcm90ZWN0ZWRSb3V0ZSkuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFnZSBza2VsZXRvbi1ibG9ja1wiIGFyaWEtYnVzeT1cInRydWVcIiBhcmlhLWxhYmVsPVwiTG9hZGluZ1wiPlxyXG4gICAgICAgIDxTa2VsZXRvbiB3aWR0aD1cIjUwJVwiIGhlaWdodD1cIjEuNzVlbVwiIC8+XHJcbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjIuNHJlbVwiIC8+XHJcbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjIuNHJlbVwiIC8+XHJcbiAgICAgICAgPFNrZWxldG9uIHdpZHRoPVwiOHJlbVwiIGhlaWdodD1cIjIuNHJlbVwiIC8+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIGlmIChpc0F1dGhlbnRpY2F0ZWQpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvXCIgcmVwbGFjZSAvPlxyXG5cclxuICByZXR1cm4gY2hpbGRyZW5cclxufVxyXG4iXX0=