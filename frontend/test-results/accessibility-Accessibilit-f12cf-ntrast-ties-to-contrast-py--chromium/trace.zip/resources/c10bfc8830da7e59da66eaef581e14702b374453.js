import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AccountPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { Lock, Palette } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { ChangePasswordForm } from "/src/features/auth/ChangePasswordForm.jsx";
import { MfaSettings } from "/src/features/auth/MfaSettings.jsx?t=1790183762308";
import { AccentColorPicker } from "/src/components/settings/AccentColorPicker.jsx";
import { SettingsNav } from "/src/components/settings/SettingsNav.jsx";
import { authApi } from "/src/features/auth/authApi.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/AccountPage.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
// Two-pane settings layout: a left-hand menu (SettingsNav) grouping every
// setting under its category, and a right-hand detail pane that shows just
// the title, description, and content of whichever single setting is
// active — no accordion, one setting on screen at a time. Adding a new
// setting is: one more entry in the right group's `items`.
function buildGroups(mfaEnabled) {
	return [{
		id: "security",
		icon: Lock,
		label: "Security",
		items: [{
			id: "password",
			label: "Password",
			description: "Change your account password",
			Content: ChangePasswordForm
		}, {
			id: "mfa",
			label: "Two-factor authentication",
			description: "Require a code from an authenticator app when signing in",
			badgeLoading: mfaEnabled === null,
			badge: mfaEnabled === null ? undefined : mfaEnabled ? "On" : "Off",
			Content: MfaSettings
		}]
	}, {
		id: "appearance",
		icon: Palette,
		label: "Appearance",
		items: [{
			id: "accent-color",
			label: "Accent color",
			description: "Pick the color used for buttons and links",
			Content: AccentColorPicker
		}]
	}];
}
export function AccountPage() {
	_s();
	const [mfaEnabled, setMfaEnabled] = useState(null);
	const [activeItemId, setActiveItemId] = useState("password");
	useEffect(() => {
		authApi.getMfaStatus().then((res) => setMfaEnabled(res.enabled)).catch(() => setMfaEnabled(false));
	}, []);
	const groups = buildGroups(mfaEnabled);
	const allItems = groups.flatMap((group) => group.items);
	const activeItem = allItems.find((item) => item.id === activeItemId) ?? allItems[0];
	const ActiveContent = activeItem.Content;
	// MfaSettings needs to report status changes back up so the nav badge
	// doesn't go stale after enabling/disabling without a page reload — every
	// other setting is a plain, prop-less component.
	const activeContentProps = activeItem.id === "mfa" ? { onStatusChange: setMfaEnabled } : {};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "settings-page",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: "Settings" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "settings-page-subtitle",
				children: "Manage your account, security, and preferences."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "settings-layout",
				children: [/* @__PURE__ */ _jsxDEV(SettingsNav, {
					groups,
					activeItemId,
					onSelect: setActiveItemId
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "settings-detail content-card",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "settings-detail-header",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: activeItem.label }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "settings-detail-description",
							children: activeItem.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(ActiveContent, { ...activeContentProps }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 5
	}, this);
}
_s(AccountPage, "1toRyohbnnpKPyzzRidBGn0pVYg=");
_c = AccountPage;
var _c;
$RefreshReg$(_c, "AccountPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/AccountPage.jsx?t=1790183762308";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/AccountPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/AccountPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/AccountPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLE1BQU0sZUFBZTtBQUM5QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGVBQWU7Ozs7Ozs7OztBQU94QixTQUFTLFlBQVksWUFBWTtDQUMvQixPQUFPLENBQ0w7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxPQUFPLENBQ0w7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLGFBQWE7R0FDYixTQUFTO0VBQ1gsR0FDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsYUFBYTtHQUNiLGNBQWMsZUFBZTtHQUM3QixPQUFPLGVBQWUsT0FBTyxZQUFZLGFBQWEsT0FBTztHQUM3RCxTQUFTO0VBQ1gsQ0FDRjtDQUNGLEdBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxPQUFPLENBQ0w7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLGFBQWE7R0FDYixTQUFTO0VBQ1gsQ0FDRjtDQUNGLENBQ0Y7QUFDRjtBQUVBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxJQUFJO0NBQ2pELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLFVBQVU7Q0FFM0QsZ0JBQWdCO0VBQ2QsUUFDRyxhQUFhLENBQUMsQ0FDZCxNQUFNLFFBQVEsY0FBYyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQ3pDLFlBQVksY0FBYyxLQUFLLENBQUM7Q0FDckMsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFNBQVMsWUFBWSxVQUFVO0NBQ3JDLE1BQU0sV0FBVyxPQUFPLFNBQVMsVUFBVSxNQUFNLEtBQUs7Q0FDdEQsTUFBTSxhQUFhLFNBQVMsTUFBTSxTQUFTLEtBQUssT0FBTyxZQUFZLEtBQUssU0FBUztDQUNqRixNQUFNLGdCQUFnQixXQUFXOzs7O0NBSWpDLE1BQU0scUJBQXFCLFdBQVcsT0FBTyxRQUFRLEVBQUUsZ0JBQWdCLGNBQWMsSUFBSSxDQUFDO0NBRTFGLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFELFlBQUksV0FBWTs7Ozs7R0FDaEIsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBeUI7R0FBa0Q7Ozs7O0dBRXhGLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxhQUFEO0tBQXFCO0tBQXNCO0tBQWMsVUFBVTtJQUFrQjs7OztjQUVyRix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUssV0FBVyxNQUFVOzs7O2dCQUMxQix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBK0IsV0FBVztNQUFlOzs7O2NBQ25FOzs7OztlQUVMLHdCQUFDLGVBQUQsRUFBZSxHQUFJLG1CQUFxQjs7OzthQUNyQzs7Ozs7WUFDRjs7Ozs7O0VBQ0U7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFjY291bnRQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExvY2ssIFBhbGV0dGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IENoYW5nZVBhc3N3b3JkRm9ybSB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvQ2hhbmdlUGFzc3dvcmRGb3JtJ1xyXG5pbXBvcnQgeyBNZmFTZXR0aW5ncyB9IGZyb20gJy4uL2ZlYXR1cmVzL2F1dGgvTWZhU2V0dGluZ3MnXHJcbmltcG9ydCB7IEFjY2VudENvbG9yUGlja2VyIH0gZnJvbSAnLi4vY29tcG9uZW50cy9zZXR0aW5ncy9BY2NlbnRDb2xvclBpY2tlcidcclxuaW1wb3J0IHsgU2V0dGluZ3NOYXYgfSBmcm9tICcuLi9jb21wb25lbnRzL3NldHRpbmdzL1NldHRpbmdzTmF2J1xyXG5pbXBvcnQgeyBhdXRoQXBpIH0gZnJvbSAnLi4vZmVhdHVyZXMvYXV0aC9hdXRoQXBpJ1xyXG5cclxuLy8gVHdvLXBhbmUgc2V0dGluZ3MgbGF5b3V0OiBhIGxlZnQtaGFuZCBtZW51IChTZXR0aW5nc05hdikgZ3JvdXBpbmcgZXZlcnlcclxuLy8gc2V0dGluZyB1bmRlciBpdHMgY2F0ZWdvcnksIGFuZCBhIHJpZ2h0LWhhbmQgZGV0YWlsIHBhbmUgdGhhdCBzaG93cyBqdXN0XHJcbi8vIHRoZSB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBjb250ZW50IG9mIHdoaWNoZXZlciBzaW5nbGUgc2V0dGluZyBpc1xyXG4vLyBhY3RpdmUg4oCUIG5vIGFjY29yZGlvbiwgb25lIHNldHRpbmcgb24gc2NyZWVuIGF0IGEgdGltZS4gQWRkaW5nIGEgbmV3XHJcbi8vIHNldHRpbmcgaXM6IG9uZSBtb3JlIGVudHJ5IGluIHRoZSByaWdodCBncm91cCdzIGBpdGVtc2AuXHJcbmZ1bmN0aW9uIGJ1aWxkR3JvdXBzKG1mYUVuYWJsZWQpIHtcclxuICByZXR1cm4gW1xyXG4gICAge1xyXG4gICAgICBpZDogJ3NlY3VyaXR5JyxcclxuICAgICAgaWNvbjogTG9jayxcclxuICAgICAgbGFiZWw6ICdTZWN1cml0eScsXHJcbiAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaWQ6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICBsYWJlbDogJ1Bhc3N3b3JkJyxcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnQ2hhbmdlIHlvdXIgYWNjb3VudCBwYXNzd29yZCcsXHJcbiAgICAgICAgICBDb250ZW50OiBDaGFuZ2VQYXNzd29yZEZvcm0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ21mYScsXHJcbiAgICAgICAgICBsYWJlbDogJ1R3by1mYWN0b3IgYXV0aGVudGljYXRpb24nLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246ICdSZXF1aXJlIGEgY29kZSBmcm9tIGFuIGF1dGhlbnRpY2F0b3IgYXBwIHdoZW4gc2lnbmluZyBpbicsXHJcbiAgICAgICAgICBiYWRnZUxvYWRpbmc6IG1mYUVuYWJsZWQgPT09IG51bGwsXHJcbiAgICAgICAgICBiYWRnZTogbWZhRW5hYmxlZCA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IG1mYUVuYWJsZWQgPyAnT24nIDogJ09mZicsXHJcbiAgICAgICAgICBDb250ZW50OiBNZmFTZXR0aW5ncyxcclxuICAgICAgICB9LFxyXG4gICAgICBdLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdhcHBlYXJhbmNlJyxcclxuICAgICAgaWNvbjogUGFsZXR0ZSxcclxuICAgICAgbGFiZWw6ICdBcHBlYXJhbmNlJyxcclxuICAgICAgaXRlbXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBpZDogJ2FjY2VudC1jb2xvcicsXHJcbiAgICAgICAgICBsYWJlbDogJ0FjY2VudCBjb2xvcicsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ1BpY2sgdGhlIGNvbG9yIHVzZWQgZm9yIGJ1dHRvbnMgYW5kIGxpbmtzJyxcclxuICAgICAgICAgIENvbnRlbnQ6IEFjY2VudENvbG9yUGlja2VyLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF0sXHJcbiAgICB9LFxyXG4gIF1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIEFjY291bnRQYWdlKCkge1xyXG4gIGNvbnN0IFttZmFFbmFibGVkLCBzZXRNZmFFbmFibGVkXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW2FjdGl2ZUl0ZW1JZCwgc2V0QWN0aXZlSXRlbUlkXSA9IHVzZVN0YXRlKCdwYXNzd29yZCcpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBhdXRoQXBpXHJcbiAgICAgIC5nZXRNZmFTdGF0dXMoKVxyXG4gICAgICAudGhlbigocmVzKSA9PiBzZXRNZmFFbmFibGVkKHJlcy5lbmFibGVkKSlcclxuICAgICAgLmNhdGNoKCgpID0+IHNldE1mYUVuYWJsZWQoZmFsc2UpKVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBncm91cHMgPSBidWlsZEdyb3VwcyhtZmFFbmFibGVkKVxyXG4gIGNvbnN0IGFsbEl0ZW1zID0gZ3JvdXBzLmZsYXRNYXAoKGdyb3VwKSA9PiBncm91cC5pdGVtcylcclxuICBjb25zdCBhY3RpdmVJdGVtID0gYWxsSXRlbXMuZmluZCgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gYWN0aXZlSXRlbUlkKSA/PyBhbGxJdGVtc1swXVxyXG4gIGNvbnN0IEFjdGl2ZUNvbnRlbnQgPSBhY3RpdmVJdGVtLkNvbnRlbnRcclxuICAvLyBNZmFTZXR0aW5ncyBuZWVkcyB0byByZXBvcnQgc3RhdHVzIGNoYW5nZXMgYmFjayB1cCBzbyB0aGUgbmF2IGJhZGdlXHJcbiAgLy8gZG9lc24ndCBnbyBzdGFsZSBhZnRlciBlbmFibGluZy9kaXNhYmxpbmcgd2l0aG91dCBhIHBhZ2UgcmVsb2FkIOKAlCBldmVyeVxyXG4gIC8vIG90aGVyIHNldHRpbmcgaXMgYSBwbGFpbiwgcHJvcC1sZXNzIGNvbXBvbmVudC5cclxuICBjb25zdCBhY3RpdmVDb250ZW50UHJvcHMgPSBhY3RpdmVJdGVtLmlkID09PSAnbWZhJyA/IHsgb25TdGF0dXNDaGFuZ2U6IHNldE1mYUVuYWJsZWQgfSA6IHt9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzZXR0aW5ncy1wYWdlXCI+XHJcbiAgICAgIDxoMT5TZXR0aW5nczwvaDE+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInNldHRpbmdzLXBhZ2Utc3VidGl0bGVcIj5NYW5hZ2UgeW91ciBhY2NvdW50LCBzZWN1cml0eSwgYW5kIHByZWZlcmVuY2VzLjwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2V0dGluZ3MtbGF5b3V0XCI+XHJcbiAgICAgICAgPFNldHRpbmdzTmF2IGdyb3Vwcz17Z3JvdXBzfSBhY3RpdmVJdGVtSWQ9e2FjdGl2ZUl0ZW1JZH0gb25TZWxlY3Q9e3NldEFjdGl2ZUl0ZW1JZH0gLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZXR0aW5ncy1kZXRhaWwgY29udGVudC1jYXJkXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNldHRpbmdzLWRldGFpbC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgPGgyPnthY3RpdmVJdGVtLmxhYmVsfTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInNldHRpbmdzLWRldGFpbC1kZXNjcmlwdGlvblwiPnthY3RpdmVJdGVtLmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxBY3RpdmVDb250ZW50IHsuLi5hY3RpdmVDb250ZW50UHJvcHN9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufVxyXG4iXX0=