import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/courses/Quiz.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { AnimatePresence, motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=7d918b77";
import { CheckCircle2, XCircle, RotateCcw, Lock, Timer, ArrowRight, ArrowLeft, CircleDashed, ScanSearch, Sparkles, Trophy, HeartHandshake } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { recordModuleQuizAttempt } from "/src/features/courses/progressStore.js";
import { PASSING_PCT, retakeCooldownMs, formatCooldown } from "/src/features/courses/progress.js";
import { playQuizStartCue, playQuizGradingTick, playQuizResultCue } from "/src/features/courses/quizSound.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/courses/Quiz.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
// Mock "grading" sequence shown between submit and result — pure theatre,
// no backend call, but it makes hitting "submit" feel like something is
// actually happening rather than an instant verdict. ~10s total.
const GRADING_STEPS = [
	{
		label: "Collecting your answers…",
		ms: 1600
	},
	{
		label: "Checking against the answer key…",
		ms: 2200
	},
	{
		label: "Scoring each question…",
		ms: 2200
	},
	{
		label: "Comparing to the passing bar…",
		ms: 2e3
	},
	{
		label: "Wrapping up your result…",
		ms: 2e3
	}
];
// Self-contained module QCM: owns its own answer/submitted state so a
// module can mount/unmount it freely (e.g. navigating away and back resets
// the attempt). Records each attempt to progressStore (best score kept)
// and throttles retakes to one per 10 minutes, per
// features/courses/progress.js rules.
//
// The cooldown gate has to hold even across a remount (navigating away and
// back, or a page reload) — it's keyed off the *stored* lastAttemptAt, not
// local "did I just submit in this session" state, otherwise a reload
// would trivially bypass it.
//
// Stage machine: intro -> active (one question at a time) -> grading (~10s
// mock scoring) -> submitted. Entering "active" plays a short chime and
// swaps in a dedicated quiz-mode backdrop (see .quiz-mode in index.css) so
// it's unmistakable the learner has left reading mode and is now being
// tested; entering "submitted" plays a score-shaped sound cue and, on a
// pass, a canvas-confetti burst — bigger for a perfect score.
// `previousAttempt` ({ score, total, lastAttemptAt } | undefined) is the
// learner's best attempt so far, if any — owned by the parent (which
// already fetched the whole course's progress) rather than fetched again
// here, since progress now lives on the backend, not synchronous
// localStorage.
export function Quiz({ quiz, courseId, moduleId, previousAttempt, onAttempt }) {
	_s();
	const [stage, setStage] = useState("intro");
	const [answers, setAnswers] = useState({});
	const [index, setIndex] = useState(0);
	const [cooldownMs, setCooldownMs] = useState(() => retakeCooldownMs(previousAttempt?.lastAttemptAt));
	// Tick the cooldown countdown once a second while it's active.
	useEffect(() => {
		if (cooldownMs <= 0) return undefined;
		const id = setInterval(() => {
			setCooldownMs((prev) => Math.max(0, prev - 1e3));
		}, 1e3);
		return () => clearInterval(id);
	}, [cooldownMs > 0]);
	const questions = quiz.questions;
	const total = questions.length;
	const allAnswered = questions.every((q) => answers[q.id]);
	const score = questions.reduce((sum, q) => answers[q.id] === q.correctOptionId ? sum + 1 : sum, 0);
	const pct = Math.round(score / total * 100);
	const passed = pct >= PASSING_PCT;
	const perfect = score === total;
	function startQuiz() {
		playQuizStartCue();
		setStage("active");
		setIndex(0);
	}
	function selectOption(questionId, optionId) {
		setAnswers((prev) => ({
			...prev,
			[questionId]: optionId
		}));
	}
	function submit() {
		setStage("grading");
	}
	async function finishGrading() {
		const attempt = await recordModuleQuizAttempt(courseId, moduleId, {
			score,
			total
		});
		setCooldownMs(retakeCooldownMs(attempt.lastAttemptAt));
		onAttempt?.({
			score,
			total,
			passed
		});
		playQuizResultCue(pct);
		if (passed) {
			const burst = perfect ? {
				particleCount: 160,
				spread: 100,
				startVelocity: 42,
				ticks: 220
			} : {
				particleCount: 90,
				spread: 75,
				startVelocity: 32,
				ticks: 180
			};
			confetti({
				...burst,
				origin: { y: .4 }
			});
		}
		setStage("submitted");
	}
	// Gated view: an attempt was made recently and the cooldown hasn't
	// elapsed yet — the learner can still re-read the chapter, just not
	// start a new attempt. Once cooldownMs reaches 0 this falls through to
	// the normal intro screen below.
	if (cooldownMs > 0 && stage !== "submitted") {
		const prevPassed = previousAttempt && previousAttempt.score / previousAttempt.total * 100 >= PASSING_PCT;
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "quiz",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "quiz-header",
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Check your understanding" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-subtitle",
					children: [
						total,
						" question",
						total === 1 ? "" : "s",
						" · pass with ",
						PASSING_PCT,
						"%+"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "quiz-cooldown-gate",
				children: [/* @__PURE__ */ _jsxDEV(Lock, { size: 20 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
					previousAttempt && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						"Last attempt: ",
						/* @__PURE__ */ _jsxDEV("strong", { children: previousAttempt.score }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 31
						}, this),
						"/",
						previousAttempt.total,
						" —",
						" ",
						prevPassed ? "passed." : "didn't pass.",
						" "
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 15
					}, this),
					"You can retake this quiz in ",
					/* @__PURE__ */ _jsxDEV("strong", { children: formatCooldown(cooldownMs) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 41
					}, this),
					". Good time to re-read the module above."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 7
		}, this);
	}
	if (stage === "intro") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "quiz",
			children: /* @__PURE__ */ _jsxDEV(motion.div, {
				className: "quiz-intro-card",
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "quiz-intro-eyebrow",
						children: [/* @__PURE__ */ _jsxDEV(Timer, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this), " Quiz mode"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Check your understanding" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "quiz-subtitle",
						children: [
							total,
							" question",
							total === 1 ? "" : "s",
							" · one at a time · pass with ",
							PASSING_PCT,
							"%+"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "quiz-start-button",
						onClick: startQuiz,
						children: "Start quiz"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 7
		}, this);
	}
	if (stage === "grading") {
		return /* @__PURE__ */ _jsxDEV(QuizGrading, { onDone: finishGrading }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 164,
			columnNumber: 12
		}, this);
	}
	if (stage === "submitted") {
		const ResultIcon = perfect ? Trophy : passed ? Sparkles : HeartHandshake;
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "quiz",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "quiz-header",
					children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Check your understanding" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "quiz-subtitle",
						children: [
							total,
							" question",
							total === 1 ? "" : "s",
							" · pass with ",
							PASSING_PCT,
							"%+"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(motion.div, {
					className: `quiz-result-hero ${passed ? "quiz-result-hero-pass" : "quiz-result-hero-fail"}`,
					initial: {
						opacity: 0,
						y: 10,
						scale: .95
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					transition: {
						type: "spring",
						stiffness: 280,
						damping: 18
					},
					children: [
						/* @__PURE__ */ _jsxDEV(motion.div, {
							className: "quiz-result-badge",
							initial: {
								scale: 0,
								rotate: -20
							},
							animate: {
								scale: 1,
								rotate: 0
							},
							transition: {
								type: "spring",
								stiffness: 320,
								damping: 12,
								delay: .1
							},
							children: /* @__PURE__ */ _jsxDEV(ResultIcon, { size: 30 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(motion.p, {
							className: "quiz-result-headline",
							initial: { opacity: 0 },
							animate: { opacity: 1 },
							transition: { delay: .2 },
							children: perfect ? "Perfect score!" : passed ? "Nice work — you passed!" : "Not quite — try again"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(motion.div, {
							className: "quiz-result-score",
							initial: { opacity: 0 },
							animate: { opacity: 1 },
							transition: { delay: .3 },
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "quiz-result-score-value",
									children: score
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "quiz-result-score-total",
									children: ["/", total]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "quiz-result-score-pct",
									children: [
										"(",
										pct,
										"%)"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "quiz-result-pct-track",
							children: /* @__PURE__ */ _jsxDEV(motion.div, {
								className: `quiz-result-pct-fill ${passed ? "" : "quiz-result-pct-fill-fail"}`,
								initial: { width: 0 },
								animate: { width: `${pct}%` },
								transition: {
									duration: .7,
									ease: "easeOut",
									delay: .15
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 178,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "quiz-summary",
					children: questions.map((question, i) => {
						const correct = answers[question.id] === question.correctOptionId;
						return /* @__PURE__ */ _jsxDEV(motion.div, {
							className: "quiz-summary-row",
							initial: {
								opacity: 0,
								x: -8
							},
							animate: {
								opacity: 1,
								x: 0
							},
							transition: { delay: .4 + i * .05 },
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: `quiz-summary-badge ${correct ? "quiz-summary-badge-correct" : "quiz-summary-badge-incorrect"}`,
								children: correct ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 30
								}, this) : /* @__PURE__ */ _jsxDEV(XCircle, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 59
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "quiz-summary-prompt",
								children: [
									i + 1,
									". ",
									question.prompt
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 17
							}, this)]
						}, question.id, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 9
				}, this),
				cooldownMs > 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-cooldown",
					children: [
						/* @__PURE__ */ _jsxDEV(Lock, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 13
						}, this),
						" Retry available in ",
						formatCooldown(cooldownMs)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 243,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => {
						setAnswers({});
						setStage("intro");
					},
					className: "quiz-retry",
					children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 13
					}, this), " Retry"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 247,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 7
		}, this);
	}
	// stage === 'active' — one question at a time, quiz-mode backdrop.
	const question = questions[index];
	const isLast = index === total - 1;
	const answeredCount = Object.keys(answers).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "quiz quiz-mode",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "quiz-header",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "quiz-intro-eyebrow",
					children: [/* @__PURE__ */ _jsxDEV(Timer, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 11
					}, this), " Quiz mode"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 270,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "quiz-subtitle",
					children: [
						"Question ",
						index + 1,
						" of ",
						total,
						" · ",
						answeredCount,
						"/",
						total,
						" answered"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 273,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 269,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "quiz-progress-dots",
				children: questions.map((q, i) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: [
						"quiz-dot",
						i === index ? "quiz-dot-active" : "",
						answers[q.id] ? "quiz-dot-answered" : ""
					].filter(Boolean).join(" "),
					onClick: () => setIndex(i),
					"aria-label": `Question ${i + 1}${answers[q.id] ? " (answered)" : ""}`
				}, q.id, false, {
					fileName: _jsxFileName,
					lineNumber: 280,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 278,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ _jsxDEV(motion.div, {
					className: "quiz-question-card",
					initial: {
						opacity: 0,
						x: 24
					},
					animate: {
						opacity: 1,
						x: 0
					},
					exit: {
						opacity: 0,
						x: -24
					},
					transition: {
						duration: .22,
						ease: "easeOut"
					},
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "quiz-question-prompt",
						children: question.prompt
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "quiz-options",
						children: question.options.map((option) => {
							const isSelected = answers[question.id] === option.id;
							return /* @__PURE__ */ _jsxDEV("label", {
								className: `quiz-option ${isSelected ? "quiz-option-selected" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: question.id,
									value: option.id,
									checked: isSelected,
									onChange: () => selectOption(question.id, option.id)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: option.text }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 321,
									columnNumber: 19
								}, this)]
							}, option.id, true, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 306,
						columnNumber: 11
					}, this)]
				}, question.id, true, {
					fileName: _jsxFileName,
					lineNumber: 297,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 296,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "quiz-nav",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "quiz-nav-button",
					disabled: index === 0,
					onClick: () => setIndex((i) => Math.max(0, i - 1)),
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 11
					}, this), " Previous"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 330,
					columnNumber: 9
				}, this), isLast ? /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					disabled: !allAnswered,
					onClick: submit,
					children: "Submit answers"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 339,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "quiz-nav-button quiz-nav-button-primary",
					onClick: () => setIndex((i) => Math.min(total - 1, i + 1)),
					children: ["Next ", /* @__PURE__ */ _jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 348,
						columnNumber: 18
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 343,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 329,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 268,
		columnNumber: 5
	}, this);
}
_s(Quiz, "I6HN5S0nJ0zanc1g9QtAVBG7n7g=");
_c = Quiz;
// ~10s mock grading sequence between "submit" and the result screen — a
// spinning scanner icon plus a step checklist, each step landing with a
// soft tick sound so the wait reads as "actively working" not "stalled".
function QuizGrading({ onDone }) {
	_s2();
	const [stepIndex, setStepIndex] = useState(0);
	const totalMs = useMemo(() => GRADING_STEPS.reduce((sum, s) => sum + s.ms, 0), []);
	useEffect(() => {
		const timeouts = [];
		let elapsed = 0;
		GRADING_STEPS.forEach((step, i) => {
			elapsed += step.ms;
			timeouts.push(setTimeout(() => {
				playQuizGradingTick();
				if (i === GRADING_STEPS.length - 1) {
					setTimeout(onDone, 300);
				} else {
					setStepIndex(i + 1);
				}
			}, elapsed));
		});
		return () => timeouts.forEach(clearTimeout);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "quiz quiz-mode",
		children: /* @__PURE__ */ _jsxDEV(motion.div, {
			className: "quiz-grading",
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			children: [
				/* @__PURE__ */ _jsxDEV(motion.div, {
					className: "quiz-grading-icon",
					animate: { rotate: 360 },
					transition: {
						duration: 1.6,
						repeat: Infinity,
						ease: "linear"
					},
					children: /* @__PURE__ */ _jsxDEV(ScanSearch, { size: 30 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 391,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 386,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", { children: "Grading your answers…" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 393,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "quiz-grading-track",
					children: /* @__PURE__ */ _jsxDEV(motion.div, {
						className: "quiz-grading-fill",
						animate: { width: `${(stepIndex + 1) / GRADING_STEPS.length * 100}%` },
						transition: {
							duration: (totalMs === 0 ? 0 : GRADING_STEPS[stepIndex]?.ms ?? 0) / 1e3,
							ease: "linear"
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 395,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 394,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("ul", {
					className: "quiz-grading-steps",
					children: GRADING_STEPS.map((step, i) => /* @__PURE__ */ _jsxDEV("li", {
						className: [
							"quiz-grading-step",
							i < stepIndex ? "quiz-grading-step-done" : "",
							i === stepIndex ? "quiz-grading-step-active" : ""
						].filter(Boolean).join(" "),
						children: [i < stepIndex ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 32
						}, this) : /* @__PURE__ */ _jsxDEV(CircleDashed, { size: 15 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 61
						}, this), step.label]
					}, step.label, true, {
						fileName: _jsxFileName,
						lineNumber: 403,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 401,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 385,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 384,
		columnNumber: 5
	}, this);
}
_s2(QuizGrading, "w6CIW+9t23vcwteMAVngXkRUTXk=");
_c2 = QuizGrading;
var _c, _c2;
$RefreshReg$(_c, "Quiz");
$RefreshReg$(_c2, "QuizGrading");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/courses/Quiz.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/courses/Quiz.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/courses/Quiz.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/courses/Quiz.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQVMsaUJBQWlCLGNBQWM7QUFDeEMsT0FBTyxjQUFjO0FBQ3JCLFNBQ0UsY0FDQSxTQUNBLFdBQ0EsTUFDQSxPQUNBLFlBQ0EsV0FDQSxjQUNBLFlBQ0EsVUFDQSxRQUNBLHNCQUNLO0FBQ1AsU0FBUywrQkFBK0I7QUFDeEMsU0FBUyxhQUFhLGtCQUFrQixzQkFBc0I7QUFDOUQsU0FBUyxrQkFBa0IscUJBQXFCLHlCQUF5Qjs7Ozs7OztBQUt6RSxNQUFNLGdCQUFnQjtDQUNwQjtFQUFFLE9BQU87RUFBNEIsSUFBSTtDQUFLO0NBQzlDO0VBQUUsT0FBTztFQUFvQyxJQUFJO0NBQUs7Q0FDdEQ7RUFBRSxPQUFPO0VBQTBCLElBQUk7Q0FBSztDQUM1QztFQUFFLE9BQU87RUFBaUMsSUFBSTtDQUFLO0NBQ25EO0VBQUUsT0FBTztFQUE0QixJQUFJO0NBQUs7QUFDaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBd0JBLE9BQU8sU0FBUyxLQUFLLEVBQUUsTUFBTSxVQUFVLFVBQVUsaUJBQWlCLGFBQWE7O0NBQzdFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxPQUFPO0NBQzFDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDLENBQUM7Q0FDekMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUM7Q0FDcEMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLGVBQWUsaUJBQWlCLGlCQUFpQixhQUFhLENBQUM7O0NBR25HLGdCQUFnQjtFQUNkLElBQUksY0FBYyxHQUFHLE9BQU87RUFDNUIsTUFBTSxLQUFLLGtCQUFrQjtHQUMzQixlQUFlLFNBQVMsS0FBSyxJQUFJLEdBQUcsT0FBTyxHQUFJLENBQUM7RUFDbEQsR0FBRyxHQUFJO0VBQ1AsYUFBYSxjQUFjLEVBQUU7Q0FDL0IsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0NBRW5CLE1BQU0sWUFBWSxLQUFLO0NBQ3ZCLE1BQU0sUUFBUSxVQUFVO0NBQ3hCLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxRQUFRLEVBQUUsR0FBRztDQUN4RCxNQUFNLFFBQVEsVUFBVSxRQUNyQixLQUFLLE1BQU8sUUFBUSxFQUFFLFFBQVEsRUFBRSxrQkFBa0IsTUFBTSxJQUFJLEtBQzdELENBQ0Y7Q0FDQSxNQUFNLE1BQU0sS0FBSyxNQUFPLFFBQVEsUUFBUyxHQUFHO0NBQzVDLE1BQU0sU0FBUyxPQUFPO0NBQ3RCLE1BQU0sVUFBVSxVQUFVO0NBRTFCLFNBQVMsWUFBWTtFQUNuQixpQkFBaUI7RUFDakIsU0FBUyxRQUFRO0VBQ2pCLFNBQVMsQ0FBQztDQUNaO0NBRUEsU0FBUyxhQUFhLFlBQVksVUFBVTtFQUMxQyxZQUFZLFVBQVU7R0FBRSxHQUFHO0lBQU8sYUFBYTtFQUFTLEVBQUU7Q0FDNUQ7Q0FFQSxTQUFTLFNBQVM7RUFDaEIsU0FBUyxTQUFTO0NBQ3BCO0NBRUEsZUFBZSxnQkFBZ0I7RUFDN0IsTUFBTSxVQUFVLE1BQU0sd0JBQXdCLFVBQVUsVUFBVTtHQUFFO0dBQU87RUFBTSxDQUFDO0VBQ2xGLGNBQWMsaUJBQWlCLFFBQVEsYUFBYSxDQUFDO0VBQ3JELFlBQVk7R0FBRTtHQUFPO0dBQU87RUFBTyxDQUFDO0VBQ3BDLGtCQUFrQixHQUFHO0VBQ3JCLElBQUksUUFBUTtHQUNWLE1BQU0sUUFBUSxVQUNWO0lBQUUsZUFBZTtJQUFLLFFBQVE7SUFBSyxlQUFlO0lBQUksT0FBTztHQUFJLElBQ2pFO0lBQUUsZUFBZTtJQUFJLFFBQVE7SUFBSSxlQUFlO0lBQUksT0FBTztHQUFJO0dBQ25FLFNBQVM7SUFBRSxHQUFHO0lBQU8sUUFBUSxFQUFFLEdBQUcsR0FBSTtHQUFFLENBQUM7RUFDM0M7RUFDQSxTQUFTLFdBQVc7Q0FDdEI7Ozs7O0NBTUEsSUFBSSxhQUFhLEtBQUssVUFBVSxhQUFhO0VBQzNDLE1BQU0sYUFBYSxtQkFBb0IsZ0JBQWdCLFFBQVEsZ0JBQWdCLFFBQVMsT0FBTztFQUMvRixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLDJCQUE0Qjs7OztjQUNoQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQ0c7TUFBTTtNQUFVLFVBQVUsSUFBSSxLQUFLO01BQUk7TUFBYztNQUFZO0tBQ2pFOzs7OztZQUNBOzs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2NBQ2pCLHdCQUFDLEtBQUQ7S0FDRyxtQkFDQztNQUFFO01BQ2Msd0JBQUMsVUFBRCxZQUFTLGdCQUFnQixNQUFjOzs7OztNQUFDO01BQUUsZ0JBQWdCO01BQU07TUFBRztNQUNoRixhQUFhLFlBQVk7TUFBZ0I7S0FDMUM7Ozs7O0tBQ0Y7S0FDMEIsd0JBQUMsVUFBRCxZQUFTLGVBQWUsVUFBVSxFQUFVOzs7OztLQUFDO0lBRXhFOzs7O1lBQ0E7Ozs7O1dBQ0Y7Ozs7OztDQUVUO0NBRUEsSUFBSSxVQUFVLFNBQVM7RUFDckIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQU8sS0FBUjtJQUNFLFdBQVU7SUFDVixTQUFTO0tBQUUsU0FBUztLQUFHLEdBQUc7SUFBRTtJQUM1QixTQUFTO0tBQUUsU0FBUztLQUFHLEdBQUc7SUFBRTtjQUg5QjtLQUtFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7Z0JBQUMsWUFDZjs7Ozs7O0tBQ04sd0JBQUMsTUFBRCxZQUFJLDJCQUE0Qjs7Ozs7S0FDaEMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FDRztPQUFNO09BQVUsVUFBVSxJQUFJLEtBQUs7T0FBSTtPQUE4QjtPQUFZO01BQ2pGOzs7Ozs7S0FDSCx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFdBQVU7TUFBb0IsU0FBUztnQkFBVztLQUVoRTs7Ozs7SUFDRTs7Ozs7O0VBQ1Q7Ozs7O0NBRVQ7Q0FFQSxJQUFJLFVBQVUsV0FBVztFQUN2QixPQUFPLHdCQUFDLGFBQUQsRUFBYSxRQUFRLGNBQWdCOzs7OztDQUM5QztDQUVBLElBQUksVUFBVSxhQUFhO0VBQ3pCLE1BQU0sYUFBYSxVQUFVLFNBQVMsU0FBUyxXQUFXO0VBQzFELE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksMkJBQTRCOzs7O2VBQ2hDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQ0c7T0FBTTtPQUFVLFVBQVUsSUFBSSxLQUFLO09BQUk7T0FBYztPQUFZO01BQ2pFOzs7OzthQUNBOzs7Ozs7SUFFTCx3QkFBQyxPQUFPLEtBQVI7S0FDRSxXQUFXLG9CQUFvQixTQUFTLDBCQUEwQjtLQUNsRSxTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7TUFBSSxPQUFPO0tBQUs7S0FDMUMsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO01BQUcsT0FBTztLQUFFO0tBQ3RDLFlBQVk7TUFBRSxNQUFNO01BQVUsV0FBVztNQUFLLFNBQVM7S0FBRztlQUo1RDtNQU1FLHdCQUFDLE9BQU8sS0FBUjtPQUNFLFdBQVU7T0FDVixTQUFTO1FBQUUsT0FBTztRQUFHLFFBQVEsQ0FBQztPQUFHO09BQ2pDLFNBQVM7UUFBRSxPQUFPO1FBQUcsUUFBUTtPQUFFO09BQy9CLFlBQVk7UUFBRSxNQUFNO1FBQVUsV0FBVztRQUFLLFNBQVM7UUFBSSxPQUFPO09BQUk7aUJBRXRFLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7O01BQ2I7Ozs7O01BQ1osd0JBQUMsT0FBTyxHQUFSO09BQ0UsV0FBVTtPQUNWLFNBQVMsRUFBRSxTQUFTLEVBQUU7T0FDdEIsU0FBUyxFQUFFLFNBQVMsRUFBRTtPQUN0QixZQUFZLEVBQUUsT0FBTyxHQUFJO2lCQUV4QixVQUFVLG1CQUFtQixTQUFTLDRCQUE0QjtNQUMzRDs7Ozs7TUFDVix3QkFBQyxPQUFPLEtBQVI7T0FDRSxXQUFVO09BQ1YsU0FBUyxFQUFFLFNBQVMsRUFBRTtPQUN0QixTQUFTLEVBQUUsU0FBUyxFQUFFO09BQ3RCLFlBQVksRUFBRSxPQUFPLEdBQUk7aUJBSjNCO1FBTUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCO1FBQVk7Ozs7O1FBQ3ZELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUEwQyxLQUFFLEtBQVk7Ozs7OztRQUN4RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFBd0M7VUFBRTtVQUFJO1NBQVE7Ozs7OztPQUM1Qzs7Ozs7O01BQ1osd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBTyxLQUFSO1FBQ0UsV0FBVyx3QkFBd0IsU0FBUyxLQUFLO1FBQ2pELFNBQVMsRUFBRSxPQUFPLEVBQUU7UUFDcEIsU0FBUyxFQUFFLE9BQU8sR0FBRyxJQUFJLEdBQUc7UUFDNUIsWUFBWTtTQUFFLFVBQVU7U0FBSyxNQUFNO1NBQVcsT0FBTztRQUFLO09BQzNEOzs7OztNQUNFOzs7OztLQUNLOzs7Ozs7SUFFWix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFVBQVUsS0FBSyxVQUFVLE1BQU07TUFDOUIsTUFBTSxVQUFVLFFBQVEsU0FBUyxRQUFRLFNBQVM7TUFDbEQsT0FDRSx3QkFBQyxPQUFPLEtBQVI7T0FFRSxXQUFVO09BQ1YsU0FBUztRQUFFLFNBQVM7UUFBRyxHQUFHLENBQUM7T0FBRTtPQUM3QixTQUFTO1FBQUUsU0FBUztRQUFHLEdBQUc7T0FBRTtPQUM1QixZQUFZLEVBQUUsT0FBTyxLQUFNLElBQUksSUFBSztpQkFMdEMsQ0FPRSx3QkFBQyxRQUFEO1FBQU0sV0FBVyxzQkFBc0IsVUFBVSwrQkFBK0I7a0JBQzdFLFVBQVUsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OzttQkFBSSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7OztPQUN4RDs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FDRyxJQUFJO1NBQUU7U0FBRyxTQUFTO1FBQ2Y7Ozs7O2VBQ0k7U0FaTCxTQUFTOzs7O2FBWUo7S0FFaEIsQ0FBQztJQUNFOzs7OztJQUVKLGFBQWEsSUFDWix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQ0Usd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7TUFBQztNQUFxQixlQUFlLFVBQVU7S0FDL0Q7Ozs7O2VBRUgsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlO01BQ2IsV0FBVyxDQUFDLENBQUM7TUFDYixTQUFTLE9BQU87S0FDbEI7S0FDQSxXQUFVO2VBTlosQ0FRRSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2VBQUMsUUFDakI7Ozs7OztHQUVQOzs7Ozs7Q0FFVDs7Q0FHQSxNQUFNLFdBQVcsVUFBVTtDQUMzQixNQUFNLFNBQVMsVUFBVSxRQUFRO0NBQ2pDLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQztDQUUzQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O2VBQUMsWUFDZjs7Ozs7Y0FDTix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQTZCO01BQ2pCLFFBQVE7TUFBRTtNQUFLO01BQU07TUFBSTtNQUFjO01BQUU7TUFBTTtLQUN4RDs7Ozs7WUFDQTs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixVQUFVLEtBQUssR0FBRyxNQUNqQix3QkFBQyxVQUFEO0tBRUUsTUFBSztLQUNMLFdBQVc7TUFDVDtNQUNBLE1BQU0sUUFBUSxvQkFBb0I7TUFDbEMsUUFBUSxFQUFFLE1BQU0sc0JBQXNCO0tBQ3hDLENBQUMsQ0FDRSxPQUFPLE9BQU8sQ0FBQyxDQUNmLEtBQUssR0FBRztLQUNYLGVBQWUsU0FBUyxDQUFDO0tBQ3pCLGNBQVksWUFBWSxJQUFJLElBQUksUUFBUSxFQUFFLE1BQU0sZ0JBQWdCO0lBQ2pFLEdBWE0sRUFBRTs7OztXQVdSLENBQ0Y7R0FDRTs7Ozs7R0FFTCx3QkFBQyxpQkFBRDtJQUFpQixNQUFLO2NBQ3BCLHdCQUFDLE9BQU8sS0FBUjtLQUVFLFdBQVU7S0FDVixTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7S0FBRztLQUM3QixTQUFTO01BQUUsU0FBUztNQUFHLEdBQUc7S0FBRTtLQUM1QixNQUFNO01BQUUsU0FBUztNQUFHLEdBQUcsQ0FBQztLQUFHO0tBQzNCLFlBQVk7TUFBRSxVQUFVO01BQU0sTUFBTTtLQUFVO2VBTmhELENBUUUsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXdCLFNBQVM7S0FBVzs7OztlQUMxRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixTQUFTLFFBQVEsS0FBSyxXQUFXO09BQ2hDLE1BQU0sYUFBYSxRQUFRLFNBQVMsUUFBUSxPQUFPO09BQ25ELE9BQ0Usd0JBQUMsU0FBRDtRQUVFLFdBQVcsZUFBZSxhQUFhLHlCQUF5QjtrQkFGbEUsQ0FJRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE1BQU0sU0FBUztTQUNmLE9BQU8sT0FBTztTQUNkLFNBQVM7U0FDVCxnQkFBZ0IsYUFBYSxTQUFTLElBQUksT0FBTyxFQUFFO1FBQ3BEOzs7O2tCQUNELHdCQUFDLFFBQUQsWUFBTyxPQUFPLEtBQVc7Ozs7Z0JBQ3BCO1VBWEEsT0FBTzs7OztjQVdQO01BRVgsQ0FBQztLQUNFOzs7O2FBQ0s7T0E1QkwsU0FBUzs7OztXQTRCSjtHQUNHOzs7OztHQUVqQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsVUFBVSxVQUFVO0tBQ3BCLGVBQWUsVUFBVSxNQUFNLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO2VBSm5ELENBTUUsd0JBQUMsV0FBRCxFQUFXLE1BQU0sR0FBSzs7OztlQUFDLFdBQ2pCOzs7OztjQUNQLFNBQ0Msd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVLENBQUM7S0FBYSxTQUFTO2VBQVE7SUFFdkQ7Ozs7ZUFFUix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixlQUFlLFVBQVUsTUFBTSxLQUFLLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDO2VBSDNELENBSUMsU0FDTSx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O2FBQ3RCOzs7OztZQUVQOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7Ozs7OztBQUtBLFNBQVMsWUFBWSxFQUFFLFVBQVU7O0NBQy9CLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLENBQUM7Q0FDNUMsTUFBTSxVQUFVLGNBQWMsY0FBYyxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0NBRWpGLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLElBQUksVUFBVTtFQUNkLGNBQWMsU0FBUyxNQUFNLE1BQU07R0FDakMsV0FBVyxLQUFLO0dBQ2hCLFNBQVMsS0FDUCxpQkFBaUI7SUFDZixvQkFBb0I7SUFDcEIsSUFBSSxNQUFNLGNBQWMsU0FBUyxHQUFHO0tBQ2xDLFdBQVcsUUFBUSxHQUFHO0lBQ3hCLE9BQU87S0FDTCxhQUFhLElBQUksQ0FBQztJQUNwQjtHQUNGLEdBQUcsT0FBTyxDQUNaO0VBQ0YsQ0FBQztFQUNELGFBQWEsU0FBUyxRQUFRLFlBQVk7O0NBRTVDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQU8sS0FBUjtHQUFZLFdBQVU7R0FBZSxTQUFTLEVBQUUsU0FBUyxFQUFFO0dBQUcsU0FBUyxFQUFFLFNBQVMsRUFBRTthQUFwRjtJQUNFLHdCQUFDLE9BQU8sS0FBUjtLQUNFLFdBQVU7S0FDVixTQUFTLEVBQUUsUUFBUSxJQUFJO0tBQ3ZCLFlBQVk7TUFBRSxVQUFVO01BQUssUUFBUTtNQUFVLE1BQU07S0FBUztlQUU5RCx3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztJQUNiOzs7OztJQUNaLHdCQUFDLE1BQUQsWUFBSSx3QkFBeUI7Ozs7O0lBQzdCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBTyxLQUFSO01BQ0UsV0FBVTtNQUNWLFNBQVMsRUFBRSxPQUFPLElBQUssWUFBWSxLQUFLLGNBQWMsU0FBVSxJQUFJLEdBQUc7TUFDdkUsWUFBWTtPQUFFLFdBQVcsWUFBWSxJQUFJLElBQUksY0FBYyxVQUFVLEVBQUUsTUFBTSxLQUFLO09BQU0sTUFBTTtNQUFTO0tBQ3hHOzs7OztJQUNFOzs7OztJQUNMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1gsY0FBYyxLQUFLLE1BQU0sTUFDeEIsd0JBQUMsTUFBRDtNQUVFLFdBQVc7T0FDVDtPQUNBLElBQUksWUFBWSwyQkFBMkI7T0FDM0MsTUFBTSxZQUFZLDZCQUE2QjtNQUNqRCxDQUFDLENBQ0UsT0FBTyxPQUFPLENBQUMsQ0FDZixLQUFLLEdBQUc7Z0JBUmIsQ0FVRyxJQUFJLFlBQVksd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztpQkFBSSx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2dCQUN0RSxLQUFLLEtBQ0o7UUFYRyxLQUFLOzs7O1lBV1IsQ0FDTDtJQUNDOzs7OztHQUNNOzs7Ozs7Q0FDVDs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJRdWl6LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEFuaW1hdGVQcmVzZW5jZSwgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0J1xyXG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJ1xyXG5pbXBvcnQge1xyXG4gIENoZWNrQ2lyY2xlMixcclxuICBYQ2lyY2xlLFxyXG4gIFJvdGF0ZUNjdyxcclxuICBMb2NrLFxyXG4gIFRpbWVyLFxyXG4gIEFycm93UmlnaHQsXHJcbiAgQXJyb3dMZWZ0LFxyXG4gIENpcmNsZURhc2hlZCxcclxuICBTY2FuU2VhcmNoLFxyXG4gIFNwYXJrbGVzLFxyXG4gIFRyb3BoeSxcclxuICBIZWFydEhhbmRzaGFrZSxcclxufSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IHJlY29yZE1vZHVsZVF1aXpBdHRlbXB0IH0gZnJvbSAnLi9wcm9ncmVzc1N0b3JlJ1xyXG5pbXBvcnQgeyBQQVNTSU5HX1BDVCwgcmV0YWtlQ29vbGRvd25NcywgZm9ybWF0Q29vbGRvd24gfSBmcm9tICcuL3Byb2dyZXNzJ1xyXG5pbXBvcnQgeyBwbGF5UXVpelN0YXJ0Q3VlLCBwbGF5UXVpekdyYWRpbmdUaWNrLCBwbGF5UXVpelJlc3VsdEN1ZSB9IGZyb20gJy4vcXVpelNvdW5kJ1xyXG5cclxuLy8gTW9jayBcImdyYWRpbmdcIiBzZXF1ZW5jZSBzaG93biBiZXR3ZWVuIHN1Ym1pdCBhbmQgcmVzdWx0IOKAlCBwdXJlIHRoZWF0cmUsXHJcbi8vIG5vIGJhY2tlbmQgY2FsbCwgYnV0IGl0IG1ha2VzIGhpdHRpbmcgXCJzdWJtaXRcIiBmZWVsIGxpa2Ugc29tZXRoaW5nIGlzXHJcbi8vIGFjdHVhbGx5IGhhcHBlbmluZyByYXRoZXIgdGhhbiBhbiBpbnN0YW50IHZlcmRpY3QuIH4xMHMgdG90YWwuXHJcbmNvbnN0IEdSQURJTkdfU1RFUFMgPSBbXHJcbiAgeyBsYWJlbDogJ0NvbGxlY3RpbmcgeW91ciBhbnN3ZXJz4oCmJywgbXM6IDE2MDAgfSxcclxuICB7IGxhYmVsOiAnQ2hlY2tpbmcgYWdhaW5zdCB0aGUgYW5zd2VyIGtleeKApicsIG1zOiAyMjAwIH0sXHJcbiAgeyBsYWJlbDogJ1Njb3JpbmcgZWFjaCBxdWVzdGlvbuKApicsIG1zOiAyMjAwIH0sXHJcbiAgeyBsYWJlbDogJ0NvbXBhcmluZyB0byB0aGUgcGFzc2luZyBiYXLigKYnLCBtczogMjAwMCB9LFxyXG4gIHsgbGFiZWw6ICdXcmFwcGluZyB1cCB5b3VyIHJlc3VsdOKApicsIG1zOiAyMDAwIH0sXHJcbl1cclxuXHJcbi8vIFNlbGYtY29udGFpbmVkIG1vZHVsZSBRQ006IG93bnMgaXRzIG93biBhbnN3ZXIvc3VibWl0dGVkIHN0YXRlIHNvIGFcclxuLy8gbW9kdWxlIGNhbiBtb3VudC91bm1vdW50IGl0IGZyZWVseSAoZS5nLiBuYXZpZ2F0aW5nIGF3YXkgYW5kIGJhY2sgcmVzZXRzXHJcbi8vIHRoZSBhdHRlbXB0KS4gUmVjb3JkcyBlYWNoIGF0dGVtcHQgdG8gcHJvZ3Jlc3NTdG9yZSAoYmVzdCBzY29yZSBrZXB0KVxyXG4vLyBhbmQgdGhyb3R0bGVzIHJldGFrZXMgdG8gb25lIHBlciAxMCBtaW51dGVzLCBwZXJcclxuLy8gZmVhdHVyZXMvY291cnNlcy9wcm9ncmVzcy5qcyBydWxlcy5cclxuLy9cclxuLy8gVGhlIGNvb2xkb3duIGdhdGUgaGFzIHRvIGhvbGQgZXZlbiBhY3Jvc3MgYSByZW1vdW50IChuYXZpZ2F0aW5nIGF3YXkgYW5kXHJcbi8vIGJhY2ssIG9yIGEgcGFnZSByZWxvYWQpIOKAlCBpdCdzIGtleWVkIG9mZiB0aGUgKnN0b3JlZCogbGFzdEF0dGVtcHRBdCwgbm90XHJcbi8vIGxvY2FsIFwiZGlkIEkganVzdCBzdWJtaXQgaW4gdGhpcyBzZXNzaW9uXCIgc3RhdGUsIG90aGVyd2lzZSBhIHJlbG9hZFxyXG4vLyB3b3VsZCB0cml2aWFsbHkgYnlwYXNzIGl0LlxyXG4vL1xyXG4vLyBTdGFnZSBtYWNoaW5lOiBpbnRybyAtPiBhY3RpdmUgKG9uZSBxdWVzdGlvbiBhdCBhIHRpbWUpIC0+IGdyYWRpbmcgKH4xMHNcclxuLy8gbW9jayBzY29yaW5nKSAtPiBzdWJtaXR0ZWQuIEVudGVyaW5nIFwiYWN0aXZlXCIgcGxheXMgYSBzaG9ydCBjaGltZSBhbmRcclxuLy8gc3dhcHMgaW4gYSBkZWRpY2F0ZWQgcXVpei1tb2RlIGJhY2tkcm9wIChzZWUgLnF1aXotbW9kZSBpbiBpbmRleC5jc3MpIHNvXHJcbi8vIGl0J3MgdW5taXN0YWthYmxlIHRoZSBsZWFybmVyIGhhcyBsZWZ0IHJlYWRpbmcgbW9kZSBhbmQgaXMgbm93IGJlaW5nXHJcbi8vIHRlc3RlZDsgZW50ZXJpbmcgXCJzdWJtaXR0ZWRcIiBwbGF5cyBhIHNjb3JlLXNoYXBlZCBzb3VuZCBjdWUgYW5kLCBvbiBhXHJcbi8vIHBhc3MsIGEgY2FudmFzLWNvbmZldHRpIGJ1cnN0IOKAlCBiaWdnZXIgZm9yIGEgcGVyZmVjdCBzY29yZS5cclxuLy8gYHByZXZpb3VzQXR0ZW1wdGAgKHsgc2NvcmUsIHRvdGFsLCBsYXN0QXR0ZW1wdEF0IH0gfCB1bmRlZmluZWQpIGlzIHRoZVxyXG4vLyBsZWFybmVyJ3MgYmVzdCBhdHRlbXB0IHNvIGZhciwgaWYgYW55IOKAlCBvd25lZCBieSB0aGUgcGFyZW50ICh3aGljaFxyXG4vLyBhbHJlYWR5IGZldGNoZWQgdGhlIHdob2xlIGNvdXJzZSdzIHByb2dyZXNzKSByYXRoZXIgdGhhbiBmZXRjaGVkIGFnYWluXHJcbi8vIGhlcmUsIHNpbmNlIHByb2dyZXNzIG5vdyBsaXZlcyBvbiB0aGUgYmFja2VuZCwgbm90IHN5bmNocm9ub3VzXHJcbi8vIGxvY2FsU3RvcmFnZS5cclxuZXhwb3J0IGZ1bmN0aW9uIFF1aXooeyBxdWl6LCBjb3Vyc2VJZCwgbW9kdWxlSWQsIHByZXZpb3VzQXR0ZW1wdCwgb25BdHRlbXB0IH0pIHtcclxuICBjb25zdCBbc3RhZ2UsIHNldFN0YWdlXSA9IHVzZVN0YXRlKCdpbnRybycpIC8vIGludHJvIHwgYWN0aXZlIHwgZ3JhZGluZyB8IHN1Ym1pdHRlZFxyXG4gIGNvbnN0IFthbnN3ZXJzLCBzZXRBbnN3ZXJzXSA9IHVzZVN0YXRlKHt9KVxyXG4gIGNvbnN0IFtpbmRleCwgc2V0SW5kZXhdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCBbY29vbGRvd25Ncywgc2V0Q29vbGRvd25Nc10gPSB1c2VTdGF0ZSgoKSA9PiByZXRha2VDb29sZG93bk1zKHByZXZpb3VzQXR0ZW1wdD8ubGFzdEF0dGVtcHRBdCkpXHJcblxyXG4gIC8vIFRpY2sgdGhlIGNvb2xkb3duIGNvdW50ZG93biBvbmNlIGEgc2Vjb25kIHdoaWxlIGl0J3MgYWN0aXZlLlxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoY29vbGRvd25NcyA8PSAwKSByZXR1cm4gdW5kZWZpbmVkXHJcbiAgICBjb25zdCBpZCA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgICAgc2V0Q29vbGRvd25NcygocHJldikgPT4gTWF0aC5tYXgoMCwgcHJldiAtIDEwMDApKVxyXG4gICAgfSwgMTAwMClcclxuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGlkKVxyXG4gIH0sIFtjb29sZG93bk1zID4gMF0pIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXHJcblxyXG4gIGNvbnN0IHF1ZXN0aW9ucyA9IHF1aXoucXVlc3Rpb25zXHJcbiAgY29uc3QgdG90YWwgPSBxdWVzdGlvbnMubGVuZ3RoXHJcbiAgY29uc3QgYWxsQW5zd2VyZWQgPSBxdWVzdGlvbnMuZXZlcnkoKHEpID0+IGFuc3dlcnNbcS5pZF0pXHJcbiAgY29uc3Qgc2NvcmUgPSBxdWVzdGlvbnMucmVkdWNlKFxyXG4gICAgKHN1bSwgcSkgPT4gKGFuc3dlcnNbcS5pZF0gPT09IHEuY29ycmVjdE9wdGlvbklkID8gc3VtICsgMSA6IHN1bSksXHJcbiAgICAwLFxyXG4gIClcclxuICBjb25zdCBwY3QgPSBNYXRoLnJvdW5kKChzY29yZSAvIHRvdGFsKSAqIDEwMClcclxuICBjb25zdCBwYXNzZWQgPSBwY3QgPj0gUEFTU0lOR19QQ1RcclxuICBjb25zdCBwZXJmZWN0ID0gc2NvcmUgPT09IHRvdGFsXHJcblxyXG4gIGZ1bmN0aW9uIHN0YXJ0UXVpeigpIHtcclxuICAgIHBsYXlRdWl6U3RhcnRDdWUoKVxyXG4gICAgc2V0U3RhZ2UoJ2FjdGl2ZScpXHJcbiAgICBzZXRJbmRleCgwKVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gc2VsZWN0T3B0aW9uKHF1ZXN0aW9uSWQsIG9wdGlvbklkKSB7XHJcbiAgICBzZXRBbnN3ZXJzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbcXVlc3Rpb25JZF06IG9wdGlvbklkIH0pKVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gc3VibWl0KCkge1xyXG4gICAgc2V0U3RhZ2UoJ2dyYWRpbmcnKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZmluaXNoR3JhZGluZygpIHtcclxuICAgIGNvbnN0IGF0dGVtcHQgPSBhd2FpdCByZWNvcmRNb2R1bGVRdWl6QXR0ZW1wdChjb3Vyc2VJZCwgbW9kdWxlSWQsIHsgc2NvcmUsIHRvdGFsIH0pXHJcbiAgICBzZXRDb29sZG93bk1zKHJldGFrZUNvb2xkb3duTXMoYXR0ZW1wdC5sYXN0QXR0ZW1wdEF0KSlcclxuICAgIG9uQXR0ZW1wdD8uKHsgc2NvcmUsIHRvdGFsLCBwYXNzZWQgfSlcclxuICAgIHBsYXlRdWl6UmVzdWx0Q3VlKHBjdClcclxuICAgIGlmIChwYXNzZWQpIHtcclxuICAgICAgY29uc3QgYnVyc3QgPSBwZXJmZWN0XHJcbiAgICAgICAgPyB7IHBhcnRpY2xlQ291bnQ6IDE2MCwgc3ByZWFkOiAxMDAsIHN0YXJ0VmVsb2NpdHk6IDQyLCB0aWNrczogMjIwIH1cclxuICAgICAgICA6IHsgcGFydGljbGVDb3VudDogOTAsIHNwcmVhZDogNzUsIHN0YXJ0VmVsb2NpdHk6IDMyLCB0aWNrczogMTgwIH1cclxuICAgICAgY29uZmV0dGkoeyAuLi5idXJzdCwgb3JpZ2luOiB7IHk6IDAuNCB9IH0pXHJcbiAgICB9XHJcbiAgICBzZXRTdGFnZSgnc3VibWl0dGVkJylcclxuICB9XHJcblxyXG4gIC8vIEdhdGVkIHZpZXc6IGFuIGF0dGVtcHQgd2FzIG1hZGUgcmVjZW50bHkgYW5kIHRoZSBjb29sZG93biBoYXNuJ3RcclxuICAvLyBlbGFwc2VkIHlldCDigJQgdGhlIGxlYXJuZXIgY2FuIHN0aWxsIHJlLXJlYWQgdGhlIGNoYXB0ZXIsIGp1c3Qgbm90XHJcbiAgLy8gc3RhcnQgYSBuZXcgYXR0ZW1wdC4gT25jZSBjb29sZG93bk1zIHJlYWNoZXMgMCB0aGlzIGZhbGxzIHRocm91Z2ggdG9cclxuICAvLyB0aGUgbm9ybWFsIGludHJvIHNjcmVlbiBiZWxvdy5cclxuICBpZiAoY29vbGRvd25NcyA+IDAgJiYgc3RhZ2UgIT09ICdzdWJtaXR0ZWQnKSB7XHJcbiAgICBjb25zdCBwcmV2UGFzc2VkID0gcHJldmlvdXNBdHRlbXB0ICYmIChwcmV2aW91c0F0dGVtcHQuc2NvcmUgLyBwcmV2aW91c0F0dGVtcHQudG90YWwpICogMTAwID49IFBBU1NJTkdfUENUXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXpcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXotaGVhZGVyXCI+XHJcbiAgICAgICAgICA8aDM+Q2hlY2sgeW91ciB1bmRlcnN0YW5kaW5nPC9oMz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInF1aXotc3VidGl0bGVcIj5cclxuICAgICAgICAgICAge3RvdGFsfSBxdWVzdGlvbnt0b3RhbCA9PT0gMSA/ICcnIDogJ3MnfSDCtyBwYXNzIHdpdGgge1BBU1NJTkdfUENUfSUrXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LWNvb2xkb3duLWdhdGVcIj5cclxuICAgICAgICAgIDxMb2NrIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIHtwcmV2aW91c0F0dGVtcHQgJiYgKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICBMYXN0IGF0dGVtcHQ6IDxzdHJvbmc+e3ByZXZpb3VzQXR0ZW1wdC5zY29yZX08L3N0cm9uZz4ve3ByZXZpb3VzQXR0ZW1wdC50b3RhbH0g4oCUeycgJ31cclxuICAgICAgICAgICAgICAgIHtwcmV2UGFzc2VkID8gJ3Bhc3NlZC4nIDogXCJkaWRuJ3QgcGFzcy5cIn17JyAnfVxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICBZb3UgY2FuIHJldGFrZSB0aGlzIHF1aXogaW4gPHN0cm9uZz57Zm9ybWF0Q29vbGRvd24oY29vbGRvd25Ncyl9PC9zdHJvbmc+LiBHb29kIHRpbWUgdG9cclxuICAgICAgICAgICAgcmUtcmVhZCB0aGUgbW9kdWxlIGFib3ZlLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIGlmIChzdGFnZSA9PT0gJ2ludHJvJykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6XCI+XHJcbiAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT1cInF1aXotaW50cm8tY2FyZFwiXHJcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDggfX1cclxuICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInF1aXotaW50cm8tZXllYnJvd1wiPlxyXG4gICAgICAgICAgICA8VGltZXIgc2l6ZT17MTR9IC8+IFF1aXogbW9kZVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPGgzPkNoZWNrIHlvdXIgdW5kZXJzdGFuZGluZzwvaDM+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJxdWl6LXN1YnRpdGxlXCI+XHJcbiAgICAgICAgICAgIHt0b3RhbH0gcXVlc3Rpb257dG90YWwgPT09IDEgPyAnJyA6ICdzJ30gwrcgb25lIGF0IGEgdGltZSDCtyBwYXNzIHdpdGgge1BBU1NJTkdfUENUfSUrXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJxdWl6LXN0YXJ0LWJ1dHRvblwiIG9uQ2xpY2s9e3N0YXJ0UXVpen0+XHJcbiAgICAgICAgICAgIFN0YXJ0IHF1aXpcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBpZiAoc3RhZ2UgPT09ICdncmFkaW5nJykge1xyXG4gICAgcmV0dXJuIDxRdWl6R3JhZGluZyBvbkRvbmU9e2ZpbmlzaEdyYWRpbmd9IC8+XHJcbiAgfVxyXG5cclxuICBpZiAoc3RhZ2UgPT09ICdzdWJtaXR0ZWQnKSB7XHJcbiAgICBjb25zdCBSZXN1bHRJY29uID0gcGVyZmVjdCA/IFRyb3BoeSA6IHBhc3NlZCA/IFNwYXJrbGVzIDogSGVhcnRIYW5kc2hha2VcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpelwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpei1oZWFkZXJcIj5cclxuICAgICAgICAgIDxoMz5DaGVjayB5b3VyIHVuZGVyc3RhbmRpbmc8L2gzPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicXVpei1zdWJ0aXRsZVwiPlxyXG4gICAgICAgICAgICB7dG90YWx9IHF1ZXN0aW9ue3RvdGFsID09PSAxID8gJycgOiAncyd9IMK3IHBhc3Mgd2l0aCB7UEFTU0lOR19QQ1R9JStcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgIGNsYXNzTmFtZT17YHF1aXotcmVzdWx0LWhlcm8gJHtwYXNzZWQgPyAncXVpei1yZXN1bHQtaGVyby1wYXNzJyA6ICdxdWl6LXJlc3VsdC1oZXJvLWZhaWwnfWB9XHJcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDEwLCBzY2FsZTogMC45NSB9fVxyXG4gICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwLCBzY2FsZTogMSB9fVxyXG4gICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgc3RpZmZuZXNzOiAyODAsIGRhbXBpbmc6IDE4IH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicXVpei1yZXN1bHQtYmFkZ2VcIlxyXG4gICAgICAgICAgICBpbml0aWFsPXt7IHNjYWxlOiAwLCByb3RhdGU6IC0yMCB9fVxyXG4gICAgICAgICAgICBhbmltYXRlPXt7IHNjYWxlOiAxLCByb3RhdGU6IDAgfX1cclxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyB0eXBlOiAnc3ByaW5nJywgc3RpZmZuZXNzOiAzMjAsIGRhbXBpbmc6IDEyLCBkZWxheTogMC4xIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxSZXN1bHRJY29uIHNpemU9ezMwfSAvPlxyXG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgICAgPG1vdGlvbi5wXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInF1aXotcmVzdWx0LWhlYWRsaW5lXCJcclxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjIgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3BlcmZlY3QgPyAnUGVyZmVjdCBzY29yZSEnIDogcGFzc2VkID8gJ05pY2Ugd29yayDigJQgeW91IHBhc3NlZCEnIDogXCJOb3QgcXVpdGUg4oCUIHRyeSBhZ2FpblwifVxyXG4gICAgICAgICAgPC9tb3Rpb24ucD5cclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInF1aXotcmVzdWx0LXNjb3JlXCJcclxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjMgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicXVpei1yZXN1bHQtc2NvcmUtdmFsdWVcIj57c2NvcmV9PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxdWl6LXJlc3VsdC1zY29yZS10b3RhbFwiPi97dG90YWx9PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxdWl6LXJlc3VsdC1zY29yZS1wY3RcIj4oe3BjdH0lKTwvc3Bhbj5cclxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpei1yZXN1bHQtcGN0LXRyYWNrXCI+XHJcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcXVpei1yZXN1bHQtcGN0LWZpbGwgJHtwYXNzZWQgPyAnJyA6ICdxdWl6LXJlc3VsdC1wY3QtZmlsbC1mYWlsJ31gfVxyXG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgd2lkdGg6IDAgfX1cclxuICAgICAgICAgICAgICBhbmltYXRlPXt7IHdpZHRoOiBgJHtwY3R9JWAgfX1cclxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjcsIGVhc2U6ICdlYXNlT3V0JywgZGVsYXk6IDAuMTUgfX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbW90aW9uLmRpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LXN1bW1hcnlcIj5cclxuICAgICAgICAgIHtxdWVzdGlvbnMubWFwKChxdWVzdGlvbiwgaSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBjb3JyZWN0ID0gYW5zd2Vyc1txdWVzdGlvbi5pZF0gPT09IHF1ZXN0aW9uLmNvcnJlY3RPcHRpb25JZFxyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e3F1ZXN0aW9uLmlkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicXVpei1zdW1tYXJ5LXJvd1wiXHJcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHg6IC04IH19XHJcbiAgICAgICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHg6IDAgfX1cclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNCArIGkgKiAwLjA1IH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcXVpei1zdW1tYXJ5LWJhZGdlICR7Y29ycmVjdCA/ICdxdWl6LXN1bW1hcnktYmFkZ2UtY29ycmVjdCcgOiAncXVpei1zdW1tYXJ5LWJhZGdlLWluY29ycmVjdCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgIHtjb3JyZWN0ID8gPENoZWNrQ2lyY2xlMiBzaXplPXsxNH0gLz4gOiA8WENpcmNsZSBzaXplPXsxNH0gLz59XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxdWl6LXN1bW1hcnktcHJvbXB0XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpICsgMX0uIHtxdWVzdGlvbi5wcm9tcHR9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2Nvb2xkb3duTXMgPiAwID8gKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicXVpei1jb29sZG93blwiPlxyXG4gICAgICAgICAgICA8TG9jayBzaXplPXsxNH0gLz4gUmV0cnkgYXZhaWxhYmxlIGluIHtmb3JtYXRDb29sZG93bihjb29sZG93bk1zKX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldEFuc3dlcnMoe30pXHJcbiAgICAgICAgICAgICAgc2V0U3RhZ2UoJ2ludHJvJylcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicXVpei1yZXRyeVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxSb3RhdGVDY3cgc2l6ZT17MTR9IC8+IFJldHJ5XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIC8vIHN0YWdlID09PSAnYWN0aXZlJyDigJQgb25lIHF1ZXN0aW9uIGF0IGEgdGltZSwgcXVpei1tb2RlIGJhY2tkcm9wLlxyXG4gIGNvbnN0IHF1ZXN0aW9uID0gcXVlc3Rpb25zW2luZGV4XVxyXG4gIGNvbnN0IGlzTGFzdCA9IGluZGV4ID09PSB0b3RhbCAtIDFcclxuICBjb25zdCBhbnN3ZXJlZENvdW50ID0gT2JqZWN0LmtleXMoYW5zd2VycykubGVuZ3RoXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXogcXVpei1tb2RlXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpei1oZWFkZXJcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJxdWl6LWludHJvLWV5ZWJyb3dcIj5cclxuICAgICAgICAgIDxUaW1lciBzaXplPXsxNH0gLz4gUXVpeiBtb2RlXHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInF1aXotc3VidGl0bGVcIj5cclxuICAgICAgICAgIFF1ZXN0aW9uIHtpbmRleCArIDF9IG9mIHt0b3RhbH0gwrcge2Fuc3dlcmVkQ291bnR9L3t0b3RhbH0gYW5zd2VyZWRcclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LXByb2dyZXNzLWRvdHNcIj5cclxuICAgICAgICB7cXVlc3Rpb25zLm1hcCgocSwgaSkgPT4gKFxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9e3EuaWR9XHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e1tcclxuICAgICAgICAgICAgICAncXVpei1kb3QnLFxyXG4gICAgICAgICAgICAgIGkgPT09IGluZGV4ID8gJ3F1aXotZG90LWFjdGl2ZScgOiAnJyxcclxuICAgICAgICAgICAgICBhbnN3ZXJzW3EuaWRdID8gJ3F1aXotZG90LWFuc3dlcmVkJyA6ICcnLFxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxyXG4gICAgICAgICAgICAgIC5qb2luKCcgJyl9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEluZGV4KGkpfVxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtgUXVlc3Rpb24gJHtpICsgMX0ke2Fuc3dlcnNbcS5pZF0gPyAnIChhbnN3ZXJlZCknIDogJyd9YH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPEFuaW1hdGVQcmVzZW5jZSBtb2RlPVwid2FpdFwiPlxyXG4gICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICBrZXk9e3F1ZXN0aW9uLmlkfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicXVpei1xdWVzdGlvbi1jYXJkXCJcclxuICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogMjQgfX1cclxuICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeDogMCB9fVxyXG4gICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCB4OiAtMjQgfX1cclxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMjIsIGVhc2U6ICdlYXNlT3V0JyB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJxdWl6LXF1ZXN0aW9uLXByb21wdFwiPntxdWVzdGlvbi5wcm9tcHR9PC9oMz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicXVpei1vcHRpb25zXCI+XHJcbiAgICAgICAgICAgIHtxdWVzdGlvbi5vcHRpb25zLm1hcCgob3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGFuc3dlcnNbcXVlc3Rpb24uaWRdID09PSBvcHRpb24uaWRcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGtleT17b3B0aW9uLmlkfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BxdWl6LW9wdGlvbiAke2lzU2VsZWN0ZWQgPyAncXVpei1vcHRpb24tc2VsZWN0ZWQnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtxdWVzdGlvbi5pZH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b3B0aW9uLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNlbGVjdE9wdGlvbihxdWVzdGlvbi5pZCwgb3B0aW9uLmlkKX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+e29wdGlvbi50ZXh0fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInF1aXotbmF2XCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJxdWl6LW5hdi1idXR0b25cIlxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2luZGV4ID09PSAwfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5kZXgoKGkpID0+IE1hdGgubWF4KDAsIGkgLSAxKSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEFycm93TGVmdCBzaXplPXsxNn0gLz4gUHJldmlvdXNcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICB7aXNMYXN0ID8gKFxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9eyFhbGxBbnN3ZXJlZH0gb25DbGljaz17c3VibWl0fT5cclxuICAgICAgICAgICAgU3VibWl0IGFuc3dlcnNcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJxdWl6LW5hdi1idXR0b24gcXVpei1uYXYtYnV0dG9uLXByaW1hcnlcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbmRleCgoaSkgPT4gTWF0aC5taW4odG90YWwgLSAxLCBpICsgMSkpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBOZXh0IDxBcnJvd1JpZ2h0IHNpemU9ezE2fSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbi8vIH4xMHMgbW9jayBncmFkaW5nIHNlcXVlbmNlIGJldHdlZW4gXCJzdWJtaXRcIiBhbmQgdGhlIHJlc3VsdCBzY3JlZW4g4oCUIGFcclxuLy8gc3Bpbm5pbmcgc2Nhbm5lciBpY29uIHBsdXMgYSBzdGVwIGNoZWNrbGlzdCwgZWFjaCBzdGVwIGxhbmRpbmcgd2l0aCBhXHJcbi8vIHNvZnQgdGljayBzb3VuZCBzbyB0aGUgd2FpdCByZWFkcyBhcyBcImFjdGl2ZWx5IHdvcmtpbmdcIiBub3QgXCJzdGFsbGVkXCIuXHJcbmZ1bmN0aW9uIFF1aXpHcmFkaW5nKHsgb25Eb25lIH0pIHtcclxuICBjb25zdCBbc3RlcEluZGV4LCBzZXRTdGVwSW5kZXhdID0gdXNlU3RhdGUoMClcclxuICBjb25zdCB0b3RhbE1zID0gdXNlTWVtbygoKSA9PiBHUkFESU5HX1NURVBTLnJlZHVjZSgoc3VtLCBzKSA9PiBzdW0gKyBzLm1zLCAwKSwgW10pXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0aW1lb3V0cyA9IFtdXHJcbiAgICBsZXQgZWxhcHNlZCA9IDBcclxuICAgIEdSQURJTkdfU1RFUFMuZm9yRWFjaCgoc3RlcCwgaSkgPT4ge1xyXG4gICAgICBlbGFwc2VkICs9IHN0ZXAubXNcclxuICAgICAgdGltZW91dHMucHVzaChcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgIHBsYXlRdWl6R3JhZGluZ1RpY2soKVxyXG4gICAgICAgICAgaWYgKGkgPT09IEdSQURJTkdfU1RFUFMubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KG9uRG9uZSwgMzAwKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2V0U3RlcEluZGV4KGkgKyAxKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sIGVsYXBzZWQpLFxyXG4gICAgICApXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuICgpID0+IHRpbWVvdXRzLmZvckVhY2goY2xlYXJUaW1lb3V0KVxyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFtdKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6IHF1aXotbW9kZVwiPlxyXG4gICAgICA8bW90aW9uLmRpdiBjbGFzc05hbWU9XCJxdWl6LWdyYWRpbmdcIiBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX0gYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19PlxyXG4gICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJxdWl6LWdyYWRpbmctaWNvblwiXHJcbiAgICAgICAgICBhbmltYXRlPXt7IHJvdGF0ZTogMzYwIH19XHJcbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAxLjYsIHJlcGVhdDogSW5maW5pdHksIGVhc2U6ICdsaW5lYXInIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFNjYW5TZWFyY2ggc2l6ZT17MzB9IC8+XHJcbiAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgIDxoMz5HcmFkaW5nIHlvdXIgYW5zd2Vyc+KApjwvaDM+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJxdWl6LWdyYWRpbmctdHJhY2tcIj5cclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInF1aXotZ3JhZGluZy1maWxsXCJcclxuICAgICAgICAgICAgYW5pbWF0ZT17eyB3aWR0aDogYCR7KChzdGVwSW5kZXggKyAxKSAvIEdSQURJTkdfU1RFUFMubGVuZ3RoKSAqIDEwMH0lYCB9fVxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAodG90YWxNcyA9PT0gMCA/IDAgOiBHUkFESU5HX1NURVBTW3N0ZXBJbmRleF0/Lm1zID8/IDApIC8gMTAwMCwgZWFzZTogJ2xpbmVhcicgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cInF1aXotZ3JhZGluZy1zdGVwc1wiPlxyXG4gICAgICAgICAge0dSQURJTkdfU1RFUFMubWFwKChzdGVwLCBpKSA9PiAoXHJcbiAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgIGtleT17c3RlcC5sYWJlbH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e1tcclxuICAgICAgICAgICAgICAgICdxdWl6LWdyYWRpbmctc3RlcCcsXHJcbiAgICAgICAgICAgICAgICBpIDwgc3RlcEluZGV4ID8gJ3F1aXotZ3JhZGluZy1zdGVwLWRvbmUnIDogJycsXHJcbiAgICAgICAgICAgICAgICBpID09PSBzdGVwSW5kZXggPyAncXVpei1ncmFkaW5nLXN0ZXAtYWN0aXZlJyA6ICcnLFxyXG4gICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcclxuICAgICAgICAgICAgICAgIC5qb2luKCcgJyl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aSA8IHN0ZXBJbmRleCA/IDxDaGVja0NpcmNsZTIgc2l6ZT17MTV9IC8+IDogPENpcmNsZURhc2hlZCBzaXplPXsxNX0gLz59XHJcbiAgICAgICAgICAgICAge3N0ZXAubGFiZWx9XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L3VsPlxyXG4gICAgICA8L21vdGlvbi5kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19