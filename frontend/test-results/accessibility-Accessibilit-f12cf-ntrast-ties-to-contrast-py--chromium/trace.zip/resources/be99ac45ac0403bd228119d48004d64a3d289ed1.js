import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Skeleton.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/components/Skeleton.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
// Facebook-style placeholder shape: a shimmering block standing in for
// content that hasn't loaded yet. Compose several of these into the rough
// outline of the real content (see MfaSettings, ProtectedRoute) instead of
// showing a blank screen or a spinner.
export function Skeleton({ width, height = "1em", circle = false, className = "" }) {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `skeleton ${circle ? "skeleton-circle" : ""} ${className}`.trim(),
		style: {
			width,
			height
		},
		"aria-hidden": "true"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
}
_c = Skeleton;
var _c;
$RefreshReg$(_c, "Skeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Skeleton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/components/Skeleton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/components/Skeleton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/components/Skeleton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBSUEsT0FBTyxTQUFTLFNBQVMsRUFBRSxPQUFPLFNBQVMsT0FBTyxTQUFTLE9BQU8sWUFBWSxNQUFNO0NBQ2xGLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLFdBQVcsWUFBWSxTQUFTLG9CQUFvQixHQUFHLEdBQUcsWUFBWSxLQUFLO0VBQzNFLE9BQU87R0FBRTtHQUFPO0VBQU87RUFDdkIsZUFBWTtDQUNiOzs7OztBQUVMIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNrZWxldG9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBGYWNlYm9vay1zdHlsZSBwbGFjZWhvbGRlciBzaGFwZTogYSBzaGltbWVyaW5nIGJsb2NrIHN0YW5kaW5nIGluIGZvclxyXG4vLyBjb250ZW50IHRoYXQgaGFzbid0IGxvYWRlZCB5ZXQuIENvbXBvc2Ugc2V2ZXJhbCBvZiB0aGVzZSBpbnRvIHRoZSByb3VnaFxyXG4vLyBvdXRsaW5lIG9mIHRoZSByZWFsIGNvbnRlbnQgKHNlZSBNZmFTZXR0aW5ncywgUHJvdGVjdGVkUm91dGUpIGluc3RlYWQgb2ZcclxuLy8gc2hvd2luZyBhIGJsYW5rIHNjcmVlbiBvciBhIHNwaW5uZXIuXHJcbmV4cG9ydCBmdW5jdGlvbiBTa2VsZXRvbih7IHdpZHRoLCBoZWlnaHQgPSAnMWVtJywgY2lyY2xlID0gZmFsc2UsIGNsYXNzTmFtZSA9ICcnIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHNwYW5cclxuICAgICAgY2xhc3NOYW1lPXtgc2tlbGV0b24gJHtjaXJjbGUgPyAnc2tlbGV0b24tY2lyY2xlJyA6ICcnfSAke2NsYXNzTmFtZX1gLnRyaW0oKX1cclxuICAgICAgc3R5bGU9e3sgd2lkdGgsIGhlaWdodCB9fVxyXG4gICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxyXG4gICAgLz5cclxuICApXHJcbn1cclxuIl19