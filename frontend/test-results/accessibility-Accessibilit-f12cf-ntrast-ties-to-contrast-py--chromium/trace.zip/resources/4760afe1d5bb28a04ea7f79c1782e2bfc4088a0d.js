import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cms/SettingsTab.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { ThemeEditor } from "/src/features/theming/ThemeEditor.jsx";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/SettingsTab.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
/**
* Settings tab — course metadata (title/description/icon/status editing
* lives in the existing course-create/edit screens, out of this workspace's
* scope per the task brief) plus the theme panel. frontend/src/features/
* theming/ThemeEditor.jsx already exists (16-theming landed), so it's
* embedded directly here rather than left as a TODO.
*/
export function SettingsTab({ course }) {
	if (!course) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "cms-settings",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cms-content-header",
				children: /* @__PURE__ */ _jsxDEV("h3", { children: course.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "cms-hint",
				children: ["Slug: ", /* @__PURE__ */ _jsxDEV("code", { children: course.slug }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ThemeEditor, { courseId: course.id }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = SettingsTab;
var _c;
$RefreshReg$(_c, "SettingsTab");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cms/SettingsTab.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/SettingsTab.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/features/cms/SettingsTab.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/features/cms/SettingsTab.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7Ozs7Ozs7Ozs7QUFTNUIsT0FBTyxTQUFTLFlBQVksRUFBRSxVQUFVO0NBQ3RDLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FDcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxNQUFELFlBQUssT0FBTyxNQUFVOzs7OztHQUNuQjs7Ozs7R0FDTCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiLENBQXdCLFVBQ2hCLHdCQUFDLFFBQUQsWUFBTyxPQUFPLEtBQVc7Ozs7WUFDOUI7Ozs7OztHQUNILHdCQUFDLGFBQUQsRUFBYSxVQUFVLE9BQU8sR0FBSzs7Ozs7RUFDaEM7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNldHRpbmdzVGFiLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUaGVtZUVkaXRvciB9IGZyb20gJy4uL3RoZW1pbmcvVGhlbWVFZGl0b3InXG5cbi8qKlxuICogU2V0dGluZ3MgdGFiIOKAlCBjb3Vyc2UgbWV0YWRhdGEgKHRpdGxlL2Rlc2NyaXB0aW9uL2ljb24vc3RhdHVzIGVkaXRpbmdcbiAqIGxpdmVzIGluIHRoZSBleGlzdGluZyBjb3Vyc2UtY3JlYXRlL2VkaXQgc2NyZWVucywgb3V0IG9mIHRoaXMgd29ya3NwYWNlJ3NcbiAqIHNjb3BlIHBlciB0aGUgdGFzayBicmllZikgcGx1cyB0aGUgdGhlbWUgcGFuZWwuIGZyb250ZW5kL3NyYy9mZWF0dXJlcy9cbiAqIHRoZW1pbmcvVGhlbWVFZGl0b3IuanN4IGFscmVhZHkgZXhpc3RzICgxNi10aGVtaW5nIGxhbmRlZCksIHNvIGl0J3NcbiAqIGVtYmVkZGVkIGRpcmVjdGx5IGhlcmUgcmF0aGVyIHRoYW4gbGVmdCBhcyBhIFRPRE8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTZXR0aW5nc1RhYih7IGNvdXJzZSB9KSB7XG4gIGlmICghY291cnNlKSByZXR1cm4gbnVsbFxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY21zLXNldHRpbmdzXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNtcy1jb250ZW50LWhlYWRlclwiPlxuICAgICAgICA8aDM+e2NvdXJzZS50aXRsZX08L2gzPlxuICAgICAgPC9kaXY+XG4gICAgICA8cCBjbGFzc05hbWU9XCJjbXMtaGludFwiPlxuICAgICAgICBTbHVnOiA8Y29kZT57Y291cnNlLnNsdWd9PC9jb2RlPlxuICAgICAgPC9wPlxuICAgICAgPFRoZW1lRWRpdG9yIGNvdXJzZUlkPXtjb3Vyc2UuaWR9IC8+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==