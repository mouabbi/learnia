import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CoursesPage.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=572b8600";
import { motion } from "/node_modules/.vite/deps/motion_react.js?v=d3070477";
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=4f48d389";
import { coursesApi } from "/src/features/courses/coursesApi.js";
import { CourseCard, CourseCardSkeleton } from "/src/features/courses/CourseCard.jsx?t=1790187136361";
import { learningProgress } from "/src/features/courses/progress.js";
var _jsxFileName = "C:/Users/user/Desktop/Learnia/frontend/src/pages/CoursesPage.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=572b8600";
var _s = $RefreshSig$();
const FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "in-progress",
		label: "In progress"
	},
	{
		id: "not-started",
		label: "Not started"
	},
	{
		id: "completed",
		label: "Completed"
	}
];
// Course catalog — currently backed by mock data (see
// features/courses/mockCourses.js) standing in for the future course API.
export function CoursesPage() {
	_s();
	const [courses, setCourses] = useState(null);
	// Map of courseId -> completion percentage, fetched alongside the course
	// list so cards can show progress and the filter chips can work.
	const [progressByCourse, setProgressByCourse] = useState({});
	const [query, setQuery] = useState("");
	const [filter, setFilter] = useState("all");
	useEffect(() => {
		let cancelled = false;
		coursesApi.listCourses().then(async (data) => {
			if (cancelled) return;
			setCourses(data);
			const entries = await Promise.all(data.map(async (summary) => {
				const [course, progress] = await Promise.all([coursesApi.getCourse(summary.slug), coursesApi.getProgress(summary.id)]);
				const pct = learningProgress(course, progress.completedPageIds).pct;
				return [summary.id, pct];
			}));
			if (!cancelled) setProgressByCourse(Object.fromEntries(entries));
		}).catch((error) => {
			if (cancelled) return;
			console.error("Failed to load courses", error);
			setCourses([]);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const filtered = useMemo(() => {
		if (!courses) return [];
		const q = query.trim().toLowerCase();
		return courses.filter((course) => {
			const matchesQuery = !q || course.title.toLowerCase().includes(q) || course.description.toLowerCase().includes(q);
			if (!matchesQuery) return false;
			const pct = progressByCourse[course.id] ?? 0;
			if (filter === "in-progress") return pct > 0 && pct < 100;
			if (filter === "not-started") return pct === 0;
			if (filter === "completed") return pct >= 100;
			return true;
		});
	}, [
		courses,
		query,
		filter,
		progressByCourse
	]);
	return /* @__PURE__ */ _jsxDEV("section", { children: [
		/* @__PURE__ */ _jsxDEV("h1", { children: "Courses" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "hint",
			children: "Pick a course to start learning."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "courses-toolbar",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "courses-search",
				children: [/* @__PURE__ */ _jsxDEV(Search, {
					size: 16,
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					type: "search",
					placeholder: "Search courses…",
					value: query,
					onChange: (e) => setQuery(e.target.value),
					"aria-label": "Search courses"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "courses-filters",
				role: "group",
				"aria-label": "Filter by progress",
				children: FILTERS.map((f) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: `filter-chip ${filter === f.id ? "filter-chip-active" : ""}`,
					onClick: () => setFilter(f.id),
					children: f.label
				}, f.id, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "course-grid",
			children: [
				courses === null && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(CourseCardSkeleton, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 11
				}, this),
				courses !== null && filtered.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
					className: "hint courses-empty",
					children: "No courses match your search."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 11
				}, this),
				filtered.map((course, index) => /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { delay: index * .05 },
					children: /* @__PURE__ */ _jsxDEV(CourseCard, {
						course,
						progressPct: progressByCourse[course.id]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this)
				}, course.id, false, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 11
				}, this))
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 98,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 5
	}, this);
}
_s(CoursesPage, "TJRsDdukrLuU8AVUQvoKPsY4zl0=");
_c = CoursesPage;
var _c;
$RefreshReg$(_c, "CoursesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/CoursesPage.jsx?t=1790187136361";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/user/Desktop/Learnia/frontend/src/pages/CoursesPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/user/Desktop/Learnia/frontend/src/pages/CoursesPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/user/Desktop/Learnia/frontend/src/pages/CoursesPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzdDLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZLDBCQUEwQjtBQUMvQyxTQUFTLHdCQUF3Qjs7OztBQUVqQyxNQUFNLFVBQVU7Q0FDZDtFQUFFLElBQUk7RUFBTyxPQUFPO0NBQU07Q0FDMUI7RUFBRSxJQUFJO0VBQWUsT0FBTztDQUFjO0NBQzFDO0VBQUUsSUFBSTtFQUFlLE9BQU87Q0FBYztDQUMxQztFQUFFLElBQUk7RUFBYSxPQUFPO0NBQVk7QUFDeEM7OztBQUlBLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTs7O0NBRzNDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsQ0FBQyxDQUFDO0NBQzNELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBRTFDLGdCQUFnQjtFQUNkLElBQUksWUFBWTtFQUNoQixXQUFXLFlBQVksQ0FBQyxDQUFDLEtBQUssT0FBTyxTQUFTO0dBQzVDLElBQUksV0FBVztHQUNmLFdBQVcsSUFBSTtHQUVmLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFDNUIsS0FBSyxJQUFJLE9BQU8sWUFBWTtJQUMxQixNQUFNLENBQUMsUUFBUSxZQUFZLE1BQU0sUUFBUSxJQUFJLENBQzNDLFdBQVcsVUFBVSxRQUFRLElBQUksR0FDakMsV0FBVyxZQUFZLFFBQVEsRUFBRSxDQUNuQyxDQUFDO0lBQ0QsTUFBTSxNQUFNLGlCQUFpQixRQUFRLFNBQVMsZ0JBQWdCLENBQUMsQ0FBQztJQUNoRSxPQUFPLENBQUMsUUFBUSxJQUFJLEdBQUc7R0FDekIsQ0FBQyxDQUNIO0dBQ0EsSUFBSSxDQUFDLFdBQVcsb0JBQW9CLE9BQU8sWUFBWSxPQUFPLENBQUM7RUFDakUsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBQ2xCLElBQUksV0FBVztHQUNmLFFBQVEsTUFBTSwwQkFBMEIsS0FBSztHQUM3QyxXQUFXLENBQUMsQ0FBQztFQUNmLENBQUM7RUFDRCxhQUFhO0dBQ1gsWUFBWTtFQUNkO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLFdBQVcsY0FBYztFQUM3QixJQUFJLENBQUMsU0FBUyxPQUFPLENBQUM7RUFDdEIsTUFBTSxJQUFJLE1BQU0sS0FBSyxDQUFDLENBQUMsWUFBWTtFQUNuQyxPQUFPLFFBQVEsUUFBUSxXQUFXO0dBQ2hDLE1BQU0sZUFDSixDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLE9BQU8sWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7R0FDN0YsSUFBSSxDQUFDLGNBQWMsT0FBTztHQUUxQixNQUFNLE1BQU0saUJBQWlCLE9BQU8sT0FBTztHQUMzQyxJQUFJLFdBQVcsZUFBZSxPQUFPLE1BQU0sS0FBSyxNQUFNO0dBQ3RELElBQUksV0FBVyxlQUFlLE9BQU8sUUFBUTtHQUM3QyxJQUFJLFdBQVcsYUFBYSxPQUFPLE9BQU87R0FDMUMsT0FBTztFQUNULENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBUztFQUFPO0VBQVE7Q0FBZ0IsQ0FBQztDQUU3QyxPQUNFLHdCQUFDLFdBQUQ7RUFDRSx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7RUFDZix3QkFBQyxLQUFEO0dBQUcsV0FBVTthQUFPO0VBQW1DOzs7OztFQUV2RCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBUSxNQUFNO0tBQUksZUFBWTtJQUFROzs7O2NBQ3RDLHdCQUFDLFNBQUQ7S0FDRSxNQUFLO0tBQ0wsYUFBWTtLQUNaLE9BQU87S0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztLQUN4QyxjQUFXO0lBQ1o7Ozs7WUFDRTs7Ozs7YUFDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFrQixNQUFLO0lBQVEsY0FBVztjQUN0RCxRQUFRLEtBQUssTUFDWix3QkFBQyxVQUFEO0tBRUUsTUFBSztLQUNMLFdBQVcsZUFBZSxXQUFXLEVBQUUsS0FBSyx1QkFBdUI7S0FDbkUsZUFBZSxVQUFVLEVBQUUsRUFBRTtlQUU1QixFQUFFO0lBQ0csR0FORCxFQUFFOzs7O1dBTUQsQ0FDVDtHQUNFOzs7O1dBQ0Y7Ozs7OztFQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRyxZQUFZLFFBQ1gsZ0RBQ0Usd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7Y0FDckIsd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7WUFDckI7Ozs7O0lBR0gsWUFBWSxRQUFRLFNBQVMsV0FBVyxLQUN2Qyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFxQjtJQUFnQzs7Ozs7SUFHbkUsU0FBUyxLQUFLLFFBQVEsVUFDckIsd0JBQUMsT0FBTyxLQUFSO0tBRUUsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO0tBQUU7S0FDNUIsU0FBUztNQUFFLFNBQVM7TUFBRyxHQUFHO0tBQUU7S0FDNUIsWUFBWSxFQUFFLE9BQU8sUUFBUSxJQUFLO2VBRWxDLHdCQUFDLFlBQUQ7TUFBb0I7TUFBUSxhQUFhLGlCQUFpQixPQUFPO0tBQU07Ozs7O0lBQzdELEdBTkwsT0FBTzs7OztXQU1GLENBQ2I7R0FDRTs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ291cnNlc1BhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSAnbW90aW9uL3JlYWN0J1xyXG5pbXBvcnQgeyBTZWFyY2ggfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IGNvdXJzZXNBcGkgfSBmcm9tICcuLi9mZWF0dXJlcy9jb3Vyc2VzL2NvdXJzZXNBcGknXHJcbmltcG9ydCB7IENvdXJzZUNhcmQsIENvdXJzZUNhcmRTa2VsZXRvbiB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvQ291cnNlQ2FyZCdcclxuaW1wb3J0IHsgbGVhcm5pbmdQcm9ncmVzcyB9IGZyb20gJy4uL2ZlYXR1cmVzL2NvdXJzZXMvcHJvZ3Jlc3MnXHJcblxyXG5jb25zdCBGSUxURVJTID0gW1xyXG4gIHsgaWQ6ICdhbGwnLCBsYWJlbDogJ0FsbCcgfSxcclxuICB7IGlkOiAnaW4tcHJvZ3Jlc3MnLCBsYWJlbDogJ0luIHByb2dyZXNzJyB9LFxyXG4gIHsgaWQ6ICdub3Qtc3RhcnRlZCcsIGxhYmVsOiAnTm90IHN0YXJ0ZWQnIH0sXHJcbiAgeyBpZDogJ2NvbXBsZXRlZCcsIGxhYmVsOiAnQ29tcGxldGVkJyB9LFxyXG5dXHJcblxyXG4vLyBDb3Vyc2UgY2F0YWxvZyDigJQgY3VycmVudGx5IGJhY2tlZCBieSBtb2NrIGRhdGEgKHNlZVxyXG4vLyBmZWF0dXJlcy9jb3Vyc2VzL21vY2tDb3Vyc2VzLmpzKSBzdGFuZGluZyBpbiBmb3IgdGhlIGZ1dHVyZSBjb3Vyc2UgQVBJLlxyXG5leHBvcnQgZnVuY3Rpb24gQ291cnNlc1BhZ2UoKSB7XHJcbiAgY29uc3QgW2NvdXJzZXMsIHNldENvdXJzZXNdID0gdXNlU3RhdGUobnVsbClcclxuICAvLyBNYXAgb2YgY291cnNlSWQgLT4gY29tcGxldGlvbiBwZXJjZW50YWdlLCBmZXRjaGVkIGFsb25nc2lkZSB0aGUgY291cnNlXHJcbiAgLy8gbGlzdCBzbyBjYXJkcyBjYW4gc2hvdyBwcm9ncmVzcyBhbmQgdGhlIGZpbHRlciBjaGlwcyBjYW4gd29yay5cclxuICBjb25zdCBbcHJvZ3Jlc3NCeUNvdXJzZSwgc2V0UHJvZ3Jlc3NCeUNvdXJzZV0gPSB1c2VTdGF0ZSh7fSlcclxuICBjb25zdCBbcXVlcnksIHNldFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZSgnYWxsJylcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxyXG4gICAgY291cnNlc0FwaS5saXN0Q291cnNlcygpLnRoZW4oYXN5bmMgKGRhdGEpID0+IHtcclxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuXHJcbiAgICAgIHNldENvdXJzZXMoZGF0YSlcclxuXHJcbiAgICAgIGNvbnN0IGVudHJpZXMgPSBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgICBkYXRhLm1hcChhc3luYyAoc3VtbWFyeSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgW2NvdXJzZSwgcHJvZ3Jlc3NdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBjb3Vyc2VzQXBpLmdldENvdXJzZShzdW1tYXJ5LnNsdWcpLFxyXG4gICAgICAgICAgICBjb3Vyc2VzQXBpLmdldFByb2dyZXNzKHN1bW1hcnkuaWQpLFxyXG4gICAgICAgICAgXSlcclxuICAgICAgICAgIGNvbnN0IHBjdCA9IGxlYXJuaW5nUHJvZ3Jlc3MoY291cnNlLCBwcm9ncmVzcy5jb21wbGV0ZWRQYWdlSWRzKS5wY3RcclxuICAgICAgICAgIHJldHVybiBbc3VtbWFyeS5pZCwgcGN0XVxyXG4gICAgICAgIH0pLFxyXG4gICAgICApXHJcbiAgICAgIGlmICghY2FuY2VsbGVkKSBzZXRQcm9ncmVzc0J5Q291cnNlKE9iamVjdC5mcm9tRW50cmllcyhlbnRyaWVzKSlcclxuICAgIH0pLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm5cclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGxvYWQgY291cnNlcycsIGVycm9yKVxyXG4gICAgICBzZXRDb3Vyc2VzKFtdKVxyXG4gICAgfSlcclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIGNhbmNlbGxlZCA9IHRydWVcclxuICAgIH1cclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3QgZmlsdGVyZWQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghY291cnNlcykgcmV0dXJuIFtdXHJcbiAgICBjb25zdCBxID0gcXVlcnkudHJpbSgpLnRvTG93ZXJDYXNlKClcclxuICAgIHJldHVybiBjb3Vyc2VzLmZpbHRlcigoY291cnNlKSA9PiB7XHJcbiAgICAgIGNvbnN0IG1hdGNoZXNRdWVyeSA9XHJcbiAgICAgICAgIXEgfHwgY291cnNlLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHwgY291cnNlLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSlcclxuICAgICAgaWYgKCFtYXRjaGVzUXVlcnkpIHJldHVybiBmYWxzZVxyXG5cclxuICAgICAgY29uc3QgcGN0ID0gcHJvZ3Jlc3NCeUNvdXJzZVtjb3Vyc2UuaWRdID8/IDBcclxuICAgICAgaWYgKGZpbHRlciA9PT0gJ2luLXByb2dyZXNzJykgcmV0dXJuIHBjdCA+IDAgJiYgcGN0IDwgMTAwXHJcbiAgICAgIGlmIChmaWx0ZXIgPT09ICdub3Qtc3RhcnRlZCcpIHJldHVybiBwY3QgPT09IDBcclxuICAgICAgaWYgKGZpbHRlciA9PT0gJ2NvbXBsZXRlZCcpIHJldHVybiBwY3QgPj0gMTAwXHJcbiAgICAgIHJldHVybiB0cnVlXHJcbiAgICB9KVxyXG4gIH0sIFtjb3Vyc2VzLCBxdWVyeSwgZmlsdGVyLCBwcm9ncmVzc0J5Q291cnNlXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uPlxyXG4gICAgICA8aDE+Q291cnNlczwvaDE+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnRcIj5QaWNrIGEgY291cnNlIHRvIHN0YXJ0IGxlYXJuaW5nLjwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291cnNlcy10b29sYmFyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2VzLXNlYXJjaFwiPlxyXG4gICAgICAgICAgPFNlYXJjaCBzaXplPXsxNn0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggY291cnNlc+KAplwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2ggY291cnNlc1wiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY291cnNlcy1maWx0ZXJzXCIgcm9sZT1cImdyb3VwXCIgYXJpYS1sYWJlbD1cIkZpbHRlciBieSBwcm9ncmVzc1wiPlxyXG4gICAgICAgICAge0ZJTFRFUlMubWFwKChmKSA9PiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBrZXk9e2YuaWR9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmlsdGVyLWNoaXAgJHtmaWx0ZXIgPT09IGYuaWQgPyAnZmlsdGVyLWNoaXAtYWN0aXZlJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKGYuaWQpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2YubGFiZWx9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtZ3JpZFwiPlxyXG4gICAgICAgIHtjb3Vyc2VzID09PSBudWxsICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxDb3Vyc2VDYXJkU2tlbGV0b24gLz5cclxuICAgICAgICAgICAgPENvdXJzZUNhcmRTa2VsZXRvbiAvPlxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge2NvdXJzZXMgIT09IG51bGwgJiYgZmlsdGVyZWQubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhpbnQgY291cnNlcy1lbXB0eVwiPk5vIGNvdXJzZXMgbWF0Y2ggeW91ciBzZWFyY2guPC9wPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtmaWx0ZXJlZC5tYXAoKGNvdXJzZSwgaW5kZXgpID0+IChcclxuICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgIGtleT17Y291cnNlLmlkfVxyXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDggfX1cclxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IGluZGV4ICogMC4wNSB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8Q291cnNlQ2FyZCBjb3Vyc2U9e2NvdXJzZX0gcHJvZ3Jlc3NQY3Q9e3Byb2dyZXNzQnlDb3Vyc2VbY291cnNlLmlkXX0gLz5cclxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==